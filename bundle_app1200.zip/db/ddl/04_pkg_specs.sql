
  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_CORE_CHART_PKG" AS
  FUNCTION Suggest_Chart_Spec (
    p_context_query      IN CLOB,
    p_rows_json          IN CLOB,
    p_plan_json          IN CLOB,
    p_ctx                IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id             IN VARCHAR2,
    p_log_id             IN NUMBER,
    p_chat_id            IN NUMBER,
    p_endpoint           IN VARCHAR2,
    p_api_format         IN VARCHAR2,
    p_model_id           IN VARCHAR2,
    p_compartment_id     IN VARCHAR2,
    p_temperature        IN NUMBER,
    p_top_p              IN NUMBER,
    p_top_k              IN NUMBER,
    o_raw_response       OUT CLOB
  ) RETURN CLOB;
END CHATBOT_CORE_CHART_PKG;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_CORE_CHART_PKG" AS

  ---------------------------------------------------------------------------
  -- Helper: count top-level rows in RESULT_ROWS_JSON
  -- Assumes p_rows_json is a JSON array ( [ {...}, {...}, ... ] ).
  -- If parsing fails, returns 0 and we simply skip charting.
  ---------------------------------------------------------------------------
  FUNCTION get_row_count_from_json(p_rows_json IN CLOB) RETURN PLS_INTEGER IS
    l_arr       json_array_t;
    l_row_count PLS_INTEGER := 0;
  BEGIN
    IF p_rows_json IS NULL THEN
      RETURN 0;
    END IF;

    BEGIN
      l_arr := json_array_t.parse(p_rows_json);
      l_row_count := l_arr.get_size;
    EXCEPTION
      WHEN OTHERS THEN
        l_row_count := 0;
    END;

    RETURN l_row_count;
  END get_row_count_from_json;

  FUNCTION Suggest_Chart_Spec (
    p_context_query      IN CLOB,
    p_rows_json          IN CLOB,
    p_plan_json          IN CLOB,
    p_ctx                IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id             IN VARCHAR2,
    p_log_id             IN NUMBER,
    p_chat_id            IN NUMBER,
    p_endpoint           IN VARCHAR2,
    p_api_format         IN VARCHAR2,
    p_model_id           IN VARCHAR2,
    p_compartment_id     IN VARCHAR2,
    p_temperature        IN NUMBER,
    p_top_p              IN NUMBER,
    p_top_k              IN NUMBER,
    o_raw_response       OUT CLOB
  ) RETURN CLOB
  IS
    -- NEW: minimum rows for which we bother calling the chart LLM
    c_min_rows_for_chart CONSTANT PLS_INTEGER := 3;

    l_row_count    PLS_INTEGER := 0;
    l_chart_system CLOB;
    l_payload      CLOB;
    l_resp         CLOB;
    l_chart_json   CLOB;
    l_preview_tok  CLOB := NULL;

    v_generated_sql CLOB;
    v_tabledesc     CLOB;
    v_column_info   CLOB := NULL;
  BEGIN
    -------------------------------------------------------------------------
    -- 0) Row-count guard: if too few rows, skip the LLM entirely.
    -------------------------------------------------------------------------
    l_row_count := get_row_count_from_json(p_rows_json);

    IF l_row_count < c_min_rows_for_chart THEN
      CHATBOT_CORE_IO_PKG.log_any(
        p_ctx, 'CHART', 'INFO', p_req_id, p_log_id, p_chat_id,
        'Suggest_Chart_Spec: skipping chart LLM; only '
                      || NVL(TO_CHAR(l_row_count), '0')
                      || ' rows (< ' || c_min_rows_for_chart || ').', NULL
      );
      RETURN NULL;
    END IF;

    -------------------------------------------------------------------------
    -- 1) Load CHART_SYSTEM prompt
    -------------------------------------------------------------------------
    l_chart_system := CHATBOT_CORE_CTX_PARAMS_PKG.load_component(p_ctx, 'CHART_SYSTEM');

    -------------------------------------------------------------------------
    -- 2) Optional redaction of result rows (reuse your existing flag)
    -------------------------------------------------------------------------
    IF p_rows_json IS NOT NULL THEN
      DECLARE
        v_flag VARCHAR2(10) := CHATBOT_CORE_CTX_PARAMS_PKG.get_param_value(p_ctx, 'REDACTION_ENABLED');
        v_on   BOOLEAN      := (UPPER(TRIM(NVL(v_flag,'Y'))) <> 'N');
      BEGIN
        IF v_on THEN
          BEGIN
            l_preview_tok := CHATBOT_CORE_SQL_PKG.redact_preview_json(
                               p_ctx     => p_ctx,
                               p_log_id  => p_log_id,
                               p_preview => p_rows_json
                             );
          EXCEPTION
            WHEN OTHERS THEN
              l_preview_tok := NULL;
          END;
        END IF;
      END;
    END IF;

    -------------------------------------------------------------------------
    -- 3) Column info based on generated SQL and TABLE_DESCRIPTIONS
    -------------------------------------------------------------------------
    v_generated_sql := CHATBOT_CORE_SUMMARY_PKG.load_generated_sql(p_log_id);
    IF v_generated_sql IS NOT NULL THEN
      DECLARE
        v_td CLOB;
      BEGIN
        v_td := CHATBOT_CORE_SUMMARY_PKG.build_tabledesc_json_for_sql(v_generated_sql);
        IF v_td IS NOT NULL THEN
          v_column_info := CHATBOT_CORE_SUMMARY_PKG.build_column_info_from_tabledesc(
                             p_rows_json      => p_rows_json,
                             p_tabledesc_json => v_td,
                             p_sql_text       => v_generated_sql
                           );
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          v_column_info := NULL;
      END;
    END IF;

    -------------------------------------------------------------------------
    -- 4) Build payload
    -------------------------------------------------------------------------
    l_payload := CHATBOT_CORE_IO_PKG.build_payload_chat(
      p_api_format     => p_api_format,
      p_model_id       => p_model_id,
      p_compartment_id => p_compartment_id,
      p_prompt_text    =>
           NVL(l_chart_system, '') || CHR(10) || CHR(10) ||
           '-- COLUMN_INFO --' || CHR(10) ||
           NVL(v_column_info, '(none)') || CHR(10) || CHR(10) ||
           '-- RESULT_ROWS_JSON --' || CHR(10) ||
           NVL(l_preview_tok, p_rows_json) || CHR(10) || CHR(10) ||
           '-- USER_QUESTION --' || CHR(10) ||
           NVL(p_context_query, ''),
      p_temperature    => p_temperature,
      p_top_p          => p_top_p,
      p_top_k          => p_top_k
    );

    CHATBOT_CORE_IO_PKG.logc(
      p_ctx, 'CHART', p_req_id,
      'Chart payload',
      CHATBOT_CORE_IO_PKG.clamp_clob(l_payload, 4000),
      p_log_id, p_chat_id
    );

    -------------------------------------------------------------------------
    -- 5) Call model
    -------------------------------------------------------------------------
    l_resp := CHATBOT_CORE_IO_PKG.call_model(
      p_ctx, 'CHART', p_endpoint, l_payload, p_req_id, p_log_id, p_chat_id
    );
    o_raw_response := l_resp;

    CHATBOT_CORE_IO_PKG.logc(
      p_ctx, 'CHART', p_req_id,
      'Raw chart resp',
      CHATBOT_CORE_IO_PKG.clamp_clob(l_resp, 4000),
      p_log_id, p_chat_id
    );

    -------------------------------------------------------------------------
    -- 6) Extract text (should be plain JSON object string)
    -------------------------------------------------------------------------
    l_chart_json := CHATBOT_CORE_IO_PKG.extract_text_from_chat_response(l_resp);

    RETURN l_chart_json;

  EXCEPTION
    WHEN OTHERS THEN
      CHATBOT_CORE_IO_PKG.log_any(
        p_ctx, 'CHART', 'ERROR', p_req_id, p_log_id, p_chat_id,
        'Suggest_Chart_Spec:error '||SQLERRM, NULL
      );
      RETURN NULL;
  END Suggest_Chart_Spec;

END CHATBOT_CORE_CHART_PKG;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_CORE_CTX_PARAMS_PKG" AS
  TYPE run_ctx_t IS RECORD (
    dataset        VARCHAR2(100),
    environment    VARCHAR2(20),
    debug_enabled  BOOLEAN
  );

  FUNCTION make_ctx(p_dataset IN VARCHAR2, p_environment IN VARCHAR2) RETURN run_ctx_t;
  FUNCTION as_bool(p IN VARCHAR2, p_default IN BOOLEAN := TRUE) RETURN BOOLEAN;

  -- Exact-scope lookups (LATEST/TEST only)
  FUNCTION get_param_value(p_ctx IN run_ctx_t, p_component_type IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION get_num_param  (p_ctx IN run_ctx_t, p_name IN VARCHAR2, p_default IN NUMBER) RETURN NUMBER;
  FUNCTION load_component (p_ctx IN run_ctx_t, p_component_type IN VARCHAR2) RETURN CLOB;

  FUNCTION is_debug_enabled(p_ctx IN run_ctx_t) RETURN BOOLEAN;
  FUNCTION is_routing_enabled(p_ctx IN run_ctx_t) RETURN BOOLEAN;
  FUNCTION is_rephrase_enabled(p_ctx IN run_ctx_t) RETURN BOOLEAN;  -- implement below

  TYPE model_cfg_t IS RECORD (
    region        VARCHAR2(50),
    model_id_out  VARCHAR2(1000),
    api_format    VARCHAR2(50),
    temperature   NUMBER,
    top_p         NUMBER,
    top_k         NUMBER
  );

  PROCEDURE get_model_config(
    p_model_id IN  VARCHAR2,
    p_cfg      OUT model_cfg_t
  );

  FUNCTION endpoint_for_region(p_region VARCHAR2) RETURN VARCHAR2;

END CHATBOT_CORE_CTX_PARAMS_PKG;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_CORE_CTX_PARAMS_PKG" AS

  FUNCTION make_ctx(p_dataset IN VARCHAR2, p_environment IN VARCHAR2) RETURN run_ctx_t IS
    l_ctx run_ctx_t;
  BEGIN
    l_ctx.dataset       := p_dataset;
    l_ctx.environment   := p_environment;
    l_ctx.debug_enabled := is_debug_enabled(l_ctx);
    RETURN l_ctx;
  END;

  FUNCTION as_bool(p IN VARCHAR2, p_default IN BOOLEAN := TRUE) RETURN BOOLEAN IS
    v VARCHAR2(10) := UPPER(TRIM(p));
  BEGIN
    IF v IS NULL THEN RETURN p_default; END IF;
    IF v IN ('Y','YES','TRUE','1','ON')  THEN RETURN TRUE;  END IF;
    IF v IN ('N','NO','FALSE','0','OFF') THEN RETURN FALSE; END IF;
    RETURN p_default;
  END;

  --------------------------------------------------------------------------
  -- Exact scope: only dataset & environment rows, ACTIVE='TRUE'
  --------------------------------------------------------------------------
  -- Return a scalar value from CONTENT (as VARCHAR2 up to 4000)
  function get_param_value(
    p_ctx            in run_ctx_t,
    p_component_type in varchar2
  ) return varchar2
  is
    l_val varchar2(4000);
  begin
    select content
      into l_val
      from CHATBOT_PARAMETERS p
    where p.active         = 'TRUE'
      and p.component_type = p_component_type
      and p.dataset        = p_ctx.dataset
      and p.environment    = p_ctx.environment
      order by p.id desc
      fetch first 1 rows only;

    return l_val;
  exception
    when no_data_found then return null;
    when others        then return null;
  end;

  -- Return a numeric value parsed from CONTENT
  function get_num_param(
    p_ctx     in run_ctx_t,
    p_name    in varchar2,
    p_default in number
  ) return number
  is
    v number;
  begin
    select to_number(content)
      into v
      from CHATBOT_PARAMETERS p
    where p.active         = 'TRUE'
      and p.component_type = p_name
      and p.dataset        = p_ctx.dataset
      and p.environment    = p_ctx.environment
      order by p.id desc
      fetch first 1 rows only;

    return v;
  exception
    when others then return p_default;
  end;

  -- Concatenate all matching CONTENT CLOBs (ordered by $.order or id)
  function load_component(
    p_ctx            in run_ctx_t,
    p_component_type in varchar2
  ) return clob
  is
    l_out clob;
  begin
    for r in (
      select content
        from CHATBOT_PARAMETERS p
      where p.active         = 'TRUE'
        and p.component_type = p_component_type
        and p.dataset        = p_ctx.dataset
        and p.environment    = p_ctx.environment
      order by nvl(json_value(p.content, '$.order' returning number), p.id)
    ) loop
      if l_out is null then dbms_lob.createtemporary(l_out, true); end if;
      dbms_lob.append(l_out, r.content);
      dbms_lob.append(l_out, chr(10)||chr(10));
    end loop;
    return l_out;
  exception when others then
    return l_out;
  end;

  --------------------------------------------------------------------------
  -- Feature toggles (exact-scope reads)
  --------------------------------------------------------------------------
  FUNCTION is_debug_enabled(p_ctx IN run_ctx_t) RETURN BOOLEAN IS
    l_dummy NUMBER;
  BEGIN
    SELECT 1 INTO l_dummy
      FROM CHATBOT_PARAMETERS
     WHERE active = 'TRUE'
       AND component_type = 'DEBUG_FLAG'
       AND dataset = p_ctx.dataset
       AND environment = p_ctx.environment
     FETCH FIRST 1 ROWS ONLY;
    RETURN TRUE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN FALSE;
    WHEN OTHERS THEN RETURN FALSE;
  END;

  function is_routing_enabled(p_ctx run_ctx_t) return boolean is
    v_val varchar2(32);
  begin
    v_val := upper(nvl(get_param_value(p_ctx, 'ROUTING_ENABLED'),
                nvl(get_param_value(p_ctx, 'ROUTER_ENABLED'),'') ));
    if v_val in ('TRUE','T','YES','Y','ON','1')  then return true;  end if;
    if v_val in ('FALSE','F','NO','N','OFF','0') then return false; end if;
    return true; -- default ON
  exception when others then
    return true; -- fail-open
  end;

  FUNCTION is_rephrase_enabled(p_ctx IN run_ctx_t) RETURN BOOLEAN IS
    v_val VARCHAR2(32);
  BEGIN
    v_val := UPPER(NVL(get_param_value(p_ctx, 'REPHRASE_ENABLED'), 'N'));
    RETURN as_bool(v_val, FALSE);
  EXCEPTION
    WHEN OTHERS THEN RETURN FALSE;
  END;

  PROCEDURE get_model_config(p_model_id IN VARCHAR2, p_cfg OUT model_cfg_t) IS
  BEGIN
    SELECT region,
           model_id,
           api_format,
           NVL(temperature,1),
           NVL(top_p,1),
           NVL(top_k,1)
      INTO p_cfg.region,
           p_cfg.model_id_out,
           p_cfg.api_format,
           p_cfg.temperature,
           p_cfg.top_p,
           p_cfg.top_k
      FROM AI_MODEL_CONFIG
     WHERE model_id = p_model_id;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- surface a clear error; caller can handle if desired
      RAISE_APPLICATION_ERROR(-20073, 'AI_MODEL_CONFIG row not found for model_id='||p_model_id);
  END;

  FUNCTION endpoint_for_region(p_region VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN 'https://inference.generativeai.'
           || LOWER(p_region)
           || '.oci.oraclecloud.com/20231130/actions/chat';
  END;

END CHATBOT_CORE_CTX_PARAMS_PKG;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_CORE_IO_PKG" as
  -- ===== Logging (respects p_ctx.debug_enabled) =====
  procedure log_any(
    p_ctx     in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_phase   in varchar2,   -- 'INITIAL'|'REPHRASE'|'SUMMARY'|'GENERAL'|'ROUTER'
    p_level   in varchar2,   -- 'INFO'|'DATA'|'HTTP REQUEST'|'HTTP RESPONSE'|'HTTP ERROR'
    p_req_id  in varchar2,
    p_log_id  in number,
    p_chat_id in number,
    p_message in varchar2,
    p_payload in clob default null
  );

  procedure logv(
    p_ctx     in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_phase   in varchar2,
    p_req_id  in varchar2,
    p_msg     in varchar2,
    p_log_id  in number default null,
    p_chat_id in number default null
  );

  procedure logc(
    p_ctx     in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_phase   in varchar2,
    p_req_id  in varchar2,
    p_label   in varchar2,
    p_c       in clob,
    p_log_id  in number default null,
    p_chat_id in number default null
  );

  -- ===== JSON/string/LOB helpers =====
  function json_escape(p_txt clob) return clob;
  function num_to_json(p_n number) return varchar2;
  function one_line(p clob) return clob;
  function clamp_clob(p clob, p_limit number) return clob;

  function clob_to_blob_utf8(p_clob in clob) return blob;
  function blob_to_clob_utf8(p_blob in blob) return clob;

  -- Strict SQL-only extraction (drops plans/markdown/semicolons)
  function extract_sql_only(p_text in clob) return clob;

  -- Detect FOLLOWUP JSON (≤2 questions); returns JSON or NULL
  function try_parse_followup_json(p_text in clob) return clob;

  -- Normalize LLM SQL blocks (strip ``` fences, leading 'sql', trim)
  function normalize_llm_sql(p_text in clob) return clob;

  -- ===== Debug =======
  function debug_on(p_ctx in chatbot_core_ctx_params_pkg.run_ctx_t) return boolean;
  function debug_on(p_dataset in varchar2, p_environment in varchar2) return boolean;

  -- ===== LLM I/O =====
  function build_payload_chat(
    p_api_format       in varchar2,
    p_model_id         in varchar2,
    p_compartment_id   in varchar2,
    p_prompt_text      in clob,
    p_temperature      in number,
    p_top_p            in number,
    p_top_k            in number
  ) return clob;

  function call_model(
    p_ctx      in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_phase    in varchar2,
    p_endpoint in varchar2,
    p_payload  in clob,
    p_req_id   in varchar2 default null,
    p_log_id   in number   default null,
    p_chat_id  in number   default null
  ) return clob;

  function extract_text_from_chat_response(p_raw in clob) return clob;

  procedure extract_usage_tokens(
    p_resp_clob      in  clob,
    p_prompt_tokens  out number,
    p_completion_tok out number
  );
end chatbot_core_io_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_CORE_IO_PKG" as
  /*----------------------------------------------------------------------------*
   * PACKAGE: chatbot_core_io_pkg
   *
   * PURPOSE
   *   Utilities for chatbot I/O:
   *     - Debug flag resolution (context-aware)
   *     - JSON/string/LOB helpers
   *     - Safe, autonomous logging (DB + APEX_DEBUG)
   *     - LLM request payload construction / response parsing
   *     - HTTP calls to OCI endpoints via DBMS_CLOUD
   *
   * BEHAVIOR & SAFETY
   *   - Debug gating: logging runs only when the dataset/env-scoped debug flag
   *     is enabled (uses precomputed flag from ctx when available).
   *   - Helpers are defensive: return NULL/safe defaults on errors.
   *   - Logging is autonomous and never raises to the caller.
   *   - HTTP invocation logs request/response details; errors are logged and
   *     re-raised after cleaning up temporary LOBs.
   *
   * KEY ROUTINES
   *   - debug_on(ctx) → boolean
   *   - json_escape(clob) → clob
   *   - num_to_json(number) → varchar2
   *   - one_line(clob) → clob
   *   - clamp_clob(clob, limit) → clob
   *   - clob_to_blob_utf8(clob) ↔ blob_to_clob_utf8(blob)
   *   - log_any(...), logv(...), logc(...)
   *   - build_payload_chat(...) → clob
   *   - extract_text_from_chat_response(clob) → clob
   *   - extract_usage_tokens(clob, OUT prompt, OUT completion)
   *   - call_model(ctx, phase, endpoint, payload, ...) → clob
   *----------------------------------------------------------------------------*/

  ------------------------------------------------------------------------------
  -- Local: read DEBUG_FLAG via parameter table (ranked by dataset/env)
  ------------------------------------------------------------------------------
  -- debug_on
  --   Returns TRUE when debugging is enabled for the run context.
  --   Uses ctx.debug_enabled if populated; otherwise queries resolver.
  --   Any exception -> FALSE (fail-closed).
  function debug_on(p_ctx in chatbot_core_ctx_params_pkg.run_ctx_t) return boolean is
  begin
    -- Prefer the precomputed flag; fall back to presence-based resolver
    if p_ctx.debug_enabled is not null then
      return p_ctx.debug_enabled;
    end if;
    return chatbot_core_ctx_params_pkg.is_debug_enabled(p_ctx);
  exception when others then
    return false;
  end;

  -- New overload for simple callers that only have ctx_id
  function debug_on(p_dataset in varchar2, p_environment in varchar2) return boolean is
    l_ctx chatbot_core_ctx_params_pkg.run_ctx_t := chatbot_core_ctx_params_pkg.make_ctx(p_dataset, p_environment);
  begin
    return debug_on(l_ctx);
  exception when others then
    return false;
  end;

  ------------------------------------------------------------------------------
  -- JSON/string/LOB helpers (match spec)
  ------------------------------------------------------------------------------
  -- json_escape
  --   Escapes backslash, double quotes, and control chars to JSON-safe sequences.
  function json_escape(p_txt clob) return clob is
    l_out clob := p_txt;
  begin
    if l_out is null then return null; end if;
    l_out := replace(l_out, '\', '\\');
    l_out := replace(l_out, '"',  '\"');
    l_out := replace(l_out, chr(8),  '\b');     -- backspace
    l_out := replace(l_out, chr(12), '\f');     -- form feed
    l_out := replace(l_out, chr(13)||chr(10), '\n');
    l_out := replace(l_out, chr(13), '\n');
    l_out := replace(l_out, chr(10), '\n');
    l_out := replace(l_out, chr(9),  '\t');
    return l_out;
  end;

  -- num_to_json
  --   Renders a NUMBER as a JSON literal string; trims trailing zeros/decimal.
  --   NULL -> 'null'.
  function num_to_json(p_n number) return varchar2 is
    l_txt varchar2(4000);
  begin
    if p_n is null then return 'null'; end if;
    l_txt := to_char(p_n,'FM999999999999990D999999999999999999','NLS_NUMERIC_CHARACTERS=.,');
    if instr(l_txt,'.') > 0 then
      l_txt := regexp_replace(l_txt,'0+$');
      l_txt := regexp_replace(l_txt,'\.$','');
    end if;
    return l_txt;
  end;

  -- one_line
  --   Normalizes CR/LF variants to single LF.
  function one_line(p in clob) return clob is
    l clob := p;
  begin
    if l is null then return null; end if;
    l := replace(l, chr(13)||chr(10), chr(10));
    l := replace(l, chr(13),        chr(10));
    return l;
  end;

  -- clamp_clob
  --   Returns the first p_limit chars of CLOB p.
  --   If p is NULL or limit <= 0 -> NULL. If shorter than limit -> p.
  function clamp_clob(p clob, p_limit number) return clob is
    l_len number;
  begin
    if p is null or p_limit is null or p_limit <= 0 then return null; end if;
    l_len := dbms_lob.getlength(p);
    if l_len <= p_limit then return p; end if;
    return dbms_lob.substr(p, p_limit, 1);
  end;

  -- clob_to_blob_utf8
  --   Converts CLOB to BLOB using AL32UTF8.
  function clob_to_blob_utf8(p_clob in clob) return blob is
    l_blob        blob;
    l_dest_offset integer := 1;
    l_src_offset  integer := 1;
    l_lang_ctx    integer := 0;
    l_warning     integer := 0;
  begin
    dbms_lob.createtemporary(l_blob, true);
    dbms_lob.converttoblob(
      dest_lob     => l_blob,
      src_clob     => p_clob,
      amount       => dbms_lob.lobmaxsize,
      dest_offset  => l_dest_offset,
      src_offset   => l_src_offset,
      blob_csid    => nls_charset_id('AL32UTF8'),
      lang_context => l_lang_ctx,
      warning      => l_warning
    );
    return l_blob;
  end;

  -- blob_to_clob_utf8
  --   Converts BLOB to CLOB using AL32UTF8.
  function blob_to_clob_utf8(p_blob in blob) return clob is
    l_clob        clob;
    l_dest_offset integer := 1;
    l_src_offset  integer := 1;
    l_lang_ctx    integer := 0;
    l_warning     integer := 0;
  begin
    if p_blob is null then return null; end if;
    dbms_lob.createtemporary(l_clob, true);
    dbms_lob.converttoclob(
      dest_lob     => l_clob,
      src_blob     => p_blob,
      amount       => dbms_lob.lobmaxsize,
      dest_offset  => l_dest_offset,
      src_offset   => l_src_offset,
      blob_csid    => nls_charset_id('AL32UTF8'),
      lang_context => l_lang_ctx,
      warning      => l_warning
    );
    return l_clob;
  end;

  ------------------------------------------------------------------------------
  -- Logging (autonomous, safe)
  ------------------------------------------------------------------------------
  -- log_any
  --   Core logger. If debug is OFF, returns immediately.
  --   Inserts into CHATBOT_JOB_DEBUG with phase/level, message and payload.
  --   Autonomous txn; swallows any insert/commit exceptions.
  procedure log_any (
    p_ctx     in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_phase   in varchar2,
    p_level   in varchar2,
    p_req_id  in varchar2,
    p_log_id  in number,
    p_chat_id in number,
    p_message in varchar2,
    p_payload in clob default null
  ) is
    pragma autonomous_transaction;
  begin
    if not nvl(p_ctx.debug_enabled, chatbot_core_ctx_params_pkg.is_debug_enabled(p_ctx)) then
      return;
    end if;

    begin
      insert into CHATBOT_JOB_DEBUG
        (req_id, log_id, chat_id, level_txt, message, payload, created_at)
      values
        (p_req_id, p_log_id, p_chat_id, p_phase||'/'||p_level, p_message, p_payload, systimestamp);
      commit;
    exception when others then null; end;
  end;

  -- logv
  --   INFO-level convenience: writes to APEX_DEBUG and log_any.
  procedure logv(
    p_ctx     in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_phase   in varchar2,
    p_req_id  in varchar2,
    p_msg     in varchar2,
    p_log_id  in number default null,
    p_chat_id in number default null
  ) is
  begin
    begin
      apex_debug.message('[%s] (%s) %s', p_req_id, p_phase, p_msg);
    exception when others then null; end;
    log_any(p_ctx, p_phase, 'INFO', p_req_id, p_log_id, p_chat_id, p_msg, null);
  end;

  -- logc
  --   DATA-level convenience with CLOB payload.
  --   Emits a snippet (up to 4000 chars) to APEX_DEBUG; full CLOB to table.
  procedure logc(
    p_ctx     in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_phase   in varchar2,
    p_req_id  in varchar2,
    p_label   in varchar2,
    p_c       in clob,
    p_log_id  in number default null,
    p_chat_id in number default null
  ) is
    l_snip varchar2(4000);
  begin
    begin
      l_snip := dbms_lob.substr(p_c, least(dbms_lob.getlength(p_c), 4000), 1);
      apex_debug.message('[%s] (%s) %s: %s', p_req_id, p_phase, p_label, l_snip);
    exception when others then null; end;

    log_any(p_ctx, p_phase, 'DATA', p_req_id, p_log_id, p_chat_id, p_label, p_c);
  end;

  ------------------------------------------------------------------------------
  -- LLM I/O
  ------------------------------------------------------------------------------
  -- build_payload_chat
  --   Builds JSON payload for an OCI GenAI chat request.
  --   Supports:
  --     * COHERE format (single "message")
  --     * GENERIC format (messages array with role/content objects)
  --   Includes model ID, compartment ID, serving mode, maxTokens, temperature,
  --   topP, topK, and optional frequency/presence penalties.
  function build_payload_chat (
    p_api_format       in varchar2,
    p_model_id         in varchar2,
    p_compartment_id   in varchar2,
    p_prompt_text      in clob,
    p_temperature      in number,
    p_top_p            in number,
    p_top_k            in number
  ) return clob
  is
    l_out clob;
  begin
    apex_json.initialize_clob_output;

    apex_json.open_object; -- root
      apex_json.write('compartmentId', p_compartment_id);

      apex_json.open_object('servingMode');
        apex_json.write('modelId',     p_model_id);
        apex_json.write('servingType', 'ON_DEMAND');
      apex_json.close_object;

      apex_json.open_object('chatRequest');
        if upper(p_api_format) = 'COHERE' then
        apex_json.write('apiFormat',   'COHERE');
        apex_json.write('maxTokens',    2048);
        apex_json.write('temperature',  nvl(p_temperature, 1));
        apex_json.write('topP',         nvl(p_top_p,       1));

        -- write topK ONLY if provided (NULL => omit key)
        if p_top_k is not null then
            apex_json.write('topK', p_top_k);
        end if;

        apex_json.write('message', p_prompt_text);

        else
        apex_json.write('apiFormat',   'GENERIC');
        apex_json.write('maxTokens',    2048);
        apex_json.write('temperature',  nvl(p_temperature, 1));
        apex_json.write('topP',         nvl(p_top_p,       1));

        -- write topK ONLY if provided (NULL => omit key)
        if p_top_k is not null then
            apex_json.write('topK', p_top_k);
        end if;

        apex_json.open_array('messages');
            apex_json.open_object;               -- message 0
            apex_json.write('role','USER');
            apex_json.open_array('content');
                apex_json.open_object;
                apex_json.write('type','TEXT');
                apex_json.write('text', p_prompt_text); -- CLOB safe
                apex_json.close_object;
            apex_json.close_array;             -- content
            apex_json.close_object;              -- message 0
        apex_json.close_array;                 -- messages
        end if;
        apex_json.close_object; -- chatRequest
    apex_json.close_object;   -- root

    l_out := apex_json.get_clob_output;
    apex_json.free_output;
    return l_out;
  end;

  -- extract_text_from_chat_response
  --   Parses LLM response to retrieve the text:
  --     1) chatResponse.text
  --     2) chatResponse.choices[0].message.content[0].text
  --   Returns NULL on errors/missing fields.
  function extract_text_from_chat_response (p_raw in clob) return clob is
    l_obj      json_object_t;
    l_cr       json_object_t;
    l_text     clob := null;
    l_choices  json_array_t;
    l_first    json_object_t;
    l_msg      json_object_t;
    l_content  json_array_t;
    l_text_obj json_object_t;
  begin
    l_obj := json_object_t.parse(p_raw);
    if not l_obj.has('chatResponse') then return null; end if;
    l_cr := l_obj.get_object('chatResponse');

    if l_cr.has('text') then
      begin l_text := l_cr.get_string('text'); exception when others then l_text := null; end;
    end if;

    if l_text is null or trim(l_text) is null then
      begin
        l_choices := l_cr.get_array('choices');
        l_first   := treat(l_choices.get(0) as json_object_t);
        l_msg     := treat(l_first.get('message') as json_object_t);
        l_content := treat(l_msg.get('content') as json_array_t);
        l_text_obj:= treat(l_content.get(0) as json_object_t);
        l_text    := l_text_obj.get_string('text');
      exception when others then l_text := null; end;
    end if;

    return l_text;
  exception when others then
    return null;
  end;

  function normalize_llm_sql(p_text in clob) return clob is
    v clob := p_text;
    blk clob;
  begin
    if v is null then return null; end if;

    -- Prefer ```sql ... ```
    blk := regexp_substr(v, '(?is)```sql\s*(.+?)\s*```', 1, 1, null, 1);
    if blk is null then
      -- fallback: any ``` ... ```
      blk := regexp_substr(v, '(?is)```\s*(.+?)\s*```', 1, 1, null, 1);
    end if;
    if blk is not null then v := blk; end if;

    -- Drop a stray leading 'sql' tag on its own line (defensive)
    v := regexp_replace(v, '^(?is)\s*sql\s*\r?\n', '');

    -- Trim + drop any leftover fences/semicolons
    v := trim(regexp_replace(v, '```(.|\n)*$', '', 1, 1, 'n'));
    v := regexp_replace(v, ';\s*$', '', 1, 1, 'n');

    return v;
  exception when others then
    return p_text;
  end;

  -- Keep only the first Oracle SELECT; drop plans/markdown/semicolons
  function extract_sql_only(p_text in clob) return clob is
    t    clob := p_text;
    p    pls_integer;
    sqlc clob;
  begin
    if t is null then return null; end if;

    -- NEW: normalize first (strip fences, "sql" tags, trailing backticks, etc.)
    t := normalize_llm_sql(t);

    -- Prefer fenced ```sql ... ```
    p := regexp_instr(t, '```sql', 1, 1, 0, 'in');
    if p > 0 then
      sqlc := regexp_substr(t, '```sql(.*)```', 1, 1, null, 'in');
      if sqlc is not null then
        sqlc := regexp_replace(sqlc, '^\s*```sql', '', 1, 1, 'in');
        sqlc := regexp_replace(sqlc, '```$', '', 1, 1, 'n');
      end if;
    end if;

    -- Fallback: first WITH/SELECT onward (no CLOB truncation)
    if sqlc is null then
      p := regexp_instr(t, '(with|select)\b', 1, 1, 0, 'in');
      if p > 0 then
        sqlc := dbms_lob.substr(t, dbms_lob.getlength(t)-p+1, p);
      end if;
    end if;

    if sqlc is null then return null; end if;

    -- Trim trailing fence/chatter/semicolon
    sqlc := regexp_replace(sqlc, '```(.|\n)*$', '', 1, 1, 'n');
    sqlc := regexp_replace(sqlc, ';\s*$', '', 1, 1, 'n');
    sqlc := trim(sqlc);

    -- Must start with WITH/SELECT
    if not regexp_like(sqlc, '^\s*(with|select)(\s|$)', 'i') then
      return null;
    end if;

    return sqlc;
  exception
    when others then
      return null;
  end;

  -- Detect a minimal FOLLOWUP JSON contract (≤2 questions). Returns the JSON or NULL.
  function try_parse_followup_json(p_text in clob) return clob is
    v   clob := p_text;
    j   json_object_t;
    a   json_array_t;
    q   clob;

    function first_from(a json_array_t) return clob is
    begin
      if a is not null and a.get_size > 0 then return a.get_string(0); end if;
      return null;
    end;
  begin
    if v is null then return null; end if;

    -- first JSON object in the response
    v := regexp_substr(v, '\{.*\}', 1, 1, 'n');
    if v is null then return null; end if;

    begin
      j := json_object_t.parse(v);
    exception when others then
      return null;
    end;

    -- canonical + alternates
    if q is null and j.has('followup')             then q := j.get_string('followup'); end if;
    if q is null and j.has('question')             then q := j.get_string('question'); end if;
    if q is null and j.has('clarification')        then q := j.get_string('clarification'); end if;
    if q is null and j.has('clarifying_question')  then q := j.get_string('clarifying_question'); end if;

    -- array forms (≤2) – keep only the first
    if q is null and j.has('clarifying_questions') then
      a := j.get_array('clarifying_questions');
      if a is not null and a.get_size <= 2 then q := first_from(a); end if;
    end if;
    if q is null and j.has('followup_questions')   then q := first_from(j.get_array('followup_questions')); end if;
    if q is null and j.has('questions')            then q := first_from(j.get_array('questions')); end if;
    if q is null and j.has('clarifications')       then q := first_from(j.get_array('clarifications')); end if;
    if q is null and j.has('follow_up_questions')  then q := first_from(j.get_array('follow_up_questions')); end if;

    if q is null or trim(q) is null then return null; end if;

    apex_json.initialize_clob_output;
    apex_json.open_object; apex_json.write('followup', q); apex_json.close_object;
    q := apex_json.get_clob_output; apex_json.free_output;
    return q;
  exception when others then
    apex_json.free_output; return null;
  end;

  -- extract_usage_tokens
  --   Pulls usage from chatResponse.usage or root.usage into OUT params.
  --   Any exception -> zeros.
  procedure extract_usage_tokens (
    p_resp_clob      in  clob,
    p_prompt_tokens  out number,
    p_completion_tok out number
  ) is
    l_root  json_object_t;
    l_node  json_object_t;
    l_usage json_object_t;
  begin
    p_prompt_tokens  := 0;
    p_completion_tok := 0;
    l_root := json_object_t.parse(p_resp_clob);

    if l_root.has('chatResponse') then
      begin
        l_node := l_root.get_object('chatResponse');
        if l_node.has('usage') then
          l_usage := l_node.get_object('usage');
        end if;
      exception when others then null; end;
    end if;

    if l_usage is null and l_root.has('usage') then
      begin
        l_usage := l_root.get_object('usage');
      exception when others then null; end;
    end if;

    if l_usage is not null then
      begin p_prompt_tokens  := nvl(l_usage.get_number('promptTokens'),     0); exception when others then null; end;
      begin p_completion_tok := nvl(l_usage.get_number('completionTokens'), 0); exception when others then null; end;
    end if;
  exception when others then
    p_prompt_tokens  := 0;
    p_completion_tok := 0;
  end;

  -- call_model
  --   Sends POST to OCI endpoint with JSON payload using DBMS_CLOUD.
  --   Logs HTTP REQUEST and RESPONSE (status, length) when debug enabled.
  --   On exception: logs HTTP ERROR, frees temps, re-raises.
  function call_model (
    p_ctx      in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_phase    in varchar2,
    p_endpoint in varchar2,
    p_payload  in clob,
    p_req_id   in varchar2 default null,
    p_log_id   in number   default null,
    p_chat_id  in number   default null
  ) return clob
  is
    l_resp_struct dbms_cloud_types.resp;
    l_body        blob := clob_to_blob_utf8(p_payload);
    l_resp_blob   blob;
    l_resp_clob   clob;
    l_status      number;
    l_len_clob    number;
    procedure free_temps is
    begin
      -- Free response BLOB if temporary
      begin
        if l_resp_blob is not null and dbms_lob.istemporary(l_resp_blob) = 1 then
          dbms_lob.freetemporary(l_resp_blob);
        end if;
      exception when others then null; end;
      -- Free request body BLOB if temporary
      begin
        if l_body is not null and dbms_lob.istemporary(l_body) = 1 then
          dbms_lob.freetemporary(l_body);
        end if;
      exception when others then null; end;
    end;
  begin
    log_any(
      p_ctx, p_phase, 'HTTP REQUEST', p_req_id, p_log_id, p_chat_id,
      'POST '||p_endpoint, p_payload
    );

    l_resp_struct := dbms_cloud.send_request(
      credential_name => 'OCI$RESOURCE_PRINCIPAL',
      uri             => p_endpoint,
      method          => 'POST',
      headers         => json_object(
                           'Content-Type'     value 'application/json',
                           'Accept-Encoding'  value 'identity'
                         ),
      body            => l_body
    );

    l_status    := dbms_cloud.get_response_status_code(l_resp_struct);
    l_resp_blob := dbms_cloud.get_response_raw(l_resp_struct);
    l_resp_clob := blob_to_clob_utf8(l_resp_blob);

    l_len_clob := case when l_resp_clob is null then 0 else dbms_lob.getlength(l_resp_clob) end;

    log_any(
      p_ctx, p_phase, 'HTTP RESPONSE', p_req_id, p_log_id, p_chat_id,
      'Response '||l_status||' from '||p_endpoint||' (len='||l_len_clob||')',
      l_resp_clob
    );

    free_temps;
    return l_resp_clob;

  exception
    when others then
      free_temps;
      log_any(
        p_ctx, p_phase, 'HTTP ERROR', p_req_id, p_log_id, p_chat_id,
        'Exception during POST '||p_endpoint||': '||substr(sqlerrm,1,2000),
        p_payload
      );
      raise;
  end;

  function unescape_json_text(p in clob) return clob is
  begin
    return replace(replace(p, '\\n', chr(10)), '\\\"', '\"');
  end;

  function normalize_llm_sql(p in clob) return clob is
    t clob := unescape_json_text(p);
  begin
    t := regexp_replace(t, '```[a-zA-Z0-9_]*', '', 1, 0, 'i');
    t := replace(t, '```', '');
    t := trim(both ';' from t);
    return trim(t);
  end;

end chatbot_core_io_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_CORE_REASONING_PKG" AS

  /* Run the optional REASONING phase.
   *
   * Inputs:
   *   p_ctx             : dataset/environment context
   *   p_reasoning_system: REASONING_SYSTEM prompt (may be NULL if disabled upstream)
   *   p_user_prompt     : final user question (after any FOLLOWUP stitching)
   *   p_schema_slice    : routed SCHEMA JSON slice ({"tables":[...]}), or full SCHEMA
   *   p_api_format      : 'COHERE' / 'GENERIC' / etc.
   *   p_model_id        : resolved model id (from AI_MODEL_CONFIG)
   *   p_compartment_id  : OCI compartment OCID
   *   p_region          : region (kept for symmetry; not strictly required here)
   *   p_endpoint        : HTTP endpoint for the model
   *   p_req_id          : request correlation id (RUNNER-level GUID)
   *   p_log_id          : CHATBOT_NL2SQL_LOG.id
   *   p_chat_id         : chat/thread id
   *   p_temperature,p_top_p,p_top_k : model knobs
   *
   * Outputs:
   *   o_reasoned_json   : normalized REASONING plan JSON (or NULL on failure)
   *
   *   io_input_chars    : accumulated input char count (+= this phase)
   *   io_output_chars   : accumulated output char count (+= this phase)
   *   io_input_tokens   : accumulated input token count (+= this phase)
   *   io_output_tokens  : accumulated output token count (+= this phase)
   *   io_metrics_json   : metrics array string; this procedure appends a
   *                       {"phase":"REASONING",...} element when successful.
   */
  PROCEDURE run_reasoning_phase(
    p_ctx              IN  chatbot_core_ctx_params_pkg.run_ctx_t,
    p_reasoning_system IN  CLOB,
    p_user_prompt      IN  CLOB,
    p_schema_slice     IN  CLOB,
    p_table_desc_slice IN  CLOB,
    p_join_metadata    IN  CLOB,
    p_api_format       IN  VARCHAR2,
    p_model_id         IN  VARCHAR2,
    p_compartment_id   IN  VARCHAR2,
    p_region           IN  VARCHAR2,
    p_endpoint         IN  VARCHAR2,
    p_req_id           IN  VARCHAR2,
    p_log_id           IN  NUMBER,
    p_chat_id          IN  NUMBER,
    p_temperature      IN  NUMBER,
    p_top_p            IN  NUMBER,
    p_top_k            IN  NUMBER,
    o_reasoned_json    OUT CLOB,
    io_input_chars     IN OUT NUMBER,
    io_output_chars    IN OUT NUMBER,
    io_input_tokens    IN OUT NUMBER,
    io_output_tokens   IN OUT NUMBER,
    io_metrics_json    IN OUT CLOB
  );

END CHATBOT_CORE_REASONING_PKG;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_CORE_REASONING_PKG" AS

  /* =========================
   Data-agnostic helper: find a single DATE/TIMESTAMP column in a table slice
   Requires that p_schema_slice contains JSON or DDL slice for the selected tables.
   ========================= */
  FUNCTION pick_single_date_column(
    p_schema_slice IN CLOB,
    p_table        IN VARCHAR2
  ) RETURN VARCHAR2 IS
    hits     PLS_INTEGER := 0;
    best     VARCHAR2(256) := NULL;
    last_col VARCHAR2(256) := NULL;
  BEGIN
    -- Expect p_schema_slice like: { "tables":[ { "name":"OWNER.TBL", "columns":[{"name":"...","type":"..."}] }, ... ] }
    -- We extract ALL tables then filter by name in the WHERE (no PASSING).
    FOR r IN (
      SELECT jt.col_name, jt.col_type
      FROM JSON_TABLE(
             p_schema_slice,
             '$.tables[*]'
             COLUMNS (
               t_name VARCHAR2(256) PATH '$.name',
               cols   CLOB FORMAT JSON PATH '$.columns'
             )
           ) t,
           JSON_TABLE(
             t.cols,
             '$[*]'
             COLUMNS (
               col_name VARCHAR2(256) PATH '$.name',
               col_type VARCHAR2(256) PATH '$.type'
             )
           ) jt
      WHERE UPPER(t.t_name) = UPPER(p_table)
        AND (
              UPPER(jt.col_type) LIKE 'DATE%'
          OR  UPPER(jt.col_type) LIKE 'TIMESTAMP%'
            )
    )
    LOOP
      hits := hits + 1;
      last_col := r.col_name;

      -- prefer names that signal date-ness
      IF best IS NULL THEN
        best := r.col_name;
      ELSIF REGEXP_LIKE(r.col_name,'(day|date|ts|timestamp)','i') THEN
        best := r.col_name;
      END IF;
    END LOOP;

    IF hits = 1 THEN
      RETURN last_col;
    ELSIF hits > 1 THEN
      RETURN best;  -- select the most date-like of the candidates
    ELSE
      RETURN NULL;
    END IF;
  END pick_single_date_column;

  FUNCTION intersect_query_terms_with_columns(
    p_query        IN VARCHAR2,
    p_schema_slice IN CLOB,
    p_table        IN VARCHAR2
  ) RETURN VARCHAR2 IS
    vtok CLOB := LOWER(p_query);
  BEGIN
    -- tokenize: keep alphanumerics and underscores
    vtok := REGEXP_REPLACE(vtok,'[^a-z0-9_]+',' ');

    FOR r IN (
      SELECT LOWER(jt.col_name) col_name
      FROM JSON_TABLE(
             p_schema_slice,
             '$.tables[*]'
             COLUMNS (
               t_name VARCHAR2(256) PATH '$.name',
               cols   CLOB FORMAT JSON PATH '$.columns'
             )
           ) t,
           JSON_TABLE(
             t.cols,
             '$[*]'
             COLUMNS (
               col_name VARCHAR2(256) PATH '$.name'
             )
           ) jt
      WHERE UPPER(t.t_name) = UPPER(p_table)
    )
    LOOP
      -- exact token match wins
      IF REGEXP_REPLACE(vtok, ' +', ' ') IS NOT NULL AND
         REGEXP_LIKE(vtok, '(^| )'||REGEXP_REPLACE(r.col_name,'([^0-9a-z_])','\\\1')||'( |$)')
      THEN
        RETURN r.col_name;
      END IF;
    END LOOP;

    RETURN NULL;
  END intersect_query_terms_with_columns;

  /* =========================
    Normalize/complete Reasoner JSON plan.
    Fills in date/metric/top_n defaults when safely inferable.
    Also validates table/column existence against p_schema_slice
    and drives needs_clarification when critical pieces are missing.
    ========================= */
  PROCEDURE normalize_reasoner_plan(
    p_plan_json     IN  CLOB,
    p_schema_slice  IN  CLOB,
    p_user_query    IN  VARCHAR2,
    o_plan_json     OUT CLOB,
    o_complete      OUT BOOLEAN,
    o_question      OUT VARCHAR2
  ) IS
    obj         JSON_OBJECT_T;
    tf          JSON_OBJECT_T;
    mobj        JSON_OBJECT_T;
    table_name  VARCHAR2(256);
    date_col    VARCHAR2(256);
    metric_col  VARCHAR2(256);

    -- Heuristic: does the query obviously talk about time / period?
    has_time_semantics BOOLEAN := FALSE;

    -- Check that a table exists in the schema slice
    FUNCTION table_exists(p_table IN VARCHAR2) RETURN BOOLEAN IS
      v_cnt NUMBER;
    BEGIN
      IF p_schema_slice IS NULL THEN
        RETURN TRUE; -- fail open if no schema slice
      END IF;

      SELECT COUNT(*)
        INTO v_cnt
        FROM JSON_TABLE(
               p_schema_slice,
               '$.tables[*]'
               COLUMNS (
                 t_name VARCHAR2(256) PATH '$.name'
               )
             ) t
       WHERE UPPER(t.t_name) = UPPER(p_table);

      RETURN v_cnt > 0;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN TRUE; -- do not block on JSON errors
    END table_exists;

    -- Check that a column exists in a given table in the schema slice
    FUNCTION col_exists(p_table IN VARCHAR2, p_col IN VARCHAR2) RETURN BOOLEAN IS
      v_cnt NUMBER;
    BEGIN
      IF p_schema_slice IS NULL OR p_col IS NULL THEN
        RETURN TRUE; -- fail open if no schema or no column name
      END IF;

      SELECT COUNT(*)
        INTO v_cnt
        FROM JSON_TABLE(
               p_schema_slice,
               '$.tables[*]'
               COLUMNS (
                 t_name VARCHAR2(256) PATH '$.name',
                 cols   CLOB FORMAT JSON PATH '$.columns'
               )
             ) t,
             JSON_TABLE(
               t.cols,
               '$[*]'
               COLUMNS (
                 col_name VARCHAR2(256) PATH '$.name'
               )
             ) jt
       WHERE UPPER(t.t_name)   = UPPER(p_table)
         AND UPPER(jt.col_name) = UPPER(p_col);

      RETURN v_cnt > 0;
    EXCEPTION
      WHEN OTHERS THEN
        RETURN TRUE; -- do not block on JSON errors
    END col_exists;

    -- Drop any columns in a string array that do not exist in the target table
    PROCEDURE prune_array(p_key IN VARCHAR2) IS
      arr    JSON_ARRAY_T;
      outarr JSON_ARRAY_T := JSON_ARRAY_T();
      v_col  VARCHAR2(256);
      i      PLS_INTEGER;
    BEGIN
      IF NOT obj.has(p_key) THEN
        RETURN;
      END IF;

      arr := obj.get_array(p_key);
      IF arr IS NULL THEN
        RETURN;
      END IF;

      FOR i IN 0 .. arr.get_size - 1 LOOP
        v_col := arr.get_string(i);
        IF v_col IS NOT NULL AND col_exists(table_name, v_col) THEN
          outarr.append(v_col);
        END IF;
      END LOOP;

      obj.put(p_key, outarr);
    EXCEPTION
      WHEN OTHERS THEN
        NULL; -- pruning is best-effort
    END prune_array;

  BEGIN
    o_complete := FALSE;
    o_question := NULL;

    obj := JSON_OBJECT_T.parse(p_plan_json);
    table_name := obj.get_String('target_table');

    -- Simple heuristic for time semantics in the question
    has_time_semantics :=
      REGEXP_LIKE(LOWER(p_user_query),
                  '(last|past|recent|month|months|week|weeks|day|days|year|years|today|yesterday|ago)');

    -- === Validate that the chosen table exists (if we have a schema slice) ===
    IF table_name IS NOT NULL AND NOT table_exists(table_name) THEN
      o_plan_json := obj.to_clob();
      o_complete  := FALSE;
      o_question  := 'The selected target table is not found in the provided schema. Which table should we use?';
      RETURN;
    END IF;

    -- === TIME FILTER COMPLETION + VALIDATION ===
    IF obj.has('time_filter') THEN
      tf := obj.get_Object('time_filter');

      -- If no column was specified, try to infer one
      IF tf.get_String('column') IS NULL THEN
        date_col := pick_single_date_column(p_schema_slice, table_name);
        IF date_col IS NOT NULL THEN
          tf.put('column', date_col);
        END IF;
      END IF;

      -- If we ended up with a column but it does not exist, null it out
      IF tf.get_String('column') IS NOT NULL
         AND NOT col_exists(table_name, tf.get_String('column'))
      THEN
        tf.put('column', TO_CLOB(NULL));
      END IF;

      -- Example of special-case relative range (your existing logic)
      IF tf.get_String('start_expr') IS NULL
         AND REGEXP_LIKE(LOWER(p_user_query), '\blast week\b')
      THEN
        tf.put('start_expr', 'TRUNC(CURRENT_DATE,''IW'') - 7');
        tf.put('end_expr',   'TRUNC(CURRENT_DATE,''IW'')');
      END IF;

      obj.put('time_filter', tf);  -- reassign updated subobject
    END IF;

    -- === METRIC COMPLETION + VALIDATION ===
    IF obj.has('metric') THEN
      mobj := obj.get_Object('metric');

      -- If no metric column was specified, try to intersect with query terms
      IF mobj.get_String('column') IS NULL THEN
        metric_col := intersect_query_terms_with_columns(p_user_query, p_schema_slice, table_name);
        IF metric_col IS NOT NULL THEN
          mobj.put('column', metric_col);
        END IF;
      END IF;

      -- If we ended up with a column but it does not exist, null it out
      IF mobj.get_String('column') IS NOT NULL
         AND NOT col_exists(table_name, mobj.get_String('column'))
      THEN
        mobj.put('column', TO_CLOB(NULL));
      END IF;

      -- Your existing aggregation / sort defaults
      IF mobj.get_String('aggregation') IS NULL
         AND REGEXP_LIKE(LOWER(p_user_query), '(top|highest|max)\b')
      THEN
        mobj.put('aggregation', 'MAX');
      END IF;

      IF mobj.get_String('sort_direction') IS NULL
         AND REGEXP_LIKE(LOWER(p_user_query), '(top|highest|max)\b')
      THEN
        mobj.put('sort_direction', 'DESC');
      END IF;

      -- Only fill top_n when explicitly stated
      IF mobj.get('top_n').is_null THEN
        IF REGEXP_LIKE(LOWER(p_user_query), '(top|bottom)\s+[0-9]+') THEN
          DECLARE
            v_n NUMBER;
          BEGIN
            v_n := REGEXP_SUBSTR(LOWER(p_user_query),
                                 '(top|bottom)\s+([0-9]+)',
                                 1, 1, NULL, 2);
            IF v_n IS NOT NULL THEN
              mobj.put('top_n', v_n);
            END IF;
          END;
        ELSE
          NULL; -- leave as NULL
        END IF;
      END IF;

      obj.put('metric', mobj);  -- reassign updated subobject
    END IF;

    -- === PRUNE INVALID entity_keys / display_columns (best-effort) ===
    IF table_name IS NOT NULL THEN
      prune_array('entity_keys');
      prune_array('display_columns');
    END IF;

    -- === COMPLETION CHECK WITH CLARIFICATION REASONS ===
    -- Critical pieces: table_name, metric.column, and (when time semantics exist) time_filter.column.

    IF table_name IS NOT NULL
       AND obj.has('metric')
       AND obj.get_Object('metric').get_String('column') IS NOT NULL
    THEN
      -- Metric is valid; now check time semantics.
      IF has_time_semantics THEN
        IF obj.has('time_filter')
           AND obj.get_Object('time_filter').get_String('column') IS NOT NULL
        THEN
          o_complete := TRUE;
          o_question := NULL;
        ELSE
          o_complete := FALSE;
          o_question := 'Which date column should define the time window?';
        END IF;
      ELSE
        -- No strong time semantics → time_filter.column may safely be NULL.
        o_complete := TRUE;
        o_question := NULL;
      END IF;
    ELSE
      -- Something important is missing: table or metric.
      o_complete := FALSE;

      IF table_name IS NULL THEN
        o_question := 'Which table should we use for this question?';
      ELSIF NOT obj.has('metric')
         OR obj.get_Object('metric').get_String('column') IS NULL
      THEN
        o_question := 'Which metric should we use?';
      ELSE
        o_question := 'Which table/columns should we use?';
      END IF;
    END IF;

    o_plan_json := obj.to_clob();

  EXCEPTION
    WHEN OTHERS THEN
      o_plan_json := p_plan_json;
      o_complete  := FALSE;
      o_question  := 'Could you confirm the target table, date column and metric?';
  END normalize_reasoner_plan;


  /* =========================
     Public entrypoint: run_reasoning_phase
     ========================= */
  PROCEDURE run_reasoning_phase(
    p_ctx              IN  chatbot_core_ctx_params_pkg.run_ctx_t,
    p_reasoning_system IN  CLOB,
    p_user_prompt      IN  CLOB,
    p_schema_slice     IN  CLOB,
    p_table_desc_slice IN  CLOB,
    p_join_metadata    IN  CLOB,
    p_api_format       IN  VARCHAR2,
    p_model_id         IN  VARCHAR2,
    p_compartment_id   IN  VARCHAR2,
    p_region           IN  VARCHAR2,
    p_endpoint         IN  VARCHAR2,
    p_req_id           IN  VARCHAR2,
    p_log_id           IN  NUMBER,
    p_chat_id          IN  NUMBER,
    p_temperature      IN  NUMBER,
    p_top_p            IN  NUMBER,
    p_top_k            IN  NUMBER,
    o_reasoned_json    OUT CLOB,
    io_input_chars     IN OUT NUMBER,
    io_output_chars    IN OUT NUMBER,
    io_input_tokens    IN OUT NUMBER,
    io_output_tokens   IN OUT NUMBER,
    io_metrics_json    IN OUT CLOB
  ) IS
    l_reasoning_prompt  CLOB;
    l_reasoning_payload CLOB;
    l_reasoning_resp    CLOB;
    l_reasoning_text    CLOB;
    l_reasoning_json    CLOB;
    l_in_chars_r        NUMBER := 0;
    l_out_chars_r       NUMBER := 0;
    l_pt_r              NUMBER;
    l_ct_r              NUMBER;
    l_glossary_hints    CLOB;
  BEGIN
    o_reasoned_json := NULL;

    -- Optional: business glossary hints (from ROUTER/business rules)
    l_glossary_hints := CHATBOT_ROUTER_PKG.get_glossary_hints(p_ctx, p_user_prompt);

    IF l_glossary_hints IS NOT NULL THEN
      CHATBOT_CORE_IO_PKG.logc(
        p_ctx, 'REASONING', p_req_id,
        'Reasoning Business Glossary Hints',
        l_glossary_hints,
        p_log_id, p_chat_id
      );
    END IF;

    l_reasoning_prompt :=
      NVL(p_reasoning_system,'')
      || CHR(10) || '--- INPUTS ---'
      || CHR(10) || 'user_query: ' || NVL(p_user_prompt,'')
      || CHR(10) || 'schema_catalog:'
      || CHR(10) || NVL(p_schema_slice,'{}')
      || CHR(10) || 'table_descriptions:'
      || CHR(10) || NVL(p_table_desc_slice,'{}');

    -- Append Business glossary hints (if any)
    IF l_glossary_hints IS NOT NULL THEN
      l_reasoning_prompt :=
           l_reasoning_prompt
        || CHR(10) || 'Business glossary hints:'
        || CHR(10) || l_glossary_hints;
    END IF;

    -- Append join metadata (TABLE_JOINS) if present
    IF p_join_metadata IS NOT NULL THEN
      l_reasoning_prompt :=
           l_reasoning_prompt
        || CHR(10) || 'Join metadata (TABLE_JOINS):'
        || CHR(10) || NVL(p_join_metadata,'{}');
    END IF;

    -- Notes + target JSON schema (kept in sync with REASONING instructions)
    l_reasoning_prompt :=
          l_reasoning_prompt
      || CHR(10) || 'Notes:'
      || CHR(10) || '- Set "top_n" to a positive integer ONLY if the user explicitly asks for top/bottom N results (e.g. "top 10", "first 5").'
      || CHR(10) || '- Otherwise, set "top_n" to null.'
      || CHR(10) || '- Treat Business glossary hints as strong guidance for metrics, filters, and semantic periods (e.g. "summer months").'
      || CHR(10) || '--- OUTPUT JSON SCHEMA ---'
      || CHR(10) || '{'
      || CHR(10) || '  "intent": "select|rank|aggregate|compare",'
      || CHR(10) || '  "target_table": "OWNER.TABLE",'
      || CHR(10) || '  "entity_keys": [],'
      || CHR(10) || '  "display_columns": [],'
      || CHR(10) || '  "time_filter": { "column": null, "start_expr": null, "end_expr": null },'
      || CHR(10) || '  "filters": ['
      || CHR(10) || '    {'
      || CHR(10) || '      "column": "col",'
      || CHR(10) || '      "operator": "EQ|NEQ|GT|GTE|LT|LTE|LIKE|IN|BETWEEN|IS_NULL|IS_NOT_NULL",'
      || CHR(10) || '      "value": "literal_or_list_or_null",'
      || CHR(10) || '      "case": "UPPER|LOWER|NONE"'
      || CHR(10) || '    }'
      || CHR(10) || '  ],'
      || CHR(10) || '  "metric": {'
      || CHR(10) || '    "column": null,'
      || CHR(10) || '    "aggregation": "MAX|MIN|SUM|AVG|COUNT|NONE",'
      || CHR(10) || '    "sort_direction": "DESC|ASC|NONE",'
      || CHR(10) || '    "top_n": null'
      || CHR(10) || '  },'
      || CHR(10) || '  "result_granularity": "entity|row",'
      || CHR(10) || '  "suggested_joins": [],'
      || CHR(10) || '  "needs_clarification": false,'
      || CHR(10) || '  "clarification_question": null'
      || CHR(10) || '}';

    l_in_chars_r := NVL(DBMS_LOB.getlength(l_reasoning_prompt),0);
    io_input_chars := io_input_chars + l_in_chars_r;

    l_reasoning_payload := CHATBOT_CORE_IO_PKG.build_payload_chat(
      p_api_format, p_model_id, p_compartment_id,
      l_reasoning_prompt, 0.0, p_top_p, p_top_k
    );

    CHATBOT_CORE_IO_PKG.logc(
      p_ctx,'REASONING',p_req_id,
      'Reasoning Payload', l_reasoning_payload,
      p_log_id, p_chat_id
    );

    l_reasoning_resp := CHATBOT_CORE_IO_PKG.call_model(
                          p_ctx,'REASONING',p_endpoint,l_reasoning_payload,
                          p_req_id,p_log_id,p_chat_id);

    l_reasoning_text := CHATBOT_CORE_IO_PKG.extract_text_from_chat_response(l_reasoning_resp);
    l_out_chars_r := NVL(DBMS_LOB.getlength(l_reasoning_text),0);
    io_output_chars := io_output_chars + l_out_chars_r;

    CHATBOT_CORE_IO_PKG.extract_usage_tokens(l_reasoning_resp, l_pt_r, l_ct_r);
    io_input_tokens  := io_input_tokens  + NVL(l_pt_r,0);
    io_output_tokens := io_output_tokens + NVL(l_ct_r,0);

    BEGIN
      l_reasoning_json := REGEXP_SUBSTR(l_reasoning_text, '\{.*\}', 1, 1, 'n');
    EXCEPTION
      WHEN OTHERS THEN
        l_reasoning_json := NULL;
    END;

    IF l_reasoning_json IS NOT NULL THEN
      DECLARE
        l_norm CLOB;
        l_ok   BOOLEAN;
        l_q    VARCHAR2(4000);
      BEGIN
        normalize_reasoner_plan(
          p_plan_json    => l_reasoning_json,
          p_schema_slice => p_schema_slice,
          p_user_query   => p_user_prompt,
          o_plan_json    => l_norm,
          o_complete     => l_ok,
          o_question     => l_q
        );
        o_reasoned_json := l_norm;

        io_metrics_json := io_metrics_json ||
          CASE WHEN io_metrics_json='[' THEN '' ELSE ',' END ||
          '{"phase":"REASONING","inputChars":'||CHATBOT_CORE_IO_PKG.num_to_json(l_in_chars_r)||
          ',"outputChars":'||CHATBOT_CORE_IO_PKG.num_to_json(l_out_chars_r)||
          ',"promptTokens":'||CHATBOT_CORE_IO_PKG.num_to_json(NVL(l_pt_r,0))||
          ',"completionTokens":'||CHATBOT_CORE_IO_PKG.num_to_json(NVL(l_ct_r,0))||'}';

        CHATBOT_CORE_IO_PKG.logc(
          p_ctx,'REASONING',p_req_id,
          CASE WHEN l_ok THEN 'Reasoning JSON normalized (complete)'
               ELSE 'Reasoning JSON normalized (incomplete)' END,
          o_reasoned_json, p_log_id, p_chat_id
        );

        IF NOT l_ok THEN
          UPDATE CHATBOT_NL2SQL_LOG
             SET reasoned_message = NVL(reasoned_message,'') || CHR(10) ||
                 '[REASONER_QUESTION] '||NVL(l_q,'(unspecified)')
           WHERE id = p_log_id;
        END IF;
      END;
    ELSE
      CHATBOT_CORE_IO_PKG.logv(
        p_ctx,'REASONING',p_req_id,
        'No valid reasoning JSON detected (skipping)', p_log_id, p_chat_id
      );
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      CHATBOT_CORE_IO_PKG.logv(
        p_ctx,'REASONING',p_req_id,
        'Reasoning phase skipped: '||SUBSTR(SQLERRM,1,500),
        p_log_id,p_chat_id
      );
      -- o_reasoned_json remains NULL; metrics counters already partially updated.
  END run_reasoning_phase;


END CHATBOT_CORE_REASONING_PKG;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_CORE_RUNNER_PKG" IS
  -- Small helper used by INITIAL path to produce the final summary
  /*function summarize_preview(
    p_ctx              in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_phase            in varchar2,
    p_endpoint         in varchar2,
    p_api_format       in varchar2,
    p_model_id         in varchar2,
    p_compartment_id   in varchar2,
    p_temperature      in number,
    p_top_p            in number,
    p_top_k            in number,
    p_summary_system   in clob,
    p_preview_json     in clob,
    p_user_prompt      in clob,
    p_req_id           in varchar2,
    p_log_id           in number,
    p_chat_id          in number,
    p_raw_resp         out clob
  ) return clob;
  */

  procedure run_general_chat_sync(
    p_log_id         in number,
    p_model_id       in varchar2,
    p_chat_id        in number,
    p_app_user       in varchar2,
    p_app_session    in varchar2,
    p_compartment_id in varchar2,
    p_dataset        in varchar2 default null,
    p_environment    in varchar2 default null
  );

  -- Main entry point
  procedure run_job(
    p_log_id          in number,
    p_model_id        in varchar2,
    p_chat_id         in number,
    p_app_user        in varchar2,
    p_app_session     in varchar2,
    p_compartment_id  in varchar2,
    --p_endpoint        in varchar2,
    p_include_history in varchar2 default 'N',
    p_dataset         in varchar2 default null,
    p_environment     in varchar2 default null
  );
END chatbot_core_RUNNER_PKG;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_CORE_RUNNER_PKG" AS
  /*----------------------------------------------------------------------------*
   * PACKAGE: chatbot_core_runner_pkg
   *
   * PURPOSE
   *   Orchestrates the NL2SQL chatbot workflow end-to-end:
   *     - Builds a dataset/environment-scoped run context.
   *     - Fetches model configuration and constructs OCI GenAI endpoints.
   *     - Loads authored components (instructions, systems, examples, schema).
   *     - Optionally builds recent history.
   *     - Routes tables (optional feature) and clamps large inputs.
   *     - Drives the main NL2SQL loop with retries + optional rephrase step.
   *     - Generates preview JSON and a user-facing summary.
   *     - Handles lighter flows (general chat, follow-up).
   *     - Updates job status, outputs, and aggregates usage metrics.
   *
   * INTENT
   *   Centralized in chatbot_core_SQL_PKG (classify_intent_smart).
   *   Runner only calls that decision point and branches.
   *----------------------------------------------------------------------------*/

  ------------------------------------------------------------------------------
  -- Small helper: build context once per entrypoint
  ------------------------------------------------------------------------------
  function build_ctx(p_dataset in varchar2, p_environment in varchar2)
    return chatbot_core_ctx_params_pkg.run_ctx_t
  is
  begin
    return chatbot_core_ctx_params_pkg.make_ctx(
             p_dataset     => p_dataset,
             p_environment => p_environment);
  end;

  ------------------------------------------------------------------------------
  -- Local helpers (static table names)
  ------------------------------------------------------------------------------
  procedure mark_status(
    p_log_id  in number,
    p_status  in varchar2,
    p_errmsg  in varchar2 default null,
    p_start   in boolean  default false,
    p_finish  in boolean  default false
  ) is
  begin
    if p_start then
      update CHATBOT_NL2SQL_LOG
         set status = p_status, started_at = systimestamp
       where id = p_log_id;
    elsif p_finish then
      update CHATBOT_NL2SQL_LOG
         set status = p_status, finished_at = systimestamp, error_message = p_errmsg
       where id = p_log_id;
    else
      update CHATBOT_NL2SQL_LOG
         set status = p_status
       where id = p_log_id;
    end if;
  end;

  procedure set_attempt(p_log_id in number, p_n in number) is
  begin
    update CHATBOT_NL2SQL_LOG
       set attempt_number = p_n
     where id = p_log_id;
  end;

  procedure write_initial_outputs(
    p_log_id        in number,
    p_generated_sql in clob,
    p_preview_json  in clob,
    p_raw_response  in clob
  ) is
  begin
    update CHATBOT_NL2SQL_LOG
       set generated_sql = p_generated_sql,
           execution_data = p_preview_json,
           raw_response   = p_raw_response
     where id = p_log_id;
  end;
  -- rewrite for new summary pkg
  procedure write_summary(
    p_log_id      in number,
    p_summary_txt in clob,
    p_reasoned    in clob default null
  ) is
  begin
    if p_reasoned is not null then
      update CHATBOT_NL2SQL_LOG
         set summary_text    = p_summary_txt,
             reasoned_message = p_reasoned
       where id = p_log_id;
    else
      update CHATBOT_NL2SQL_LOG
         set summary_text = p_summary_txt
       where id = p_log_id;
    end if;
  end;

  procedure write_chart_spec(
    p_log_id       in number,
    p_chart_spec   in clob
  ) is
  begin
    update CHATBOT_NL2SQL_LOG
       set chart_spec_json = p_chart_spec
     where id = p_log_id;
  end;

  procedure write_metrics_totals(
    p_log_id              in number,
    p_input_chars_total   in number,
    p_output_chars_total  in number,
    p_input_tokens_total  in number,
    p_output_tokens_total in number,
    p_metrics_json        in clob
  ) is
  begin
    update CHATBOT_NL2SQL_LOG
       set input_chars_total   = p_input_chars_total,
           output_chars_total  = p_output_chars_total,
           input_tokens_total  = p_input_tokens_total,
           output_tokens_total = p_output_tokens_total,
           metrics_json        = p_metrics_json
     where id = p_log_id;
  end;

  /* Slice selected tables out of all active global JSON rows (SCHEMA + DESCRIPTIONS) */
  procedure slice_from_globals_json(
    p_ctx         in  chatbot_core_ctx_params_pkg.run_ctx_t,
    p_selected    in  sys.odcivarchar2list,    -- OWNER.TABLE list (UPPER)
    o_schema_json out clob,
    o_descr_json  out clob
  ) is
  begin
    -- === SCHEMA slice ===
    with comps as (
      select content
      from   chatbot_parameters
      where  component_type = 'SCHEMA'
        and  active = 'TRUE'
        and  (dataset = p_ctx.dataset or dataset is null)
        and  (environment = p_ctx.environment or environment is null)
    ),
    rows_unnest as (
      select upper(json_value(jt.obj,'$.name')) as tname,
            jt.obj as obj
      from   comps c,
            json_table(
              c.content,
              '$.tables[*]'
              columns (obj clob format json path '$')
            ) jt
    ),
    rows_dedup as (
      select tname, obj,
            row_number() over (partition by tname order by tname) rn
      from   rows_unnest
    ),
    rows_sel as (
      select obj
      from   rows_dedup r
      where  rn = 1
        and exists (
              select 1
              from   table(p_selected) s
              where  upper(s.column_value) = r.tname
            )
    )
    select json_object(
            'tables' value json_arrayagg(obj format json returning clob) returning clob
          )
    into   o_schema_json
    from   rows_sel;

    if o_schema_json is null then
      o_schema_json := '{"tables":[]}';
    end if;

    -- === DESCRIPTIONS slice ===
    with comps as (
      select content
      from   chatbot_parameters
      where  component_type = 'TABLE_DESCRIPTIONS'
        and  active = 'TRUE'
        and  (dataset = p_ctx.dataset or dataset is null)
        and  (environment = p_ctx.environment or environment is null)
    ),
    rows_unnest as (
      select upper(json_value(jt.obj,'$.name')) as tname,
            jt.obj as obj
      from   comps c,
            json_table(
              c.content,
              '$.tables[*]'
              columns (obj clob format json path '$')
            ) jt
    ),
    rows_dedup as (
      select tname, obj,
            row_number() over (partition by tname order by tname) rn
      from   rows_unnest
    ),
    rows_sel as (
      select obj
      from   rows_dedup r
      where  rn = 1
        and exists (
              select 1
              from   table(p_selected) s
              where  upper(s.column_value) = r.tname
            )
    )
    select json_object(
            'tables' value json_arrayagg(obj format json returning clob) returning clob
          )
    into   o_descr_json
    from   rows_sel;

    if o_descr_json is null then
      o_descr_json := '{"tables":[]}';
    end if;
  exception
    when others then
      o_schema_json := '{"tables":[]}';
      o_descr_json  := '{"tables":[]}';
  end slice_from_globals_json;

  --------------------------------------------------------------------------
  -- Extract a human-facing question for the SUMMARY prompt
  -- Strips any FOLLOWUP/SQL stitch blocks and fences, falls back to original.
  --------------------------------------------------------------------------
  FUNCTION summary_user_prompt_clean(p_raw CLOB) RETURN CLOB IS
    v   CLOB := NVL(p_raw, '');
    seg CLOB;
    v_trim CLOB;
  BEGIN
    -- If we find a stitched FOLLOW-UP block, use just that part
    seg := REGEXP_SUBSTR(
            v,
            '(?<=---\s*FOLLOW-UP\s*---)(.*?)(?=---\s*PREVIOUS\s+SQL\s*---)',
            1, 1, 'n'
          );
    IF seg IS NOT NULL THEN
      v := TRIM(seg);
    END IF;

    -- Strip code fences and residual labels if any slipped in
    v := REGEXP_REPLACE(v, '^\s*```[a-zA-Z]*\s*', '', 1, 1, 'n');
    v := REGEXP_REPLACE(v, '```(\r|\n|.)*$',       '', 1, 1, 'n');

    -- Hard-trim any LEFTOVER stitched sections (defensive)
    v := REGEXP_REPLACE(v, '---\s*PREVIOUS\s+SQL\s*---(\r|\n|.)*$', '', 1, 1, 'n');
    v := REGEXP_REPLACE(v, '---\s*OUTPUT\s*---(\r|\n|.)*$',         '', 1, 1, 'n');

    v_trim := TRIM(v);

    -- If cleaning nuked everything, fall back to original raw text
    IF v_trim IS NULL THEN
      RETURN TRIM(NVL(p_raw, ''));
    ELSE
      RETURN v_trim;
    END IF;
  END summary_user_prompt_clean;

  procedure get_model_config(
    p_model_id           in  varchar2,
    p_region             out varchar2,
    p_model_id_out       out varchar2,
    p_api_format         out varchar2,
    p_temperature        out number,
    p_top_p              out number,
    p_top_k              out number
  ) is
  begin
    select region,
           model_id,
           api_format,
           nvl(temperature,0.2),
           nvl(top_p,1),
           null
      into p_region,
           p_model_id_out,
           p_api_format,
           p_temperature,
           p_top_p,
           p_top_k
      from AI_MODEL_CONFIG
     where model_id = p_model_id;

  end;

  function endpoint_for_region(p_region varchar2) return varchar2 is
  begin
    return 'https://inference.generativeai.'||lower(p_region)||'.oci.oraclecloud.com/20231130/actions/chat';
  end;

  ------------------------------------------------------------------------------
  -- PUBLIC: run_general_chat_sync (uses unified history with mode=GENERIC)
  ------------------------------------------------------------------------------
  procedure run_general_chat_sync(
    p_log_id         in number,
    p_model_id       in varchar2,
    p_chat_id        in number,
    p_app_user       in varchar2,
    p_app_session    in varchar2,
    p_compartment_id in varchar2,
    p_dataset        in varchar2 default null,
    p_environment    in varchar2 default null
  ) is
    l_ctx                 chatbot_core_ctx_params_pkg.run_ctx_t := build_ctx(p_dataset, p_environment);
    l_req_id              varchar2(32) := rawtohex(sys_guid());
    l_region              varchar2(50);
    l_model_id_res        varchar2(1000);
    l_api_format          varchar2(50);
    l_temperature         number;
    l_top_p               number;
    l_top_k               number;
    l_endpoint            varchar2(1000);

    l_user_prompt         clob;
    l_chat_system         clob;
    l_prompt              clob;
    l_payload             clob;
    l_resp                clob;
    l_text                clob;

    l_prev_user           clob;
    l_prev_summary        clob;
    l_prev_sql            clob;
    l_hist_block          clob;
    l_context_turns       number := 10;
    l_history_max         number := 1500;

    l_in_chars  number := 0;
    l_out_chars number := 0;
    l_pt number; l_ct number;
    l_err varchar2(4000);
  begin
    mark_status(p_log_id, 'RUNNING', p_start => true);

    select user_prompt
      into l_user_prompt
      from CHATBOT_NL2SQL_LOG
     where id = p_log_id
       for update;

    -- knobs
    begin
      l_context_turns := chatbot_core_ctx_params_pkg.get_num_param(l_ctx, 'CONTEXT_TURNS',     l_context_turns);
    exception when others then null; end;
    begin
      l_history_max   := chatbot_core_ctx_params_pkg.get_num_param(l_ctx, 'HISTORY_MAX_CHARS', l_history_max);
    exception when others then null; end;

    -- unified generic history (non-NL2SQL)
    chatbot_core_sql_pkg.get_context_and_history(
      p_chat_id           => p_chat_id,
      p_log_id            => p_log_id,
      p_mode              => 'GENERIC',
      p_context_turns     => l_context_turns,
      p_history_max_chars => l_history_max,
      p_prev_user         => l_prev_user,
      p_prev_summary      => l_prev_summary,
      p_prev_sql          => l_prev_sql,
      p_history_block     => l_hist_block
    );

    l_chat_system := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'GENERAL_CHAT_SYSTEM');
    if l_chat_system is null then
      raise_application_error(-20073,
        'Missing parameter: GENERAL_CHAT_SYSTEM for '||l_ctx.dataset||'/'||l_ctx.environment);
    end if;

    declare
      l_hist_clean clob;
    begin
      -- Clamp the history block to whatever you already configured (l_history_max),
      -- and avoid forcing it through SQL-only extraction.
      l_hist_clean := case
                        when l_hist_block is not null
                        then chatbot_core_io_pkg.clamp_clob(l_hist_block, l_history_max)
                        else null
                      end;

      l_prompt := l_chat_system
                  || case when l_hist_clean is not null and dbms_lob.getlength(l_hist_clean) > 0
                          then chr(10)||'-- RECENT CONTEXT --'||chr(10)||l_hist_clean
                          else '' end
                  || chr(10)||chr(10)||chatbot_core_io_pkg.one_line(l_user_prompt);
    end;

    get_model_config(p_model_id, l_region, l_model_id_res, l_api_format,
                     l_temperature, l_top_p, l_top_k);
    l_endpoint := endpoint_for_region(l_region);

    l_in_chars := nvl(dbms_lob.getlength(l_prompt),0);

    l_payload := chatbot_core_io_pkg.build_payload_chat(
                   l_api_format, l_model_id_res, p_compartment_id, l_prompt,
                   least(l_temperature,0.7), l_top_p, l_top_k);

    chatbot_core_io_pkg.logc(l_ctx, 'GENERAL', l_req_id, 'GENERAL_CHAT Payload (sync)',
                             l_payload, p_log_id, p_chat_id);

    l_resp := chatbot_core_io_pkg.call_model(
                l_ctx, 'GENERAL', l_endpoint, l_payload, l_req_id, p_log_id, p_chat_id);

    l_text := chatbot_core_io_pkg.extract_text_from_chat_response(l_resp);
    l_out_chars := nvl(dbms_lob.getlength(l_text),0);
    chatbot_core_io_pkg.extract_usage_tokens(l_resp, l_pt, l_ct);

    -- Persist general chat answer as summary_text (no tokenization needed)
    write_summary(
      p_log_id      => p_log_id,
      p_summary_txt => l_text,
      p_reasoned    => null
    );

    update CHATBOT_NL2SQL_LOG
      set raw_response        = l_resp,
          input_chars_total   = nvl(input_chars_total,0)   + l_in_chars,
          output_chars_total  = nvl(output_chars_total,0)  + l_out_chars,
          input_tokens_total  = nvl(input_tokens_total,0)  + nvl(l_pt,0),
          output_tokens_total = nvl(output_tokens_total,0) + nvl(l_ct,0),
          metrics_json        = case
            when metrics_json is null then
                to_clob('[') ||
                to_clob('{"phase":"GENERAL_CHAT","inputChars":') || to_clob(chatbot_core_io_pkg.num_to_json(l_in_chars)) ||
                to_clob(',"outputChars":')                        || to_clob(chatbot_core_io_pkg.num_to_json(l_out_chars)) ||
                to_clob(',"promptTokens":')                       || to_clob(chatbot_core_io_pkg.num_to_json(nvl(l_pt,0))) ||
                to_clob(',"completionTokens":')                   || to_clob(chatbot_core_io_pkg.num_to_json(nvl(l_ct,0))) ||
                to_clob('}]')
            when regexp_like(metrics_json, '\]\s*$') then
                rtrim(metrics_json, ']') ||
                case when dbms_lob.getlength(metrics_json) > 2 then to_clob(',') else to_clob('') end ||
                to_clob('{"phase":"GENERAL_CHAT","inputChars":') || to_clob(chatbot_core_io_pkg.num_to_json(l_in_chars)) ||
                to_clob(',"outputChars":')                        || to_clob(chatbot_core_io_pkg.num_to_json(l_out_chars)) ||
                to_clob(',"promptTokens":')                       || to_clob(chatbot_core_io_pkg.num_to_json(nvl(l_pt,0))) ||
                to_clob(',"completionTokens":')                   || to_clob(chatbot_core_io_pkg.num_to_json(nvl(l_ct,0))) ||
                to_clob('}]')
            else metrics_json
          end,
          status              = 'SUCCEEDED',
          finished_at         = systimestamp
    where id = p_log_id;

  exception
    when others then
      l_err := substr(sqlerrm,1,3500);
      rollback;
      mark_status(p_log_id, 'FAILED', p_errmsg => 'GENERAL_CHAT (sync) failed: '||l_err, p_finish => true);
      raise;
  end run_general_chat_sync;

  ------------------------------------------------------------------------------
  -- PUBLIC: run_job (main orchestrator)
  ------------------------------------------------------------------------------
  procedure run_job(
    p_log_id          in number,
    p_model_id        in varchar2,
    p_chat_id         in number,
    p_app_user        in varchar2,
    p_app_session     in varchar2,
    p_compartment_id  in varchar2,
    p_include_history in varchar2 default 'N',
    p_dataset         in varchar2 default null,
    p_environment     in varchar2 default null
  ) is
    l_ctx                 chatbot_core_ctx_params_pkg.run_ctx_t := build_ctx(p_dataset, p_environment);
    l_req_id              varchar2(32) := rawtohex(sys_guid());

    l_region              varchar2(50);
    l_model_id_res        varchar2(1000);
    l_api_format          varchar2(50);
    l_temperature         number;
    l_top_p               number;
    l_top_k               number;
    l_endpoint            varchar2(1000);

    l_rephrase_enabled boolean := false; --disabled
    l_model_id_r          varchar2(1000);
    l_region_r            varchar2(50);
    l_api_format_r        varchar2(50);
    l_temperature_r       number;
    l_top_p_r             number;
    l_top_k_r             number;
    l_endpoint_r          varchar2(1000);

    l_instruction         clob;
    /*l_sqlqa_system        clob;   -- NEW: Oracle SQL guardrails (SQL_QA_SYSTEM)*/
    l_summary_system      clob;
    l_rephrase_system     clob;
    l_examples            clob;

    -- Optional Reasoning
    l_reasoning_enabled   varchar2(1);
    l_reasoning_system    clob;
    l_strict_sql_output  clob;
    l_raw_resp_json      clob;
    l_text_resp          clob;

    l_use_history         boolean := chatbot_core_ctx_params_pkg.as_bool(p_include_history, false);
    l_context_turns       number := 10;
    l_history_max_chars   number := 2000;
    l_history             clob;

    cap_instr     number := 8000;
    cap_schema    number := 12000;
    cap_tables    number := 12000;
    cap_examples  number := 6000;
    cap_history   number := 2000;
    cap_rephrase  number := 2000;
    cap_summary   number := 32000;

    l_candidates          sys.odcivarchar2list;
    l_router_json         clob;
    l_selected            sys.odcivarchar2list;
    l_schema_info         clob;
    l_table_joins         clob;
    l_table_desc          clob;
    l_joins_clob          clob;

    v_attempt             number := 0;
    v_max_attempts        constant number := 1;
    v_last_failed         varchar2(1) := 'Y';
    v_reasoned_msg        clob := null;

    l_user_prompt         clob;
    l_err                 varchar2(4000);
    l_intent              varchar2(40);

    -- unified outs (if history needed)
    l_prev_user           clob;
    l_prev_summary        clob;
    l_prev_sql            clob;
    l_hist_block          clob;
    l_summary_question    varchar2(4000);

    -- followup
    l_exec_mode   varchar2(30);
    l_parent_id   number;
    l_job_name    varchar2(128);
    l_summary_context     clob;

    v_input_chars_total   number := 0;
    v_output_chars_total  number := 0;
    v_input_tokens_total  number := 0;
    v_output_tokens_total number := 0;
    v_metrics_json        clob   := '[';
    v_response_sql        clob;
    v_response_raw        clob;
    v_preview_json        clob;
    v_summary_text        clob;
    l_full_json           clob;          
    l_max_full_chars      number;
  begin
    begin execute immediate 'alter session disable parallel dml'; exception when others then null; end;

    mark_status(p_log_id, 'RUNNING', p_start => true);

    select user_prompt
      into l_user_prompt
      from CHATBOT_NL2SQL_LOG
     where id = p_log_id;

    -- Compute a stable question string for SUMMARY once, based on the original LOG row.
    -- We purposely do this BEFORE any FOLLOWUP stitching / intent logic mutates l_user_prompt.
    l_summary_question :=
      SUBSTR(
        NVL(
          summary_user_prompt_clean(l_user_prompt),
          NVL(l_user_prompt, '(no user question)')
        ),
        1,
        3900
      );

    -- Hard fallback if cleaning somehow produced NULL/empty
    IF l_summary_question IS NULL OR TRIM(l_summary_question) IS NULL THEN
      BEGIN
        SELECT NVL(user_prompt,'(no user question)')
          INTO l_summary_question
          FROM CHATBOT_NL2SQL_LOG
         WHERE id = p_log_id;

        l_summary_question :=
          SUBSTR(NVL(l_summary_question,'(no user question)'), 1, 3900);
      EXCEPTION
        WHEN OTHERS THEN
          l_summary_question := '(no user question)';
      END;
    END IF;

    -- Debug: see what we actually pass to SUMMARY
    BEGIN
      CHATBOT_CORE_IO_PKG.logc(
        l_ctx, 'SUMMARY', l_req_id,
        'Effective SUMMARY question',
        CHATBOT_CORE_IO_PKG.clamp_clob(l_summary_question, 500),
        p_log_id, p_chat_id
      );
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;

    begin
      select exec_mode, parent_id, job_name
        into l_exec_mode, l_parent_id, l_job_name
        from CHATBOT_NL2SQL_LOG
      where id = p_log_id;
    exception
      when others then
        l_exec_mode := 'INITIAL';
        l_parent_id := null;
        l_job_name  := null;
    end;

    -- Backfill INTENT label/score for follow-up children (defensive)
    begin
      if l_parent_id is not null
        and upper(nvl(l_exec_mode,'INITIAL')) in ('FOLLOWUP_REWRITE','FOLLOWUP_ANSWER')
      then
        update CHATBOT_NL2SQL_LOG t
          set t.intent_label =
                coalesce(t.intent_label,
                          case when upper(l_exec_mode)='FOLLOWUP_REWRITE'
                              then 'FOLLOWUP_REWRITE'
                              else 'GENERAL_CHAT'
                          end),
              t.intent_score10 =
                coalesce(
                  t.intent_score10,
                  (select intent_score10
                      from CHATBOT_NL2SQL_LOG p
                    where p.id = l_parent_id),
                  9  -- last-resort default
                )
        where t.id = p_log_id;
      end if;
    exception when others then null; end;

    chatbot_core_io_pkg.logv(l_ctx, 'GENERAL', l_req_id,
      'RUNNER start; log_id='||p_log_id||', chat_id='||p_chat_id||', model_id='||p_model_id,
      p_log_id, p_chat_id);

    get_model_config(p_model_id, l_region, l_model_id_res, l_api_format,
                     l_temperature, l_top_p, l_top_k);
    l_endpoint := endpoint_for_region(l_region);

    -- EARLY history hydrate so fast-path can see prior SQL
    declare
      l_cturns   number := 10;
      l_hist_max number := 1500;
    begin
      begin
        l_cturns := chatbot_core_ctx_params_pkg.get_num_param(l_ctx,'CONTEXT_TURNS', l_cturns);
      exception when others then null; end;
      begin
        l_hist_max := chatbot_core_ctx_params_pkg.get_num_param(l_ctx,'HISTORY_MAX_CHARS', l_hist_max);
      exception when others then null; end;

      -- Always include prior SQL turn (honor CONTEXT_TURNS but prioritize NL2SQL)
      chatbot_core_sql_pkg.get_context_and_history(
        p_chat_id           => p_chat_id,
        p_log_id            => p_log_id,
        p_mode              => 'NL2SQL',
        p_context_turns     => l_cturns,
        p_history_max_chars => l_hist_max,
        p_prev_user         => l_prev_user,
        p_prev_summary      => l_prev_summary,
        p_prev_sql          => l_prev_sql,
        p_history_block     => l_hist_block
      );
    end;
    -- FAST PATH:
    --  - If EXECUTE_SQL_NO_CLARIFY: execute SQL directly (unchanged behavior)
    --  - If JOBHINT:FOLLOWUP_USE_PREV_SQL: stitch follow-up + previous SQL and continue to NL2SQL
    declare
      v_hint_txt       clob;
      v_sql_ready      clob;
      v_preview_json   clob;
      v_summary_text   clob;
      l_summary_system clob;
      l_raw_resp_s     clob;
    begin
      /* Read both columns once; keep FOR UPDATE if you already rely on it for sequencing */
      select reasoned_message, generated_sql
        into v_hint_txt, v_sql_ready
        from CHATBOT_NL2SQL_LOG
      where id = p_log_id;

      /* -------- Hints + FOLLOW-UP stitching (single source of truth) -------- */
      declare
        l_stitched_block  clob := null;
        l_is_followup_rw  boolean := false;
      begin
        /* 1) Immediate execute path (unchanged semantics, now using SUMMARY_PKG) */
        if v_hint_txt is not null
          and regexp_like(v_hint_txt, 'JOBHINT:EXECUTE_SQL_NO_CLARIFY', 'i')
        then
          chatbot_core_io_pkg.logv(
            l_ctx, 'NL2SQL', l_req_id,
            'FAST PATH detected (JOBHINT:EXECUTE_SQL_NO_CLARIFY) — executing SQL directly.',
            p_log_id, p_chat_id
          );

          -- Execute the already-prepared SQL and build a 50-row preview
          v_preview_json := chatbot_core_sql_pkg.fetch_preview_json(v_sql_ready, 50);
          write_initial_outputs(p_log_id, v_sql_ready, v_preview_json, null);

          -- SUMMARY on the preview JSON only (matching old behavior:
          -- summarize the executed SQL without re-running NL2SQL).
          begin
            declare
              l_json_for_summary CLOB;
              -- preview = partial result set → mark as not complete
              l_meta_json        CLOB := '{"is_complete":false,"limit":50,"offset":0}';
              l_use_llm          BOOLEAN := TRUE;
              -- chart
              l_chart_raw        CLOB;
              l_chart_json       CLOB;
            begin
              l_json_for_summary := chatbot_core_io_pkg.clamp_clob(
                                      nvl(v_preview_json,'{}'),
                                      cap_summary);

              v_summary_text := CHATBOT_CORE_SUMMARY_PKG.Render_Auto(
                                  p_context_query  => l_summary_question,
                                  p_plan_json      => '{}',          -- no reasoning plan in fast path
                                  p_rows_json      => l_json_for_summary,
                                  p_meta_json      => l_meta_json,
                                  p_ctx            => l_ctx,
                                  p_req_id         => l_req_id,
                                  p_log_id         => p_log_id,
                                  p_chat_id        => p_chat_id,
                                  p_use_llm        => l_use_llm,
                                  p_endpoint       => l_endpoint,
                                  p_api_format     => l_api_format,
                                  p_model_id       => l_model_id_res,
                                  p_compartment_id => p_compartment_id,
                                  p_temperature    => l_temperature,
                                  p_top_p          => l_top_p,
                                  p_top_k          => l_top_k
                                );

              -- CHART suggestion (fast path)
              begin
                l_chart_json := CHATBOT_CORE_CHART_PKG.Suggest_Chart_Spec(
                  p_context_query  => l_summary_question,
                  p_rows_json      => l_json_for_summary,
                  p_plan_json      => '{}',  -- no reasoning in fast path
                  p_ctx            => l_ctx,
                  p_req_id         => l_req_id,
                  p_log_id         => p_log_id,
                  p_chat_id        => p_chat_id,
                  p_endpoint       => l_endpoint,
                  p_api_format     => l_api_format,
                  p_model_id       => l_model_id_res,
                  p_compartment_id => p_compartment_id,
                  p_temperature    => l_temperature,
                  p_top_p          => l_top_p,
                  p_top_k          => l_top_k,
                  o_raw_response   => l_chart_raw
                );

                if l_chart_json is not null then
                  write_chart_spec(p_log_id, l_chart_json);
                end if;
              exception
                when others then
                  CHATBOT_CORE_IO_PKG.logv(
                    l_ctx, 'CHART', l_req_id,
                    'Fast-path chart suggestion failed: '||substr(sqlerrm,1,800),
                    p_log_id, p_chat_id
                  );
              end;
            exception
              when others then
                chatbot_core_io_pkg.logv(
                  l_ctx,'SUMMARY',l_req_id,
                  'Fast-path SUMMARY failed: '||substr(sqlerrm,1,800),
                  p_log_id,p_chat_id
                );
                v_summary_text :=
                  to_clob('Query executed and preview JSON is available. Open the results panel for details.');
            end;

            write_summary(p_log_id, v_summary_text, null);
          end;

          mark_status(p_log_id, 'SUCCEEDED', p_finish => true);
          return;
        end if;

        /* 2) FOLLOW-UP rewrite detection + stitched prompt (restored as before) */
        l_is_followup_rw := (v_hint_txt is not null
                            and regexp_like(v_hint_txt, 'JOBHINT:FOLLOWUP_USE_PREV_SQL', 'i'));

        declare
          has_recent_sql boolean := (l_prev_sql is not null);
        begin
          l_is_followup_rw := l_is_followup_rw and has_recent_sql;
        end;

        -- Ensure child has label/score when taking FOLLOWUP fast-path
        begin
          if upper(nvl(l_exec_mode,'INITIAL'))='FOLLOWUP_REWRITE' then
            update CHATBOT_NL2SQL_LOG t
              set t.intent_label =
                    coalesce(t.intent_label, 'FOLLOWUP_CLARIFY'),
                  t.intent_score10 =
                    coalesce(
                      t.intent_score10,
                      (select intent_score10
                         from CHATBOT_NL2SQL_LOG p
                        where p.id = l_parent_id),
                      9
                    )
            where t.id = p_log_id;
          end if;
        exception when others then null; end;

        if l_is_followup_rw then
          -- Prefer the stitched block left by FOLLOWUP_PKG for determinism
          begin
            l_stitched_block := REGEXP_SUBSTR(
                v_hint_txt,
                '\[FOLLOWUP_STITCH_PROMPT\]\s*(.*)$',
                1, 1, 'n', 1);
            CHATBOT_CORE_IO_PKG.logc(
              l_ctx, 'FOLLOWUP', l_req_id,
              'FOLLOWUP_STITCH_APPLIED (effective question)',
              CHATBOT_CORE_IO_PKG.clamp_clob(l_stitched_block, 1200),
              p_log_id, p_chat_id
            );
          exception when others then l_stitched_block := null; end;

          if l_stitched_block is not null and length(trim(l_stitched_block)) > 0 then
            l_user_prompt := trim(l_stitched_block);
          else
            -- Fallback: build on the child row’s generated_sql (which FOLLOWUP_PKG populated with prev SQL)
            /*l_user_prompt :=
              'Apply this follow-up to the previous SQL.'||chr(10)||
              '--- FOLLOW-UP ---'||chr(10)||nvl(CHATBOT_CORE_IO_PKG.one_line(l_user_prompt),'(missing)')||chr(10)||
              '--- PREVIOUS SQL ---'||chr(10)||nvl(v_sql_ready,'(missing)')||chr(10)||
              '--- RULES ---'||chr(10)||
              '- Use ONLY columns that exist in the referenced tables shown or implied by the previous SQL.'||chr(10)||
              '- If the follow-up mentions a field with no matching column, do NOT invent a new column; omit it or ask to map it.'||chr(10)||
              '- Preserve existing filters/joins unless explicitly changed.'||chr(10)||
              '--- OUTPUT ---'||chr(10)||
              'Return exactly one Oracle SQL SELECT and nothing else. No markdown, no code fences, no prose.';*/
            l_user_prompt :=
              'Apply this follow-up to the previous SQL.'||chr(10)||
              '--- FOLLOW-UP ---'||chr(10)||nvl(CHATBOT_CORE_IO_PKG.one_line(l_user_prompt),'(missing)')||chr(10)||
              case when l_prev_summary is not null then
                  '--- PREVIOUS SUMMARY ---'||chr(10)||CHATBOT_CORE_IO_PKG.clamp_clob(l_prev_summary, 1200)||chr(10)
              else '' end||
              '--- PREVIOUS SQL ---'||chr(10)||nvl(v_sql_ready,'(missing)')||chr(10)||
              '--- RULES ---'||chr(10)||
              '- Use ONLY columns that exist in the referenced tables shown or implied by the previous SQL.'||chr(10)||
              '- If the follow-up mentions a field with no matching column, do NOT invent a new column; omit it or ask to map it.'||chr(10)||
              '- Preserve existing filters/joins unless explicitly changed.'||chr(10)||
              '--- OUTPUT ---'||chr(10)||
              'Return exactly one Oracle SQL SELECT and nothing else. No markdown, no code fences, no prose.';
          end if;

          -- Trace (hidden from UI)
          begin
            CHATBOT_CORE_IO_PKG.logc(
              l_ctx, 'FOLLOWUP', l_req_id,
              'FOLLOWUP_STITCH_APPLIED (effective question)',
              CHATBOT_CORE_IO_PKG.clamp_clob(l_user_prompt, 1200),
              p_log_id, p_chat_id
            );
          exception when others then null; end;
        end if;

        -- Persist a tiny flag in reasoned_message for later checks (non-fatal)
        begin
          if l_is_followup_rw then
            update CHATBOT_NL2SQL_LOG
              set reasoned_message = nvl(reasoned_message,'') || chr(10) || '[NOTE] Runner stitched FOLLOWUP_REWRITE.'
            where id = p_log_id;
          end if;
        exception when others then null; end;
      end;

    exception
      when others then
        null; -- preserve original behavior; downstream path will still run
    end;

    -- ============================================================
    -- 1) CENTRALIZED INTENT (ALWAYS FIRST)
    -- ============================================================
    declare
      r_intent chatbot_core_sql_pkg.intent_result_t;
    begin
      chatbot_core_sql_pkg.resolve_intent(
        p_ctx            => l_ctx,
        p_text           => l_user_prompt,
        p_api_format     => l_api_format,
        p_model_id       => l_model_id_res,
        p_compartment_id => p_compartment_id,
        p_region         => l_region,
        p_req_id         => l_req_id,
        p_log_id         => p_log_id,
        p_chat_id        => p_chat_id,
        p_threshold      => null,
        p_persist        => true,    -- writes INTENT_LABEL + INTENT_SCORE10
        p_result         => r_intent
      );
      l_intent := r_intent.label;

      chatbot_core_io_pkg.logv(l_ctx, 'INTENT', l_req_id,
        'RESOLVED | intent='||l_intent||
        ', needs_clarify='||case when r_intent.needs_clarify then 'Y' else 'N' end,
        p_log_id, p_chat_id);

      -- Accept either previous SQL or previous SUMMARY as sufficient context
      declare
        l_cturns number := 10;
        has_recent_context boolean := false;
        l_hist_max number := 1500;
      begin
        begin
          l_cturns  := chatbot_core_ctx_params_pkg.get_num_param(l_ctx,'CONTEXT_TURNS', l_cturns);
        exception when others then null; end;
        begin
          l_hist_max := chatbot_core_ctx_params_pkg.get_num_param(l_ctx,'HISTORY_MAX_CHARS', l_hist_max);
        exception when others then null; end;

        -- Already hydrated earlier; only reload if still empty (defensive).
        if l_prev_sql is null and l_prev_user is null and l_hist_block is null then
          chatbot_core_sql_pkg.get_context_and_history(
            p_chat_id           => p_chat_id,
            p_log_id            => p_log_id,
            p_mode              => 'NL2SQL',
            p_context_turns     => l_cturns,
            p_history_max_chars => l_hist_max,
            p_prev_user         => l_prev_user,
            p_prev_summary      => l_prev_summary,
            p_prev_sql          => l_prev_sql,
            p_history_block     => l_hist_block
          );
        end if;
        -- We might have only summary in window after the SUMMARY refactor
        has_recent_context := (l_prev_sql is not null or l_prev_summary is not null);

        -- Only downshift to GENERAL if we truly have no recent context
        if l_intent = 'FOLLOWUP_CLARIFY' and not has_recent_context then
          update CHATBOT_NL2SQL_LOG
            set intent_label = 'GENERAL_CHAT', intent_score10 = null
          where id = p_log_id;
          run_general_chat_sync(p_log_id, l_model_id_res, p_chat_id, p_app_user, p_app_session,
                      p_compartment_id, l_ctx.dataset, l_ctx.environment);
          return;
        end if;
      end;

      -- Force FOLLOWUP_ANSWER to use GENERAL chat style/output
      IF UPPER(NVL(l_exec_mode,'INITIAL')) = 'FOLLOWUP_ANSWER' THEN
        BEGIN
          UPDATE CHATBOT_NL2SQL_LOG
            SET intent_label = 'GENERAL_CHAT'
          WHERE id = p_log_id;
        EXCEPTION WHEN OTHERS THEN NULL; END;

        -- Make the runner take the GENERAL_CHAT path (uses GENERAL_CHAT_SYSTEM)
        l_intent := 'GENERAL_CHAT';
      END IF;

      IF r_intent.label = 'FOLLOWUP_CLARIFY' 
        AND NVL(l_exec_mode,'INITIAL') = 'INITIAL'
        AND l_parent_id IS NULL
        AND l_job_name IS NULL
      THEN
        -- Hand off to the new followup orchestrator unconditionally
        UPDATE CHATBOT_NL2SQL_LOG
          SET intent_label = 'FOLLOWUP_CLARIFY'
        WHERE id = p_log_id;
        COMMIT;

        CHATBOT_FOLLOWUP_PKG.run_followup(
          p_log_id         => p_log_id,
          p_model_id       => l_model_id_res,
          p_chat_id        => p_chat_id,
          p_app_user       => p_app_user,
          p_app_session    => p_app_session,
          p_compartment_id => p_compartment_id,
          p_dataset        => l_ctx.dataset,
          p_environment    => l_ctx.environment
        );
        RETURN;
      END IF;

    end;

    -- If launched by DBMS_SCHEDULER, only force NL2SQL for SQL-type intents.
    declare
      v_job_name varchar2(128);
    begin
      select job_name
        into v_job_name
        from CHATBOT_NL2SQL_LOG
      where id = p_log_id;

      if v_job_name is not null then
        case upper(nvl(l_intent,''))
          when 'GENERAL_CHAT' then
            -- Honor GENERAL_CHAT, but let the glossary pass run first.
            null;

          when 'FOLLOWUP_CLARIFY' then
            -- Let the FOLLOWUP handoff below run as-is (no override)
            null;

          else
            -- NL2SQL (or anything non-general) is forced to NL2SQL
            l_intent := 'NL2SQL';
            chatbot_core_io_pkg.logv(
              l_ctx, 'BRANCH', l_req_id,
              'FORCE_NL2SQL_BY_SCHEDULER',
              p_log_id, p_chat_id
            );
        end case;
      end if;
    exception
      when no_data_found then null;
    end;

    -- ============================================================
    -- 2) GENERAL_CHAT branch → try GLOSSARY only if *definitional*
    -- ============================================================
    if l_intent = 'GENERAL_CHAT' then
      declare
        -- quick heuristic (cheap and safe). If this says TRUE, we still verify with LLM gate below.
        is_def_heur   boolean :=
          regexp_like(lower(l_user_prompt),
            '^\s*(what\s+is|what''s|define|definition|explain|meaning of|difference between)\b');

        -- tiny LLM boolean gate: returns just Y/N
        is_def_llm    boolean := false;
        gate_prompt   clob;
        gate_payload  clob;
        gate_resp     clob;
        gate_text     clob;

        -- glossary quick match
        g_json    clob;
        j         json_object_t;
        g_score   number := 0;
        g_thresh  number := chatbot_core_ctx_params_pkg.get_num_param(l_ctx,'GLOSSARY_THRESHOLD_SCORE10',0.38);
        g_excerpt clob;

        g_sys     clob;
        g_payload clob;
        g_resp    clob;
        g_ans     clob;
        l_pt number; l_ct number;
        l_in_chars number := 0; l_out_chars number := 0;
      begin
        -- LLM definitional gate (deterministic, tiny prompt)
        if not is_def_heur then
          gate_prompt := to_clob(
            'Return only Y or N.'||chr(10)||
            'Question: Is this a definitional/terminology question that should be answered from a glossary (definitions, meanings, differences, acronyms)?'||chr(10)||
            'User: '||chatbot_core_io_pkg.one_line(l_user_prompt)||chr(10)||
            'Answer:'
          );

          gate_payload := chatbot_core_io_pkg.build_payload_chat(
                            l_api_format, l_model_id_res, p_compartment_id, gate_prompt,
                            0, 1, 1);
          chatbot_core_io_pkg.logc(l_ctx, 'GLOSSARY_GATE', l_req_id, 'Definitional Gate Payload',
                                   gate_payload, p_log_id, p_chat_id);
          gate_resp := chatbot_core_io_pkg.call_model(
                         l_ctx, 'GLOSSARY_GATE', l_endpoint, gate_payload, l_req_id, p_log_id, p_chat_id);
          gate_text := upper(regexp_substr(chatbot_core_io_pkg.extract_text_from_chat_response(gate_resp),'[A-Z]'));
          is_def_llm := (gate_text = 'Y');
        end if;

        if (is_def_heur or is_def_llm) then
          -- Now and only now, check glossary similarity
          g_json := chatbot_core_sql_pkg.glossary_lookup_quick_text(
                      p_ctx       => l_ctx,
                      p_query     => l_user_prompt,
                      p_max_chars => 2500,
                      p_threshold => g_thresh);

          if g_json is not null then
            select nvl(json_value(g_json,'$.match_score' returning number),0),
                   json_value(g_json,'$.excerpt' returning clob)
              into g_score, g_excerpt
              from dual;
          end if;

          if g_score >= g_thresh and g_excerpt is not null then
            g_sys := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'GLOSSARY_EXTRACT_SYSTEM');
            IF g_sys IS NULL THEN
              -- No system prompt configured → skip glossary path and go GENERAL
              chatbot_core_io_pkg.logv(l_ctx, 'GLOSSARY', l_req_id,
                'GLOSSARY_EXTRACT_SYSTEM missing; routing to GENERAL_CHAT.', p_log_id, p_chat_id);

              run_general_chat_sync(
                p_log_id, l_model_id_res, p_chat_id, p_app_user, p_app_session,
                p_compartment_id, l_ctx.dataset, l_ctx.environment
              );
              RETURN;
            END IF;

            g_payload := chatbot_core_io_pkg.build_payload_chat(
                            l_api_format, l_model_id_res, p_compartment_id,
                            g_sys||chr(10)||chr(10)||
                            '-- GLOSSARY --'||chr(10)||g_excerpt||chr(10)||chr(10)||
                            '-- USER QUESTION --'||chr(10)||chatbot_core_io_pkg.one_line(l_user_prompt),
                            least(l_temperature,0.2), l_top_p, l_top_k);

            chatbot_core_io_pkg.logc(l_ctx, 'GLOSSARY', l_req_id, 'Glossary Extract Payload',
                                     g_payload, p_log_id, p_chat_id);

            g_resp := chatbot_core_io_pkg.call_model(
                        l_ctx, 'GLOSSARY', l_endpoint, g_payload, l_req_id, p_log_id, p_chat_id);

            g_ans := chatbot_core_io_pkg.extract_text_from_chat_response(g_resp);
            -- If the system tells us there is no match, route to GENERAL.
            IF TRIM(UPPER(NVL(g_ans,''))) = 'NO_GLOSSARY_MATCH' THEN
              chatbot_core_io_pkg.logv(l_ctx, 'GLOSSARY', l_req_id,
                'NO_GLOSSARY_MATCH token received; routing to GENERAL_CHAT.', p_log_id, p_chat_id);

              -- Label as GENERAL and continue through the standard general-chat flow
              BEGIN
                UPDATE CHATBOT_NL2SQL_LOG
                  SET INTENT_LABEL   = 'GENERAL_CHAT',
                      INTENT_SCORE10 = NULL
                WHERE id = p_log_id;
              EXCEPTION WHEN OTHERS THEN NULL; END;

              run_general_chat_sync(
                p_log_id, l_model_id_res, p_chat_id, p_app_user, p_app_session,
                p_compartment_id, l_ctx.dataset, l_ctx.environment
              );
              RETURN;
            END IF;
            l_in_chars  := dbms_lob.getlength(g_payload);
            l_out_chars := nvl(dbms_lob.getlength(g_ans),0);
            chatbot_core_io_pkg.extract_usage_tokens(g_resp, l_pt, l_ct);

            -- Label as GLOSSARY and persist score from matcher
            begin
              update CHATBOT_NL2SQL_LOG
                 set INTENT_LABEL   = 'GLOSSARY',
                     INTENT_SCORE10 = case when g_score is not null then round(10*g_score) end,
                     summary_text   = g_ans,
                     raw_response   = g_resp,
                     input_chars_total   = nvl(input_chars_total,0)   + l_in_chars,
                     output_chars_total  = nvl(output_chars_total,0)  + l_out_chars,
                     input_tokens_total  = nvl(input_tokens_total,0)  + nvl(l_pt,0),
                     output_tokens_total = nvl(output_tokens_total,0) + nvl(l_ct,0),
                     metrics_json =
                        case
                          when metrics_json is null then
                            TO_CLOB('[') ||
                            TO_CLOB('{"phase":"GLOSSARY","inputChars":') || TO_CLOB(chatbot_core_io_pkg.num_to_json(l_in_chars)) ||
                            TO_CLOB(',"outputChars":')                   || TO_CLOB(chatbot_core_io_pkg.num_to_json(l_out_chars)) ||
                            TO_CLOB(',"promptTokens":')                  || TO_CLOB(chatbot_core_io_pkg.num_to_json(nvl(l_pt,0))) ||
                            TO_CLOB(',"completionTokens":')              || TO_CLOB(chatbot_core_io_pkg.num_to_json(nvl(l_ct,0))) ||
                            TO_CLOB(',"score":')                         || TO_CLOB(chatbot_core_io_pkg.num_to_json(g_score)) ||
                            TO_CLOB('}]')
                          when regexp_like(metrics_json, '\]\s*$') then
                            regexp_replace(metrics_json, '\]\s*$', '') ||
                            TO_CLOB(',{"phase":"GLOSSARY","inputChars":') || TO_CLOB(chatbot_core_io_pkg.num_to_json(l_in_chars)) ||
                            TO_CLOB(',"outputChars":')                    || TO_CLOB(chatbot_core_io_pkg.num_to_json(l_out_chars)) ||
                            TO_CLOB(',"promptTokens":')                   || TO_CLOB(chatbot_core_io_pkg.num_to_json(nvl(l_pt,0))) ||
                            TO_CLOB(',"completionTokens":')               || TO_CLOB(chatbot_core_io_pkg.num_to_json(nvl(l_ct,0))) ||
                            TO_CLOB(',"score":')                          || TO_CLOB(chatbot_core_io_pkg.num_to_json(g_score)) ||
                            TO_CLOB('}]')
                          else metrics_json
                        end,
                     status      = 'SUCCEEDED',
                     finished_at = systimestamp
               where id = p_log_id;
            exception when others then null; end;

            commit;
            return;
          end if; -- glossary match present
        end if;   -- definitional
      exception when others then
        chatbot_core_io_pkg.logv(l_ctx, 'GLOSSARY', l_req_id,
          'Glossary path skipped due to error: '||substr(sqlerrm,1,800), p_log_id, p_chat_id);
      end;

      -- Not definitional or no glossary hit → plain GENERAL_CHAT
      run_general_chat_sync(
        p_log_id, l_model_id_res, p_chat_id, p_app_user, p_app_session,
        p_compartment_id, l_ctx.dataset, l_ctx.environment
      );
      return;

    -- ============================================================
    -- 3) NL2SQL
    -- ============================================================
    elsif l_intent = 'NL2SQL' then
      null;  -- fall through to your existing NL2SQL build/loop below
    end if;

    -- Instruction selection depends on exec_mode
    if upper(nvl(l_exec_mode,'INITIAL')) = 'FOLLOWUP_REWRITE' then
      -- FOLLOW-UP mode: use minimal SQL patching system, NOT the full NL2SQL generator.
      l_instruction := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'FOLLOWUP_SQL_SYSTEM');

      if l_instruction is null then
        raise_application_error(
          -20071,
          'Missing parameter: FOLLOWUP_SQL_SYSTEM for '||
          l_ctx.dataset||'/'||l_ctx.environment
        );
      end if;
    else
      -- Normal NL2SQL generation
      l_instruction := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'NL2SQL_INSTRUCTION');
      if l_instruction is null then
        l_instruction := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'INSTRUCTION');
        if l_instruction is null then
          raise_application_error(
            -20071,
            'Missing parameter: NL2SQL_INSTRUCTION (and legacy INSTRUCTION) for '||
            l_ctx.dataset||'/'||l_ctx.environment
          );
        end if;
      end if;
    end if;

    -- reasoning toggle via existing ctx getter
    l_reasoning_enabled := NVL(chatbot_core_ctx_params_pkg.get_param_value(l_ctx, 'REASONING_ENABLED'),'N');

    -- HARD OVERRIDE for follow-up modes
    begin
      -- 1) exec_mode says this is a FOLLOWUP_REWRITE child → NEVER reason
      if upper(nvl(l_exec_mode,'INITIAL')) = 'FOLLOWUP_REWRITE' then
        l_reasoning_enabled := 'N';

      -- 2) exec_mode says this is a FOLLOWUP_NEW child → ALWAYS reason
      elsif upper(nvl(l_exec_mode,'INITIAL')) = 'FOLLOWUP_NEW' then
        l_reasoning_enabled := 'Y';
      end if;

      -- 3) (belt & suspenders) detect the FOLLOWUP hint on this row
      if l_reasoning_enabled = 'Y' then
        declare v_hint_txt clob;
        begin
          select reasoned_message into v_hint_txt
            from CHATBOT_NL2SQL_LOG
          where id = p_log_id;
          if v_hint_txt is not null
            and regexp_like(v_hint_txt, 'JOBHINT:FOLLOWUP_USE_PREV_SQL', 'i')
          then
            -- If row was accidentally marked as FOLLOWUP_USE_PREV_SQL, still disable reasoning
            l_reasoning_enabled := 'N';
          end if;
        exception when others then null; end;
      end if;
    exception when others then null; end;

    -- Load/clear the system based on the final flag
    if l_reasoning_enabled = 'Y' then
      l_reasoning_system := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'REASONING_SYSTEM');
      if l_reasoning_system is null then
        raise_application_error(-20072,
          'REASONING_ENABLED=Y but REASONING_SYSTEM is missing for '||
          l_ctx.dataset||'/'||l_ctx.environment);
      end if;
    else
      l_reasoning_system := null;
    end if;

    -- Log FINAL Reasoning
    CHATBOT_CORE_IO_PKG.logv(
      l_ctx, 'REASONING', l_req_id,
      'enabled='||l_reasoning_enabled||', exec_mode='||nvl(l_exec_mode,'INITIAL'),
      p_log_id, p_chat_id);

    -- summary
    l_summary_system  := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'SUMMARY_SYSTEM');
    if l_rephrase_enabled then
        l_rephrase_system := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'REPHRASE_SYSTEM');
    else
        l_rephrase_system := null;
    end if;

    -- strict SQL-only contract (required)
    l_strict_sql_output := CHATBOT_CORE_CTX_PARAMS_PKG.load_component(l_ctx, 'STRICT_SQL_OUTPUT');
    if l_strict_sql_output is null then
      raise_application_error(-20074, 'Missing STRICT_SQL_OUTPUT for '||
                                      l_ctx.dataset||'/'||l_ctx.environment);
    end if;

    -- examples
    l_examples := null;
    for r in (
      select content,
             nvl(json_value(content,'$.order' returning number), id) as ord,
             case
               when dataset=l_ctx.dataset and environment=l_ctx.environment then 1
               when dataset=l_ctx.dataset and environment is null          then 2
               when dataset is null     and environment=l_ctx.environment  then 3
               when dataset is null     and environment is null            then 4
               else 9
             end rnk
        from CHATBOT_PARAMETERS
       where component_type = 'EXAMPLE'
         and active = 'TRUE'
         and (dataset = l_ctx.dataset or dataset is null)
         and (environment = l_ctx.environment or environment is null)
       order by rnk, ord
    ) loop
      declare
        v_q varchar2(32767);
        v_s varchar2(32767);
      begin
        select json_value(r.content, '$.user_question' returning varchar2(32767)),
              json_value(r.content, '$.oracle_sql'   returning varchar2(32767))
          into v_q, v_s
          from dual;

        l_examples := nvl(l_examples, to_clob(''))
                      || 'Q: '|| to_clob(v_q) || chr(10)
                      || 'A: '|| to_clob(v_s) || chr(10) || chr(10);
      exception when others then
        null;
      end;
    end loop;

    -- routing
    IF upper(nvl(l_exec_mode,'INITIAL')) = 'FOLLOWUP_REWRITE' THEN
      -- FOLLOWUP_REWRITE:
      --   - Do NOT route
      --   - Do NOT load global SCHEMA/TABLE_DESCRIPTIONS
      --   - Let the model rewrite purely based on FOLLOW-UP + PREVIOUS SQL
      l_schema_info := NULL;
      l_table_desc  := NULL;

      CHATBOT_CORE_IO_PKG.logv(
        l_ctx, 'ROUTER', l_req_id,
        'FOLLOWUP_REWRITE: skipping router and SCHEMA/TABLE_DESCRIPTIONS.',
        p_log_id, p_chat_id
      );
    ELSE
      DECLARE
        l_routing_enabled BOOLEAN := chatbot_core_ctx_params_pkg.is_routing_enabled(l_ctx);
      BEGIN
        IF l_routing_enabled THEN
          l_candidates  := chatbot_core_sql_pkg.prefilter_table_candidates(l_ctx, l_user_prompt, 12);
          l_router_json := chatbot_core_sql_pkg.route_tables(
                            l_ctx, l_user_prompt, l_candidates, l_req_id, p_log_id, p_chat_id,
                            l_api_format, l_model_id_res, p_compartment_id, l_temperature, l_top_p,
                            l_top_k, l_endpoint);
          chatbot_core_io_pkg.logc(l_ctx, 'ROUTER', l_req_id, 'Router JSON', nvl(l_router_json,'[NULL]'), p_log_id, p_chat_id);

          l_selected := chatbot_core_sql_pkg.parse_router_tables(l_router_json);

          -- First try legacy chunk path (kept for backward-compat)
          chatbot_core_sql_pkg.load_authored_chunks_for_selected(
            l_ctx, l_selected, l_schema_info, l_table_desc, true);

          -- If chunk path returned empty or non-JSON, slice from global JSON rows
          IF (l_selected IS NOT NULL AND l_selected.COUNT > 0) AND
             (l_schema_info IS NULL OR l_table_desc IS NULL
               OR NOT json_exists(l_schema_info, '$.tables')
               OR NOT json_exists(l_table_desc,  '$.tables'))
          THEN
            CHATBOT_CORE_IO_PKG.logv(
              l_ctx,'ROUTER',l_req_id,
              'Chunk slicer empty; slicing from global JSON.',
              p_log_id, p_chat_id
            );
            slice_from_globals_json(l_ctx, l_selected, l_schema_info, l_table_desc);
          END IF;

          -- If still nothing (or router returned 0), fall back to full globals
          IF (l_selected IS NULL OR l_selected.COUNT = 0)
             OR l_schema_info IS NULL OR l_table_desc IS NULL
             OR NOT json_exists(l_schema_info, '$.tables')
             OR NOT json_exists(l_table_desc,  '$.tables')
          THEN
            l_schema_info := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'SCHEMA');
            l_table_desc  := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'TABLE_DESCRIPTIONS');
            CHATBOT_CORE_IO_PKG.logv(
              l_ctx, 'ROUTER', l_req_id,
              'Using global SCHEMA/TABLE_DESCRIPTIONS fallback.',
              p_log_id, p_chat_id
            );
          END IF;

        ELSE
          -- routing disabled → full globals
          l_schema_info := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'SCHEMA');
          l_table_desc  := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'TABLE_DESCRIPTIONS');
          chatbot_core_io_pkg.logv(
            l_ctx, 'ROUTER', l_req_id,
            'Routing disabled; using global SCHEMA/TABLE_DESCRIPTIONS only.',
            p_log_id, p_chat_id
          );
        END IF;
      END;
    END IF;

    l_joins_clob := chatbot_core_ctx_params_pkg.load_component(l_ctx, 'TABLE_JOINS');

    -- caps
    cap_instr    := chatbot_core_ctx_params_pkg.get_num_param(l_ctx, 'MAX_INSTRUCTION_CHARS', cap_instr);
    cap_schema   := chatbot_core_ctx_params_pkg.get_num_param(l_ctx, 'MAX_SCHEMA_CHARS',      cap_schema);
    cap_tables   := chatbot_core_ctx_params_pkg.get_num_param(l_ctx, 'MAX_TABLEDESC_CHARS',   cap_tables);
    cap_examples := chatbot_core_ctx_params_pkg.get_num_param(l_ctx, 'MAX_EXAMPLES_CHARS',    cap_examples);
    cap_history  := chatbot_core_ctx_params_pkg.get_num_param(l_ctx, 'MAX_HISTORY_CHARS',     cap_history);
    if l_rephrase_enabled then
        cap_rephrase := chatbot_core_ctx_params_pkg.get_num_param(l_ctx, 'MAX_REPHRASE_CHARS', cap_rephrase);
    end if;

    l_instruction := chatbot_core_io_pkg.clamp_clob(l_instruction, cap_instr);
    l_schema_info := chatbot_core_io_pkg.clamp_clob(l_schema_info, cap_schema);
    l_table_desc  := chatbot_core_io_pkg.clamp_clob(l_table_desc,  cap_tables);
    l_examples    := chatbot_core_io_pkg.clamp_clob(l_examples,    cap_examples);
    -- we still suppress l_history in NL2SQL fresh runs

    -- 🟩 LOG all components (after routing + clamping)
    CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'SCHEMA_SLICE',       nvl(l_schema_info,to_clob('[NULL]')),  p_log_id, p_chat_id);
    CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'TABLE_DESCRIPTIONS', nvl(l_table_desc,to_clob('[NULL]')),   p_log_id, p_chat_id);
    CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'TABLE_JOINS',        nvl(l_joins_clob,to_clob('[NULL]')),   p_log_id, p_chat_id);
    CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'NL2SQL_INSTRUCTION', l_instruction,                         p_log_id, p_chat_id);
    CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'REASONING_SYSTEM',   nvl(l_reasoning_system,to_clob('[OFF]')), p_log_id, p_chat_id);
    CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'STRICT_SQL_OUTPUT',  l_strict_sql_output,                   p_log_id, p_chat_id);

    -- ============================================================
    -- PHASE 5: OPTIONAL REASONING (PLAN → ANSWER)
    -- ============================================================
    IF NVL(l_reasoning_enabled,'N') = 'Y' THEN
      l_table_joins := CHATBOT_CORE_CTX_PARAMS_PKG.load_component(l_ctx, 'TABLE_JOINS');
      CHATBOT_CORE_REASONING_PKG.run_reasoning_phase(
        p_ctx              => l_ctx,
        p_reasoning_system => l_reasoning_system,
        p_user_prompt      => l_user_prompt,
        p_schema_slice     => l_schema_info,
        p_table_desc_slice => l_table_desc,
        p_join_metadata    => l_table_joins,
        p_api_format       => l_api_format,
        p_model_id         => l_model_id_res,
        p_compartment_id   => p_compartment_id,
        p_region           => l_region,
        p_endpoint         => l_endpoint,
        p_req_id           => l_req_id,
        p_log_id           => p_log_id,
        p_chat_id          => p_chat_id,
        p_temperature      => l_temperature,
        p_top_p            => l_top_p,
        p_top_k            => l_top_k,
        o_reasoned_json    => v_reasoned_msg,
        io_input_chars     => v_input_chars_total,
        io_output_chars    => v_output_chars_total,
        io_input_tokens    => v_input_tokens_total,
        io_output_tokens   => v_output_tokens_total,
        io_metrics_json    => v_metrics_json
      );
    END IF;

    ----------------------------------------------------------------
    -- If REASONING_JSON asks for a clarification, surface it now
    -- and stop before NL2SQL.
    ----------------------------------------------------------------
    DECLARE
      v_clar_q   VARCHAR2(4000);
      v_needs_cl VARCHAR2(10);
    BEGIN
      IF v_reasoned_msg IS NOT NULL
         AND JSON_EXISTS(v_reasoned_msg, '$.clarification_question')
      THEN
        SELECT JSON_VALUE(v_reasoned_msg, '$.clarification_question' RETURNING VARCHAR2(4000)),
               JSON_VALUE(v_reasoned_msg, '$.needs_clarification'   RETURNING VARCHAR2(10))
          INTO v_clar_q,
               v_needs_cl
          FROM dual;

        IF v_clar_q IS NOT NULL
           AND TRIM(v_clar_q) IS NOT NULL
           AND (v_needs_cl IS NULL OR UPPER(v_needs_cl) = 'TRUE')
        THEN
          -- Show the clarification question to the user
          write_summary(
            p_log_id      => p_log_id,
            p_summary_txt => v_clar_q,
            p_reasoned    => v_reasoned_msg
          );

          -- Mark job as finished; UI will display the question
          mark_status(p_log_id, 'SUCCEEDED', p_finish => TRUE);
          RETURN;
        END IF;
      END IF;
    END;

    -- === MAIN LOOP ===
    while v_attempt < v_max_attempts loop
      v_attempt := v_attempt + 1;
      set_attempt(p_log_id, v_attempt);

      declare
        l_input      clob := case when v_attempt = 1 or v_reasoned_msg is null then l_user_prompt else v_reasoned_msg end;
        l_prompt     clob;
        l_payload    clob;
        l_model_resp clob;
        l_text_raw   clob;
        l_has_data   boolean := false;
        l_in_chars   number := 0;
        l_out_chars  number := 0;
        l_pt number; l_ct number;
        l_qa_prompt   clob;
        l_qa_payload  clob;
        l_qa_resp     clob;
        l_qa_text     clob;
        l_sql_verified clob;
        l_text_clean     CLOB;
        l_sql_only    CLOB;
        v_followup       CLOB;
        v_json_candidate CLOB;
      begin
        -- Build a compact, high-signal NL2SQL prompt:
        -- 1) Task contract (NL2SQL_INSTRUCTION or legacy INSTRUCTION)
        -- 2) Oracle guardrails (SQL_QA_SYSTEM)
        -- 3) Facts: SCHEMA + TABLE_DESCRIPTIONS (you already loaded/sliced them above)
        -- 4) Optional examples
        -- 5) The user question
        l_prompt :=
          /* task contract */            l_instruction||chr(10)||
          /* facts (skip for FOLLOWUP_REWRITE) */
          CASE
            WHEN upper(nvl(l_exec_mode,'INITIAL')) <> 'FOLLOWUP_REWRITE' THEN
              '-- SCHEMA --'||chr(10)||nvl(l_schema_info,'')||chr(10)||
              '-- TABLES --'||chr(10)||nvl(l_table_desc,'')||chr(10)||
              CASE
                WHEN l_joins_clob IS NOT NULL THEN
                  '-- TABLE_JOINS --'||chr(10)||l_joins_clob||chr(10)
                ELSE
                  ''
              END
            ELSE
              ''   -- no SCHEMA/TABLES/TABLE_JOINS for pure SQL rewrite
          END||
          /* optional examples */        case when l_examples is not null
                                               then '-- EXAMPLES --'||chr(10)||l_examples||chr(10)
                                               else '' end||
          /* optional reasoning */       case when v_reasoned_msg is not null 
                                              then '-- REASONING_JSON --'||CHR(10)||v_reasoned_msg||CHR(10)
                                              when l_reasoning_system is not null 
                                              then '-- REASONING_SYSTEM --'||CHR(10)||l_reasoning_system||CHR(10)
                                              else '' end||
                                         '-- OUTPUT CONTRACT --'||chr(10)||
                                          CASE 
                                            WHEN v_reasoned_msg IS NOT NULL 
                                                AND REGEXP_LIKE(v_reasoned_msg,'"time_filter"\s*:\s*\{[^\}]*"column"\s*:', 'n')
                                                AND REGEXP_LIKE(v_reasoned_msg,'"metric"\s*:\s*\{[^\}]*"column"\s*:', 'n')
                                            THEN l_strict_sql_output || CHR(10) ||
                                                'Do not ask follow-up questions. A complete plan is provided in REASONING_JSON. Render a single valid Oracle SQL statement only.'
                                            ELSE l_strict_sql_output
                                          END || CHR(10)||
          /* question */                 '-- QUESTION --'||chr(10)||
                                         'Q: '||l_input||chr(10)||
                                         'A:';

        CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'PROMPT_BUILT', l_prompt, p_log_id, p_chat_id);
        l_in_chars := nvl(dbms_lob.getlength(l_prompt),0);
        v_input_chars_total := v_input_chars_total + l_in_chars;
        chatbot_core_io_pkg.logv(l_ctx, 'INITIAL', l_req_id, 'Input chars='||l_in_chars, p_log_id, p_chat_id);

        /* ===== NL2SQL model call (strict SQL-only) ===== */

        -- 1) Build HTTP payload
        l_payload := CHATBOT_CORE_IO_PKG.build_payload_chat(
          p_api_format       => l_api_format,
          p_model_id         => l_model_id_res,
          p_compartment_id   => p_compartment_id,
          p_prompt_text      => l_prompt,
          p_temperature      => l_temperature,
          p_top_p            => l_top_p,
          p_top_k            => l_top_k
        );

        -- 2) Call endpoint (logged by IO)
        l_raw_resp_json := CHATBOT_CORE_IO_PKG.call_model(
          p_ctx      => l_ctx,
          p_phase    => 'NL2SQL',
          p_endpoint => l_endpoint,
          p_payload  => l_payload,
          p_req_id   => l_req_id,
          p_log_id   => p_log_id,
          p_chat_id  => p_chat_id
        );
        CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'RAW_JSON',  l_raw_resp_json, p_log_id, p_chat_id);

        -- 3) Extract assistant text
        l_text_resp := CHATBOT_CORE_IO_PKG.extract_text_from_chat_response(l_raw_resp_json);
        CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'TEXT_BODY', l_text_resp, p_log_id, p_chat_id);
        -- Count token usage from NL2SQL response
        CHATBOT_CORE_IO_PKG.extract_usage_tokens(l_raw_resp_json, l_pt, l_ct);
        v_input_tokens_total  := v_input_tokens_total  + NVL(l_pt,0);
        v_output_tokens_total := v_output_tokens_total + NVL(l_ct,0);
        l_out_chars := NVL(DBMS_LOB.getlength(l_text_resp),0);
        v_output_chars_total := v_output_chars_total + l_out_chars;
        -- normalize the assistant text once
        l_text_clean := NVL(l_text_resp,'');
        l_text_clean := REPLACE(l_text_clean, UNISTR('\FEFF'), '');
        l_text_clean := REPLACE(l_text_clean, UNISTR('\200B'), '');
        l_text_clean := REPLACE(l_text_clean, UNISTR('\200E'), '');
        l_text_clean := REPLACE(l_text_clean, UNISTR('\200F'), '');
        l_text_clean := REGEXP_REPLACE(l_text_clean, '^\s*```[a-zA-Z]*\s*', '', 1, 1, 'n');
        l_text_clean := REGEXP_REPLACE(l_text_clean, '```(\r|\n|.)*$', '', 1, 1, 'n');
        l_text_clean := TRIM(l_text_clean);

        -- Detect FOLLOWUP JSON from the cleaned body
        BEGIN
          BEGIN
            v_json_candidate := REGEXP_SUBSTR(l_text_clean, '\{.*\}', 1, 1, 'n');
          EXCEPTION WHEN OTHERS THEN
            v_json_candidate := NULL;
          END;

          IF v_json_candidate IS NOT NULL AND JSON_EXISTS(v_json_candidate, '$.followup') THEN
            v_followup := v_json_candidate;
          ELSIF JSON_EXISTS(l_text_clean, '$.followup') THEN
            v_followup := l_text_clean;
          END IF;

          IF v_followup IS NOT NULL
            AND NOT (v_reasoned_msg IS NOT NULL
                      AND REGEXP_LIKE(v_reasoned_msg,'"time_filter"\s*:\s*\{[^\}]*"column"\s*:', 'n')
                      AND REGEXP_LIKE(v_reasoned_msg,'"metric"\s*:\s*\{[^\}]*"column"\s*:', 'n'))
            AND NVL(l_exec_mode,'INITIAL') = 'INITIAL'
            AND l_parent_id IS NULL
            AND l_job_name IS NULL
          THEN
            UPDATE CHATBOT_NL2SQL_LOG
              SET raw_response     = l_raw_resp_json,
                  intent_label     = 'FOLLOWUP_CLARIFY',
                  reasoned_message = NVL(reasoned_message,'') ||
                                      CHR(10) || '[FOLLOWUP_PAYLOAD]' || CHR(10) || v_followup
            WHERE id = p_log_id;
            COMMIT;

            CHATBOT_FOLLOWUP_PKG.run_followup(
              p_log_id         => p_log_id,
              p_model_id       => l_model_id_res,
              p_chat_id        => p_chat_id,
              p_app_user       => p_app_user,
              p_app_session    => p_app_session,
              p_compartment_id => p_compartment_id,
              p_dataset        => l_ctx.dataset,
              p_environment    => l_ctx.environment
            );
            RETURN;
          END IF;
        END;

        -- 4) Robust SQL extraction (use l_text_clean prepared above)
        l_sql_only := CHATBOT_CORE_IO_PKG.normalize_llm_sql(l_text_clean);
        l_sql_only := CHATBOT_CORE_IO_PKG.extract_sql_only(NVL(l_sql_only, l_text_clean));

        IF l_sql_only IS NULL THEN
          IF REGEXP_LIKE(l_text_clean, '^\s*(WITH|SELECT)(\s|$)', 'i') THEN
            l_sql_only := REGEXP_REPLACE(l_text_clean, ';\s*$', '', 1, 1, 'n');
          END IF;
        END IF;

        IF l_sql_only IS NULL THEN
          DECLARE p PLS_INTEGER; len PLS_INTEGER; tmp CLOB;
          BEGIN
            p := REGEXP_INSTR(l_text_clean, '(with|select)', 1, 1, 0, 'i');
            IF p > 0 THEN
              len := DBMS_LOB.getlength(l_text_clean);
              tmp := DBMS_LOB.SUBSTR(l_text_clean, len - p + 1, p);
              tmp := REGEXP_REPLACE(tmp, '```(.|\n)*$', '', 1, 1, 'n');
              tmp := REGEXP_REPLACE(tmp, ';\s*$', '', 1, 1, 'n');
              tmp := TRIM(tmp);
              IF REGEXP_LIKE(tmp, '^\s*(WITH|SELECT)(\s|$)', 'i') THEN
                l_sql_only := tmp;
              END IF;
            END IF;
          END;
        END IF;

        CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'SQL_ONLY(final)', l_sql_only, p_log_id, p_chat_id);

        -- 5) Optional guard: if user didn’t mention a year, block hard-coded years
        IF NOT REGEXP_LIKE(UPPER(l_input), '(^|[^0-9])20[0-9]{2}([^0-9]|$)')
          AND REGEXP_LIKE(UPPER(l_sql_only), '(^|[^0-9])20[0-9]{2}([^0-9]|$)')
          AND NOT (
            v_reasoned_msg IS NOT NULL
            AND JSON_EXISTS(v_reasoned_msg, '$.time_filter.column')
          )
        THEN
          CHATBOT_CORE_IO_PKG.logc(l_ctx,'NL2SQL',l_req_id,'YEAR_GUARD_TRIGGERED', l_sql_only, p_log_id, p_chat_id);
          RAISE_APPLICATION_ERROR(-20075, 'NL2SQL: Hard-coded year found without explicit year in the question.');
        END IF;

        /* === Preflight: parse the SQL to detect invalid columns (ORA-00904) === */
        declare
          v_err_col   varchar2(256);
          v_err_code  number;
          v_err_msg   varchar2(4000);
          v_question  clob;
        begin
          begin
            -- Parse-only: EXPLAIN PLAN avoids scanning data
            execute immediate 'EXPLAIN PLAN FOR '|| l_sql_only;
          exception
            when others then
              v_err_code := SQLCODE;
              v_err_msg  := SQLERRM;

              if v_err_code = -904 then
                -- Try to extract offending identifier (often quoted in the error)
                v_err_col := regexp_substr(v_err_msg, '"([^"]+)"', 1, 1, null, 1);
                if v_err_col is null then
                  v_err_col := regexp_substr(v_err_msg, 'ORA-00904:\s*([A-Z0-9_]+)', 1, 1, null, 1);
                end if;

                -- Suggest close column names from the routed schema slice
                declare
                  v_suggestions   clob := null;
                  v_tables        sys.odcivarchar2list := sys.odcivarchar2list();
                  v_tables_count  integer := 0;
                  i               pls_integer := 1;
                  v_owner_tbl     varchar2(512);
                begin
                  -- Only try if schema JSON looks usable
                  if l_schema_info is not null
                    and json_exists(l_schema_info, '$.tables[*].columns[*]')
                  then
                    -- Harvest OWNER.TBL tokens from previous SQL (best-effort)
                    loop
                      v_owner_tbl := regexp_substr(l_prev_sql, '([A-Z0-9_]+\.)?[A-Z0-9_]+', 1, i, 'i');
                      exit when v_owner_tbl is null;
                      if regexp_like(v_owner_tbl, '^[A-Z0-9_]+\.[A-Z0-9_]+$', 'i') then
                        v_tables.extend; v_tables(v_tables.count) := upper(v_owner_tbl);
                      end if;
                      i := i + 1;
                    end loop;
                    v_tables_count := v_tables.count;

                    if v_tables_count > 0 then
                      for r in (
                        select jt.col_name,
                              utl_match.jaro_winkler_similarity(lower(jt.col_name), lower(nvl(v_err_col,''))) as sim
                        from json_table(l_schema_info, '$.tables[*]'
                              columns (
                                t_name varchar2(256) path '$.name',
                                cols   CLOB FORMAT JSON path '$.columns'
                              )
                            ) t,
                            json_table(t.cols, '$[*]'
                              columns ( col_name varchar2(256) path '$.name' )
                            ) jt
                        where jt.col_name is not null
                          and upper(t.t_name) in (select column_value from table(v_tables))
                        order by sim desc fetch first 5 rows only
                      ) loop
                        v_suggestions := nvl(v_suggestions,'') ||
                                        case when v_suggestions is null then '' else ', ' end ||
                                        r.col_name;
                      end loop;
                    else
                      -- No table filter available → global suggestions
                      for r in (
                        select jt.col_name,
                              utl_match.jaro_winkler_similarity(lower(jt.col_name), lower(nvl(v_err_col,''))) as sim
                        from json_table(l_schema_info, '$.tables[*]'
                              columns (
                                t_name varchar2(256) path '$.name',
                                cols   CLOB FORMAT JSON PATH '$.columns'
                              )
                            ) t,
                            json_table(t.cols, '$[*]'
                              columns ( col_name varchar2(256) path '$.name' )
                            ) jt
                        where jt.col_name is not null
                        order by sim desc fetch first 5 rows only
                      ) loop
                        v_suggestions := nvl(v_suggestions,'') ||
                                        case when v_suggestions is null then '' else ', ' end ||
                                        r.col_name;
                      end loop;
                    end if;
                  end if;

                  v_question :=
                    'The column "'||nvl(v_err_col,'(unknown)')||'" is not present in the selected tables.'||chr(10)||
                    'Did you mean one of: '||nvl(v_suggestions,'(no close matches)')||' ?'||chr(10)||
                    'Or should I remove it and proceed?';

                  -- Surface clarify and finish gracefully
                  write_summary(p_log_id, v_question, v_reasoned_msg);
                  mark_status(p_log_id, 'SUCCEEDED', p_finish => true);
                  return;
                end;

              elsif v_err_code = -979 then
                v_question :=
                  'The follow-up added columns that are not in the GROUP BY. '||
                  'Should I (a) aggregate them (e.g., MIN/ANY_VALUE), (b) join to a dimension keyed by CUSTOMER_ID, or (c) add them to GROUP BY?';
                write_summary(p_log_id, v_question, v_reasoned_msg);
                mark_status(p_log_id, 'SUCCEEDED', p_finish => true);
                return;

              elsif v_err_code = -918 then
                v_question :=
                  'A column in the SELECT is ambiguous (it exists in multiple joined tables). '||
                  'Should I qualify it with the correct table alias (e.g., t1.CURRENCY_CODE)?';
                write_summary(p_log_id, v_question, v_reasoned_msg);
                mark_status(p_log_id, 'SUCCEEDED', p_finish => true);
                return;

              else
                -- let other errors fall through to existing handling
                null;
              end if;
          end;
        end;

        -- 6) Hand off only the filtered SQL downstream
        v_response_sql := l_sql_only;

        -- Probe rows on the extracted SQL-only result
        v_response_sql := chatbot_core_sql_pkg.probe_sql_has_data(v_response_sql, l_has_data);
        CHATBOT_CORE_IO_PKG.logv(l_ctx, 'NL2SQL', l_req_id,
          'SQL probe has_data='||case when l_has_data then 'Y' else 'N' end,
          p_log_id, p_chat_id);

        IF l_has_data THEN
          -- 1) Preview (first 50 rows)
          v_preview_json := chatbot_core_sql_pkg.fetch_preview_json(v_response_sql, 50);
          CHATBOT_CORE_IO_PKG.logc(l_ctx,'SUMMARY',l_req_id,'Preview JSON (first 50 rows)', v_preview_json, p_log_id, p_chat_id);

          -- 2) Persist SQL + preview + raw LLM response immediately (so success is not lost)
          write_initial_outputs(p_log_id, v_response_sql, v_preview_json, l_raw_resp_json);

          -- 3) Try SUMMARY, but sandbox it so failure here doesn't cancel success
          BEGIN
            -- Optional: store full JSON (capped)
            BEGIN
              l_max_full_chars := chatbot_core_ctx_params_pkg.get_num_param(l_ctx, 'MAX_FULL_JSON_CHARS', 2000000);
            EXCEPTION WHEN OTHERS THEN
              l_max_full_chars := 2000000;
            END;

            l_full_json := chatbot_core_sql_pkg.fetch_full_json(v_response_sql, l_max_full_chars);
            IF dbms_lob.getlength(l_full_json) >= l_max_full_chars THEN
              BEGIN
                UPDATE CHATBOT_NL2SQL_LOG
                  SET reasoned_message = nvl(reasoned_message,'') ||
                      chr(10)||'[note] Full JSON reached MAX_FULL_JSON_CHARS cap ('||l_max_full_chars||').'
                WHERE id = p_log_id;
              EXCEPTION WHEN OTHERS THEN NULL; END;
            END IF;

            UPDATE CHATBOT_NL2SQL_LOG
              SET execution_data = l_full_json
            WHERE id = p_log_id;
          EXCEPTION WHEN OTHERS THEN
            -- non-fatal if full JSON store fails
            CHATBOT_CORE_IO_PKG.logv(l_ctx,'SUMMARY',l_req_id,'Full JSON store skipped: '||substr(sqlerrm,1,800), p_log_id, p_chat_id);
          END;

                    -- 4) SUMMARY via SUMMARY_PKG (auto: simple vs LLM vs rule-based)
          DECLARE
            l_json_for_summary   CLOB;
            l_in_chars_s         NUMBER := 0;
            l_out_chars_s        NUMBER := 0;
            l_summary_text       CLOB;
            l_meta_json          CLOB := '{"is_complete":true}';
            l_use_llm            BOOLEAN := TRUE; -- default for NL2SQL
            -- chart
            l_chart_raw          CLOB;
            l_chart_json         CLOB;
          BEGIN
            -- Prefer FULL JSON; if absent, fall back to the 50-row preview
            l_json_for_summary := CHATBOT_CORE_IO_PKG.clamp_clob(
                                    COALESCE(l_full_json, v_preview_json),
                                    cap_summary);

            l_in_chars_s := NVL(DBMS_LOB.getlength(NVL(l_json_for_summary,'{}')),0);
            v_input_chars_total := v_input_chars_total + l_in_chars_s;

            -- Let SUMMARY_PKG decide: simple vs LLM vs rule-based
            l_summary_text := CHATBOT_CORE_SUMMARY_PKG.Render_Auto(
                                p_context_query  => l_summary_question,
                                p_plan_json      => COALESCE(v_reasoned_msg, '{}'),
                                p_rows_json      => l_json_for_summary,
                                p_meta_json      => l_meta_json,
                                p_ctx            => l_ctx,
                                p_req_id         => l_req_id,
                                p_log_id         => p_log_id,
                                p_chat_id        => p_chat_id,
                                p_use_llm        => l_use_llm,
                                p_endpoint       => l_endpoint,
                                p_api_format     => l_api_format,
                                p_model_id       => l_model_id_res,
                                p_compartment_id => p_compartment_id,
                                p_temperature    => l_temperature,
                                p_top_p          => l_top_p,
                                p_top_k          => l_top_k
                              );

            -- CHART suggestion (normal NL2SQL path)
            begin
              l_chart_json := CHATBOT_CORE_CHART_PKG.Suggest_Chart_Spec(
                p_context_query  => l_summary_question,
                p_rows_json      => l_json_for_summary,
                p_plan_json      => COALESCE(v_reasoned_msg, '{}'),
                p_ctx            => l_ctx,
                p_req_id         => l_req_id,
                p_log_id         => p_log_id,
                p_chat_id        => p_chat_id,
                p_endpoint       => l_endpoint,
                p_api_format     => l_api_format,
                p_model_id       => l_model_id_res,
                p_compartment_id => p_compartment_id,
                p_temperature    => l_temperature,
                p_top_p          => l_top_p,
                p_top_k          => l_top_k,
                o_raw_response   => l_chart_raw
              );

              if l_chart_json is not null then
                write_chart_spec(p_log_id, l_chart_json);
              end if;
            exception
              when others then
                CHATBOT_CORE_IO_PKG.logv(
                  l_ctx,'CHART',l_req_id,
                  'Chart suggestion failed: '||SUBSTR(SQLERRM,1,800),
                  p_log_id,p_chat_id
                );
            end;

            v_summary_text := l_summary_text;
            l_out_chars_s  := NVL(DBMS_LOB.getlength(v_summary_text),0);
            v_output_chars_total := v_output_chars_total + l_out_chars_s;

            -- metrics entry for SUMMARY ...
            v_metrics_json := v_metrics_json
              || CASE WHEN v_metrics_json='[' THEN '' ELSE ',' END
              || '{"phase":"SUMMARY","inputChars":'||CHATBOT_CORE_IO_PKG.num_to_json(l_in_chars_s)
              || ',"outputChars":'||CHATBOT_CORE_IO_PKG.num_to_json(l_out_chars_s)
              || ',"promptTokens":0,"completionTokens":0}';

            write_summary(
              p_log_id      => p_log_id,
              p_summary_txt => v_summary_text,
              p_reasoned    => v_reasoned_msg
            );
          EXCEPTION
            WHEN OTHERS THEN
              CHATBOT_CORE_IO_PKG.logv(
                l_ctx,'SUMMARY',l_req_id,
                'Summary engine failed: '||SUBSTR(SQLERRM,1,800),
                p_log_id, p_chat_id);

              BEGIN
                write_summary(
                  p_log_id,
                  TO_CLOB('Query generated and result JSON is available. Open the results panel for details.'),
                  v_reasoned_msg
                );
              EXCEPTION WHEN OTHERS THEN NULL; END;
          END;

          -- 5) Finalize metrics/status on success (outside the summary try)
          BEGIN
            IF v_metrics_json IS NOT NULL THEN
              v_metrics_json := v_metrics_json || ']';
            END IF;

            write_metrics_totals(
              p_log_id              => p_log_id,
              p_input_chars_total   => v_input_chars_total,
              p_output_chars_total  => v_output_chars_total,
              p_input_tokens_total  => v_input_tokens_total,
              p_output_tokens_total => v_output_tokens_total,
              p_metrics_json        => v_metrics_json
            );
          EXCEPTION WHEN OTHERS THEN NULL; END;

          mark_status(p_log_id, 'SUCCEEDED', p_finish => true);
          COMMIT;
          RETURN;
        ELSE
          -- Handle LLM FOLLOWUP when no data found
          IF NOT l_has_data AND v_followup IS NOT NULL THEN
            DECLARE
              q1 VARCHAR2(4000);
              q2 VARCHAR2(4000);
            BEGIN
              q1 := JSON_VALUE(v_followup, '$.followup.questions[0]' RETURNING VARCHAR2(4000));
              q2 := JSON_VALUE(v_followup, '$.followup.questions[1]' RETURNING VARCHAR2(4000));
              IF q1 IS NOT NULL THEN
                -- persist raw model response for audit
                UPDATE CHATBOT_NL2SQL_LOG
                  SET raw_response = l_raw_resp_json
                WHERE id = p_log_id;

                -- trace
                CHATBOT_CORE_IO_PKG.logc(l_ctx,'FOLLOWUP',l_req_id,'No rows returned; surfacing follow-up prompt',v_followup, p_log_id, p_chat_id);

                write_summary(
                  p_log_id      => p_log_id,
                  p_summary_txt => 'I need a bit more detail:'||CHR(10)||
                                  '- '||q1||CASE WHEN q2 IS NOT NULL THEN CHR(10)||'- '||q2 ELSE '' END,
                  p_reasoned    => v_reasoned_msg
                );
                IF v_metrics_json IS NOT NULL AND v_metrics_json NOT LIKE '%]%' THEN
                  v_metrics_json := v_metrics_json || ']';
                END IF;
                write_metrics_totals(
                  p_log_id              => p_log_id,
                  p_input_chars_total   => v_input_chars_total,
                  p_output_chars_total  => v_output_chars_total,
                  p_input_tokens_total  => v_input_tokens_total,
                  p_output_tokens_total => v_output_tokens_total,
                  p_metrics_json        => v_metrics_json
                );
                mark_status(p_log_id, 'SUCCEEDED', p_finish => TRUE);
                COMMIT;
                RETURN;
              END IF;
            END;
          END IF;

          v_last_failed := 'Y';
        END IF;
      exception
        when others then
          v_last_failed := 'Y';
      end;

      -- REPHRASE (kept but disabled by flag)
      if l_rephrase_enabled and v_last_failed = 'Y' and v_attempt < v_max_attempts then
        begin
          l_model_id_r := chatbot_core_ctx_params_pkg.get_param_value(l_ctx, 'REPHRASE_MODEL_ID');
          if l_model_id_r is null then
            l_model_id_r          := l_model_id_res;
            l_region_r            := l_region;
            l_api_format_r        := l_api_format;
            l_temperature_r       := l_temperature;
            l_top_p_r             := l_top_p;
            l_top_k_r             := l_top_k;
          else
            get_model_config(l_model_id_r, l_region_r, l_model_id_r, l_api_format_r,
                             l_temperature_r, l_top_p_r, l_top_k_r);
          end if;
          l_endpoint_r := endpoint_for_region(nvl(l_region_r,l_region));
        exception when others then
          l_model_id_r          := l_model_id_res;
          l_region_r            := l_region;
          l_api_format_r        := l_api_format;
          l_temperature_r       := l_temperature;
          l_top_p_r             := l_top_p;
          l_top_k_r             := l_top_k;
          l_endpoint_r          := l_endpoint;
        end;

        declare
          l_last_sql_snip clob := chatbot_core_io_pkg.clamp_clob(
                                    chatbot_core_io_pkg.one_line(v_response_sql), 500);
          l_prompt_r      clob;
          l_payload_r     clob;
          l_resp_r        clob;
        begin
          l_prompt_r :=
            l_rephrase_system
            || chr(10) || '--- CONTEXT ---'
            || chr(10) || 'Previous attempt returned NO ROWS.'
            || case when l_last_sql_snip is not null then chr(10)||'Last SQL (snippet): '||l_last_sql_snip else '' end
            || chr(10) || 'User said: ' || chatbot_core_io_pkg.one_line(
                                    chatbot_core_io_pkg.clamp_clob( nvl(v_reasoned_msg, l_user_prompt), 800))
            || chr(10) || '--- END CONTEXT ---';

          l_prompt_r := chatbot_core_io_pkg.clamp_clob(l_prompt_r, cap_rephrase);

          l_payload_r := chatbot_core_io_pkg.build_payload_chat(
                           l_api_format_r, l_model_id_r, p_compartment_id, l_prompt_r,
                           l_temperature_r, l_top_p_r, l_top_k_r);

          chatbot_core_io_pkg.logc(l_ctx, 'REPHRASE', l_req_id, 'Rephrase Payload',
                                   l_payload_r, p_log_id, p_chat_id);

          l_resp_r := chatbot_core_io_pkg.call_model(
                        l_ctx, 'REPHRASE', l_endpoint_r, l_payload_r, l_req_id, p_log_id, p_chat_id);

          v_reasoned_msg := chatbot_core_io_pkg.clamp_clob(
                            chatbot_core_io_pkg.one_line(chatbot_core_io_pkg.extract_text_from_chat_response(l_resp_r)),600);
        exception when others then
          null;
        end;
      end if;

    end loop;

    begin
        if v_metrics_json is not null then
            v_metrics_json := v_metrics_json || ']';
        end if;

        write_metrics_totals(
            p_log_id              => p_log_id,
            p_input_chars_total   => v_input_chars_total,
            p_output_chars_total  => v_output_chars_total,
            p_input_tokens_total  => v_input_tokens_total,
            p_output_tokens_total => v_output_tokens_total,
            p_metrics_json        => v_metrics_json
        );
    exception when others then null; end;

    mark_status(p_log_id, 'FAILED', p_errmsg => 'No results found.', p_finish => true);
    commit;

  exception
    when others then
        if sqlcode = -20902 then
            return; -- already queued; do not overwrite status
        end if;
        l_err := substr(sqlerrm,1,3500);
        begin
            mark_status(p_log_id, 'FAILED', p_errmsg => l_err, p_finish => true);
        exception when others then null; end;
        raise;
  end run_job;

END CHATBOT_CORE_RUNNER_PKG;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_CORE_SQL_PKG" as
  -- ===== Generic SQL/text utilities =====
  procedure safe_close(p_cursor in out integer);
  function ms_between(p_start timestamp with time zone, p_end timestamp with time zone) return number;

  -- Extract table names seen after FROM / JOIN (optionally schema-qualified)
  function extract_tables_from_sql(p_sql in clob) return sys.odcivarchar2list;

  -- Probe + preview
  function probe_sql_has_data(
    p_sql      in  clob,
    p_has_data out boolean
  ) return clob;

  function fetch_preview_json(
    p_sql       in clob,
    p_row_limit in number default 50
  ) return clob;

  -- Return ALL rows as JSON (capped by p_max_chars to stay safe)
  function fetch_full_json(
    p_sql        in clob,
    p_max_chars  in number default 2000000  -- hard cap in characters
  ) return clob;

  -- Phase 6: Redact non-numeric/date attributes from preview JSON
  function redact_preview_json(
    p_ctx      in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_log_id   in number,
    p_preview  in clob,
    p_chat_id  in number   default null,
    p_req_id   in varchar2 default null
  ) return clob;

  -- Redact literals in a free-text summary using tokens derived from a preview/full JSON.
  function redact_preview_literals(
    p_ctx          in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_preview_json in clob,
    p_summary_text in clob,
    p_log_id       in number,
    p_chat_id      in number,
    p_req_id       in varchar2
  ) return clob;

  -- Persist or refresh token map + masked sample for a LOG_ID
  procedure upsert_redaction_map(
    p_log_id                 in number,
    p_chat_id                in number,
    p_token_map_json         in clob,
    p_masked_preview_json    in clob default null,
    p_original_preview_json  in clob default null
  );

  -- Fetch persisted redaction token map (forward map) for a LOG_ID
  function get_redaction_map_json(
    p_log_id in number
  ) return clob;

  -- Write detokenized summary (simple wrapper)
  -- Debug-enabled overload
  procedure write_summary_detokenized(
    p_log_id            in number,
    p_summary_tokenized in clob,
    p_ctx               in chatbot_core_ctx_params_pkg.run_ctx_t default null,
    p_chat_id           in number   default null,
    p_req_id            in varchar2 default null
  );

  -- History
  function build_history(
    p_chat_id           in number,
    p_context_turns     in number,
    p_history_max_chars in number
  ) return clob;

  -- Optional schema helpers
  function list_tables_in_sql(p_sql in clob) return sys.odcivarchar2list;
  function build_mini_schema_for_sql(p_sql clob, p_char_budget number := 2000) return clob;

  -- ===== Router (candidate selection + authored chunks) =====
  function to_tokens(p_q varchar2, p_max pls_integer := 8) return sys.odcivarchar2list;
  function listagg_token_debug(p_list sys.odcivarchar2list) return varchar2;

  function prefilter_table_candidates(
    p_ctx      in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_question in clob,
    p_k        in number default 12,
    p_req_id   in varchar2 default null,
    p_log_id   in number   default null,
    p_chat_id  in number   default null
  ) return sys.odcivarchar2list;

  function build_router_catalog(
    p_ctx    in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_tables in sys.odcivarchar2list
  ) return clob;

  function route_tables(
    p_ctx              in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_question         in clob,
    p_candidates       in sys.odcivarchar2list,
    p_req_id           in varchar2,
    p_log_id           in number,
    p_chat_id          in number,
    p_api_format       in varchar2,
    p_model_id         in varchar2,
    p_compartment_id   in varchar2,
    p_temperature      in number,
    p_top_p            in number,
    p_top_k            in number,
    p_endpoint         in varchar2
  ) return clob;

  function parse_router_tables(p_json clob) return sys.odcivarchar2list;
  function norm_table(p in varchar2) return varchar2;

  function get_schema_for_table(
    p_ctx   in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_table in varchar2
  ) return clob;

  function get_desc_for_table(
    p_ctx   in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_table in varchar2
  ) return clob;

  procedure load_authored_chunks_for_selected(
    p_ctx          in  chatbot_core_ctx_params_pkg.run_ctx_t,
    p_selected     in  sys.odcivarchar2list,
    p_schema_out   out nocopy clob,
    p_tables_out   out nocopy clob,
    p_with_headers in  boolean default true
  );

  -- ===== Intent classification =====
  function classify_intent(p_text clob) return varchar2;

  function classify_intent_llm(
    p_ctx            in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_text           in clob,
    p_api_format     in varchar2,
    p_model_id       in varchar2,
    p_compartment_id in varchar2,
    p_endpoint       in varchar2,
    p_req_id         in varchar2,
    p_log_id         in number,
    p_chat_id        in number
  ) return varchar2;

  function classify_intent_smart(
    p_ctx            in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_text           in clob,
    p_api_format     in varchar2,
    p_model_id       in varchar2,
    p_compartment_id in varchar2,
    p_region         in varchar2,
    p_req_id         in varchar2,
    p_log_id         in number,
    p_chat_id        in number
  ) return varchar2;

  -- NEW 01102025 - Glossary quick matcher
  function glossary_lookup_quick_text(
    p_ctx        in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_query      in clob,
    p_max_chars  in number   default 900,
    p_threshold  in number   default 0.35
  ) return clob;

  -- Public JSON classifier (STRICT JSON text)
  function classify_intent_llm_json(
    p_ctx            in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_text           in clob,
    p_api_format     in varchar2,
    p_model_id       in varchar2,
    p_compartment_id in varchar2,
    p_endpoint       in varchar2,
    p_req_id         in varchar2,
    p_log_id         in number,
    p_chat_id        in number
  ) return clob;

  -- FOLLOWUP SQL refinement heuristic
  function is_sql_refinement_request(p_text in clob) return boolean;

  -- Persist intent label + score10 to the log (best-effort; no commit)
  procedure persist_intent_to_log(
    p_log_id  in number,
    p_label   in varchar2,
    p_score10 in number default null
  );

  -- Context bundle helper
  procedure get_context_and_history(
    p_chat_id           in  number,
    p_log_id            in  number,
    p_mode              in  varchar2,  -- 'ALL' | 'GENERIC' | 'NONE'
    p_context_turns     in  number,
    p_history_max_chars in  number,
    p_prev_user         out clob,
    p_prev_summary      out clob,
    p_prev_sql          out clob,
    p_history_block     out clob
  );

  ------------------------------------------------------------------------------
  -- Unified Intent API (centralized ownership in SQL_PKG)
  ------------------------------------------------------------------------------
  type intent_result_t is record (
    label            varchar2(40),  -- FOLLOWUP_CLARIFY | NL2SQL | GENERAL_CHAT
    score10          number,        -- 0..10 (or null)
    needs_clarify    boolean,       -- true => ask a short clarify question
    clarify_question clob           -- single-line question when needs_clarify
  );

  procedure resolve_intent(
    p_ctx            in  chatbot_core_ctx_params_pkg.run_ctx_t,
    p_text           in  clob,
    p_api_format     in  varchar2,
    p_model_id       in  varchar2,
    p_compartment_id in  varchar2,
    p_region         in  varchar2,
    p_req_id         in  varchar2,
    p_log_id         in  number,
    p_chat_id        in  number,
    p_threshold      in  number  default null,  -- override INTENT_NL2SQL_THRESHOLD_SCORE10
    p_persist        in  boolean default true,  -- write INTENT_* to log + metrics
    p_result         out intent_result_t
  );

  -- Error aware and auto-clarify
  -- Build a tiny {"followup": "..."} blob
  function make_followup_json(p_q in clob) return clob;

  -- Map ORA- errors to a hint key
  function classify_ora_error(p_err in varchar2) return varchar2;

  ------------------------------------------------------------------------------
  -- FOLLOWUP: LLM decider (strict JSON). Lets the model choose:
  --   answer_directly | modify_previous_sql | new_query | ask_clarifying
  ------------------------------------------------------------------------------
  function classify_followup_decision(
    p_ctx            in  chatbot_core_ctx_params_pkg.run_ctx_t,
    p_prev_user      in  clob,
    p_prev_summary   in  clob,
    p_prev_sql       in  clob,
    p_user_text      in  clob,
    p_api_format     in  varchar2,
    p_model_id       in  varchar2,
    p_compartment_id in  varchar2,
    p_endpoint       in  varchar2,
    p_req_id         in  varchar2,
    p_log_id         in  number,
    p_chat_id        in  number
  ) return clob;  -- STRICT JSON per FOLLOWUP_DECIDER_SYSTEM

end chatbot_core_sql_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_CORE_SQL_PKG" as
  /*----------------------------------------------------------------------------*
   * PACKAGE: chatbot_core_sql_pkg (enhanced)
   *
   * PURPOSE
   *   SQL-focused utilities for the chatbot pipeline + improved intent ensemble:
   *     - Parse/clean model text into executable SQL fragments.
   *     - Probe SQL for data presence and fetch preview rows as JSON.
   *     - Build concise conversation history blocks.
   *     - Lightweight table routing helpers (tokenization, scoring, catalog).
   *     - Intent classification (heuristic + LLM + router priors) with metrics.
   *
   * CHANGES (highlights)
   *   - classify_intent: stronger heuristics (EN+GR), SQL smell, time windows, agg cues.
   *   - classify_intent_llm_json: returns STRICT JSON with scores+reason (few-shots).
   *   - decide_intent: ensemble combiner with router priors and follow-up affordance.
   *   - classify_intent_smart: now uses ensemble (keeps signature).
   *   - prefilter_table_candidates: optional bonus for token↔column-name matches.
   *----------------------------------------------------------------------------*/

  -- === Safe DBMS_SQL cursor close ============================================
  procedure safe_close (p_cursor in out integer) is
  begin
    if p_cursor is not null then
      if dbms_sql.is_open(p_cursor) then
        dbms_sql.close_cursor(p_cursor);
      end if;
    end if;
  exception when others then null;
  end;

    -- Get context and history (no legacy helpers)
    procedure get_context_and_history(
        p_chat_id           in  number,
        p_log_id            in  number,
        p_mode              in  varchar2,
        p_context_turns     in  number,
        p_history_max_chars in  number,
        p_prev_user         out clob,
        p_prev_summary      out clob,
        p_prev_sql          out clob,
        p_history_block     out clob
    ) is
        l_mode     varchar2(20) := upper(nvl(trim(p_mode),'NONE'));
        l_prev_id  number;
        l_budget   number := nvl(p_history_max_chars, 1500);
        l_hist     clob;
    begin
        -- Previous turn id
        begin
            if l_mode = 'NL2SQL' then
              select id
                into l_prev_id
              from (
                select id
                from chatbot_nl2sql_log
                where chat_id = p_chat_id
                  and id < p_log_id
                  and generated_sql is not null
                  -- and id > p_log_id - p_context_turns  -- (optional bound)
                order by id desc
              )
              where rownum = 1;
            else
              select max(id)
                into l_prev_id
              from chatbot_nl2sql_log
              where chat_id = p_chat_id
                and id < p_log_id;
            end if;
        exception when no_data_found then
            l_prev_id := null;
        end;

        -- Previous user / summary / sql
        if l_prev_id is not null then
            begin
                select user_prompt, summary_text, generated_sql
                into p_prev_user, p_prev_summary, p_prev_sql
                from chatbot_nl2sql_log
                where id = l_prev_id;
            exception when others then
                p_prev_user := null; p_prev_summary := null; p_prev_sql := null;
            end;
        else
            p_prev_user := null; p_prev_summary := null; p_prev_sql := null;
        end if;

        -- History block
        if l_mode = 'ALL' then
            -- reuse existing rich history builder
            p_history_block := build_history(p_chat_id, p_context_turns, p_history_max_chars);

        elsif l_mode = 'GENERIC' then
            -- inline "generic" history (non-NL2SQL turns without SQL); light + trimmed
            if nvl(p_context_turns,0) > 0 then
                for r in (
                select *
                    from (
                    select id,
                            nvl(created_at, systimestamp) as created_at,
                            user_prompt,
                            summary_text,
                            intent_label,
                            generated_sql
                        from chatbot_nl2sql_log
                    where chat_id = p_chat_id
                        and nvl(upper(intent_label),'GENERAL_CHAT') <> 'NL2SQL'
                        and generated_sql is null
                    order by id desc
                    )
                where rownum <= p_context_turns
                order by id
                ) loop
                    exit when l_budget <= 0;
                    declare
                    l_user_snip clob := chatbot_core_io_pkg.clamp_clob(chatbot_core_io_pkg.one_line(r.user_prompt), 600);
                    l_sum_snip  clob := chatbot_core_io_pkg.clamp_clob(chatbot_core_io_pkg.one_line(r.summary_text), 900);
                    l_block     clob := 'Turn #'||r.id||' @ '||to_char(r.created_at,'YYYY-MM-DD HH24:MI')||chr(10)
                                        || 'User: '||nvl(l_user_snip,'')||chr(10)
                                        || 'Prev Summary: '||nvl(l_sum_snip,'')||chr(10);
                    begin
                    if dbms_lob.getlength(l_block) > l_budget then
                        l_block := dbms_lob.substr(l_block, l_budget, 1);
                    end if;
                    l_hist  := nvl(l_hist,'') || l_block || chr(10);
                    l_budget := l_budget - dbms_lob.getlength(l_block);
                    end;
                end loop;

                if l_hist is not null then
                    l_hist := '-- NON-NL2SQL HISTORY (last '||p_context_turns||' turns) --' || chr(10) || l_hist || chr(10);
                end if;

                -- safety: strip any stray code blocks
                -- keep general chat text; optionally strip fenced code blocks only
                p_history_block := l_hist;
                /* optional: defensively remove fenced code, but keep prose
                p_history_block := regexp_replace(l_hist, '```(.|\n)*?```', '', 1, 0, 'n');
                */
            else
                p_history_block := null;
            end if;
        else
            p_history_block := null;
        end if;

    exception
        when others then
            -- fail-closed: never break callers
            p_prev_user     := null;
            p_prev_summary  := null;
            p_prev_sql      := null;
            p_history_block := null;
    end;

  procedure persist_intent_to_log(
    p_log_id  in number,
    p_label   in varchar2,
    p_score10 in number default null
  ) is
  begin
    update chatbot_nl2sql_LOG
       set INTENT_LABEL  = p_label,
           INTENT_SCORE10 = p_score10
     where id = p_log_id;
  exception when others then
    -- swallow; runner continues even if this write fails
    null;
  end;

  /* ==================== Q2 2.2 helpers ==================== */

  -- SHA-256 as HEX using DBMS_CRYPTO (works in PL/SQL)
  function sha256_hex(p_val in varchar2) return varchar2 is
    r raw(32);
  begin
    r := dbms_crypto.hash(utl_i18n.string_to_raw(nvl(p_val,''), 'AL32UTF8'), dbms_crypto.hash_sh256);
    return rawtohex(r);
  end;

  -- Build tiny {"followup":"..."} JSON (one line, safely escaped)
  function make_followup_json(p_q in clob) return clob is
    v clob := chatbot_core_io_pkg.one_line(p_q);
  begin
    if v is null then return null; end if;
    apex_json.initialize_clob_output;
    apex_json.open_object;
    apex_json.write('followup', nvl(v,''));
    apex_json.close_object;
    v := apex_json.get_clob_output;
    apex_json.free_output;
    return v;
  exception when others then
    apex_json.free_output; return null;
  end;

  -- Map Oracle error text to a compact key the Runner understands
  function classify_ora_error(p_err in varchar2) return varchar2 is
    e varchar2(4000) := upper(nvl(p_err,''));
  begin
    if e like '%NO DATA FOUND%' or e like '%ORA-01403%' then return 'NO_DATA'; end if;
    if e like '%ORA-00904%' then return 'MISSING_COL'; end if;                   -- invalid identifier
    if e like '%ORA-00942%' then return 'NOT_EXISTS'; end if;                    -- table or view does not exist
    if e like '%ORA-01031%' then return 'PRIVS'; end if;                         -- insufficient privileges
    if e like '%ORA-00933%' or e like '%ORA-00936%' or e like '%ORA-00907%' 
      or e like '%ORA-01784%' or e like '%ORA-01756%' then return 'SYNTAX'; end if;
    if e like '%ORA-018%' then return 'DATE_FMT'; end if;                         -- date/time format family
    if e like '%ORA-01722%' then return 'TO_NUMBER'; end if;
    if e like '%ORA-12899%' or e like '%ORA-01438%' then return 'VALUE_RANGE'; end if;
    if e like '%ORA-00054%' then return 'LOCK'; end if;
    if e like '%ORA-01013%' or e like '%ORA-3136%' or e like '%TIMEOUT%' then return 'TIMEOUT'; end if;
    if e like '%ORA-04036%' or e like '%ORA-30036%' or e like '%ORA-01652%' 
      or e like '%ORA-01555%' then return 'RESOURCE'; end if;                    -- PGA/TMP/UNDO
    return 'OTHER';
  end;

  -- Turn error class (+ minimal context) into one concrete follow-up question
  function build_followup_from_error(p_user in clob, p_err in varchar2) return clob is
    cls varchar2(40) := classify_ora_error(p_err);
    u   clob := chatbot_core_io_pkg.one_line(p_user);
    q   clob;
  begin
    case cls
      when 'NO_DATA'      then q := 'No rows came back. Should I broaden filters (date range, region) or switch metric?';
      when 'MISSING_COL'  then q := 'A column name seems invalid. Which field did you mean, or which table should I use for it?';
      when 'NOT_EXISTS'   then q := 'That table isn’t accessible here. Should I use a different table/view for this analysis?';
      when 'PRIVS'        then q := 'I lack privileges for a needed object. Do you want me to switch to a permitted table or summarize without it?';
      when 'SYNTAX'       then q := 'The draft SQL hit a syntax edge. Do you want me to simplify the query (e.g., remove CTEs or window funcs)?';
      when 'DATE_FMT'     then q := 'What date format/column should I use (e.g., ORDER_DATE, YYYY-MM-DD) and what time window?';
      when 'TO_NUMBER'    then q := 'A text→number cast failed. Should I treat the field as text or pick a different numeric metric?';
      when 'VALUE_RANGE'  then q := 'A value overflow occurred. Should I round/scale the metric or choose a different aggregation?';
      when 'LOCK'         then q := 'The source is locked. Is it OK to query a smaller slice or a recent summary table instead?';
      when 'TIMEOUT'      then q := 'The query timed out. May I narrow the date range or add a filter (e.g., product/region)?';
      when 'RESOURCE'     then q := 'Resources were insufficient. May I aggregate first or sample a smaller period?';
      else                    q := 'Should I adjust filters/time window or pick a simpler metric to generate a lighter query?';
    end case;

    -- If the user’s last message is a short refinement, mention it
    if u is not null and length(u) <= 140 then
      q := q || ' (You said: '||u||')';
    end if;

    return make_followup_json(q);
  end;

  -- === ms_between helper ======================================================
  function ms_between (p_start timestamp with time zone, p_end timestamp with time zone) return number is
  begin
    return ( extract(day    from (p_end - p_start)) * 86400000 )
         + ( extract(hour   from (p_end - p_start)) * 3600000 )
         + ( extract(minute from (p_end - p_start)) * 60000 )
         +   round(extract(second from (p_end - p_start)) * 1000);
  end;

  -- Extract table names seen after FROM / JOIN (optionally schema-qualified)
  function extract_tables_from_sql(p_sql in clob) return sys.odcivarchar2list is
    l_list sys.odcivarchar2list := sys.odcivarchar2list();
    l_seen sys.odcivarchar2list := sys.odcivarchar2list();
    l_tok  varchar2(4000);
    c_pat  constant varchar2(4000) :=
      '(?is)(?:\bfrom\b|\bjoin\b)\s+("([^"]+)"(?:\."[^"]+")?|[A-Za-z0-9_$#]+(?:\.[A-Za-z0-9_$#]+)?)';
    n pls_integer;
  begin
    if p_sql is null then return l_list; end if;

    n := regexp_count(p_sql, c_pat);
    for i in 1..n loop
      l_tok := regexp_substr(p_sql, c_pat, 1, i, null, 1);
      l_tok := replace(l_tok, '"');
      l_tok := trim(regexp_replace(l_tok, '(,|$|\s+(?:as\s+)?[A-Za-z0-9_$#]+).*$', '', 1, 0, 'i'));
      if l_tok is not null then
        -- de-dup (case-insensitive)
        declare
          exists_flag boolean := false;
        begin
          if l_seen is not null then
            for j in 1..l_seen.count loop
              if lower(l_seen(j)) = lower(l_tok) then exists_flag := true; exit; end if;
            end loop;
          end if;
          if not exists_flag then
            l_list.extend; l_list(l_list.count) := l_tok;
            l_seen.extend; l_seen(l_seen.count) := l_tok;
          end if;
        end;
      end if;
    end loop;
    return l_list;
  exception when others then
    return sys.odcivarchar2list(); -- best effort
  end;

  -- === Probe SQL for any non-null data in first row ==========================
  function probe_sql_has_data (
    p_sql      in  clob,
    p_has_data out boolean
  ) return clob is
    l_sql_body clob := rtrim(p_sql, ';');
    l_sql      clob := to_clob('SELECT * FROM (') || l_sql_body || ') WHERE ROWNUM = 1';
    l_cursor   integer;
    l_desc_tab dbms_sql.desc_tab;
    l_col_cnt  integer;
    l_status   integer;
    l_has_data boolean := false;
  begin
    p_has_data := false;
    if l_sql_body is null then return null; end if;

    l_cursor := dbms_sql.open_cursor;
    dbms_sql.parse(l_cursor, l_sql, dbms_sql.native);
    dbms_sql.describe_columns(l_cursor, l_col_cnt, l_desc_tab);

    for i in 1..l_col_cnt loop
      case l_desc_tab(i).col_type
        when dbms_sql.varchar2_type  then declare v_vc varchar2(32767); begin dbms_sql.define_column(l_cursor,i,v_vc,32767); end;
        when dbms_sql.clob_type      then declare v_c  clob;           begin dbms_sql.define_column(l_cursor,i,v_c);       end;
        when dbms_sql.number_type    then declare v_n  number;         begin dbms_sql.define_column(l_cursor,i,v_n);       end;
        when dbms_sql.date_type      then declare v_d  date;           begin dbms_sql.define_column(l_cursor,i,v_d);       end;
        when dbms_sql.timestamp_type then declare v_ts timestamp;      begin dbms_sql.define_column(l_cursor,i,v_ts);      end;
        else                             declare v_f  clob;           begin dbms_sql.define_column(l_cursor,i,v_f);       end;
      end case;
    end loop;

    l_status := dbms_sql.execute(l_cursor);

    if dbms_sql.fetch_rows(l_cursor) > 0 then
      for i in 1..l_col_cnt loop
        case l_desc_tab(i).col_type
          when dbms_sql.varchar2_type then
            declare v_vc varchar2(32767);
            begin dbms_sql.column_value(l_cursor,i,v_vc); if v_vc is not null then l_has_data := true; exit; end if; end;
          when dbms_sql.clob_type then
            declare v_c clob;
            begin dbms_sql.column_value(l_cursor,i,v_c); if v_c is not null and dbms_lob.getlength(v_c) > 0 then l_has_data := true; exit; end if; end;
          when dbms_sql.number_type then
            declare v_n number;
            begin dbms_sql.column_value(l_cursor,i,v_n); if v_n is not null then l_has_data := true; exit; end if; end;
          when dbms_sql.date_type then
            declare v_d date;
            begin dbms_sql.column_value(l_cursor,i,v_d); if v_d is not null then l_has_data := true; exit; end if; end;
          when dbms_sql.timestamp_type then
            declare v_ts timestamp;
            begin dbms_sql.column_value(l_cursor,i,v_ts); if v_ts is not null then l_has_data := true; exit; end if; end;
          else
            declare v_c2 clob;
            begin dbms_sql.column_value(l_cursor,i,v_c2); if v_c2 is not null and dbms_lob.getlength(v_c2) > 0 then l_has_data := true; exit; end if; end;
        end case;
      end loop;
    end if;

    dbms_sql.close_cursor(l_cursor);
    p_has_data := l_has_data;
    return l_sql_body;

  exception when others then
    safe_close(l_cursor);
    p_has_data := false;
    return l_sql_body;
  end;

  -- Returns TRUE for numbers or common date/time formats; FALSE otherwise.
  function is_numeric_or_date_like(p_str in varchar2) return boolean is
  begin
    if p_str is null then return false; end if;

    -- numeric (int/float, optional sign, decimals, exponent)
    if regexp_like(p_str, '^\s*[+-]?(\d+|\d+\.\d*|\.\d+)([eE][+-]?\d+)?\s*$') then
      return true;
    end if;

    -- ISO-8601 date/time (YYYY-MM-DD, with optional time/TZ)
    if regexp_like(p_str,
        '^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}(:\d{2}(\.\d{1,6})?)?(Z|[+-]\d{2}:\d{2})?)?$') then
      return true;
    end if;

    -- dd/mm/yyyy or dd-mm-yyyy (optional time)
    if regexp_like(p_str,
        '^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}([ T]\d{2}:\d{2}(:\d{2})?)?$') then
      return true;
    end if;

    -- Month name dates (e.g., 29 Oct 2025, Oct 29, 2025)
    if regexp_like(p_str,
        '^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4}$',
        'i') then
      return true;
    end if;

    return false;
  end;

  -- ====== NEW: token map helpers (single-row JSON) ======
  -- Shape:
  -- { "by_col": { "COL":[{"orig":"...","tok":"«COL_1»"}, ...] },
  --   "reverse": { "«COL_1»":"..." },
  --   "meta": { "created_at":"...", "token_prefix":"«", "token_suffix":"»" } }

    /* ======== Redaction utilities (forward/reverse map) ======== */
  -- Safe regex escape for literals/tokens (CLOB-in, VARCHAR2-out)
  function re_esc(p in varchar2) return varchar2 is
  begin
    return regexp_replace(nvl(p,''), '([\\.^$|()\\[\\]{}*+?])', '\\\1');
  end;

  -- Load token map row (create empty JSON if missing)
  procedure load_or_init_token_map(
    p_log_id          in  number,
    p_chat_id         out number,
    p_token_map_json  out clob
  ) is
  begin
    begin
      select chat_id, token_map_json
        into p_chat_id, p_token_map_json
        from CHATBOT_NL2SQL_REDACTION
       where log_id = p_log_id
        order by created_at desc
        fetch first 1 row only;
    exception
      when no_data_found then
        p_chat_id := null;
        p_token_map_json := '{"forward":{},"reverse":{}}';
    end;
  end load_or_init_token_map;

  -- Merge/upsert token map row
  procedure upsert_redaction_map(
    p_log_id                 in number,
    p_chat_id                in number,
    p_token_map_json         in clob,
    p_masked_preview_json    in clob default null,
    p_original_preview_json  in clob default null
  ) is
  begin
    merge into OCI_FOCUS_REPORTS.CHATBOT_NL2SQL_REDACTION t
    using (select p_log_id as log_id from dual) s
       on (t.log_id = s.log_id)
    when matched then update set
      t.chat_id         = p_chat_id,
      t.token_map_json  = p_token_map_json,
      t.redacted_value  = coalesce(p_masked_preview_json, t.redacted_value),
      t.original_value  = coalesce(p_original_preview_json, t.original_value)
    when not matched then insert (
      log_id, chat_id, token_map_json, redacted_value, original_value, map_version, created_at
    ) values (
      p_log_id, p_chat_id, p_token_map_json, p_masked_preview_json, p_original_preview_json, 1, systimestamp
    );
  exception when others then null; -- best-effort, never break the caller
  end upsert_redaction_map;

  -- Persist / update the single-row TOKEN_MAP_JSON
  procedure upsert_token_map_json(
    p_ctx   in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_log_id in number,
    p_chat_id in number,
    p_map_json in clob
  ) is
  begin
    merge into OCI_FOCUS_REPORTS.CHATBOT_NL2SQL_REDACTION r
    using (select p_log_id as log_id, p_chat_id as chat_id from dual) s
       on (r.log_id = s.log_id)
    when matched then
      update set r.token_map_json = p_map_json,
                 r.chat_id        = s.chat_id,
                 r.dataset        = p_ctx.dataset,
                 r.environment    = p_ctx.environment,
                 r.map_version    = nvl(r.map_version,1),
                 r.created_at     = systimestamp
    when not matched then
      insert (log_id, chat_id, dataset, environment, token_map_json, map_version, created_at)
      values (s.log_id, s.chat_id, p_ctx.dataset, p_ctx.environment, p_map_json, 1, systimestamp);
  exception when others then null; -- never break caller
  end;

  -- Load existing TOKEN_MAP_JSON (if any)
  function load_token_map_json(p_log_id in number) return clob is
    v clob;
  begin
    select token_map_json into v
      from OCI_FOCUS_REPORTS.CHATBOT_NL2SQL_REDACTION
     where log_id = p_log_id;
    return v;
  exception when others then
    return null;
  end;

  function get_redaction_map_json(
    p_log_id in number
  ) return clob
  is
  begin
    -- delegate to the existing private helper
    return load_token_map_json(p_log_id);
  exception
    when others then
      -- fail-safe: no map
      return null;
  end get_redaction_map_json;

  /* Old
  -- Build a TOKEN_MAP_JSON from a preview JSON (array of objects).
  -- Skips numeric/date-like strings.
  function build_token_map_from_preview(p_preview in clob) return clob is
    j_in    json_element_t;
    j_rev   json_object_t := json_object_t(); -- token -> original
    j_bycol json_object_t := json_object_t(); -- column/path -> [{orig,tok},...]
    j_root  json_object_t := json_object_t();

    procedure add_pair(p_col varchar2, p_val varchar2, p_tok varchar2) is
      arr json_array_t;
      obj json_object_t := json_object_t();
    begin
      if not j_bycol.has(p_col) then
        j_bycol.put(p_col, json_array_t());
      end if;
      arr := j_bycol.get_array(p_col);
      obj.put('orig', p_val);
      obj.put('tok',  p_tok);
      arr.append(obj);
      if not j_rev.has(p_tok) then
        j_rev.put(p_tok, p_val);
      end if;
    end;

    function mk_token(p_val varchar2) return varchar2 is
    begin
      return '<<T:SHA256:' || sha256_hex(p_val) || '>>';
    end;

    procedure walk(p_path varchar2, e json_element_t) is
      obj  json_object_t;
      arr  json_array_t;
      keys json_key_list;
      k    varchar2(4000);
      s    varchar2(32767);
    begin
      if e is null then
        null;
      elsif e.is_scalar then
        s := e.to_string;
        if regexp_like(s, '^".*"$') then
          s := regexp_replace(s, '^"(.*)"$', '\1');
          if s is not null and not is_numeric_or_date_like(s) then
            add_pair(nvl(regexp_substr(p_path, '[^.]+$', 1, 1), '*'), s, mk_token(s));
          end if;
        end if;
      elsif e.is_object then
        obj  := treat(e as json_object_t);
        keys := obj.get_keys;
        for i in 1 .. keys.count loop
          k := keys(i);
          walk(case when p_path is null then k else p_path||'.'||k end, obj.get(k));
        end loop;
      elsif e.is_array then
        arr := treat(e as json_array_t);
        for i in 0 .. arr.get_size-1 loop
          walk(case when p_path is null then '[]' else p_path||'.[]' end, arr.get(i));
        end loop;
      end if;
    end;

  begin
    if p_preview is null then return null; end if;

    begin
      j_in := json_element_t.parse(p_preview);
    exception when others then
      return null; -- don't produce a map on invalid JSON
    end;

    walk(null, j_in);

    -- meta + root
    declare m json_object_t := json_object_t(); begin
      m.put('created_at', to_char(systimestamp, 'YYYY-MM-DD"T"HH24:MI:SS.FF3TZH:TZM'));
      m.put('token_prefix','<<'); m.put('token_suffix','>>'); m.put('algo','SHA256');
      j_root.put('by_col',  j_bycol);
      j_root.put('reverse', j_rev);
      j_root.put('meta',    m);
    end;

    return j_root.to_string;
  end;*/

  -- Apply FORWARD map (original -> token) to arbitrary text using the saved map
  function redact_text_with_forward_map(
    p_log_id in number,
    p_text   in clob
  ) return clob
  is
    l_map_json clob;
    j          json_object_t;
    fwd        json_object_t;
    keys       json_key_list;
    out_txt    clob := p_text;
    key        varchar2(4000);
    val        varchar2(32767);
  begin
    if p_text is null then
      return null;
    end if;

    l_map_json := load_token_map_json(p_log_id);
    if l_map_json is null then
      return p_text;
    end if;

    j   := json_object_t.parse(l_map_json);

    -- 1) pairs → do replacements
    declare
      arr json_array_t := j.get_array('pairs');
      o   json_object_t;
      orig varchar2(32767);
      tok  varchar2(32767);
    begin
      if arr is not null and arr.get_size > 0 then
        for i in 0 .. arr.get_size-1 loop
          o := treat(arr.get(i) as json_object_t);
          orig := o.get_string('orig');
          tok  := o.get_string('tok');
          if orig is not null and tok is not null then
            out_txt := regexp_replace(out_txt, re_esc(orig), tok, 1, 0, 'n');
          end if;
        end loop;
        return out_txt;
      end if;
    end;

    -- 2) fallback: legacy forward
    fwd := j.get_object('forward');
    if fwd is null or fwd.get_size = 0 then
      return p_text;
    end if;

    keys := fwd.get_keys;

    -- Longest-first to avoid substring collisions
    for pass in 1..2 loop
      for i in 1 .. keys.count loop
        key := keys(i);
        if key is not null then
          if (pass = 1 and length(key) >= 12) or (pass = 2 and length(key) < 12) then
            val := fwd.get_string(key);
            out_txt := regexp_replace(out_txt, re_esc(key), val, 1, 0, 'n');
          end if;
        end if;
      end loop;
    end loop;

    return out_txt;
  exception when others then
    return p_text;
  end;

  -- Phase 6: Tokenize preview JSON (per-value, column-aware), persist map, return valid JSON
  function redact_preview_json(
    p_ctx      in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_log_id   in number,
    p_preview  in clob,
    p_chat_id  in number   default null,
    p_req_id   in varchar2 default null
  ) return clob
  is
    -- JSON working vars
    e_root   json_element_t;
    a_rows   json_array_t;
    o_row    json_object_t;
    klist    json_key_list;
    i        pls_integer;
    j        pls_integer;
    key      varchar2(4000);
    val_elm  json_element_t;
    val_str  varchar2(32767);
    seq      pls_integer := 0;
    l_chat_id number;

    -- forward = original -> token, reverse = token -> original
    j_fwd    json_object_t := json_object_t();
    j_rev    json_object_t := json_object_t();

    -- Helpers (local to keep surface area small)
    function is_sensitive(p_col in varchar2, p_val in varchar2) return boolean is
    begin
      -- Heuristic; you can later make this param-driven via ctx (REDACTION_COLUMN_MODE_JSON)
      if p_col is null then return false; end if;
      if regexp_like(p_col, '(NAME|EMAIL|PHONE|ADDR|ADDRESS|ACCOUNT|CONTACT|CUSTOMER|PERSON|USER)', 'i') then
        return true;
      end if;
      return false;
    end;

    function looks_numeric_or_date_like(p in varchar2) return boolean is
    begin
      -- Reuse your existing global helper semantics (copied locally to avoid cross-calls in parse errors)
      if p is null then return false; end if;

      if regexp_like(p, '^\s*[+-]?(\d+|\d+\.\d*|\.\d+)([eE][+-]?\d+)?\s*$') then
        return true;
      end if;

      if regexp_like(p,
          '^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}(:\d{2}(\.\d{1,6})?)?(Z|[+-]\d{2}:\d{2})?)?$') then
        return true;
      end if;

      if regexp_like(p,'^\d{1,2}[/-]\d{1,2}[/-]\d{2,4}([ T]\d{2}:\d{2}(:\d{2})?)?$') then
        return true;
      end if;

      if regexp_like(p,'^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4}$','i') then
        return true;
      end if;

      return false;
    end;

    -- Helpers (place near other small utils)
    function norm_col(p in varchar2) return varchar2 is
    begin
      return upper(regexp_replace(nvl(p,''), '[^A-Z0-9_]+', '_'));
    end;

    function word_count(p in varchar2) return pls_integer is
      v varchar2(32767) := nvl(trim(p),'');
    begin
      if v is null then return 0; end if;
      return regexp_count(v, '\S+', 1, 'n');
    end;

    function clamp_len(p in varchar2, pmax number := 120) return number is
      n number := nvl(length(p),0);
    begin
      return case when n > pmax then pmax else n end;
    end;

    function sha256_hex6(p in varchar2) return varchar2 is
      r raw(32);
    begin
      r := dbms_crypto.hash(utl_i18n.string_to_raw(nvl(p,''), 'AL32UTF8'), dbms_crypto.hash_sh256);
      return substr(rawtohex(r),1,6);
    end;

    -- Column-aware token builder using JSON objects j_fwd/j_rev
    function token_for(p_col varchar2, p_literal varchar2) return varchar2 is
      key varchar2(32767) := p_literal;
      tok varchar2(32767);
      col varchar2(128) := norm_col(p_col);
      w   pls_integer   := word_count(p_literal);
      l   number        := clamp_len(p_literal, 120);
      h6  varchar2(6)   := sha256_hex6(p_literal);
    begin
      -- If we already issued a token for this exact literal, reuse it
      if j_fwd.has(key) then
        return j_fwd.get_string(key);
      end if;

      tok := '«STR:'||col||':W'||w||':L'||l||':H'||h6||'»';

      -- Update forward and reverse JSON maps
      j_fwd.put(key, tok);
      if not j_rev.has(tok) then
        j_rev.put(tok, key);
      end if;

      return tok;
    end;

    -- persist forward/reverse to CHATBOT_NL2SQL_REDACTION
    procedure persist_map is
      jroot   json_object_t := json_object_t();
      l_map   clob;
      klist   json_key_list;
      pairs   json_array_t := json_array_t();
      i       pls_integer;
      o       json_object_t;
    begin
      -- Build pairs: [{"orig":"...","tok":"..."}]
      klist := j_fwd.get_keys;
      for i in 1 .. nvl(klist.count,0) loop
        o := json_object_t();
        o.put('orig', klist(i));
        o.put('tok',  j_fwd.get_string(klist(i)));
        pairs.append(o);
      end loop;

      jroot.put('pairs',   pairs);   -- <-- safe, no non-ASCII keys
      jroot.put('reverse', j_rev);   -- <-- token keys are ASCII

      l_map := jroot.to_clob;

      merge into OCI_FOCUS_REPORTS.CHATBOT_NL2SQL_REDACTION d
      using (
        select p_log_id as log_id,
              (select chat_id from CHATBOT_NL2SQL_LOG where id = p_log_id) as chat_id
        from dual
      ) s
      on (d.log_id = s.log_id)
      when matched then update set
        d.token_map_json = l_map,
        d.dataset        = p_ctx.dataset,
        d.environment    = p_ctx.environment,
        d.chat_id        = coalesce(s.chat_id, d.chat_id),
        d.created_at     = systimestamp
      when not matched then insert (log_id, chat_id, dataset, environment, token_map_json, map_version, created_at) 
      values (s.log_id, s.chat_id, p_ctx.dataset, p_ctx.environment, l_map, 1, systimestamp);
    exception
      when others then
        chatbot_core_io_pkg.logv(
          p_ctx,'REDACT_PREVIEW',p_req_id,
          sqlerrm||' | mapSizePairs='||case when pairs is null then 0 else pairs.get_size end,
          p_log_id, l_chat_id
        );
    end;

  begin
    -- Resolve real chat_id from the log entry
    begin
      select chat_id
        into l_chat_id
        from CHATBOT_NL2SQL_LOG
      where id = p_log_id;
    exception
      when no_data_found then
        l_chat_id := null;
      when others then
        l_chat_id := null;
    end;
    if p_preview is null or trim(p_preview) is null then
      return p_preview;
    end if;

    -- Parse as JSON (array or object)
    begin
      e_root := json_element_t.parse(p_preview);
    exception when others then
      -- invalid JSON: do nothing
      return p_preview;
    end;

    -- If it's a single object, wrap in a one-element array to unify logic
    if e_root is of (json_object_t) then
      a_rows := json_array_t();
      a_rows.append(e_root);
    elsif e_root is of (json_array_t) then
      a_rows := treat(e_root as json_array_t);
    else
      return p_preview;
    end if;

    -- Walk each row and build a brand-new array; never mutate the source in place
    declare
      a_out json_array_t := json_array_t();
      sz    pls_integer  := a_rows.get_size;  -- cache original size
    begin
      for i in 0 .. sz - 1 loop
        if a_rows.get(i) is of (json_object_t) then
          -- read-only view of the input row
          declare
            in_row json_object_t := treat(a_rows.get(i) as json_object_t);
            out_row json_object_t := json_object_t(); -- new row we will emit
            keys   json_key_list := in_row.get_keys;
            k      varchar2(4000);
            ve     json_element_t;
            vs     varchar2(32767);
          begin
            for j in 1 .. keys.count loop
              k  := keys(j);
              ve := in_row.get(k);

              -- non-scalars: copy as-is
              if not ve.is_scalar then
                out_row.put(k, ve);

              else
                -- stringify & strip quotes json_element_t adds for strings
                vs := regexp_replace(ve.to_string, '^"(.*)"$', '\1');

                -- If already a token, copy as-is
                if regexp_like(vs, '^«STR:[^»]+»$') then
                  out_row.put(k, vs);

                -- Skip blanks, numeric/date-like
                elsif vs is null or length(trim(vs)) = 0 or looks_numeric_or_date_like(vs) then
                  out_row.put(k, ve);

                -- Optional: only mask sensitive-looking columns
                -- (uncomment the next two lines if you want column gating)
                -- elsif not is_sensitive(k, vs) then
                --   out_row.put(k, ve);

                else
                  out_row.put(k, token_for(k, vs));
                end if;
              end if;
            end loop;

            a_out.append(out_row); -- append exactly one output row per input row
          end;
        else
          -- keep non-object entries untouched
          a_out.append(a_rows.get(i));
        end if;
      end loop;

      -- swap arrays atomically by returning the new one
      a_rows := a_out;
    end;

    -- Persist the map (only if any entries exist)
    if j_fwd.get_size > 0 then
      persist_map;
      -- DEBUG: token map stats + samples
      begin
        if chatbot_core_io_pkg.debug_on(p_ctx) then
          chatbot_core_io_pkg.logv(
            p_ctx,'REDACT_PREVIEW',p_req_id,
            'forward='||j_fwd.get_size||', reverse='||j_rev.get_size,
            p_log_id, nvl(l_chat_id, null)
          );

          declare
            klist json_key_list := j_fwd.get_keys;
            lim   pls_integer   := least(nvl(klist.count,0), 3);
          begin
            for i in 1 .. lim loop
              chatbot_core_io_pkg.logv(
                p_ctx,'REDACT_PREVIEW',p_req_id,
                '[pair'||i||'] '||substr(klist(i),1,200)||' -> '||substr(j_fwd.get_string(klist(i)),1,200),
                p_log_id, nvl(l_chat_id, null)
              );
            end loop;
          end;
        end if;
      exception when others then null; end;
    end if;

    -- If original root was an object, return the first array element as object
    if e_root is of (json_object_t) then
      return treat(a_rows.get(0) as json_object_t).to_clob;
    else
      return a_rows.to_clob;
    end if;

  exception
    when others then
      -- fail-open: return original preview if anything goes wrong
      return p_preview;
  end redact_preview_json;

  ------- Phase 6
  -- Redact literals in a free-text summary using the saved TOKEN_MAP_JSON.
  -- If no map exists yet, build it from p_preview_json and save it.
  function redact_preview_literals(
    p_ctx          in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_preview_json in clob,
    p_summary_text in clob,
    p_log_id       in number,
    p_chat_id      in number,
    p_req_id       in varchar2
  ) return clob
  is
    l_map_json  clob;
    j           json_object_t;
    fwd         json_object_t;
    keys        json_key_list;
    out_txt     clob := p_summary_text;
    key         varchar2(4000);
    val         varchar2(32767);
    l_chat_id   number;  -- <-- use a local for OUT param calls
    ignore      clob;
  begin
    -- DEBUG: input summary (pre-tokenize)
    begin
      if chatbot_core_io_pkg.debug_on(p_ctx) then
        chatbot_core_io_pkg.logc(
          p_ctx,'REDACT_SUMMARY',p_req_id,
          '[in] summary_text',
          p_summary_text,
          p_log_id, p_chat_id);
      end if;
    exception when others then null; end;
    -- Prefer provided JSON (builds map) but fall back to persisted map
    if p_preview_json is not null then
      begin
        -- Build+persist the token map from the preview
        -- (redact_preview_json writes into CHATBOT_NL2SQL_REDACTION)
        ignore := redact_preview_json(p_ctx, p_log_id, p_preview_json, p_chat_id, p_req_id);
      exception when others then null; end;
    end if;

    -- Load (persisted) map
    load_or_init_token_map(p_log_id, l_chat_id, l_map_json);
    if (l_map_json is null or l_map_json = '{"forward":{},"reverse":{}}')
      and p_preview_json is not null
    then
      begin
        ignore := redact_preview_json(p_ctx, p_log_id, p_preview_json, p_chat_id, p_req_id); -- builds + persists
        load_or_init_token_map(p_log_id, l_chat_id, l_map_json);        -- reload after build
      exception when others then null; end;
    end if;

    -- If still nothing, bail out
    if l_map_json is null then
      return out_txt;
    end if;

    j   := json_object_t.parse(l_map_json);
    -- Try new "pairs" first
    declare
      arr json_array_t;
      i   pls_integer;
      o   json_object_t;
      orig varchar2(32767);
      tok  varchar2(32767);
    begin
      arr := j.get_array('pairs');
      if arr is not null and arr.get_size > 0 then
        -- Build a local forward map from pairs for replacement
        for i in 0 .. arr.get_size-1 loop
          o := treat(arr.get(i) as json_object_t);
          orig := o.get_string('orig');
          tok  := o.get_string('tok');
          if orig is not null and tok is not null then
            -- longest-first: store in a local collection or just apply now
            out_txt := regexp_replace(out_txt, re_esc(orig), tok, 1, 0, 'n');
          end if;
        end loop;
        return out_txt; -- done
      end if;
    end;

    -- Fallback: legacy "forward" object (ASCII-only keys)
    fwd := j.get_object('forward');
    if fwd is not null and fwd.get_size > 0 then

      keys := fwd.get_keys;

      -- Longest-first: two passes to avoid substring collisions
      for pass in 1..2 loop
        for i in 1 .. keys.count loop
          key := keys(i);
          if key is not null then
            if (pass = 1 and length(key) >= 12) or (pass = 2 and length(key) < 12) then
              val := fwd.get_string(key);
              out_txt := regexp_replace(out_txt, re_esc(key), val, 1, 0, 'n');
            end if;
          end if;
        end loop;
      end loop;

      -- DEBUG: tokenization result + map size and a few examples
      begin
        if chatbot_core_io_pkg.debug_on(p_ctx) then
          chatbot_core_io_pkg.logc(
            p_ctx,'REDACT_SUMMARY',p_req_id,
            '[out] text',
            out_txt,
            p_log_id, p_chat_id);

          chatbot_core_io_pkg.logv(
            p_ctx,'REDACT_SUMMARY','[forward_size]',
            case when fwd is null then '0' else to_char(fwd.get_size) end,
            p_log_id, p_chat_id
          );

          if fwd is not null and fwd.get_size > 0 then
            declare
              k json_key_list := fwd.get_keys;
              lim pls_integer := least(nvl(k.count,0), 3);
            begin
              for i in 1 .. lim loop
                chatbot_core_io_pkg.logv(
                  p_ctx,'REDACT_SUMMARY','[pair'||i||']',
                  substr(k(i),1,200)||' -> '||substr(fwd.get_string(k(i)),1,200),
                  p_log_id, p_chat_id
                );
              end loop;
            end;
          end if;
        end if;
      exception when others then null; end;

          return out_txt;
    end if;

  exception when others then
    return p_summary_text; -- best-effort
  end redact_preview_literals;

  procedure write_summary_detokenized(
    p_log_id            in number,
    p_summary_tokenized in clob,
    p_ctx               in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_chat_id           in number,
    p_req_id            in varchar2
  ) is
    l_map_json clob;
    j          json_object_t;
    rev        json_object_t;
    keys       json_key_list;
    tok        varchar2(4000);
    val        varchar2(32767);
    out_raw    clob := p_summary_tokenized;
    l_chat_id  number;
  begin
    -- DEBUG: tokenized summary in
    begin
      if chatbot_core_io_pkg.debug_on(p_ctx) then
        chatbot_core_io_pkg.logc(
          p_ctx,'DETOK',p_req_id,
          '[in-tokenized]',
          chatbot_core_io_pkg.clamp_clob(p_summary_tokenized, 1200),
          p_log_id, p_chat_id
        );
      end if;
    exception when others then null; end;

    if p_summary_tokenized is null then
      update CHATBOT_NL2SQL_LOG
        set summary_text = null
      where id = p_log_id;
      return;
    end if;

    load_or_init_token_map(p_log_id, l_chat_id, l_map_json);
    j   := json_object_t.parse(l_map_json);
    rev := j.get_object('reverse');

    -- Optional debug: token presence check
    begin
      if chatbot_core_io_pkg.debug_on(p_ctx) then
        declare
          vtok varchar2(4000);
          miss pls_integer := 0;
          seen pls_integer := 0;
          ixs  pls_integer := 1;
        begin
          loop
            vtok := regexp_substr(p_summary_tokenized, '«STR:[^»]+»', 1, ixs, null, 0);
            exit when vtok is null;
            seen := seen + 1;
            if rev is null or not rev.has(vtok) then
              miss := miss + 1;
              if miss <= 5 then
                chatbot_core_io_pkg.logv(p_ctx,'DETOK','[missing]', vtok, p_log_id, nvl(p_chat_id, l_chat_id));
              end if;
            end if;
            ixs := ixs + 1;
          end loop;

          chatbot_core_io_pkg.logv(
            p_ctx,'DETOK','[tokens]',
            'found='||seen||', missing='||miss||', revSize='||case when rev is null then 0 else rev.get_size end,
            p_log_id, nvl(p_chat_id, l_chat_id)
          );
        end;
      end if;
    exception when others then null; end;

    if rev is not null and rev.get_size > 0 then
      keys := rev.get_keys;

      for pass in 1..2 loop
        for i in 1 .. keys.count loop
          tok := keys(i);
          if tok is not null then
            if (pass = 1 and length(tok) >= 12) or (pass = 2 and length(tok) < 12) then
              val := rev.get_string(tok);
              out_raw := regexp_replace(out_raw, re_esc(tok), val, 1, 0, 'n');
            end if;
          end if;
        end loop;
      end loop;
    end if;

    -- DEBUG: detokenized summary out
    begin
      if chatbot_core_io_pkg.debug_on(p_ctx) then
        chatbot_core_io_pkg.logc(
          p_ctx,'DETOK',p_req_id,
          '[out-detokenized]',
          chatbot_core_io_pkg.clamp_clob(out_raw, 1200),
          p_log_id, p_chat_id
        );
      end if;
    exception when others then null; end;

    update CHATBOT_NL2SQL_LOG
      set summary_text = out_raw
    where id = p_log_id;

  exception
    when others then
      -- last resort: write tokenized text so UI still shows something
      begin
        update CHATBOT_NL2SQL_LOG
          set summary_text = p_summary_tokenized
        where id = p_log_id;
      exception when others then null; end;
  end;

  -- === Fetch preview JSON (array of objects) =================================
  function fetch_preview_json (
    p_sql       in clob,
    p_row_limit in number default 50
  ) return clob
  is
    l_cursor    integer;
    l_desc_tab  dbms_sql.desc_tab;
    l_col_cnt   integer;
    l_status    integer;
    l_out       clob;
    max_rows    pls_integer := least(nvl(p_row_limit,50),100);

    v_vc        varchar2(32767);
    v_c         clob;
    v_n         number;
    v_d         date;
    v_ts        timestamp;
  begin
    l_cursor := dbms_sql.open_cursor;
    dbms_sql.parse(
      l_cursor,
      to_clob('SELECT * FROM (')||p_sql||') WHERE ROWNUM <= '||max_rows,
      dbms_sql.native
    );

    dbms_sql.describe_columns(l_cursor, l_col_cnt, l_desc_tab);

    for i in 1..l_col_cnt loop
      case l_desc_tab(i).col_type
        when dbms_sql.varchar2_type  then dbms_sql.define_column(l_cursor,i,v_vc,32767);
        when dbms_sql.clob_type      then dbms_sql.define_column(l_cursor,i,v_c);
        when dbms_sql.number_type    then dbms_sql.define_column(l_cursor,i,v_n);
        when dbms_sql.date_type      then dbms_sql.define_column(l_cursor,i,v_d);
        when dbms_sql.timestamp_type then dbms_sql.define_column(l_cursor,i,v_ts);
        else dbms_sql.define_column(l_cursor,i,v_c);
      end case;
    end loop;

    l_status := dbms_sql.execute(l_cursor);

    apex_json.initialize_clob_output;
    apex_json.open_array;

    while dbms_sql.fetch_rows(l_cursor) > 0 loop
      apex_json.open_object;

      for i in 1..l_col_cnt loop
        declare k varchar2(128) := replace(l_desc_tab(i).col_name, '"', '');
        begin
          case l_desc_tab(i).col_type
            when dbms_sql.varchar2_type then
              dbms_sql.column_value(l_cursor,i,v_vc);
              if v_vc is null then apex_json.write_raw(k, 'null'); else apex_json.write(k, v_vc); end if;

            when dbms_sql.clob_type then
              dbms_sql.column_value(l_cursor,i,v_c);
              if v_c is null then apex_json.write_raw(k, 'null'); else apex_json.write(k, dbms_lob.substr(v_c, 32000, 1)); end if;

            when dbms_sql.number_type then
              dbms_sql.column_value(l_cursor,i,v_n);
              if v_n is null then apex_json.write_raw(k, 'null'); else apex_json.write(k, v_n); end if;

            when dbms_sql.date_type then
              dbms_sql.column_value(l_cursor,i,v_d);
              if v_d is null then apex_json.write_raw(k, 'null'); else apex_json.write(k, to_char(v_d,'YYYY-MM-DD"T"HH24:MI:SS')); end if;

            when dbms_sql.timestamp_type then
              dbms_sql.column_value(l_cursor,i,v_ts);
              if v_ts is null then apex_json.write_raw(k, 'null'); else apex_json.write(k, to_char(v_ts,'YYYY-MM-DD"T"HH24:MI:SS.FF')); end if;

            else
              dbms_sql.column_value(l_cursor,i,v_c);
              if v_c is null then apex_json.write_raw(k, 'null'); else apex_json.write(k, dbms_lob.substr(v_c, 32000, 1)); end if;
          end case;
        end;
      end loop;

      apex_json.close_object;
    end loop;

    apex_json.close_array;
    l_out := apex_json.get_clob_output;
    apex_json.free_output;

    dbms_sql.close_cursor(l_cursor);
    return l_out;

  exception
    when others then
      if dbms_sql.is_open(l_cursor) then dbms_sql.close_cursor(l_cursor); end if;
      apex_json.free_output;
      raise;
  end;

  -- === Fetch FULL JSON (all rows; clamped by p_max_chars) ======================
  function fetch_full_json(
    p_sql        in clob,
    p_max_chars  in number
  ) return clob
  is
    l_cursor    integer;
    l_desc_tab  dbms_sql.desc_tab;
    l_col_cnt   integer;
    l_status    integer;
    l_out       clob;
    l_cap       number := nvl(p_max_chars, 2000000);

    v_vc        varchar2(32767);
    v_c         clob;
    v_n         number;
    v_d         date;
    v_ts        timestamp;

    procedure write_value(p_key varchar2, p_is_null boolean, p_vc varchar2 default null,
                          p_c clob default null, p_n number default null, p_d date default null,
                          p_ts timestamp default null, p_coltype pls_integer default null) is
    begin
      if p_is_null then
        apex_json.write_raw(p_key, 'null');
      else
        case p_coltype
          when dbms_sql.varchar2_type then apex_json.write(p_key, p_vc);
          when dbms_sql.clob_type     then apex_json.write(p_key, dbms_lob.substr(p_c, 32000, 1));
          when dbms_sql.number_type   then apex_json.write(p_key, p_n);
          when dbms_sql.date_type     then apex_json.write(p_key, to_char(p_d,'YYYY-MM-DD"T"HH24:MI:SS'));
          when dbms_sql.timestamp_type then apex_json.write(p_key, to_char(p_ts,'YYYY-MM-DD"T"HH24:MI:SS.FF'));
          else                             apex_json.write(p_key, dbms_lob.substr(p_c, 32000, 1));
        end case;
      end if;
    end;
  begin
    if p_sql is null then return null; end if;

    l_cursor := dbms_sql.open_cursor;
    -- NO rownum limit here: this is the "full" fetcher
    dbms_sql.parse(l_cursor, p_sql, dbms_sql.native);

    dbms_sql.describe_columns(l_cursor, l_col_cnt, l_desc_tab);

    for i in 1..l_col_cnt loop
      case l_desc_tab(i).col_type
        when dbms_sql.varchar2_type  then dbms_sql.define_column(l_cursor,i,v_vc,32767);
        when dbms_sql.clob_type      then dbms_sql.define_column(l_cursor,i,v_c);
        when dbms_sql.number_type    then dbms_sql.define_column(l_cursor,i,v_n);
        when dbms_sql.date_type      then dbms_sql.define_column(l_cursor,i,v_d);
        when dbms_sql.timestamp_type then dbms_sql.define_column(l_cursor,i,v_ts);
        else dbms_sql.define_column(l_cursor,i,v_c);
      end case;
    end loop;

    l_status := dbms_sql.execute(l_cursor);

    apex_json.initialize_clob_output;
    apex_json.open_array;

    while dbms_sql.fetch_rows(l_cursor) > 0 loop
      apex_json.open_object;

      for i in 1..l_col_cnt loop
        declare
          k varchar2(128) := replace(l_desc_tab(i).col_name, '"', '');
          isnull boolean := false;
        begin
          case l_desc_tab(i).col_type
            when dbms_sql.varchar2_type then
              dbms_sql.column_value(l_cursor,i,v_vc); isnull := v_vc is null;
              write_value(k, isnull, p_vc => v_vc, p_coltype => dbms_sql.varchar2_type);

            when dbms_sql.clob_type then
              dbms_sql.column_value(l_cursor,i,v_c); isnull := v_c is null;
              write_value(k, isnull, p_c => v_c, p_coltype => dbms_sql.clob_type);

            when dbms_sql.number_type then
              dbms_sql.column_value(l_cursor,i,v_n); isnull := v_n is null;
              write_value(k, isnull, p_n => v_n, p_coltype => dbms_sql.number_type);

            when dbms_sql.date_type then
              dbms_sql.column_value(l_cursor,i,v_d); isnull := v_d is null;
              write_value(k, isnull, p_d => v_d, p_coltype => dbms_sql.date_type);

            when dbms_sql.timestamp_type then
              dbms_sql.column_value(l_cursor,i,v_ts); isnull := v_ts is null;
              write_value(k, isnull, p_ts => v_ts, p_coltype => dbms_sql.timestamp_type);

            else
              dbms_sql.column_value(l_cursor,i,v_c); isnull := v_c is null;
              write_value(k, isnull, p_c => v_c); -- generic
          end case;
        end;
      end loop;

      apex_json.close_object;

      -- Character cap guard: stop once we exceed p_max_chars (leave array valid)
      if dbms_lob.getlength(apex_json.get_clob_output) >= l_cap then
        exit;
      end if;
    end loop;

    apex_json.close_array;
    l_out := apex_json.get_clob_output;
    apex_json.free_output;

    dbms_sql.close_cursor(l_cursor);
    return l_out;

  exception
    when others then
      if dbms_sql.is_open(l_cursor) then dbms_sql.close_cursor(l_cursor); end if;
      apex_json.free_output;
      raise;
  end fetch_full_json;

    ----New glossary implementation 01102025
    function glossary_lookup_quick_text(
        p_ctx        in chatbot_core_ctx_params_pkg.run_ctx_t,
        p_query      in clob,
        p_max_chars  in number,
        p_threshold  in number
    ) return clob
    is
        l_gloss_all  clob;
        l_text       clob;
        l_text_lc    clob;
        l_q          varchar2(32767);
        l_tokens     sys.odcivarchar2list := sys.odcivarchar2list(); -- unigrams
        l_bigrams    sys.odcivarchar2list := sys.odcivarchar2list(); -- bigrams
        l_hits       pls_integer := 0;
        l_hits2      pls_integer := 0; -- bigram hits
        l_total      pls_integer := 0;
        l_total2     pls_integer := 0; -- bigram total
        l_ratio      number := 0;
        l_best_pos   pls_integer := 0;   -- best unigram pos
        l_best_tok   varchar2(4000);

        l_best2_pos  pls_integer := 0;   -- best bigram pos
        l_best2_tok  varchar2(4000);

        -- tiny stopword list (generic)
        type t_stop is table of varchar2(30);
        l_stop t_stop := t_stop('the','a','an','of','and','or','to','in','on','for','with','by',
                                'is','are','be','was','were','as','at','from','this','that','these',
                                'those','it','its','into','about','how','what','which','when','who');

        -- helpers
        function is_stop(p_tok varchar2) return boolean is
        begin
            for i in 1 .. l_stop.count loop
            if p_tok = l_stop(i) then return true; end if;
            end loop;
            return false;
        end;

        procedure push_unique(io_list in out nocopy sys.odcivarchar2list, p_tok in varchar2) is
        begin
            if p_tok is null then return; end if;
            for i in 1 .. io_list.count loop
            if io_list(i) = p_tok then return; end if;
            end loop;
            io_list.extend; io_list(io_list.count) := p_tok;
        end;

        -- get surrounding paragraph (between blank lines)
        function paragraph_around(p_text clob, p_pos integer) return clob is
            l_len  integer := dbms_lob.getlength(p_text);
            l_l    integer := greatest(1, p_pos);
            l_start integer := l_l;
            l_end   integer := l_l;
            l_2nl   varchar2(2) := chr(10)||chr(10);
            l_prev  integer;
            l_next  integer;
        begin
            -- previous blank line
            l_prev := dbms_lob.instr(p_text, l_2nl, 1, 1);
            -- walk forward to last blank line before p_pos
            while l_prev > 0 and l_prev < l_l loop
            l_start := l_prev + 2;
            l_prev  := dbms_lob.instr(p_text, l_2nl, l_prev+1, 1);
            end loop;
            if l_start > l_l then l_start := 1; end if;

            -- next blank line after p_pos
            l_next := dbms_lob.instr(p_text, l_2nl, l_l, 1);
            if l_next = 0 then
            l_end := l_len;
            else
            l_end := l_next - 1;
            end if;

            return dbms_lob.substr(p_text, least(l_end, l_len) - greatest(1, l_start) + 1, greatest(1, l_start));
        end;

        procedure tokenize(p_line in varchar2) is
            v varchar2(32767) := p_line;
            t varchar2(32767);
            i pls_integer := 1;
            prev varchar2(4000) := null;
        begin
            loop
            t := regexp_substr(v, '\S+', 1, i);
            exit when t is null;
            t := regexp_replace(lower(t), '[^[:alnum:]]', '');
            if length(t) >= 3 and not is_stop(t) then
                push_unique(l_tokens, t);
                if prev is not null then
                push_unique(l_bigrams, prev||' '||t);
                end if;
                prev := t;
            end if;
            i := i + 1;
            end loop;
        end;

        begin
        if p_query is null then
            return null;
        end if;

        -- Load scoped glossary
        begin
            select content
            into l_gloss_all
            from (
                select p.content,
                    case
                        when p.dataset = p_ctx.dataset and p.environment = p_ctx.environment then 1
                        when p.dataset = p_ctx.dataset and p.environment is null              then 2
                        when p.dataset is null        and p.environment = p_ctx.environment  then 3
                        else 4
                    end rnk,
                    p.id
                from CHATBOT_PARAMETERS p
                where p.component_type = 'GLOSSARY_TEXT'
                and p.active = 'TRUE'
                and (p.dataset = p_ctx.dataset or p.dataset is null)
                and (p.environment = p_ctx.environment or p.environment is null)
            )
            order by rnk, id
            fetch first 1 row only;
        exception
            when no_data_found then
            return null;
        end;

        l_text := l_gloss_all;
        if l_text is null then
            return null;
        end if;

        l_text_lc := lower(l_text);

        -- Normalize prompt and tokenize (unigrams + bigrams)
        l_q := lower(regexp_replace(dbms_lob.substr(p_query, 4000, 1), '[^[:alnum:] ]', ' '));
        l_q := regexp_replace(l_q, '\s+', ' ');
        tokenize(l_q);

        l_total  := nvl(l_tokens.count, 0);
        l_total2 := nvl(l_bigrams.count, 0);
        if l_total = 0 and l_total2 = 0 then
            return null;
        end if;

        -- Unigram hits
        for k in 1 .. nvl(l_tokens.count,0) loop
            declare p integer; t varchar2(4000) := l_tokens(k); begin
            p := dbms_lob.instr(l_text_lc, t, 1, 1);
            if p > 0 then
                l_hits := l_hits + 1;
                if l_best_pos = 0 or length(t) > length(nvl(l_best_tok,'')) then
                l_best_pos := p; l_best_tok := t;
                end if;
            end if;
            end;
        end loop;

        -- Bigram hits (prefer these if any)
        for k in 1 .. nvl(l_bigrams.count,0) loop
            declare p integer; t varchar2(4000) := l_bigrams(k); begin
            p := dbms_lob.instr(l_text_lc, t, 1, 1);
            if p > 0 then
                l_hits2 := l_hits2 + 1;
                if l_best2_pos = 0 or length(t) > length(nvl(l_best2_tok,'')) then
                l_best2_pos := p; l_best2_tok := t;
                end if;
            end if;
            end;
        end loop;

        -- Compute confidence ratio (weight bigrams slightly higher if present)
        if l_total2 > 0 and l_hits2 > 0 then
            l_ratio := (l_hits + 1.6*l_hits2) / greatest(1, l_total + 1.6*l_total2);
        else
            l_ratio := case when l_total = 0 then 0 else l_hits / l_total end;
        end if;

        if l_ratio < nvl(p_threshold, 0.35) then
            return null;
        end if;

        -- Extract clean paragraph around the best position (prefer bigram anchor)
        declare
            anchor_pos integer := case when l_best2_pos > 0 then l_best2_pos else l_best_pos end;
            para       clob;
            out_json   clob;
        begin
            if anchor_pos <= 0 then
                para := chatbot_core_io_pkg.clamp_clob(
                        chatbot_core_io_pkg.one_line(l_text),
                        nvl(p_max_chars, 900));
            else
                para := paragraph_around(l_text, anchor_pos);
                para := chatbot_core_io_pkg.clamp_clob(
                        chatbot_core_io_pkg.one_line(para),
                        nvl(p_max_chars, 900));
            end if;

            apex_json.initialize_clob_output;
            apex_json.open_object;
                apex_json.write('match_score', l_ratio);
                apex_json.write('excerpt', para); -- safely escaped
            apex_json.close_object;
            out_json := apex_json.get_clob_output;
            apex_json.free_output;

            return out_json;
        end;

    exception
        when others then
            -- Never break the runner because of glossary logic
            return null;
    end;
    ----END - New glossary implementation 01102025

    --FOLLOWUP SQL Refinement 01102025
    function is_sql_refinement_request(p_text in clob) return boolean is
        v varchar2(32767);
    begin
        v := lower(substr(p_text,1,2000));
        -- very lightweight heuristic; tweak keywords freely
        if v like '% group by %' or v like 'group by %' then return true; end if;
        if v like '% order by %' or v like 'order by %' then return true; end if;
        if v like '% show % by %' or v like '% by % market%' then return true; end if;
        if v like '% add %filter%' or v like '% remove %filter%' then return true; end if;
        if v like '% filter %' or v like '% where %' then return true; end if;
        if v like '% compare %' or v like '% versus %' or v like '% vs %' then return true; end if;
        if v like '% change %grain%' or v like '% change % time %' then return true; end if;
        return false;
    end;

    ------------------------------------------------------------------------------
    -- FOLLOWUP: LLM decider (strict JSON)
    ------------------------------------------------------------------------------
    /*function classify_followup_decision(
      p_ctx            in  chatbot_core_ctx_params_pkg.run_ctx_t,
      p_prev_user      in  clob,
      p_prev_summary   in  clob,
      p_prev_sql       in  clob,
      p_user_text      in  clob,
      p_api_format     in  varchar2,
      p_model_id       in  varchar2,
      p_compartment_id in  varchar2,
      p_endpoint       in  varchar2,
      p_req_id         in  varchar2,
      p_log_id         in  number,
      p_chat_id        in  number
    ) return clob is
      l_system  clob;
      l_prompt  clob;
      l_payload clob;
      l_resp    clob;
      l_text    clob;
    begin
      l_system := chatbot_core_ctx_params_pkg.load_component(p_ctx, 'FOLLOWUP_DECIDER_SYSTEM');

      l_prompt :=
        l_system||chr(10)||
        '--- PREVIOUS USER ---'||chr(10)||nvl(chatbot_core_io_pkg.one_line(p_prev_user),'')||chr(10)||
        '--- PREVIOUS SUMMARY ---'||chr(10)||nvl(p_prev_summary,'')||chr(10)||
        '--- PREVIOUS SQL ---'||chr(10)||nvl(p_prev_sql,'')||chr(10)||
        '--- NEW MESSAGE ---'||chr(10)||chatbot_core_io_pkg.one_line(p_user_text)||chr(10)||
        '--- OUTPUT ---'||chr(10)||'{';

      l_payload := chatbot_core_io_pkg.build_payload_chat(
                     p_api_format, p_model_id, p_compartment_id, l_prompt, null, null, null);

      l_resp := chatbot_core_io_pkg.call_model(
                  p_ctx, 'FOLLOWUP', p_endpoint, l_payload, p_req_id, p_log_id, p_chat_id);

      l_text := chatbot_core_io_pkg.extract_text_from_chat_response(l_resp);

      return nvl(regexp_substr(l_text, '\{.*\}', 1, 1, 'n'), '{}');
    end;
    */
    function classify_followup_decision(
      p_ctx            in  chatbot_core_ctx_params_pkg.run_ctx_t,
      p_prev_user      in  clob,
      p_prev_summary   in  clob,
      p_prev_sql       in  clob,
      p_user_text      in  clob,
      p_api_format     in  varchar2,
      p_model_id       in  varchar2,
      p_compartment_id in  varchar2,
      p_endpoint       in  varchar2,
      p_req_id         in  varchar2,
      p_log_id         in  number,
      p_chat_id        in  number
    ) return clob is
      l_system   clob;
      l_prompt   clob;
      l_payload  clob;
      l_resp     clob;
      l_text     clob;
      -- NEW: pull deeper history for better follow-up decisions
      l_turns    number := 4;      -- default > 1 to fix (3) & (4)
      l_himax    number := 1800;   -- safe cap for the decider
      l_hist     clob;
    begin
      -- allow ctx overrides
      begin l_turns := chatbot_core_ctx_params_pkg.get_num_param(p_ctx,'FOLLOWUP_CONTEXT_TURNS', l_turns); exception when others then null; end;
      begin l_himax := chatbot_core_ctx_params_pkg.get_num_param(p_ctx,'FOLLOWUP_HISTORY_MAX_CHARS', l_himax); exception when others then null; end;

      -- build compact, multi-turn history (USER/SUMMARY/SQL snippets)
      l_hist := build_history(p_chat_id, l_turns, l_himax);

      l_system := chatbot_core_ctx_params_pkg.load_component(p_ctx, 'FOLLOWUP_DECIDER_SYSTEM');

      l_prompt :=
        l_system||chr(10)||
        case when l_hist is not null then l_hist||chr(10) else '' end||
        '--- PREVIOUS USER ---'||chr(10)||nvl(chatbot_core_io_pkg.one_line(p_prev_user),'')||chr(10)||
        '--- PREVIOUS SUMMARY ---'||chr(10)||nvl(p_prev_summary,'')||chr(10)||
        '--- PREVIOUS SQL ---'||chr(10)||nvl(p_prev_sql,'')||chr(10)||
        '--- NEW MESSAGE ---'||chr(10)||chatbot_core_io_pkg.one_line(p_user_text)||chr(10)||
        '--- OUTPUT ---'||chr(10)||'{';  -- STRICT JSON sentinel

      l_payload := chatbot_core_io_pkg.build_payload_chat(
                    p_api_format, p_model_id, p_compartment_id, l_prompt, 0, 1, 1);

      l_resp := chatbot_core_io_pkg.call_model(
                  p_ctx, 'FOLLOWUP', p_endpoint, l_payload, p_req_id, p_log_id, p_chat_id);

      l_text := chatbot_core_io_pkg.extract_text_from_chat_response(l_resp);
      return nvl(regexp_substr(l_text, '\{.*\}', 1, 1, 'n'), '{}');
    end;

  -- === Build trimmed multi-turn history block ================================
  function build_history (
    p_chat_id           in number,
    p_context_turns     in number,
    p_history_max_chars in number
  ) return clob is
    l_history clob;
    l_budget  number := p_history_max_chars;
  begin
    if p_context_turns is null or p_context_turns <= 0 then
      return null;
    end if;

    for r in (
      select *
        from (
          select id, nvl(created_at, systimestamp) as created_at,
                 user_prompt, generated_sql, summary_text
            from chatbot_nl2sql_log
           where chat_id = p_chat_id
           order by id desc
        )
       where rownum <= p_context_turns
       order by id
    ) loop
      exit when l_budget <= 0;
      declare
        l_user_snip clob := chatbot_core_io_pkg.clamp_clob(chatbot_core_io_pkg.one_line(r.user_prompt), 600);
        l_sum_snip  clob := chatbot_core_io_pkg.clamp_clob(chatbot_core_io_pkg.one_line(r.summary_text), 800);
        l_sql_snip  clob := chatbot_core_io_pkg.clamp_clob(chatbot_core_io_pkg.one_line(r.generated_sql), 400);
        l_block     clob;
      begin
        l_block := 'Turn #'||r.id||' @ '||to_char(r.created_at,'YYYY-MM-DD HH24:MI')||chr(10)
                   || 'User: '||nvl(l_user_snip,'')||chr(10)
                   || case when l_sum_snip is not null
                           then 'Prev Summary: '||l_sum_snip||chr(10)
                           else 'Prev SQL: '||nvl(l_sql_snip,'')||chr(10)
                      end;

        if dbms_lob.getlength(l_block) > l_budget then
          l_block := dbms_lob.substr(l_block, l_budget, 1);
        end if;

        l_history := nvl(l_history,'') || l_block || chr(10);
        l_budget  := l_budget - dbms_lob.getlength(l_block);
      end;
    end loop;

    if l_history is not null then
      l_history := '-- HISTORY (last '||p_context_turns||' turns) --' || chr(10) || l_history || chr(10);
    end if;

    return l_history;
  end;

  -- === list_tables_in_sql =====================================================
  function list_tables_in_sql(p_sql in clob) return sys.odcivarchar2list is
    res sys.odcivarchar2list := sys.odcivarchar2list();
    i   pls_integer := 0;
  begin
    execute immediate 'explain plan for ' || p_sql;
    for r in (
      select distinct nvl(object_owner, user) as owner, object_name as table_name
      from plan_table
      where object_type = 'TABLE' and object_name is not null
    ) loop
      i := i + 1;
      res.extend; res(i) := r.owner||'.'||r.table_name;
    end loop;
    return res;
  exception when others then
    return res;
  end;

  -- === build_mini_schema_for_sql =============================================
  function build_mini_schema_for_sql(p_sql clob, p_char_budget number := 2000) return clob is
    l_out     clob := to_clob('');
    l_budget  number := nvl(p_char_budget,2000);
  begin
    for t in (
      select distinct nvl(object_owner, user) as owner, object_name as table_name
      from plan_table
      where object_type = 'TABLE' and object_name is not null
    ) loop
      exit when l_budget <= 0;
      declare
        l_desc varchar2(4000);
      begin
        begin
          select summary_text
            into l_desc
            from chatbot_nl2sql_summary
           where table_name = t.table_name
           fetch first 1 row only;
        exception when others then l_desc := null; end;

        l_out := l_out || t.table_name || ': ' || nvl(l_desc,'') || chr(10) || '  cols: ';

        for c in (
          select column_name, data_type, nullable
            from all_tab_columns
           where owner = t.owner and table_name = t.table_name
           order by column_id
           fetch first 20 rows only
        ) loop
          l_out := l_out || c.column_name || ' ' || c.data_type ||
                   case when c.nullable='N' then ' not null' end || ', ';
        end loop;

        l_out := rtrim(l_out, ', ') || chr(10);
        l_budget := p_char_budget - nvl(dbms_lob.getlength(l_out),0);
      end;
    end loop;
    return chatbot_core_io_pkg.clamp_clob(l_out, p_char_budget);
  exception when others then
    return null;
  end;
  
  /*-- === build_mini_schema_for_sql =============================================
  function build_mini_schema_for_sql(p_sql clob, p_char_budget number := 2000) return clob is
    l_out     clob := to_clob('');
    l_budget  number := nvl(p_char_budget,2000);
  begin
    for t in (
      select distinct nvl(object_owner, user) as owner, object_name as table_name
        from plan_table
      where object_type = 'TABLE'
        and object_name is not null
    ) loop
      exit when l_budget <= 0;
      declare
        l_desc varchar2(4000);
        l_qual varchar2(261) := t.owner||'.'||t.table_name;
      begin
        -- Prefer JSON summary->$.summary; fallback to legacy plain text
        begin
          select coalesce(
                  case
                    when json_exists(s.summary_text, '$') then
                      json_value(s.summary_text, '$.summary' returning varchar2)
                  end,
                  dbms_lob.substr(s.summary_text, 4000, 1)
                )
            into l_desc
            from OCI_FOCUS_REPORTS.chatbot_nl2sql_summary s
          where s.table_name = l_qual
          fetch first 1 row only;
        exception when others then
          l_desc := null;
        end;

        l_out := l_out
              || l_qual || ': ' || nvl(l_desc,'') || chr(10) || '  cols: ';

        for c in (
          select column_name, data_type, nullable
            from all_tab_columns
          where owner = t.owner
            and table_name = t.table_name
          order by column_id
          fetch first 20 rows only
        ) loop
          l_out := l_out
                || c.column_name || ' ' || c.data_type
                || case when c.nullable='N' then ' not null' end || ', ';
        end loop;

        l_out := rtrim(l_out, ', ') || chr(10);
        l_budget := p_char_budget - nvl(dbms_lob.getlength(l_out),0);
      end;
    end loop;

    return chatbot_core_io_pkg.clamp_clob(l_out, p_char_budget);
  exception
    when others then
      return null;
  end;*/

  -- === Tokenization ===========================================================
  function to_tokens(p_q varchar2, p_max pls_integer := 8)
    return sys.odcivarchar2list
  is
    v   varchar2(4000) := regexp_replace(nvl(p_q,''), '[^[:alnum:]]+', ' ');
    res sys.odcivarchar2list := sys.odcivarchar2list();
    seen varchar2(4000) := '|';
  begin
    for w in (
      select upper(regexp_substr(v, '\S+', 1, level)) t
      from dual
      connect by regexp_substr(v, '\S+', 1, level) is not null
    ) loop
      if length(w.t) >= 2 and w.t not in ('AND','OR','NOT')
         and instr(seen, '|'||w.t||'|') = 0
      then
        res.extend; res(res.count) := w.t;
        seen := seen || w.t || '|';
        exit when res.count >= p_max;
      end if;
    end loop;
    return res;
  end;

  function listagg_token_debug(p_list sys.odcivarchar2list) return varchar2 is
    v_out varchar2(4000);
  begin
    if p_list is null or p_list.count = 0 then return '[none]'; end if;
    for i in 1..p_list.count loop
      v_out := v_out || case when i>1 then ',' end || p_list(i);
    end loop;
    return v_out;
  end;

  -- === Router prefilter with optional column-name boost ======================
  -- prefilter_table_candidates: heuristic shortlist of table names based on tokens and summaries.
  function prefilter_table_candidates(
    p_ctx      in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_question in clob,
    p_k        in number default 12,
    p_req_id   in varchar2 default null,
    p_log_id   in number   default null,
    p_chat_id  in number   default null
  ) return sys.odcivarchar2list
  is
  begin
    return chatbot_router_pkg.prefilter_table_candidates(
            p_ctx, p_question, p_k, p_req_id, p_log_id, p_chat_id
          );
  end;

  -- === Router catalog =========================================================
  function build_router_catalog(
    p_ctx    in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_tables in sys.odcivarchar2list
  ) return clob
  is
  begin
    return chatbot_router_pkg.build_router_catalog(p_ctx, p_tables);
  end;

  -- === LLM table router (unchanged) ==========================================
  function route_tables(
    p_ctx              in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_question         in clob,
    p_candidates       in sys.odcivarchar2list,
    p_req_id           in varchar2,
    p_log_id           in number,
    p_chat_id          in number,
    p_api_format       in varchar2,
    p_model_id         in varchar2,
    p_compartment_id   in varchar2,
    p_temperature      in number,
    p_top_p            in number,
    p_top_k            in number,
    p_endpoint         in varchar2
  ) return clob
  is
  begin
    return chatbot_router_pkg.route_tables(
            p_ctx, p_question, p_candidates, p_req_id, p_log_id, p_chat_id,
            p_api_format, p_model_id, p_compartment_id, p_temperature, p_top_p,
            p_top_k, p_endpoint
          );
  end;

  -- === Parse router tables ====================================================
  function parse_router_tables(p_json clob)
    return sys.odcivarchar2list
  is
  begin
    return chatbot_router_pkg.parse_router_tables(p_json);
  end;

  -- === Normalize owner.table ==================================================
  function norm_table(p in varchar2)
    return varchar2 
  is
  begin
    return chatbot_router_pkg.norm_table(p);
  end;

  -- === Get authored SCHEMA/TABLE_DESCRIPTIONS chunks =========================
  function get_schema_for_table(
    p_ctx   in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_table in varchar2
  ) return clob
  is
  begin
    return chatbot_router_pkg.get_schema_for_table(p_ctx, p_table);
  end;

  function get_desc_for_table(
    p_ctx   in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_table in varchar2
  ) return clob
  is
  begin
    return chatbot_router_pkg.get_desc_for_table(p_ctx, p_table);
  end;

    /* In CHATBOT_CORE_SQL_PKG (package body) */

    procedure load_authored_chunks_for_selected(
    p_ctx          in  chatbot_core_ctx_params_pkg.run_ctx_t,
    p_selected     in  sys.odcivarchar2list,
    p_schema_out   out nocopy clob,
    p_tables_out   out nocopy clob,
    p_with_headers in  boolean default true
    ) is
    -- caps (fall back to sane defaults if params missing)
    cap_schema  number := 12000;
    cap_tables  number := 12000;

    -- locals
    l_item       varchar2(261);
    l_schema_one clob;
    l_desc_one   clob;

    procedure append_chunk(io_target in out nocopy clob, i_hdr varchar2, i_chunk clob) is
    begin
        if i_chunk is null then return; end if;
        if io_target is null then dbms_lob.createtemporary(io_target, true); end if;
        if p_with_headers and i_hdr is not null then
        dbms_lob.append(io_target, to_clob('-- ')||to_clob(i_hdr)||to_clob(' --')||chr(10));
        end if;
        dbms_lob.append(io_target, i_chunk);
        dbms_lob.append(io_target, chr(10));
    end;
    begin
    -- read caps from parameters (best-effort)
    begin cap_schema := chatbot_core_ctx_params_pkg.get_num_param(p_ctx,'MAX_SCHEMA_CHARS', cap_schema); exception when others then null; end;
    begin cap_tables := chatbot_core_ctx_params_pkg.get_num_param(p_ctx,'MAX_TABLEDESC_CHARS', cap_tables); exception when others then null; end;

    -- If nothing selected, fall back to global authored blocks (exactly as RUNNER’s else-branch)
    if p_selected is null or p_selected.count = 0 then
        p_schema_out := chatbot_core_ctx_params_pkg.load_component(p_ctx, 'SCHEMA');
        p_tables_out := chatbot_core_ctx_params_pkg.load_component(p_ctx, 'TABLE_DESCRIPTIONS');

        p_schema_out := chatbot_core_io_pkg.clamp_clob(p_schema_out, cap_schema);
        p_tables_out := chatbot_core_io_pkg.clamp_clob(p_tables_out, cap_tables);
        return;
    end if;

    -- For each selected table, pull authored slices from ROUTER_PKG helpers
    for i in 1 .. p_selected.count loop
        l_item := p_selected(i);

        begin
        l_schema_one := CHATBOT_ROUTER_PKG.get_schema_for_table(p_ctx, l_item);
        exception when others then l_schema_one := null; end;

        begin
        l_desc_one := CHATBOT_ROUTER_PKG.get_desc_for_table(p_ctx, l_item);
        exception when others then l_desc_one := null; end;

        append_chunk(p_schema_out, l_item, l_schema_one);
        append_chunk(p_tables_out, l_item, l_desc_one);
    end loop;

    -- clamp
    p_schema_out := chatbot_core_io_pkg.clamp_clob(p_schema_out, cap_schema);
    p_tables_out := chatbot_core_io_pkg.clamp_clob(p_tables_out, cap_tables);

    exception
    when others then
        -- fail-closed: return whatever we accumulated (possibly NULL), clamped
        begin p_schema_out := chatbot_core_io_pkg.clamp_clob(p_schema_out, cap_schema); exception when others then null; end;
        begin p_tables_out := chatbot_core_io_pkg.clamp_clob(p_tables_out, cap_tables); exception when others then null; end;
    end load_authored_chunks_for_selected;

  -- === Intent helpers =========================================================

  -- Stronger heuristic: EN+GR, SQL smell, time windows/agg, follow-up cues, greetings.
  function classify_intent(p_text clob) return varchar2 is
    v   varchar2(4000) := upper(regexp_replace(nvl(to_char(p_text),''), '\s+', ' '));
    len number := length(v);
    function has(pat varchar2) return boolean is begin return regexp_like(v, pat, 'n'); end;
  begin
    if v is null or trim(v) is null then return 'GENERAL_CHAT'; end if;

    -- SQL smell and fenced code
    if has('```SQL') or has('\bSELECT\b.*\bFROM\b') or has('\bJOIN\b') or has('\bGROUP\s+BY\b') or has('\bORDER\s+BY\b') or has('\bCOUNT\s*\(') or has('\bSUM\s*\(') then
      return 'NL2SQL';
    end if;

    -- Greetings / thanks -> general chat
    if has('^(HI|HELLO|HEY)\b') or has('\bTHANK(S| YOU)\b') or has('^ΚΑΛΗΜΕΡΑ\b') or has('^ΓΕΙΑ\b') then
      return 'GENERAL_CHAT';
    end if;

    -- Analytics/timegrain/aggregation cues -> NL2SQL
    if has('\b(TOP\s+\d+|RANK|TREND|GROWTH|MOM|YOY|BY\s+(YEAR|MONTH|WEEK|DAY)|PER\s+(YEAR|MONTH|WEEK|DAY)|AVERAGE|AVG|COUNT|SUM|MAX|MIN|PERCENT(AGE)?)\b')
       or has('\b(ΑΝΑ\s+(ΜΗΝΑ|ΕΒΔΟΜΑΔΑ|ΗΜΕΡΑ)|ΣΥΝΟΛΟ|ΜΕΣΟΣ|ΤΑΣΗ|ΚΟΡΥΦΑΙΑ|ΠΡΩΤΑ\s+\d+)\b')
       or has('\b(LAST|PAST|PREVIOUS)\s+\d+\s+(DAY|WEEK|MONTH|YEAR)S?\b') then
      return 'NL2SQL';
    end if;

    -- Strong follow-up markers (short + deictic/modify verbs)
    if len <= 120 and (
         has('^(AND |OR )?(NOW|INSTEAD|ALSO)\b')
      or has('\b(THIS|THAT|THESE|THOSE|ABOVE|SAME|LIKE BEFORE|AS ABOVE)\b')
      or has('\b(CHANGE|MAKE IT|FILTER|LIMIT|SORT|GROUP|COMPARE)\b')
      or has('\b(ΑΥΤΟ|ΕΚΕΙΝΟ|ΟΠΩΣ ΠΡΙΝ|ΙΔΙΟ|ΑΛΛΑΞΕ|ΦΙΛΤΡΑΡΕ|ΤΑΞΙΝΟΜΗΣΕ|ΣΥΓΚΡΙΝΕ)\b')
    ) then
      return 'FOLLOWUP_CLARIFY';
    end if;

    -- Question words default to NL2SQL unless clearly general knowledge
    if has('^(WHAT|WHICH|HOW|WHY|ΠΩΣ|ΤΙ|ΓΙΑΤΙ)\b') then
      return 'NL2SQL';
    end if;

    return 'NL2SQL';
  end;

  -- Did previous turn have SQL or preview values?
  function last_turn_had_sql(p_log_id in number) return boolean is
    l_prev_sql    clob;
    l_prev_sum    clob;
    l_preview     clob;
    l_chat_id     number;
    l_prev_id     number;
  begin
    begin
      select chat_id into l_chat_id
        from chatbot_nl2sql_log where id = p_log_id;
    exception when others then return false; end;

    begin
      select id
        into l_prev_id
      from (
        select id
        from chatbot_nl2sql_log
        where chat_id = l_chat_id
          and id < p_log_id
          and (generated_sql is not null or execution_data is not null)
        order by id desc
      )
      where rownum = 1;
    exception when others then return false; end;

    if l_prev_id is null then return false; end if;

    begin
      select generated_sql, summary_text into l_prev_sql, l_prev_sum
      from chatbot_nl2sql_log
      where id = l_prev_id;
    exception when others then l_prev_sql := null; l_prev_sum := null; end;

    begin
      select execution_data into l_preview
      from chatbot_nl2sql_log
      where id = l_prev_id;
    exception when others then l_preview := null; end;

    return (l_prev_sql is not null) or (l_preview is not null);
  exception when others then
    return false;
  end;

  -- Safe get number from JSON (0 if missing)
  function safe_json_number(p_obj json_object_t, p_key varchar2) return number is
  begin
    return nvl(p_obj.get_number(p_key), 0);
  exception when others then
    return 0;
  end;

  -- === LLM intent: JSON (private). Returns STRICT JSON text ===================
  function classify_intent_llm_json(
    p_ctx            in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_text           in clob,
    p_api_format     in varchar2,
    p_model_id       in varchar2,
    p_compartment_id in varchar2,
    p_endpoint       in varchar2,
    p_req_id         in varchar2,
    p_log_id         in number,
    p_chat_id        in number
  ) return clob
  is
    l_prompt        clob;
    l_payload       clob;
    l_resp          clob;
    l_text          clob;
    l_prev_sum      clob;
    l_prev_sql      clob;
    l_prev_preview  clob;
    l_intent_system clob;
    l_history       clob;
    l_sys           clob;
  begin
    -- previous turn fields (no legacy helper)
    declare
        l_prev_id number;
    begin
        select max(id)
            into l_prev_id
            from chatbot_nl2sql_log
        where chat_id = p_chat_id
            and id < p_log_id;

        if l_prev_id is not null then
            begin
            select summary_text, generated_sql, execution_data
                into l_prev_sum, l_prev_sql, l_prev_preview
                from chatbot_nl2sql_log
            where id = l_prev_id;
            exception when others then
            l_prev_sum := null; l_prev_sql := null; l_prev_preview := null;
            end;
        else
            l_prev_sum := null; l_prev_sql := null; l_prev_preview := null;
        end if;
    end;

    l_history := build_history(p_chat_id, 3, 1200);

    l_intent_system := chatbot_core_ctx_params_pkg.load_component(p_ctx, 'INTENT_SYSTEM');

    -- System prompt with schema + few-shots + scoring
    l_sys := chatbot_core_io_pkg.clamp_clob(l_intent_system, 2000);

    -- If INTENT_SYSTEM is missing, don't call the model; return a deterministic default.
    if l_sys is null then
      chatbot_core_io_pkg.logv(
        p_ctx     => p_ctx,  -- type: CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t
        p_phase   => 'INTENT',
        p_req_id  => p_req_id,
        p_msg     => 'INTENT_SYSTEM missing for dataset='
                    || substr(nvl(p_ctx.dataset,'[null]'),1,100)
                    || ', env='
                    || substr(nvl(p_ctx.environment,'[null]'),1,100),
        p_log_id  => p_log_id,
        p_chat_id => p_chat_id
      );

      return '{"intent":"NL2SQL","scores":{"FOLLOWUP_CLARIFY":0,"NL2SQL":1,"GENERAL_CHAT":0},"reason":"no_intent_system"}';
    end if;

    -- Step 4: Mask summary/preview before sending to LLM (guarded map build)
    begin
      declare
        l_map_json   clob;
        l_dummy_chat number;
        l_built      boolean := false;
      begin
        -- 4a) See if a map already exists for this LOG_ID
        load_or_init_token_map(p_log_id, l_dummy_chat, l_map_json);

        -- 4b) If no map yet and we have a previous preview, build + persist once.
        if (l_map_json is null or l_map_json = '{"forward":{},"reverse":{}}')
          and l_prev_preview is not null
        then
          begin
            -- Builds map + persists; also returns the tokenized preview JSON
            l_prev_preview := redact_preview_json(p_ctx, p_log_id, l_prev_preview);
            l_built := true;

            -- Reload the map we just built
            load_or_init_token_map(p_log_id, l_dummy_chat, l_map_json);
          exception when others then
            l_built := false; -- fail-closed
          end;
        end if;

        -- 4c) If we now have a map (built or existing), apply it to the prev summary.
        if l_prev_sum is not null then
          -- Pass the preview JSON only when we JUST built from it;
          -- otherwise let redact_preview_literals reuse the persisted map.
          if l_built then
            l_prev_sum := redact_preview_literals(
                            p_ctx          => p_ctx,
                            p_preview_json => l_prev_preview,
                            p_summary_text => l_prev_sum,
                            p_log_id       => p_log_id,
                            p_chat_id      => p_chat_id,
                            p_req_id       => p_req_id
                          );
          else
            l_prev_sum := redact_preview_literals(
                            p_ctx          => p_ctx,
                            p_preview_json => null,           -- don't rebuild
                            p_summary_text => l_prev_sum,
                            p_log_id       => p_log_id,
                            p_chat_id      => p_chat_id,
                            p_req_id       => p_req_id
                          );
          end if;
        end if;
      end;
    exception
      when others then null; -- fail-closed: never block INTENT
    end;

    l_prompt := l_sys
      || chr(10) || nvl(l_history, '[no prior turns]')
      || chr(10) || '--- PREVIOUS ANSWER SUMMARY (trimmed) ---' || chr(10)
      || nvl(chatbot_core_io_pkg.clamp_clob(chatbot_core_io_pkg.one_line(l_prev_sum), 800), '[none]')
      || chr(10) || '--- PREVIOUS SQL (snippet) ---' || chr(10)
      || nvl(chatbot_core_io_pkg.clamp_clob(chatbot_core_io_pkg.one_line(l_prev_sql), 200), '[none]')
      || chr(10) || '--- PREVIOUS PREVIEW VALUES (trimmed) ---' || chr(10)
      || nvl(chatbot_core_io_pkg.clamp_clob(chatbot_core_io_pkg.one_line(l_prev_preview), 400), '[none]')
      || chr(10) || '--- USER ---' || chr(10)
      || chatbot_core_io_pkg.one_line(chatbot_core_io_pkg.clamp_clob(p_text, 600));

    l_payload := chatbot_core_io_pkg.build_payload_chat(
        p_api_format, p_model_id, p_compartment_id, l_prompt,
        0 /*temperature*/, 1 /*top_p*/, 1 /*top_k*/
    );

    chatbot_core_io_pkg.logc(p_ctx, 'INTENT/DEBUG', p_req_id, 'INTENT Payload', l_payload, p_log_id, p_chat_id);

    l_resp := chatbot_core_io_pkg.call_model(
      p_ctx, 'INTENT', p_endpoint, l_payload, p_req_id, p_log_id, p_chat_id
    );

    l_text := chatbot_core_io_pkg.extract_text_from_chat_response(l_resp);

    -- Best-effort usage metrics
    begin
      declare
        l_in_chars  number := nvl(dbms_lob.getlength(l_prompt), 0);
        l_out_chars number := nvl(dbms_lob.getlength(l_text),   0);
        l_pt number; l_ct number;
        l_item clob; l_metrics clob;
      begin
        chatbot_core_io_pkg.extract_usage_tokens(l_resp, l_pt, l_ct);

        l_item := '{"phase":"INTENT","inputChars":'||chatbot_core_io_pkg.num_to_json(l_in_chars)
               ||',"outputChars":'||chatbot_core_io_pkg.num_to_json(l_out_chars)
               ||',"promptTokens":'||chatbot_core_io_pkg.num_to_json(nvl(l_pt,0))
               ||',"completionTokens":'||chatbot_core_io_pkg.num_to_json(nvl(l_ct,0))||'}';

        select case
                 when metrics_json is null then '['||l_item||']'
                 when regexp_like(metrics_json, '\]\s*$') then
                      rtrim(metrics_json, ']')||case when length(metrics_json)>2 then ',' else '' end||l_item||']'
                 else metrics_json
               end
          into l_metrics
          from chatbot_nl2sql_log
         where id = p_log_id
           for update;

        update chatbot_nl2sql_log
           set input_chars_total   = nvl(input_chars_total,0)   + l_in_chars,
               output_chars_total  = nvl(output_chars_total,0)  + l_out_chars,
               input_tokens_total  = nvl(input_tokens_total,0)  + nvl(l_pt,0),
               output_tokens_total = nvl(output_tokens_total,0) + nvl(l_ct,0),
               metrics_json        = l_metrics
         where id = p_log_id;

        commit;
      exception when others then rollback; end;
    exception when others then null; end;

    -- Extract JSON object only
    l_text := regexp_substr(nvl(l_text,''), '\{.*\}', 1, 1, 'n');
    if l_text is null then
      return '{"intent":"NL2SQL","scores":{"FOLLOWUP_CLARIFY":0,"NL2SQL":1,"GENERAL_CHAT":0},"reason":"no_json_in_response"}';
    end if;

    return l_text;
  end;

  -- Original classify_intent_llm: returns label only (kept for compatibility)
  function classify_intent_llm(
    p_ctx            in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_text           in clob,
    p_api_format     in varchar2,
    p_model_id       in varchar2,
    p_compartment_id in varchar2,
    p_endpoint       in varchar2,
    p_req_id         in varchar2,
    p_log_id         in number,
    p_chat_id        in number
  ) return varchar2
  is
    l_json_text clob;
    l_json      json_object_t;
    l_intent    varchar2(40) := 'NL2SQL';
  begin
    l_json_text := classify_intent_llm_json(p_ctx, p_text, p_api_format, p_model_id, p_compartment_id,
                                            p_endpoint, p_req_id, p_log_id, p_chat_id);

    begin
      l_json   := json_object_t.parse(l_json_text);
      l_intent := upper(nvl(l_json.get_string('intent'),'NL2SQL'));
    exception when others then
      l_intent := 'NL2SQL';
    end;

    if l_intent not in ('FOLLOWUP_CLARIFY','NL2SQL','GENERAL_CHAT') then
      l_intent := 'NL2SQL';
    end if;

    return l_intent;
  end;

  -- === Ensemble combiner ======================================================
  function decide_intent(
    p_ctx                        in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_text                       in clob,
    p_llm_json                   in clob,
    p_prev_had_sql               in boolean,
    p_router_candidates_count    in number,
    p_log_id                     in number
  ) return varchar2
  is
    j json_object_t;
    s json_object_t;
    f number := 0; n number := 0; g number := 0;
    v varchar2(40) := 'NL2SQL';
    v_h varchar2(40) := classify_intent(p_text);
    vtxt varchar2(4000) := upper(regexp_replace(nvl(to_char(p_text),''), '\s+', ' '));
    len number := length(vtxt);

    function bump(x number, d number) return number is begin return least(1, greatest(0, x + d)); end;
  begin
    -- Parse LLM JSON (label + scores)
    begin
      j := json_object_t.parse(nvl(regexp_substr(nvl(p_llm_json,''), '\{.*\}', 1, 1, 'n'), '{}'));
      s := j.get_object('scores');
      f := safe_json_number(s, 'FOLLOWUP_CLARIFY');
      n := safe_json_number(s, 'NL2SQL');
      g := safe_json_number(s, 'GENERAL_CHAT');
      v := upper(nvl(j.get_string('intent'),'NL2SQL'));
    exception when others then
      -- fallback: map heuristic to 1.0 if LLM JSON bad
      if v_h = 'FOLLOWUP_CLARIFY' then f := 1; elsif v_h = 'GENERAL_CHAT' then g := 1; else n := 1; end if;
      v := v_h;
    end;

    -- Router prior: if no candidates, nudge GENERAL_CHAT; else nudge NL2SQL
    if nvl(p_router_candidates_count,0) <= 0 then
      g := bump(g, 0.15);
    else
      n := bump(n, 0.10);
    end if;

    -- Follow-up affordance
    if p_prev_had_sql and len <= 120 and regexp_like(vtxt, '\b(THIS|THAT|ABOVE|SAME|INSTEAD|NOW|CHANGE|FILTER|COMPARE|ΟΠΩΣ ΠΡΙΝ|ΙΔΙΟ|ΑΛΛΑΞΕ|ΣΥΓΚΡΙΝΕ)\b','n')
    then
      f := bump(f, 0.20);
    end if;

    -- Hard guard: greetings/thanks => GENERAL_CHAT
    if regexp_like(vtxt, '^(HI|HELLO|HEY)\b|\bTHANK(S| YOU)\b|^ΚΑΛΗΜΕΡΑ\b|^ΓΕΙΑ\b', 'n') then
      f := 0; n := 0; g := 1;
    end if;

    -- Final decision
    if greatest(f,n,g) >= 0.55 then
      if f >= n and f >= g then v := 'FOLLOWUP_CLARIFY';
      elsif n >= g then v := 'NL2SQL';
      else v := 'GENERAL_CHAT';
      end if;
    else
      v := v_h; -- fallback
    end if;

    -- Log the ensemble decision (best-effort)
    begin
      declare l_metrics clob; l_item clob;
      begin
        l_item := '{"phase":"INTENT_DECISION","heuristic":"' || v_h
               || '","final":"' || v
               || '","scores":{"FOLLOWUP_CLARIFY":'||chatbot_core_io_pkg.num_to_json(f)
               || ',"NL2SQL":'||chatbot_core_io_pkg.num_to_json(n)
               || ',"GENERAL_CHAT":'||chatbot_core_io_pkg.num_to_json(g)
               || '}}';

        select case
                 when metrics_json is null then '['||l_item||']'
                 when regexp_like(metrics_json, '\]\s*$') then
                      rtrim(metrics_json, ']')||case when length(metrics_json)>2 then ',' else '' end||l_item||']'
                 else metrics_json
               end
          into l_metrics
          from chatbot_nl2sql_log
         where id = p_log_id
           for update;

        update chatbot_nl2sql_log
           set metrics_json = l_metrics
         where id = p_log_id;

        commit;
      exception when others then rollback; end;
    exception when others then null; end;

    return v;
  end;

    ------------------------------------------------------------------------------
  -- Unified Intent API
  -- Implements: resolve_intent (spec defines intent_result_t record type)
  ------------------------------------------------------------------------------
  procedure resolve_intent(
    p_ctx            in  chatbot_core_ctx_params_pkg.run_ctx_t,
    p_text           in  clob,
    p_api_format     in  varchar2,
    p_model_id       in  varchar2,
    p_compartment_id in  varchar2,
    p_region         in  varchar2,
    p_req_id         in  varchar2,
    p_log_id         in  number,
    p_chat_id        in  number,
    p_threshold      in  number  default null,   -- override score10 threshold
    p_persist        in  boolean default true,   -- write INTENT_* to LOG
    p_result         out intent_result_t
  ) is
    l_endpoint   varchar2(1000) :=
      'https://inference.generativeai.'||lower(p_region)||'.oci.oraclecloud.com/20231130/actions/chat';

    -- Router prior
    l_candidates  sys.odcivarchar2list;
    l_cat_count   number := 0;

    -- LLM JSON (STRICT) + ensemble
    l_json_text   clob;
    l_prev_had_sql boolean := last_turn_had_sql(p_log_id);
    l_label       varchar2(40) := 'NL2SQL';

    -- Scores parsed from LLM JSON (0..1)
    j   json_object_t;
    s   json_object_t;
    f   number := 0;   -- FOLLOWUP_CLARIFY score
    n   number := 1;   -- NL2SQL score
    g   number := 0;   -- GENERAL_CHAT score

    -- Threshold/clarify
    l_threshold   number := nvl(p_threshold, 6);  -- default if no parameter row
    l_needs_clar  boolean := false;
    l_clar_q      clob := null;

  begin
    -- 1) Router prior (count-only)
    l_candidates := prefilter_table_candidates(p_ctx, p_text, 6, p_req_id, p_log_id, p_chat_id);
    l_cat_count  := case when l_candidates is null then 0 else l_candidates.count end;

    -- 2) LLM JSON
    l_json_text := classify_intent_llm_json(
      p_ctx, p_text, p_api_format, p_model_id, p_compartment_id,
      l_endpoint, p_req_id, p_log_id, p_chat_id
    );

    -- 3) Ensemble decision
    l_label := decide_intent(p_ctx, p_text, l_json_text, l_prev_had_sql, l_cat_count, p_log_id);

    -- 4) Parse LLM scores (best-effort)
    begin
      j := json_object_t.parse(nvl(regexp_substr(nvl(l_json_text,''), '\{.*\}', 1, 1, 'n'), '{}'));
      s := j.get_object('scores');
      f := safe_json_number(s, 'FOLLOWUP_CLARIFY');
      n := safe_json_number(s, 'NL2SQL');
      g := safe_json_number(s, 'GENERAL_CHAT');
    exception when others then
      -- keep defaults
      null;
    end;

    -- 5) Resolve threshold from parameters when not overridden
    if p_threshold is null then
      begin
        select to_number(json_value(content, '$.score10' returning varchar2))
          into l_threshold
          from (
            select p.content,
                   case
                     when p.dataset = p_ctx.dataset and p.environment = p_ctx.environment then 1
                     when p.dataset = p_ctx.dataset and p.environment is null              then 2
                     when p.dataset is null        and p.environment = p_ctx.environment  then 3
                     else 4
                   end rnk,
                   p.id
              from chatbot_parameters p
             where p.component_type = 'INTENT_NL2SQL_THRESHOLD_SCORE10'
               and p.active = 'TRUE'
               and (p.dataset = p_ctx.dataset or p.dataset is null)
               and (p.environment = p_ctx.environment or p.environment is null)
          )
         where rownum = 1
         order by rnk, id;
      exception when others then
        null; -- keep default 6
      end;
    end if;

    -- 6) Compute score10 on the chosen label
    declare
      l_score10 number;
    begin
      if l_label = 'FOLLOWUP_CLARIFY' then
        l_score10 := round(10 * least(greatest(f,0),1));
      elsif l_label = 'GENERAL_CHAT' then
        l_score10 := round(10 * least(greatest(g,0),1));
      else
        l_score10 := round(10 * least(greatest(n,0),1)); -- NL2SQL
      end if;

      -- 7) Decide clarify
      --    - Always clarify for FOLLOWUP_CLARIFY (keep convo snappy).
      --    - Clarify for borderline NL2SQL (score10 < threshold).
      if l_label = 'FOLLOWUP_CLARIFY' then
        -- Let the FOLLOWUP runner's LLM decider handle clarify/routing.
        l_needs_clar := false;

        /*if is_sql_refinement_request(p_text) or l_prev_had_sql then
          l_clar_q := 'Do you want me to modify the previous SQL (e.g., change grouping/filters) or draft a new query?';
        else
          l_clar_q := 'Should I generate SQL to answer that, or were you asking a general question?';
        end if;*/
        -- Keep l_clar_q null; runner will ask if the decider chooses ask_clarifying.
        l_clar_q := null;

      elsif l_label = 'NL2SQL' and l_score10 < l_threshold then
        l_needs_clar := true;
        l_clar_q := 'Quick check: which metric, time window, and grouping should I use for the SQL?';
      else
        l_needs_clar := false;
        l_clar_q := null;
      end if;

      -- 8) Persist (best-effort)
      if p_persist then
        persist_intent_to_log(p_log_id => p_log_id, p_label => l_label, p_score10 => l_score10);
      end if;

      -- 9) OUT record
      p_result.label            := l_label;
      p_result.score10          := l_score10;
      p_result.needs_clarify    := l_needs_clar;
      p_result.clarify_question := case when l_clar_q is not null then chatbot_core_io_pkg.clamp_clob(chatbot_core_io_pkg.one_line(l_clar_q), 220) end;
    end;

  exception
    when others then
      -- fail-closed to NL2SQL (no throw)
      p_result.label            := 'NL2SQL';
      p_result.score10          := null;
      p_result.needs_clarify    := false;
      p_result.clarify_question := null;
  end;

  -- === Public smart classifier (keeps signature, now uses ensemble) ==========
  function classify_intent_smart(
    p_ctx            in chatbot_core_ctx_params_pkg.run_ctx_t,
    p_text           in clob,
    p_api_format     in varchar2,
    p_model_id       in varchar2,
    p_compartment_id in varchar2,
    p_region         in varchar2,
    p_req_id         in varchar2,
    p_log_id         in number,
    p_chat_id        in number
  ) return varchar2
  is
    l_endpoint varchar2(1000) :=
      'https://inference.generativeai.'||lower(p_region)||'.oci.oraclecloud.com/20231130/actions/chat';
    l_json_text clob;
    l_prev_sql  boolean := last_turn_had_sql(p_log_id);
    l_candidates sys.odcivarchar2list;
    l_cat_count number := 0;
    l_final varchar2(40) := 'NL2SQL';
  begin
    -- Router prior (count only; OK if empty)
    l_candidates := prefilter_table_candidates(p_ctx, p_text, 6, p_req_id, p_log_id, p_chat_id);
    l_cat_count  := case when l_candidates is null then 0 else l_candidates.count end;

    -- LLM JSON (STRICT)
    l_json_text := classify_intent_llm_json(
      p_ctx, p_text, p_api_format, p_model_id, p_compartment_id,
      l_endpoint, p_req_id, p_log_id, p_chat_id
    );

    -- Ensemble decision
    l_final := decide_intent(p_ctx, p_text, l_json_text, l_prev_sql, l_cat_count, p_log_id);

    return l_final;
  exception when others then
    return 'NL2SQL';
  end;

end chatbot_core_sql_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_CORE_SUMMARY_PKG" IS
  ------------------------------------------------------------------------------
  -- Single source of truth for SUMMARY: rendering, tokenization/detokenization,
  -- answer-first, entity guardrails, tie-breakers, formatting. Data-agnostic.
  ------------------------------------------------------------------------------

  -- Original render (no internal tokenization). Kept for backward compat.
  FUNCTION Render(
    p_context_query IN CLOB,
    p_plan_json     IN CLOB,
    p_rows_json     IN CLOB,
    p_meta_json     IN CLOB,
    p_ctx           IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id        IN VARCHAR2,
    p_log_id        IN NUMBER,
    p_chat_id       IN NUMBER
  ) RETURN CLOB;

  ------------------------------------------------------------------------------
  -- NEW: Redaction-aware rendering
  -- If p_redaction_enabled = TRUE:
  --   1) Tokenize rows/plan/context_query internally, logging token_map.
  --   2) Run summary on tokenized JSON.
  --   3) If p_detokenize_output = TRUE, detokenize the final summary for UI.
  --      Otherwise, return tokenized summary (for UIs that detokenize later).
  ------------------------------------------------------------------------------
  FUNCTION Render_Redacted(
    p_context_query      IN CLOB,
    p_plan_json          IN CLOB,
    p_rows_json          IN CLOB,
    p_meta_json          IN CLOB,
    p_ctx                IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id             IN VARCHAR2,
    p_log_id             IN NUMBER,
    p_chat_id            IN NUMBER,
    p_redaction_enabled  IN BOOLEAN DEFAULT FALSE,
    p_detokenize_output  IN BOOLEAN DEFAULT TRUE
  ) RETURN CLOB;

  FUNCTION Render_Auto(
    p_context_query      IN CLOB,
    p_plan_json          IN CLOB,
    p_rows_json          IN CLOB,
    p_meta_json          IN CLOB,
    p_ctx                IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id             IN VARCHAR2,
    p_log_id             IN NUMBER,
    p_chat_id            IN NUMBER,
    p_use_llm            IN BOOLEAN,
    p_endpoint           IN VARCHAR2,
    p_api_format         IN VARCHAR2,
    p_model_id           IN VARCHAR2,
    p_compartment_id     IN VARCHAR2,
    p_temperature        IN NUMBER,
    p_top_p              IN NUMBER,
    p_top_k              IN NUMBER
  ) RETURN CLOB;

  ------------------------------------------------------------------------------
  -- Public helpers (you can reuse from Runner or tests if desired)
  ------------------------------------------------------------------------------
  PROCEDURE Tokenize_For_Summary(
    p_plan_json     IN  CLOB,
    p_rows_json     IN  CLOB,
    p_context_query IN  CLOB,
    p_ctx           IN  CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id        IN  VARCHAR2,
    p_log_id        IN  NUMBER,
    p_chat_id       IN  NUMBER,
    o_plan_tokenized OUT CLOB,
    o_rows_tokenized OUT CLOB,
    o_cq_tokenized   OUT CLOB,
    o_token_map      OUT CLOB                -- JSON: {"«token»":"original", ...}
  );

  FUNCTION Detokenize_Summary(
    p_text      IN CLOB,
    p_token_map IN CLOB
  ) RETURN CLOB;

  ------------------------------------------------------------------------------
  -- Deterministic shape diagnostics (unchanged)
  ------------------------------------------------------------------------------
  PROCEDURE AnalyzeResultShape(
    p_plan_json           IN  CLOB,
    p_rows_json           IN  CLOB,
    o_single_entity       OUT BOOLEAN,
    o_missing_requested   OUT BOOLEAN,
    o_has_time_column     OUT BOOLEAN
  );

  -- Formatting helpers (public for reuse)
  FUNCTION FormatNumber(p_value IN VARCHAR2) RETURN VARCHAR2;
  /*FUNCTION FormatDate  (p_value IN VARCHAR2) RETURN VARCHAR2;

  -- Token helpers (public; used by tokenizer)
  FUNCTION TokenizeLabel  (p_label IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION DetokenizeLabel(p_label IN VARCHAR2) RETURN VARCHAR2;*/

  TYPE t_vc_list IS TABLE OF VARCHAR2(4000);

  FUNCTION parse_output_columns_from_sql(
    p_sql IN CLOB
  ) RETURN t_vc_list;

  FUNCTION build_column_info_from_tabledesc(
    p_rows_json      IN CLOB,
    p_tabledesc_json IN CLOB,
    p_sql_text       IN CLOB
  ) RETURN CLOB;

  FUNCTION load_generated_sql(
    p_log_id IN NUMBER
  ) RETURN CLOB;

  FUNCTION build_tabledesc_json_for_sql(
    p_sql_text IN CLOB
  ) RETURN CLOB;

END CHATBOT_CORE_SUMMARY_PKG;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_CORE_SUMMARY_PKG" AS
  ----------------------------------------------------------------------
  -- Constants (headings, limits). Keep these here so Runner is oblivious.
  ----------------------------------------------------------------------
  c_h_overview    CONSTANT VARCHAR2(40) := '## Overview';
  c_h_details     CONSTANT VARCHAR2(40) := '## Details';
  c_h_aggs        CONSTANT VARCHAR2(60) := '## Aggregates (in these results)';
  c_h_insights    CONSTANT VARCHAR2(60) := '## Observations / Result Insight';
  c_max_words     CONSTANT PLS_INTEGER  := 150;
  c_phase         CONSTANT VARCHAR2(20) := 'SUMMARY'; -- for logging

  c_token_l  CONSTANT VARCHAR2(2) := '«';
  c_token_r  CONSTANT VARCHAR2(2) := '»';

  -- simple stable hash (short) for tokens
  FUNCTION hash_short(p_in VARCHAR2) RETURN VARCHAR2 IS
    rawhash RAW(32);
  BEGIN
    BEGIN
      -- Preferred: UTF-8 stable hash using SHA-256
      rawhash := DBMS_CRYPTO.HASH(
                  UTL_I18N.STRING_TO_RAW(NVL(p_in,''), 'AL32UTF8'),
                  DBMS_CRYPTO.HASH_SH256);
      RETURN UPPER(SUBSTR(RAWTOHEX(rawhash), 1, 6)); -- short token suffix
    EXCEPTION
      WHEN OTHERS THEN
        -- Fallback if DBMS_CRYPTO not granted
        RETURN TO_CHAR(
                ABS(DBMS_UTILITY.get_hash_value(NVL(p_in,''), 1, 999999)),
                'FM000000');
    END;
  END;

  ----------------------------------------------------------------------
  -- Small JSON helpers
  ----------------------------------------------------------------------
  FUNCTION get_json_bool(o JSON_OBJECT_T, k VARCHAR2, d BOOLEAN) RETURN BOOLEAN IS
  BEGIN
    RETURN CASE WHEN o.has(k) THEN o.get_boolean(k) ELSE d END;
  EXCEPTION WHEN OTHERS THEN RETURN d; END;

  FUNCTION get_json_str(o JSON_OBJECT_T, k VARCHAR2, d VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN CASE WHEN o.has(k) THEN o.get_string(k) ELSE d END;
  EXCEPTION WHEN OTHERS THEN RETURN d; END;

  FUNCTION get_time_col(plan JSON_OBJECT_T) RETURN VARCHAR2 IS
  BEGIN
    IF plan.has('time_filter') THEN
      DECLARE tf JSON_OBJECT_T := plan.get_object('time_filter'); BEGIN
        IF tf.has('column') THEN RETURN tf.get_string('column'); END IF;
      END;
    END IF;
    RETURN NULL;
  END;

  -- JSON parser helpers
  FUNCTION safe_parse_object(p_json IN CLOB) RETURN JSON_OBJECT_T IS
  BEGIN
    RETURN JSON_OBJECT_T.parse(p_json);
  EXCEPTION
    WHEN OTHERS THEN
      -- optional: log the parse error
      RETURN JSON_OBJECT_T(); -- empty object
  END;

  FUNCTION safe_parse_array(p_json IN CLOB) RETURN JSON_ARRAY_T IS
  BEGIN
    RETURN JSON_ARRAY_T.parse(p_json);
  EXCEPTION
    WHEN OTHERS THEN
      -- optional: log the parse error
      RETURN JSON_ARRAY_T(); -- empty array
  END;

  FUNCTION summary_user_prompt_clean(p_text IN CLOB) RETURN CLOB IS
  BEGIN
    -- Minimal: just normalise NULL and trim whitespace.
    IF p_text IS NULL THEN
      RETURN NULL;
    END IF;
    RETURN TRIM(p_text);
  END summary_user_prompt_clean;

    ----------------------------------------------------------------------
  -- Helper: load generated SQL for this LOG_ID from NL2SQL log table
  -- Adjust table/column names as needed.
  ----------------------------------------------------------------------
  FUNCTION load_generated_sql(
    p_log_id IN NUMBER
  ) RETURN CLOB IS
    l_sql CLOB;
  BEGIN
    BEGIN
      SELECT generated_sql
        INTO l_sql
        FROM CHATBOT_NL2SQL_LOG   
       WHERE ID = p_log_id;   
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RETURN NULL;
    END;

    RETURN l_sql;
  END load_generated_sql;

  ----------------------------------------------------------------------
  -- Helper: parse FROM/JOIN clause and return table names actually used
  -- Supports:
  --   FROM OWNER.TABLE
  --   JOIN "OWNER"."TABLE"
  --   FROM TABLE
  -- and allows whitespace/newlines around the dot.
  ----------------------------------------------------------------------
  FUNCTION parse_tables_from_sql(
    p_sql IN CLOB
  ) RETURN t_vc_list IS
    l_out    t_vc_list := t_vc_list();
    v_sql    CLOB;
    v_owner  VARCHAR2(128);
    v_table  VARCHAR2(128);
    v_full   VARCHAR2(4000);
    v_idx    PLS_INTEGER := 1;
  BEGIN
    IF p_sql IS NULL THEN
      RETURN l_out;
    END IF;

    -- Work on an upper-cased copy
    v_sql := UPPER(p_sql);

    LOOP
      ------------------------------------------------------------------
      -- 1) Try OWNER.TABLE first (allows spaces/newlines around the dot)
      ------------------------------------------------------------------
      v_owner := REGEXP_SUBSTR(
                   v_sql,
                   '(FROM|JOIN)\s+"?([A-Z0-9_]+)"?\s*\.\s*"?([A-Z0-9_]+)"?',
                   1,
                   v_idx,
                   'i',
                   2           -- owner
                 );

      v_table := REGEXP_SUBSTR(
                   v_sql,
                   '(FROM|JOIN)\s+"?([A-Z0-9_]+)"?\s*\.\s*"?([A-Z0-9_]+)"?',
                   1,
                   v_idx,
                   'i',
                   3           -- table
                 );

      IF v_owner IS NOT NULL AND v_table IS NOT NULL THEN
        v_full := v_owner || '.' || v_table;
      ELSE
        ----------------------------------------------------------------
        -- 2) Fallback: unqualified table name: FROM TABLE [alias]
        ----------------------------------------------------------------
        v_table := REGEXP_SUBSTR(
                     v_sql,
                     '(FROM|JOIN)\s+"?([A-Z0-9_]+)"?',
                     1,
                     v_idx,
                     'i',
                     2          -- table name
                   );

        IF v_table IS NULL THEN
          EXIT; -- no more matches
        END IF;

        v_full := v_table;
      END IF;

      -- Normalize: strip quotes / whitespace, upper-case
      v_full := REGEXP_REPLACE(v_full, '"', NULL);

      l_out.EXTEND;
      l_out(l_out.COUNT) := UPPER(TRIM(v_full));

      v_idx := v_idx + 1;
    END LOOP;

    RETURN l_out;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN t_vc_list(); -- fail-quiet
  END parse_tables_from_sql;

    ----------------------------------------------------------------------
  -- Helper: build a TABLE_DESCRIPTIONS JSON blob only for tables
  -- that actually appear in the generated SQL.
  --
  -- It scans CHATBOT_PARAMETERS where COMPONENT_TYPE
  -- = 'TABLE_DESCRIPTIONS', parses each CONTENT JSON, and keeps only
  -- those table entries whose "name" matches one of the tables in
  -- p_sql_text (FROM/JOIN).
  --
  -- Returns a JSON of the form:
  --   {"tables":[ {<table1>}, {<table2>} ... ]}
  -- or NULL if nothing matched.
  ----------------------------------------------------------------------
  FUNCTION build_tabledesc_json_for_sql(
    p_sql_text IN CLOB
  ) RETURN CLOB
  IS
    l_used_tables t_vc_list := t_vc_list();
    l_out         CLOB      := NULL;
    l_first       BOOLEAN   := TRUE;

    -- local helper: does NAME appear in l_used_tables?
    FUNCTION used_table(p_name VARCHAR2) RETURN BOOLEAN IS
      v_param_full VARCHAR2(4000);
      v_param_base VARCHAR2(4000);
      v_used_full  VARCHAR2(4000);
      v_used_base  VARCHAR2(4000);
    BEGIN
      IF p_name IS NULL THEN
        RETURN FALSE;
      END IF;

      IF l_used_tables IS NULL OR l_used_tables.COUNT = 0 THEN
        RETURN FALSE;
      END IF;

      -- Normalize: strip quotes, upper-case
      v_param_full := UPPER(REGEXP_REPLACE(TRIM(p_name), '"', NULL));
      -- base name = last identifier after dot (if any)
      v_param_base := REGEXP_SUBSTR(v_param_full, '[^.]+$', 1, 1, 'i');

      FOR i IN 1 .. l_used_tables.COUNT LOOP
        v_used_full := UPPER(TRIM(l_used_tables(i)));
        v_used_base := REGEXP_SUBSTR(v_used_full, '[^.]+$', 1, 1, 'i');

        -- match either full qualified name or just base table name
        IF v_param_full = v_used_full OR v_param_base = v_used_base THEN
          RETURN TRUE;
        END IF;
      END LOOP;

      RETURN FALSE;
    END;
  BEGIN
    IF p_sql_text IS NULL THEN
      RETURN NULL;
    END IF;

    -- derive tables from FROM/JOIN clauses of the generated SQL
    l_used_tables := parse_tables_from_sql(p_sql_text);
    BEGIN
      IF CHATBOT_CORE_IO_PKG.debug_on(p_ctx => NULL) THEN
        DECLARE
          j JSON_OBJECT_T := JSON_OBJECT_T();
          a JSON_ARRAY_T  := JSON_ARRAY_T();
        BEGIN
          IF l_used_tables IS NOT NULL THEN
            FOR i IN 1 .. l_used_tables.COUNT LOOP
              a.append(l_used_tables(i));
            END LOOP;
          END IF;
          j.put('used_tables', a);
          CHATBOT_CORE_IO_PKG.logc(
          NULL,c_phase,NULL,
          'Summary:tabledesc-used-tables',
          TO_CLOB(j.to_string),
          NULL, NULL
          );
        EXCEPTION
          WHEN OTHERS THEN NULL;
        END;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;
    IF l_used_tables IS NULL OR l_used_tables.COUNT = 0 THEN
      RETURN NULL;
    END IF;

    -- scan all TABLE_DESCRIPTIONS rows and pick only matching tables
    FOR r IN (
      SELECT content
        FROM CHATBOT_PARAMETERS
       WHERE component_type = 'TABLE_DESCRIPTIONS'
    )
    LOOP
      DECLARE
        j_root   JSON_OBJECT_T;
        j_tables JSON_ARRAY_T;
        j_tbl    JSON_OBJECT_T;
        tbl_name VARCHAR2(4000);
      BEGIN
        -- if one row has bad JSON, skip it; do not raise out
        BEGIN
          j_root := JSON_OBJECT_T.parse(r.content);
        EXCEPTION
          WHEN OTHERS THEN
            j_root := NULL;
        END;

        IF j_root IS NULL OR NOT j_root.has('tables') THEN
          CONTINUE;
        END IF;

        j_tables := j_root.get_array('tables');
        IF j_tables IS NULL THEN
          CONTINUE;
        END IF;

        FOR i IN 0 .. j_tables.get_size - 1 LOOP
          j_tbl := TREAT(j_tables.get(i) AS JSON_OBJECT_T);
          IF j_tbl IS NULL THEN
            CONTINUE;
          END IF;

          BEGIN
            tbl_name := j_tbl.get_string('name');
          EXCEPTION
            WHEN OTHERS THEN
              tbl_name := NULL;
          END;

          IF used_table(tbl_name) THEN
            -- first match: open the {"tables":[ ... } envelope
            IF l_first THEN
              l_out   := '{"tables":[' || j_tbl.to_string;
              l_first := FALSE;
            ELSE
              l_out := l_out || ',' || j_tbl.to_string;
            END IF;
          END IF;
        END LOOP;
      END;
    END LOOP;

    IF l_first THEN
      -- no matching tables found
      RETURN NULL;
    END IF;

    l_out := l_out || ']}';
    RETURN l_out;
  EXCEPTION
    WHEN OTHERS THEN
      -- fail-quiet: no COLUMN INFO if anything goes wrong here
      RETURN NULL;
  END build_tabledesc_json_for_sql;

  ----------------------------------------------------------------------
  -- Helper: infer output column name from one SELECT expression
  -- Examples:
  --   "MAX(fraud_score) AS METRIC_VALUE"  -> METRIC_VALUE
  --   "t.customer_name customer_name"     -> CUSTOMER_NAME
  --   "t.customer_id"                     -> CUSTOMER_ID
  ----------------------------------------------------------------------
  FUNCTION infer_output_name_from_expr(
    p_expr IN VARCHAR2
  ) RETURN VARCHAR2 IS
    v_expr       VARCHAR2(32767) := TRIM(p_expr);
    v_expr_upper VARCHAR2(32767) := UPPER(v_expr);
    v_pos        PLS_INTEGER;
    v_tmp        VARCHAR2(32767);
    v_name       VARCHAR2(128);
  BEGIN
    -- 1) Explicit "AS alias"
    v_pos := INSTR(v_expr_upper, ' AS ');
    IF v_pos > 0 THEN
      v_tmp  := TRIM(SUBSTR(v_expr, v_pos + 4)); -- after " AS "
      v_name := REGEXP_SUBSTR(v_tmp, '"?([A-Z0-9_]+)"?', 1, 1, 'in', 1);
      IF v_name IS NOT NULL THEN
        RETURN REGEXP_REPLACE(v_name, '^"(.*)"$', '\1');
      END IF;
    END IF;

    -- 2) Trailing identifier alias: "expr alias"
    v_pos := INSTR(v_expr, ' ', -1); -- last space
    IF v_pos > 0 THEN
      v_tmp := TRIM(SUBSTR(v_expr, v_pos + 1));
      IF REGEXP_LIKE(v_tmp, '^"?[A-Z0-9_]+"?$', 'in') THEN
        RETURN REGEXP_REPLACE(v_tmp, '^"(.*)"$', '\1');
      END IF;
    END IF;

    -- 3) Simple "t.col" or "col"
    v_tmp := REGEXP_SUBSTR(v_expr, '([A-Z0-9_"]+)\.("?[A-Z0-9_]+"?)', 1, 1, 'in', 2);
    IF v_tmp IS NOT NULL THEN
      RETURN REGEXP_REPLACE(v_tmp, '^"(.*)"$', '\1');
    END IF;

    v_tmp := REGEXP_SUBSTR(v_expr, '"?([A-Z0-9_]+)"?', 1, 1, 'in', 1);
    IF v_tmp IS NOT NULL THEN
      RETURN REGEXP_REPLACE(v_tmp, '^"(.*)"$', '\1');
    END IF;

    RETURN NULL;
  END infer_output_name_from_expr;

  ----------------------------------------------------------------------
  -- Helper: parse SELECT list and return visible output column names
  -- Very pragmatic: between first SELECT and following FROM, split on
  -- commas at top-level (ignoring commas inside parentheses).
  ----------------------------------------------------------------------
  FUNCTION parse_output_columns_from_sql(
    p_sql IN CLOB
  ) RETURN t_vc_list IS
    l_out       t_vc_list := t_vc_list();

    v_raw       VARCHAR2(32767);
    v_text      VARCHAR2(32767);
    v_upper     VARCHAR2(32767);

    v_selectpos PLS_INTEGER;
    v_frompos   PLS_INTEGER;

    v_chunk     VARCHAR2(32767);
    i           PLS_INTEGER;
    start_pos   PLS_INTEGER;
    nest        PLS_INTEGER := 0;
    ch          CHAR(1);
    v_expr      VARCHAR2(32767);
    v_name      VARCHAR2(128);
  BEGIN
    IF p_sql IS NULL THEN
      RETURN l_out;
    END IF;

    ------------------------------------------------------------------
    -- 1) Flatten SQL into a single line (for easier parsing)
    ------------------------------------------------------------------
    v_raw := DBMS_LOB.SUBSTR(p_sql, 32767, 1);  -- first 32k characters

    -- Replace CR/LF with spaces
    v_text := REPLACE(REPLACE(v_raw, CHR(13), ' '), CHR(10), ' ');
    v_upper := UPPER(v_text);

    ------------------------------------------------------------------
    -- 2) Locate SELECT and FROM
    ------------------------------------------------------------------
    -- First occurrence of "SELECT "
    v_selectpos := INSTR(v_upper, 'SELECT ');
    IF v_selectpos = 0 THEN
      RETURN l_out;
    END IF;

    -- First " FROM " after the SELECT
    v_frompos := INSTR(v_upper, ' FROM ', v_selectpos + LENGTH('SELECT '));
    IF v_frompos = 0 THEN
      RETURN l_out;
    END IF;

    ------------------------------------------------------------------
    -- 3) Extract the SELECT list between SELECT and FROM
    ------------------------------------------------------------------
    v_chunk := SUBSTR(
                 v_text,
                 v_selectpos + LENGTH('SELECT '),
                 v_frompos - (v_selectpos + LENGTH('SELECT '))
               );

    ------------------------------------------------------------------
    -- 4) Walk v_chunk, splitting on commas at top-level (nesting-aware)
    ------------------------------------------------------------------
    start_pos := 1;
    FOR i IN 1 .. LENGTH(v_chunk) LOOP
      ch := SUBSTR(v_chunk, i, 1);

      IF ch = '(' THEN
        nest := nest + 1;
      ELSIF ch = ')' THEN
        nest := nest - 1;
        IF nest < 0 THEN
          nest := 0;
        END IF;
      ELSIF ch = ',' AND nest = 0 THEN
        v_expr := TRIM(SUBSTR(v_chunk, start_pos, i - start_pos));
        IF v_expr IS NOT NULL THEN
          v_name := infer_output_name_from_expr(v_expr);
          IF v_name IS NOT NULL THEN
            l_out.EXTEND;
            l_out(l_out.COUNT) := UPPER(v_name);
          END IF;
        END IF;
        start_pos := i + 1;
      END IF;
    END LOOP;

    -- Last expression after the final comma
    v_expr := TRIM(SUBSTR(v_chunk, start_pos));
    IF v_expr IS NOT NULL THEN
      v_name := infer_output_name_from_expr(v_expr);
      IF v_name IS NOT NULL THEN
        l_out.EXTEND;
        l_out(l_out.COUNT) := UPPER(v_name);
      END IF;
    END IF;

    RETURN l_out;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN t_vc_list(); -- fail-quiet
  END parse_output_columns_from_sql;

  ----------------------------------------------------------------------
  -- Tokenization / formatting (adjust as needed later)
  ----------------------------------------------------------------------
  /*FUNCTION TokenizeLabel(p_label IN VARCHAR2) RETURN VARCHAR2 IS BEGIN RETURN p_label; END;
  FUNCTION DetokenizeLabel(p_label IN VARCHAR2) RETURN VARCHAR2 IS BEGIN RETURN p_label; END;*/

  FUNCTION FormatNumber(p_value IN VARCHAR2) RETURN VARCHAR2 IS
    n NUMBER;
  BEGIN
    n := TO_NUMBER(p_value);
    RETURN TO_CHAR(n, 'FM999G999G999G990D00'); -- 2 decimals, grouping
  EXCEPTION WHEN OTHERS THEN
    RETURN p_value; -- pass-through if not numeric
  END;

  /*FUNCTION FormatDate(p_value IN VARCHAR2) RETURN VARCHAR2 IS
    d DATE;
  BEGIN
    BEGIN d := TO_DATE(p_value, 'YYYY-MM-DD'); EXCEPTION WHEN OTHERS THEN NULL; END;
    IF d IS NOT NULL THEN RETURN TO_CHAR(d, 'YYYY-MM-DD'); END IF;
    RETURN p_value;
  END;*/

  ---------------------------------------------------------------------------
  -- Private: detokenize summary text using CHATBOT_NL2SQL_REDACTION
  -- Looks up TOKEN_MAP_JSON by LOG_ID and replaces each token with its
  -- original text. Best-effort: never raise back out.
  ---------------------------------------------------------------------------
  FUNCTION detokenize_summary_from_map(
    p_text   IN CLOB,
    p_log_id IN NUMBER,
    p_ctx    IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id IN VARCHAR2,
    p_chat_id IN NUMBER
  ) RETURN CLOB IS
    l_map_json CLOB;
    l_out      CLOB := p_text;
    jo   JSON_OBJECT_T;
    rev  JSON_OBJECT_T;
  BEGIN
    IF p_text IS NULL THEN
      RETURN p_text;
    END IF;

    -- Get latest map row for this LOG_ID (highest MAP_VERSION)
    BEGIN
      SELECT token_map_json
        INTO l_map_json
        FROM chatbot_nl2sql_redaction
      WHERE log_id = p_log_id
        AND map_version = (
              SELECT MAX(map_version)
                FROM chatbot_nl2sql_redaction
                WHERE log_id = p_log_id
            );
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN p_text;
      WHEN OTHERS THEN
        RETURN p_text;
    END;

    IF l_map_json IS NULL THEN
      RETURN p_text;
    END IF;

    -- Parse reverse map (tok -> orig) if present
    BEGIN
      jo := JSON_OBJECT_T.parse(l_map_json);
      IF jo.has('reverse') THEN
        rev := jo.get_object('reverse');
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        rev := NULL;
    END;

    -- Use the "pairs" array: each element has { "orig": "...", "tok": "..." }
    FOR r IN (
      SELECT jt.tok  AS tok,
            jt.orig AS orig
      FROM JSON_TABLE(
            l_map_json,
            '$.pairs[*]'
            COLUMNS (
              orig VARCHAR2(4000) PATH '$.orig',
              tok  VARCHAR2(4000) PATH '$.tok'
            )
          ) jt
    ) LOOP
      l_out := REPLACE(l_out, r.tok, r.orig);
    END LOOP;

    -- Debug logging (old DETOK semantics)
    BEGIN
      IF CHATBOT_CORE_IO_PKG.debug_on(p_ctx) THEN
        -- 1) final detokenized text
        CHATBOT_CORE_IO_PKG.logc(
          p_ctx,'DETOK',p_req_id,
          '[out-detokenized]',
          CHATBOT_CORE_IO_PKG.clamp_clob(l_out, 1200),
          p_log_id, p_chat_id
        );

        -- 2) token presence / missing mapping stats
        DECLARE
          vtok VARCHAR2(4000);
          miss PLS_INTEGER := 0;
          seen PLS_INTEGER := 0;
          ixs  PLS_INTEGER := 1;
        BEGIN
          LOOP
            vtok := REGEXP_SUBSTR(p_text, '«STR:[^»]+»', 1, ixs, NULL, 0);
            EXIT WHEN vtok IS NULL;
            seen := seen + 1;

            IF rev IS NULL OR NOT rev.has(vtok) THEN
              miss := miss + 1;
              IF miss <= 5 THEN
                CHATBOT_CORE_IO_PKG.logv(
                  p_ctx,'DETOK',p_req_id,
                  '[missing] '||vtok,
                  p_log_id, p_chat_id
                );
              END IF;
            END IF;

            ixs := ixs + 1;
          END LOOP;

          CHATBOT_CORE_IO_PKG.logv(
            p_ctx,'DETOK',p_req_id,
            '[tokens] found='||seen||
            ', missing='||miss||
            ', revSize='||CASE WHEN rev IS NULL THEN 0 ELSE rev.get_size END,
            p_log_id, p_chat_id
          );
        EXCEPTION
          WHEN OTHERS THEN NULL;
        END;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;

    RETURN l_out;
  EXCEPTION
    WHEN OTHERS THEN
      -- Fail-closed: if anything goes wrong, just return the tokenized text
      RETURN p_text;
  END detokenize_summary_from_map;

  ----------------------------------------------------------------------
  -- Internal utilities: entity key set, reducers
  ----------------------------------------------------------------------
  FUNCTION entity_key_tuple(row_obj JSON_OBJECT_T, keys JSON_ARRAY_T) RETURN VARCHAR2 IS
    acc VARCHAR2(32767) := '';
  BEGIN
    IF keys IS NULL OR keys.get_size=0 THEN RETURN NULL; END IF;
    FOR i IN 0 .. keys.get_size-1 LOOP
      DECLARE k VARCHAR2(256) := keys.get_string(i);
              v VARCHAR2(4000);
      BEGIN
        IF row_obj.has(k) THEN
          BEGIN v := row_obj.get_string(k); EXCEPTION WHEN OTHERS THEN v := TO_CHAR(row_obj.get_number(k)); END;
        END IF;
        acc := acc || '|' || k || '=' || NVL(v,'<NULL>');
      END;
    END LOOP;
    RETURN acc;
  END;

  FUNCTION rows_single_entity(rows JSON_ARRAY_T, keys JSON_ARRAY_T) RETURN BOOLEAN IS
    TYPE t_set IS TABLE OF VARCHAR2(32767) INDEX BY VARCHAR2(32767);
    s t_set;
  BEGIN
    IF keys IS NULL OR keys.get_size=0 THEN RETURN FALSE; END IF;
    FOR i IN 0 .. rows.get_size-1 LOOP
      DECLARE r JSON_OBJECT_T := TREAT(rows.get(i) AS JSON_OBJECT_T); k VARCHAR2(32767);
      BEGIN
        k := entity_key_tuple(r, keys);
        IF k IS NOT NULL THEN s(k) := k; END IF;
      END;
    END LOOP;
    RETURN s.COUNT = 1;
  END;

  FUNCTION value_from_latest(rows JSON_ARRAY_T, alias VARCHAR2, time_col VARCHAR2) RETURN VARCHAR2 IS
    best_date DATE := TO_DATE('1900-01-01','YYYY-MM-DD');
    best      VARCHAR2(4000);
  BEGIN
    FOR i IN 0 .. rows.get_size-1 LOOP
      DECLARE
        r   JSON_OBJECT_T := TREAT(rows.get(i) AS JSON_OBJECT_T);
        d   DATE := NULL;
        cur VARCHAR2(4000) := NULL;
        tmp_el JSON_ELEMENT_T;
        tval   VARCHAR2(4000);
      BEGIN
        -- current value for alias (string or number)
        BEGIN
          cur := r.get_string(alias);
        EXCEPTION WHEN OTHERS THEN
          BEGIN cur := TO_CHAR(r.get_number(alias)); EXCEPTION WHEN OTHERS THEN cur := NULL; END;
        END;

        -- date from time_col (string → DATE or JSON date)
        IF time_col IS NOT NULL THEN
          BEGIN
            tmp_el := r.get(time_col); -- raises if missing
            -- Try JSON date first
            BEGIN d := r.get_date(time_col); EXCEPTION WHEN OTHERS THEN d := NULL; END;
            IF d IS NULL THEN
              BEGIN tval := r.get_string(time_col); EXCEPTION WHEN OTHERS THEN tval := NULL; END;
              IF tval IS NOT NULL THEN
                BEGIN d := TO_DATE(tval,'YYYY-MM-DD'); EXCEPTION WHEN OTHERS THEN d := NULL; END;
              END IF;
            END IF;
          EXCEPTION WHEN OTHERS THEN
            d := NULL;
          END;
        END IF;

        IF cur IS NOT NULL THEN
          IF d IS NULL THEN
            -- no time → prefer any non-null; but keep last seen to be deterministic
            IF best IS NULL THEN best := cur; END IF;
          ELSE
            IF d >= best_date THEN best_date := d; best := cur; END IF;
          END IF;
        END IF;
      END;
    END LOOP;
    RETURN best;
  END;

  FUNCTION value_max_numeric(rows JSON_ARRAY_T, alias VARCHAR2) RETURN VARCHAR2 IS
    bestn NUMBER := NULL; bests VARCHAR2(4000) := NULL;
  BEGIN
    FOR i IN 0 .. rows.get_size-1 LOOP
      DECLARE r JSON_OBJECT_T := TREAT(rows.get(i) AS JSON_OBJECT_T);
      BEGIN
        BEGIN bestn := GREATEST(NVL(bestn,-1e125), r.get_number(alias)); EXCEPTION WHEN OTHERS THEN
          BEGIN bests := GREATEST(NVL(bests,''), r.get_string(alias)); EXCEPTION WHEN OTHERS THEN NULL; END;
        END;
      END;
    END LOOP;
    IF bestn IS NOT NULL THEN RETURN TO_CHAR(bestn); END IF;
    IF bests IS NOT NULL THEN RETURN bests; END IF;
    RETURN NULL;
  END;

  FUNCTION rows_has_column(rows JSON_ARRAY_T, alias VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    FOR j IN 0 .. rows.get_size-1 LOOP
      BEGIN
        DECLARE
          obj JSON_OBJECT_T := TREAT(rows.get(j) AS JSON_OBJECT_T);
          el  JSON_ELEMENT_T;
        BEGIN
          IF obj IS NULL THEN CONTINUE; END IF;
          el := obj.get(alias); -- raises if key missing
          IF el IS NOT NULL THEN RETURN TRUE; END IF;
        END;
      EXCEPTION WHEN OTHERS THEN NULL;
      END;
    END LOOP;
    RETURN FALSE;
  END;

  FUNCTION clamp_words(p_text CLOB, p_max_words PLS_INTEGER) RETURN CLOB IS
    res CLOB := EMPTY_CLOB(); cnt PLS_INTEGER := 0; token VARCHAR2(32767);
    i PLS_INTEGER := 1; len PLS_INTEGER := DBMS_LOB.getlength(p_text);
  BEGIN
    -- simple word clamp
    WHILE i <= len LOOP
      token := REGEXP_SUBSTR(p_text, '\S+', 1, cnt+1);
      EXIT WHEN token IS NULL;
      cnt := cnt + 1;
      IF cnt = 1 THEN res := token; ELSE res := res || ' ' || token; END IF;
      EXIT WHEN cnt >= p_max_words;
      i := i + LENGTH(token) + 1;
    END LOOP;
    IF cnt >= p_max_words THEN res := res || ' …'; END IF;
    RETURN res;
  END;

  ----------------------------------------------------------------------
  -- Tokenization core (rows/plan/context_query + detokenization)
  ----------------------------------------------------------------------
  -- Build token like: «STR:<col>:W<words>:L<len>:H<hash>»
  FUNCTION make_token(p_col VARCHAR2, p_val VARCHAR2) RETURN VARCHAR2 IS
    w NUMBER := REGEXP_COUNT(NVL(p_val,''), '\S+');
    l NUMBER := LENGTH(NVL(p_val,''));
  BEGIN
    RETURN c_token_l
           || 'STR:' || NVL(p_col,'?')
           || ':W' || w
           || ':L' || l
           || ':H' || hash_short(p_val)
           || c_token_r;
  END;

  /*FUNCTION maybe_tokenize_value(p_col VARCHAR2, p_val VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN RETURN NULL; END IF;
    -- don’t tokenize if it already looks like a token
    IF REGEXP_LIKE(p_val, '^\Q' || c_token_l || '\E.*\Q' || c_token_r || '\E$') THEN
      RETURN p_val;
    END IF;
    RETURN make_token(p_col, p_val);
  END;*/
  FUNCTION maybe_tokenize_value(p_col VARCHAR2, p_val VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN
      RETURN NULL;
    END IF;

    -- Already a token → leave as-is
    IF REGEXP_LIKE(
        p_val,
        '^\Q' || c_token_l || '\E.*\Q' || c_token_r || '\E$'
      )
    THEN
      RETURN p_val;
    END IF;

    ------------------------------------------------------------------
    -- Heuristics: values we do NOT want to tokenize
    -- 1) Purely numeric values (IDs, counts, amounts like 1001, 42, 2024)
    ------------------------------------------------------------------
    IF REGEXP_LIKE(p_val, '^[0-9]+$') THEN
      RETURN p_val;
    END IF;

    ------------------------------------------------------------------
    -- 2) Very short “code-ish” tokens (e.g. EUR, GR, US, A1, etc.)
    --    This is optional, but helps avoid turning tiny codes into STR:...
    ------------------------------------------------------------------
    IF LENGTH(p_val) <= 4
      AND REGEXP_LIKE(p_val, '^[A-Z0-9_]+$')
    THEN
      RETURN p_val;
    END IF;

    ------------------------------------------------------------------
    -- Everything else (names, free-text, longer strings) → tokenize
    ------------------------------------------------------------------
    RETURN make_token(p_col, p_val);
  END;

  PROCEDURE tokenize_rows_and_build_map(
    p_rows_json   IN  CLOB,
    o_rows_token  OUT CLOB,
    io_token_map  IN OUT JSON_OBJECT_T
  ) IS
    arr  JSON_ARRAY_T;
    outa JSON_ARRAY_T := JSON_ARRAY_T();
  BEGIN
    IF p_rows_json IS NULL THEN
      o_rows_token := '[]';
      RETURN;
    END IF;

    arr := JSON_ARRAY_T.parse(p_rows_json);

    FOR i IN 0 .. arr.get_size-1 LOOP
      DECLARE
        r    JSON_OBJECT_T := TREAT(arr.get(i) AS JSON_OBJECT_T);
        rout JSON_OBJECT_T := JSON_OBJECT_T();
        keys JSON_KEY_LIST;
      BEGIN
        keys := r.get_keys;
        FOR k IN 1 .. keys.COUNT LOOP
          DECLARE col VARCHAR2(256) := keys(k);
          BEGIN
            -- try to treat value as string; else copy the element
            BEGIN
              DECLARE
                orig VARCHAR2(4000) := r.get_string(col);
                tok  VARCHAR2(4000) := maybe_tokenize_value(col, orig);
              BEGIN
                rout.put(col, tok);
                IF tok IS NOT NULL THEN
                  io_token_map.put(tok, orig);
                END IF;
              END;
            EXCEPTION
              WHEN OTHERS THEN
                rout.put(col, r.get(col));
            END;
          END;
        END LOOP;
        outa.append(rout);
      END;
    END LOOP;

    o_rows_token := outa.stringify;
  END;

  FUNCTION replace_words_with_tokens(
    p_text      IN CLOB,
    p_token_map IN JSON_OBJECT_T
  ) RETURN CLOB IS
    res CLOB := p_text;
    keys JSON_KEY_LIST;
  BEGIN
    IF p_text IS NULL OR p_token_map IS NULL THEN RETURN p_text; END IF;

    keys := p_token_map.get_keys;
    FOR i IN 1 .. keys.COUNT LOOP
      DECLARE
        tok VARCHAR2(4000) := keys(i);
        org VARCHAR2(32767);
      BEGIN
        org := p_token_map.get_string(tok);
        IF org IS NOT NULL THEN
          -- whole-word-ish replace; escape regex metacharacters
          res := REGEXP_REPLACE(res,
                  '(^|[^[:alnum:]_])' || REGEXP_REPLACE(org,'([\\.^$*+?()\[\]{}|])','\\\1') || '([^[:alnum:]_]|$)',
                  '\1' || tok || '\2', 1, 0, 'n');
        END IF;
      END;
    END LOOP;
    RETURN res;
  END;

  PROCEDURE tokenize_plan_and_cq(
    p_plan_json     IN  CLOB,
    p_context_query IN  CLOB,
    p_token_map     IN  JSON_OBJECT_T,
    o_plan_token    OUT CLOB,
    o_cq_token      OUT CLOB
  ) IS
  BEGIN
    o_plan_token := NVL(p_plan_json,'{}'); -- plan is usually structural; keep as-is
    o_cq_token   := replace_words_with_tokens(p_context_query, p_token_map);
  END;

  PROCEDURE Tokenize_For_Summary(
    p_plan_json      IN  CLOB,
    p_rows_json      IN  CLOB,
    p_context_query  IN  CLOB,
    p_ctx            IN  CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id         IN  VARCHAR2,
    p_log_id         IN  NUMBER,
    p_chat_id        IN  NUMBER,
    o_plan_tokenized OUT CLOB,
    o_rows_tokenized OUT CLOB,
    o_cq_tokenized   OUT CLOB,
    o_token_map      OUT CLOB
  ) IS
    l_tok_rows CLOB;
    l_tok_cq   CLOB;
    l_map      JSON_OBJECT_T := JSON_OBJECT_T();
  BEGIN
    -- 1) Tokenize rows using local tokenization logic
    tokenize_rows_and_build_map(
      p_rows_json  => p_rows_json,
      o_rows_token => l_tok_rows,
      io_token_map => l_map
    );

    o_rows_tokenized := COALESCE(l_tok_rows, NVL(p_rows_json, '[]'));
    o_plan_tokenized := NVL(p_plan_json,'{}');

    -- 2) Tokenize the context_query using the same in-memory token map
    l_tok_cq := replace_words_with_tokens(
                  p_text      => p_context_query,
                  p_token_map => l_map
                );
    o_cq_tokenized := NVL(l_tok_cq, p_context_query);

    -- 3) Serialize token map to CLOB so Detokenize_Summary can use it later
    o_token_map := l_map.to_clob;

    -- Optional debug log
    CHATBOT_CORE_IO_PKG.logc(
      p_ctx, c_phase, p_req_id,
      'Tokenize:map', o_token_map, p_log_id, p_chat_id
    );

  EXCEPTION
    WHEN OTHERS THEN
      CHATBOT_CORE_IO_PKG.log_any(
        p_ctx, c_phase, 'ERROR', p_req_id, p_log_id, p_chat_id,
        'Tokenize_For_Summary:error '||SQLERRM, NULL
      );
      -- fall back to original inputs
      o_plan_tokenized := NVL(p_plan_json,'{}');
      o_rows_tokenized := NVL(p_rows_json,'[]');
      o_cq_tokenized   := p_context_query;
      o_token_map      := NULL;
  END;

  FUNCTION Detokenize_Summary(
    p_text      IN CLOB,
    p_token_map IN CLOB
  ) RETURN CLOB IS
    res CLOB := p_text;
    jo  JSON_OBJECT_T;
    keys JSON_KEY_LIST;
  BEGIN
    IF p_text IS NULL OR p_token_map IS NULL THEN RETURN p_text; END IF;
    jo := JSON_OBJECT_T.parse(p_token_map);
    keys := jo.get_keys;

    FOR i IN 1 .. keys.COUNT LOOP
      DECLARE
        tok VARCHAR2(4000) := keys(i);
        org VARCHAR2(32767) := jo.get_string(tok);
      BEGIN
        res := REPLACE(res, tok, org);
      END;
    END LOOP;
    RETURN res;
  EXCEPTION WHEN OTHERS THEN
    RETURN p_text; -- fail-safe
  END;

  ----------------------------------------------------------------------
  -- PUBLIC: AnalyzeResultShape
  ----------------------------------------------------------------------
  PROCEDURE AnalyzeResultShape(
    p_plan_json           IN  CLOB,
    p_rows_json           IN  CLOB,
    o_single_entity       OUT BOOLEAN,
    o_missing_requested   OUT BOOLEAN,
    o_has_time_column     OUT BOOLEAN
  ) IS
    plan JSON_OBJECT_T := safe_parse_object(NVL(p_plan_json,'{}'));
    rows JSON_ARRAY_T  := CASE WHEN p_rows_json IS NOT NULL THEN safe_parse_array(NVL(p_rows_json,'[]')) ELSE JSON_ARRAY_T() END;
    keys JSON_ARRAY_T  := CASE WHEN plan.has('entity_keys') THEN plan.get_array('entity_keys') END;
    req  JSON_ARRAY_T  := CASE WHEN plan.has('requested_outputs') THEN plan.get_array('requested_outputs') END;
    tcol VARCHAR2(256) := get_time_col(plan);
  BEGIN
    o_single_entity := rows_single_entity(rows, keys);
    o_has_time_column := (tcol IS NOT NULL);
    o_missing_requested := FALSE;

    IF req IS NOT NULL THEN
      FOR i IN 0 .. req.get_size-1 LOOP
        IF NOT rows_has_column(rows, req.get_string(i)) THEN
          o_missing_requested := TRUE; EXIT;
        END IF;
      END LOOP;
    END IF;
  END AnalyzeResultShape;

  ----------------------------------------------------------------------
  -- Decide if this looks like a simple direct answer
  -- (few rows, few cols, single entity or trivial 1-row result).
  ----------------------------------------------------------------------
  FUNCTION Is_Simple_Answer(
    p_plan_json IN CLOB,
    p_rows_json IN CLOB
  ) RETURN BOOLEAN IS
    rows           JSON_ARRAY_T  := CASE WHEN p_rows_json IS NOT NULL
                                         THEN safe_parse_array(NVL(p_rows_json,'[]'))
                                         ELSE JSON_ARRAY_T() END;
    keys_ja        JSON_ARRAY_T;
    single_entity  BOOLEAN;
    missing_req    BOOLEAN;
    has_time       BOOLEAN;
    row_count      PLS_INTEGER;
    first_obj      JSON_OBJECT_T;
    keylist        JSON_KEY_LIST;
    col_count      PLS_INTEGER := 0;
  BEGIN
    row_count := rows.get_size;

    -- No rows → not a simple "answer"
    IF row_count = 0 THEN
      RETURN FALSE;
    END IF;

    -- Inspect first row for column count
    IF row_count > 0 THEN
      first_obj := TREAT(rows.get(0) AS JSON_OBJECT_T);
      IF first_obj IS NOT NULL THEN
        keylist   := first_obj.get_keys;
        col_count := keylist.COUNT;
      END IF;
    END IF;

    --------------------------------------------------------------------
    -- 1) Trivial 1-row shortcut
    -- For a single row with a small number of columns, treat as simple
    -- regardless of entity_keys / requested_outputs (works for FOLLOWUP
    -- where plan/entity_keys are often empty).
    --------------------------------------------------------------------
    IF row_count = 1
       AND col_count > 0
       AND col_count <= 5
    THEN
      RETURN TRUE;
    END IF;

    --------------------------------------------------------------------
    -- 2) Existing heuristic for slightly larger "small" results
    --------------------------------------------------------------------
    IF row_count > 3 THEN
      RETURN FALSE;
    END IF;

    -- Use existing AnalyzeResultShape for single_entity signal
    AnalyzeResultShape(
      p_plan_json         => p_plan_json,
      p_rows_json         => p_rows_json,
      o_single_entity     => single_entity,
      o_missing_requested => missing_req,
      o_has_time_column   => has_time
    );

    -- Heuristic: small, single-entity, low column count
    IF    single_entity
      AND NOT missing_req
      AND row_count <= 3
      AND col_count <= 3
    THEN
      RETURN TRUE;
    END IF;

    RETURN FALSE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE; -- fail-safe: treat as non-simple
  END Is_Simple_Answer;

  ----------------------------------------------------------------------
  -- Infer "list-only" display column from REASONING plan.
  -- Returns the single display column when:
  --   - intent = 'select'
  --   - result_granularity = 'entity'
  --   - metric.column IS NULL
  --   - metric.aggregation = 'NONE'
  --   - display_columns has exactly one entry
  -- Otherwise returns NULL.
  ----------------------------------------------------------------------
  FUNCTION infer_list_display_column(
    p_plan_json IN CLOB
  ) RETURN VARCHAR2 IS
    plan        JSON_OBJECT_T := safe_parse_object(NVL(p_plan_json,'{}'));
    l_intent    VARCHAR2(50);
    l_gran      VARCHAR2(50);
    l_metriccol VARCHAR2(200);
    l_metricagg VARCHAR2(50);
    l_disp      JSON_ARRAY_T;
    l_col       VARCHAR2(256);
    mobj        JSON_OBJECT_T;
  BEGIN
    BEGIN
      IF plan.has('intent') THEN
        l_intent := LOWER(plan.get_string('intent'));
      END IF;
    EXCEPTION WHEN OTHERS THEN
      l_intent := NULL;
    END;

    BEGIN
      IF plan.has('result_granularity') THEN
        l_gran := LOWER(plan.get_string('result_granularity'));
      END IF;
    EXCEPTION WHEN OTHERS THEN
      l_gran := NULL;
    END;

    BEGIN
      IF plan.has('metric') THEN
        mobj := plan.get_object('metric');
        IF mobj.has('column') THEN
          l_metriccol := mobj.get_string('column');
        END IF;
        IF mobj.has('aggregation') THEN
          l_metricagg := LOWER(mobj.get_string('aggregation'));
        END IF;
      END IF;
    EXCEPTION WHEN OTHERS THEN
      l_metriccol := NULL;
      l_metricagg := NULL;
    END;

    BEGIN
      IF plan.has('display_columns') THEN
        l_disp := plan.get_array('display_columns');
        IF l_disp.get_size = 1 THEN
          l_col := l_disp.get_string(0);
        END IF;
      END IF;
    EXCEPTION WHEN OTHERS THEN
      l_col := NULL;
    END;

    IF    l_intent = 'select'
      AND l_gran   = 'entity'
      AND (l_metriccol IS NULL OR TRIM(l_metriccol) IS NULL)
      AND NVL(l_metricagg, 'none') = 'none'
      AND l_col IS NOT NULL
    THEN
      RETURN l_col;
    END IF;

    RETURN NULL;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END infer_list_display_column;

  ----------------------------------------------------------------------
  -- Render_List_Only: for "show me the names of workloads" cases.
  -- Output: plain Markdown list with one item per value in p_column_name.
  -- No headings, no commentary.
  ----------------------------------------------------------------------
  FUNCTION Render_List_Only(
    p_rows_json   IN CLOB,
    p_column_name IN VARCHAR2
  ) RETURN CLOB IS
    rows JSON_ARRAY_T := safe_parse_array(NVL(p_rows_json,'[]'));
    obj  JSON_OBJECT_T;
    out  CLOB := EMPTY_CLOB();
    val  VARCHAR2(4000);
    col  VARCHAR2(256) := p_column_name;
  BEGIN
    IF rows.get_size = 0 THEN
      RETURN '';
    END IF;

    FOR i IN 0 .. rows.get_size - 1 LOOP
      obj := TREAT(rows.get(i) AS JSON_OBJECT_T);
      IF obj IS NULL THEN
        CONTINUE;
      END IF;

      BEGIN
        val := obj.get_string(col);
      EXCEPTION
        WHEN OTHERS THEN
          BEGIN
            val := TO_CHAR(obj.get_number(col));
          EXCEPTION
            WHEN OTHERS THEN
              val := NULL;
          END;
      END;

      IF val IS NOT NULL THEN
        IF DBMS_LOB.getlength(out) > 0 THEN
          out := out || CHR(10);
        END IF;
        out := out || '- ' || val;
      END IF;
    END LOOP;

    RETURN out;
  EXCEPTION
    WHEN OTHERS THEN
      -- Fail-quiet: fall back to empty (UI still has the table).
      RETURN '';
  END Render_List_Only;

  ----------------------------------------------------------------------
  -- Render_Simple_Answer: tiny result → compact Markdown "## Result"
  ----------------------------------------------------------------------
  FUNCTION Render_Simple_Answer(
    p_rows_json     IN CLOB,
    p_context_query IN CLOB
  ) RETURN CLOB IS
    rows      JSON_ARRAY_T := safe_parse_array(NVL(p_rows_json,'[]'));
    first_obj JSON_OBJECT_T;
    keylist   JSON_KEY_LIST;
    out       CLOB := EMPTY_CLOB();
    val       VARCHAR2(4000);
  BEGIN
    -- No data
    IF rows.get_size = 0 THEN
      RETURN '## Result' || CHR(10) ||
             CHR(10) ||
             'No rows returned.';
    END IF;

    first_obj := TREAT(rows.get(0) AS JSON_OBJECT_T);
    IF first_obj IS NULL THEN
      RETURN '## Result' || CHR(10) ||
             CHR(10) ||
             'No rows returned.';
    END IF;

    keylist := first_obj.get_keys;

    --------------------------------------------------------------------
    -- 1) Single cell answer: one row, one column
    --------------------------------------------------------------------
    IF keylist.COUNT = 1 AND rows.get_size = 1 THEN
      BEGIN
        val := first_obj.get_string(keylist(1));
      EXCEPTION
        WHEN OTHERS THEN
          BEGIN
            val := TO_CHAR(first_obj.get_number(keylist(1)));
          EXCEPTION
            WHEN OTHERS THEN
              val := NULL;
          END;
      END;

      -- Friendly scalar rendering: hide technical column name / expression
      IF val IS NULL THEN
        RETURN '## Result' || CHR(10) ||
               CHR(10) ||
               'No value returned.';
      END IF;

      IF p_context_query IS NOT NULL THEN
        RETURN '## Result' || CHR(10) ||
               CHR(10) ||
               'Based on your question, the answer is: ' || val || '.';
      ELSE
        RETURN '## Result' || CHR(10) ||
               CHR(10) ||
               'The answer is: ' || val || '.';
      END IF;
    END IF;

    --------------------------------------------------------------------
    -- 2) Small set of key/values: 1–3 rows, few columns
    --    Render as a Markdown list instead of "COL: VAL | COL: VAL"
    --------------------------------------------------------------------
    out := '## Result' || CHR(10) || CHR(10) ||
           CASE
             WHEN rows.get_size = 1 THEN
               'The query returned one row with these values:'
             WHEN rows.get_size = 2 THEN
               'The query returned two rows with these values:'
             ELSE
               'The query returned a few rows with these values:'
           END || CHR(10) || CHR(10);

    FOR r IN 0 .. rows.get_size-1 LOOP
      DECLARE
        obj JSON_OBJECT_T := TREAT(rows.get(r) AS JSON_OBJECT_T);
      BEGIN
        IF obj IS NULL THEN
          CONTINUE;
        END IF;

        -- Label rows only when there is more than one
        IF rows.get_size > 1 THEN
          out := out || '- Row ' || (r + 1) || ':' || CHR(10);
        END IF;

        FOR k IN 1 .. keylist.COUNT LOOP
          DECLARE
            col VARCHAR2(256) := keylist(k);
            v   VARCHAR2(4000);
          BEGIN
            BEGIN
              v := obj.get_string(col);
            EXCEPTION
              WHEN OTHERS THEN
                BEGIN
                  v := TO_CHAR(obj.get_number(col));
                EXCEPTION
                  WHEN OTHERS THEN
                    v := NULL;
                END;
            END;

            -- Indent values as bullets (Markdown)
            IF v IS NOT NULL THEN
              out := out || '  - ' || col || ': ' || v || CHR(10);
            END IF;
          END;
        END LOOP;

        IF rows.get_size > 1 AND r < rows.get_size-1 THEN
          out := out || CHR(10); -- blank line between rows
        END IF;
      END;
    END LOOP;

    RETURN out;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN '## Result' || CHR(10) ||
             CHR(10) ||
             'Answer unavailable due to an internal error.';
  END Render_Simple_Answer;

  ---------------------------------------------------------------------------
  -- Build COLUMN INFO block from TABLEDESCRIPTIONS for:
  --   - only the tables that actually appear in p_sql_text, and
  --   - only the output columns (SELECT list).
  ---------------------------------------------------------------------------
  FUNCTION build_column_info_from_tabledesc(
    p_rows_json      IN CLOB,
    p_tabledesc_json IN CLOB,
    p_sql_text       IN CLOB
  ) RETURN CLOB
  IS
    -- Columns to describe (from SQL SELECT list, if available)
    l_output_cols   t_vc_list := t_vc_list();

    -- Tables actually used in the generated SQL
    l_used_tables   t_vc_list := t_vc_list();

    -- Fallback: visible JSON columns (if SQL parsing fails)
    l_rows_arr   json_array_t;
    l_first_row  json_object_t;
    l_keys       json_key_list;

    -- TABLEDESC parsing
    l_desc_root  json_object_t;
    l_tables     json_array_t;
    l_tbl        json_object_t;
    l_cols       json_array_t;
    l_col        json_object_t;

    l_col_out    VARCHAR2(128);      -- output column name (alias)
    l_lookup     VARCHAR2(128);      -- name to look up in TABLEDESCRIPTIONS
    l_td_name    VARCHAR2(128);
    l_tbl_name   VARCHAR2(256);
    l_desc       VARCHAR2(4000);
    l_out        CLOB := NULL;
    -- PRIMARY table from generated SQL (FROM table)
    l_main_table VARCHAR2(256);

    FUNCTION table_is_used(p_name VARCHAR2) RETURN BOOLEAN IS
      v_param_full VARCHAR2(4000);
      v_param_base VARCHAR2(4000);
      v_main_full  VARCHAR2(4000);
      v_main_base  VARCHAR2(4000);
    BEGIN
      IF p_name IS NULL THEN
        RETURN FALSE;
      END IF;

      -- If we couldn't parse any table at all, allow everything (fallback)
      IF l_main_table IS NULL THEN
        RETURN TRUE;
      END IF;

      v_param_full := UPPER(REGEXP_REPLACE(TRIM(p_name), '"', NULL));
      v_param_base := REGEXP_SUBSTR(v_param_full, '[^.]+$', 1, 1, 'i');

      v_main_full  := UPPER(REGEXP_REPLACE(TRIM(l_main_table), '"', NULL));
      v_main_base  := REGEXP_SUBSTR(v_main_full, '[^.]+$', 1, 1, 'i');

      RETURN (v_param_full = v_main_full OR v_param_base = v_main_base);
    END;
  BEGIN
    IF p_tabledesc_json IS NULL THEN
      RETURN NULL;
    END IF;

    ------------------------------------------------------------------
    -- 1) Preferred: derive output columns AND used tables from SQL
    ------------------------------------------------------------------
    IF p_sql_text IS NOT NULL THEN
      l_output_cols := parse_output_columns_from_sql(p_sql_text);
      l_used_tables := parse_tables_from_sql(p_sql_text);
    END IF;

    -- Decide the primary FROM table: first entry in l_used_tables
    IF l_used_tables IS NOT NULL AND l_used_tables.COUNT > 0 THEN
      l_main_table := l_used_tables(1);
    END IF;

    ------------------------------------------------------------------
    -- 2) Fallback: use JSON first-row keys if SQL/columns parsing fails
    ------------------------------------------------------------------
    IF (l_output_cols IS NULL OR l_output_cols.COUNT = 0)
       AND p_rows_json IS NOT NULL
    THEN
      l_rows_arr := json_array_t.parse(p_rows_json);
      IF l_rows_arr.get_size > 0 THEN
        l_first_row := TREAT(l_rows_arr.get(0) AS json_object_t);
        IF l_first_row IS NOT NULL THEN
          l_keys := l_first_row.get_keys;
          IF l_keys IS NOT NULL THEN
            l_output_cols := t_vc_list();
            FOR i IN 1 .. l_keys.COUNT LOOP
              l_output_cols.EXTEND;
              l_output_cols(l_output_cols.COUNT) := UPPER(l_keys(i));
            END LOOP;
          END IF;
        END IF;
      END IF;
    END IF;

    IF l_output_cols IS NULL OR l_output_cols.COUNT = 0 THEN
      RETURN NULL; -- nothing to describe
    END IF;

    ------------------------------------------------------------------
    -- 3) Parse TABLEDESCRIPTIONS JSON once
    ------------------------------------------------------------------
    l_desc_root := json_object_t.parse(p_tabledesc_json);
    l_tables    := l_desc_root.get_array('tables');

    IF l_tables IS NULL THEN
      RETURN NULL;
    END IF;

    ------------------------------------------------------------------
    -- 4) For each visible output column, find matching description
    --    only in tables actually used by the SQL.
    ------------------------------------------------------------------
    FOR i IN 1 .. l_output_cols.COUNT LOOP
      l_col_out := l_output_cols(i);
      l_lookup  := l_col_out;
      l_desc    := NULL;

      -- Scan tables[] but skip those not present in l_used_tables
      FOR t IN 0 .. l_tables.get_size - 1 LOOP
        l_tbl      := TREAT(l_tables.get(t) AS json_object_t);
        l_tbl_name := l_tbl.get_string('name');

        IF NOT table_is_used(l_tbl_name) THEN
          CONTINUE;
        END IF;

        l_cols := l_tbl.get_array('columns');
        IF l_cols IS NOT NULL THEN
          FOR c IN 0 .. l_cols.get_size - 1 LOOP
            l_col := TREAT(l_cols.get(c) AS json_object_t);

            l_td_name := UPPER(l_col.get_string('name'));
            IF l_td_name = l_lookup THEN
              IF l_col.has('description') THEN
                l_desc := l_col.get_string('description');
              END IF;
              EXIT; -- found in this table
            END IF;
          END LOOP;
        END IF;

        EXIT WHEN l_desc IS NOT NULL;
      END LOOP;

      IF l_desc IS NOT NULL THEN
        IF l_out IS NOT NULL THEN
          l_out := l_out || CHR(10);
        END IF;
        l_out := l_out || '- ' || l_col_out || ': ' || l_desc;
      END IF;
    END LOOP;

    RETURN l_out;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL; -- fail-quiet
  END build_column_info_from_tabledesc;

  ----------------------------------------------------------------------
  -- Render_LLM_Summary: LLM-based summary with redaction (old summarize_preview)
  ----------------------------------------------------------------------
  FUNCTION Render_LLM_Summary(
      p_ctx            IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
      p_phase          IN VARCHAR2,
      p_endpoint       IN VARCHAR2,
      p_api_format     IN VARCHAR2,
      p_model_id       IN VARCHAR2,
      p_compartment_id IN VARCHAR2,
      p_temperature    IN NUMBER,
      p_top_p          IN NUMBER,
      p_top_k          IN NUMBER,
      p_summary_system IN CLOB,
      p_result_json    IN CLOB,
      p_user_prompt    IN CLOB,
      p_req_id         IN VARCHAR2,
      p_log_id         IN NUMBER,
      p_chat_id        IN NUMBER,
      p_raw_resp       OUT CLOB
  ) RETURN CLOB
  IS
    l_payload        CLOB;
    l_resp           CLOB;
    l_text           CLOB;
    -- Redaction locals
    l_preview_token  CLOB := NULL;
    l_summary_token  CLOB := NULL;
    -- Column info locals
    v_column_info    CLOB := NULL;
    v_generated_sql  CLOB := NULL;
  BEGIN
    ------------------------------------------------------------------
    -- 1) Optionally tokenize JSON (respect REDACTION_ENABLED)
    ------------------------------------------------------------------
    IF p_result_json IS NOT NULL THEN
      DECLARE
        v_flag VARCHAR2(10) := CHATBOT_CORE_CTX_PARAMS_PKG.get_param_value(p_ctx, 'REDACTION_ENABLED');
        v_on   BOOLEAN      := (UPPER(TRIM(NVL(v_flag,'Y'))) <> 'N');
      BEGIN
        IF v_on THEN
          BEGIN
            l_preview_token := CHATBOT_CORE_SQL_PKG.redact_preview_json(
                                 p_ctx     => p_ctx,
                                 p_log_id  => p_log_id,
                                 p_preview => p_result_json
                               );
          EXCEPTION
            WHEN OTHERS THEN
              l_preview_token := NULL;  -- fail-closed
          END;
        ELSE
          l_preview_token := NULL;      -- redaction disabled
        END IF;
      END;
    END IF;

    CHATBOT_CORE_IO_PKG.logc(
      p_ctx,'SUMMARY',p_req_id,
      'Tokenized preview',
      l_preview_token,
      p_log_id,p_chat_id
    );

    ------------------------------------------------------------------
    -- 2) Build COLUMN INFO by:
    --    - loading generated SQL for this LOG_ID
    --    - building a merged TABLE_DESCRIPTIONS blob only for tables
    --      that appear in the generated SQL (FROM/JOIN)
    --    - passing that blob once into build_column_info_from_tabledesc
    ------------------------------------------------------------------
    v_generated_sql := load_generated_sql(p_log_id);

    IF v_generated_sql IS NOT NULL THEN
      DECLARE
        v_tabledesc_json CLOB;
      BEGIN
        -- Build {"tables":[...]} only for tables used in v_generated_sql
        v_tabledesc_json := build_tabledesc_json_for_sql(v_generated_sql);

        IF v_tabledesc_json IS NOT NULL THEN
          v_column_info := build_column_info_from_tabledesc(
                             p_rows_json      => p_result_json,   -- fallback
                             p_tabledesc_json => v_tabledesc_json,
                             p_sql_text       => v_generated_sql
                           );
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          v_column_info := NULL;
      END;

      -- Optional debug log of final COLUMN INFO block
      BEGIN
        CHATBOT_CORE_IO_PKG.logc(
          p_ctx, p_phase, p_req_id,
          'Summary:column-info',
          CHATBOT_CORE_IO_PKG.clamp_clob(v_column_info, 2000),
          p_log_id, p_chat_id
        );
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END IF;

    ------------------------------------------------------------------
    -- 3) Build payload using tokenized JSON (fallback to original),
    --    injecting COLUMN INFO between system prompt and rows if present.
    ------------------------------------------------------------------
    l_payload := CHATBOT_CORE_IO_PKG.build_payload_chat(
      p_api_format,
      p_model_id,
      p_compartment_id,
        p_summary_system
        || CASE
             WHEN v_column_info IS NOT NULL THEN
               CHR(10) || CHR(10) ||
               '-- COLUMN INFO --' || CHR(10) ||
               v_column_info
             ELSE
               ''
           END
        || CHR(10) || CHR(10) ||
           NVL(l_preview_token, p_result_json)
        || CHR(10) || CHR(10) ||
           NVL(p_user_prompt,''),
      p_temperature,
      p_top_p,
      p_top_k
    );

    CHATBOT_CORE_IO_PKG.logc(
      p_ctx, p_phase, p_req_id, 'Summary Payload',
      l_payload, p_log_id, p_chat_id
    );

    ------------------------------------------------------------------
    -- 4) Call model
    ------------------------------------------------------------------
    l_resp := CHATBOT_CORE_IO_PKG.call_model(
      p_ctx, p_phase, p_endpoint, l_payload, p_req_id, p_log_id, p_chat_id
    );
    p_raw_resp := l_resp;

    CHATBOT_CORE_IO_PKG.logc(
      p_ctx,'SUMMARY',p_req_id,
      'Raw summary resp',
      l_resp,
      p_log_id,p_chat_id
    );

    ------------------------------------------------------------------
    -- 5) Extract text and re-tokenize literals in the summary
    ------------------------------------------------------------------
    l_text := CHATBOT_CORE_IO_PKG.extract_text_from_chat_response(l_resp);

    l_summary_token := CHATBOT_CORE_SQL_PKG.redact_preview_literals(
      p_ctx          => p_ctx,
      p_preview_json => NVL(l_preview_token, p_result_json),
      p_summary_text => l_text,
      p_log_id       => p_log_id,
      p_chat_id      => p_chat_id,
      p_req_id       => p_req_id
    );

    CHATBOT_CORE_IO_PKG.logc(
      p_ctx,'SUMMARY',p_req_id,
      'Tokenized summary',
      l_summary_token,
      p_log_id,p_chat_id
    );

    RETURN NVL(l_summary_token, l_text);

  EXCEPTION
    WHEN OTHERS THEN
      -- Fail-closed: return whatever we have (possibly NULL)
      RETURN l_text;
  END Render_LLM_Summary;

  ----------------------------------------------------------------------
  -- PUBLIC: Render_Auto
  --  - simple scalar → plain answer, no LLM, no headings
  --  - otherwise → LLM summary with SUMMARY_SYSTEM (using redaction)
  --  - fallback → rule-based Render_Redacted
  ----------------------------------------------------------------------
  FUNCTION Render_Auto(
    p_context_query      IN CLOB,
    p_plan_json          IN CLOB,
    p_rows_json          IN CLOB,
    p_meta_json          IN CLOB,
    p_ctx                IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id             IN VARCHAR2,
    p_log_id             IN NUMBER,
    p_chat_id            IN NUMBER,
    p_use_llm            IN BOOLEAN,
    p_endpoint           IN VARCHAR2,
    p_api_format         IN VARCHAR2,
    p_model_id           IN VARCHAR2,
    p_compartment_id     IN VARCHAR2,
    p_temperature        IN NUMBER,
    p_top_p              IN NUMBER,
    p_top_k              IN NUMBER
  ) RETURN CLOB IS
    v_simple        BOOLEAN;
    v_summary       CLOB;
    v_raw_resp      CLOB;
    v_summary_system CLOB;
    v_list_col       VARCHAR2(256);
  BEGIN
    -- First: try REASONING-driven "list-only" mode
    v_list_col := infer_list_display_column(p_plan_json);

    IF v_list_col IS NOT NULL THEN
      -- e.g. "show me the names of workloads" → just list the names
      RETURN Render_List_Only(p_rows_json, v_list_col);
    END IF;

    -- Otherwise fall back to existing simple/LLM logic
    v_simple := Is_Simple_Answer(p_plan_json, p_rows_json);

    IF v_simple THEN
      -- small scalar-ish answer, no template, no LLM
      RETURN Render_Simple_Answer(p_rows_json, p_context_query);
    ELSIF p_use_llm THEN
      -- LLM-based summary with SUMMARY_SYSTEM
      v_summary_system := CHATBOT_CORE_CTX_PARAMS_PKG.load_component(p_ctx, 'SUMMARY_SYSTEM');

      v_summary := Render_LLM_Summary(
                     p_ctx            => p_ctx,
                     p_phase          => 'SUMMARY',
                     p_endpoint       => p_endpoint,
                     p_api_format     => p_api_format,
                     p_model_id       => p_model_id,
                     p_compartment_id => p_compartment_id,
                     p_temperature    => p_temperature,
                     p_top_p          => p_top_p,
                     p_top_k          => p_top_k,
                     p_summary_system => NVL(v_summary_system,''),
                     p_result_json    => p_rows_json,
                     p_user_prompt    => TO_CLOB('-- USER QUESTION --')||CHR(10)||NVL(p_context_query,''),
                     p_req_id         => p_req_id,
                     p_log_id         => p_log_id,
                     p_chat_id        => p_chat_id,
                     p_raw_resp       => v_raw_resp
                   );

      -- Detokenize using persisted redaction map for this LOG_ID (best-effort)
      v_summary := detokenize_summary_from_map(
                     p_text    => v_summary,
                     p_log_id  => p_log_id,
                     p_ctx     => p_ctx,
                     p_req_id  => p_req_id,
                     p_chat_id => p_chat_id
                   );

      RETURN v_summary;
    ELSE
      -- Fallback: existing rule-based summary with redaction + headings
      RETURN Render_Redacted(
               p_context_query      => p_context_query,
               p_plan_json          => p_plan_json,
               p_rows_json          => p_rows_json,
               p_meta_json          => p_meta_json,
               p_ctx                => p_ctx,
               p_req_id             => p_req_id,
               p_log_id             => p_log_id,
               p_chat_id            => p_chat_id,
               p_redaction_enabled  => TRUE,
               p_detokenize_output  => TRUE
             );
    END IF;
  END Render_Auto;

  ----------------------------------------------------------------------
  -- PUBLIC: Render  (includes logging context)
  ----------------------------------------------------------------------
  FUNCTION Render(
    p_context_query IN CLOB,
    p_plan_json     IN CLOB,
    p_rows_json     IN CLOB,
    p_meta_json     IN CLOB,
    p_ctx           IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id        IN VARCHAR2,
    p_log_id        IN NUMBER,
    p_chat_id       IN NUMBER
  ) RETURN CLOB IS
    plan JSON_OBJECT_T := safe_parse_object(NVL(p_plan_json,'{}'));
    rows JSON_ARRAY_T  := CASE WHEN p_rows_json IS NOT NULL THEN safe_parse_array(NVL(p_rows_json,'[]')) ELSE JSON_ARRAY_T() END;
    meta JSON_OBJECT_T := CASE WHEN p_meta_json IS NOT NULL THEN safe_parse_object(NVL(p_meta_json,'{}')) ELSE JSON_OBJECT_T() END;

    keys JSON_ARRAY_T  := CASE WHEN plan.has('entity_keys') THEN plan.get_array('entity_keys') END;
    req  JSON_ARRAY_T  := CASE WHEN plan.has('requested_outputs') THEN plan.get_array('requested_outputs') END;
    pol  JSON_OBJECT_T := CASE WHEN plan.has('reduction_policy') THEN plan.get_object('reduction_policy') END;

    tcol VARCHAR2(256) := get_time_col(plan);
    answer_first BOOLEAN := get_json_bool(plan,'answer_first',FALSE);

    out CLOB := EMPTY_CLOB();
    answer  CLOB := EMPTY_CLOB();
    has_answer BOOLEAN := FALSE;

    single_entity BOOLEAN := rows_single_entity(rows, keys);
  BEGIN
    -- start log (payload = plan for easy repro)
    CHATBOT_CORE_IO_PKG.logc(
      p_ctx, c_phase, p_req_id,
      'Render:start', p_plan_json, p_log_id, p_chat_id
    );

    -- helpful trace about shape
    DECLARE
      jo            JSON_OBJECT_T := JSON_OBJECT_T();
      trace_payload CLOB;
    BEGIN
      jo.put('single_entity', CASE WHEN single_entity THEN 'Y' ELSE 'N' END);
      jo.put('answer_first',  CASE WHEN answer_first  THEN 'Y' ELSE 'N' END);
      jo.put('has_time_col',  CASE WHEN tcol IS NOT NULL THEN 'Y' ELSE 'N' END);
      trace_payload := TO_CLOB(jo.to_string);

      CHATBOT_CORE_IO_PKG.logc(
        p_ctx, c_phase, p_req_id,
        'Render:shape', trace_payload, p_log_id, p_chat_id
      );
    EXCEPTION WHEN OTHERS THEN NULL; END;

    -- Guardrail: if context implies single-entity (answer_first) but rows have multiple entities
    IF answer_first AND NOT single_entity THEN
      out := c_h_overview || CHR(10) ||
             'Results include multiple entities; cannot produce a single-entity answer. The following sections reflect only the visible rows.' || CHR(10) ||
             c_h_details || CHR(10) ||
             '- See table for row-level values.' || CHR(10) ||
             c_h_aggs || CHR(10) ||
             '- Count of rows: '|| rows.get_size || CHR(10) ||
             c_h_insights || CHR(10) ||
             'Broader insights require aggregates over the full dataset.';

      CHATBOT_CORE_IO_PKG.logc(
        p_ctx, c_phase, p_req_id,
        'Render:multi-entity-guard', NULL, p_log_id, p_chat_id
      );

      RETURN clamp_words(out, c_max_words);
    END IF;

    BEGIN
      DECLARE
        dbg        JSON_OBJECT_T := JSON_OBJECT_T();
        req_echo   JSON_ARRAY_T  := JSON_ARRAY_T();
        keys_ja    JSON_ARRAY_T  := JSON_ARRAY_T();
        first_obj  JSON_OBJECT_T;
        keylist    JSON_KEY_LIST;
      BEGIN
        IF req IS NOT NULL THEN
          FOR i IN 0 .. req.get_size-1 LOOP
            req_echo.append(req.get_string(i));
          END LOOP;
        END IF;

        IF rows.get_size > 0 THEN
          first_obj := TREAT(rows.get(0) AS JSON_OBJECT_T);
          IF first_obj IS NOT NULL THEN
            keylist := first_obj.get_keys;
            FOR k IN 1 .. keylist.COUNT LOOP
              keys_ja.append(keylist(k));
            END LOOP;
          END IF;
        END IF;

        dbg.put('requested_outputs', req_echo);
        dbg.put('first_row_keys',    keys_ja);

        CHATBOT_CORE_IO_PKG.logc(
          p_ctx, c_phase, p_req_id,
          'Render:debug-keys', TO_CLOB(dbg.to_string), p_log_id, p_chat_id
        );
      EXCEPTION WHEN OTHERS THEN NULL; END;
    END;

    -- Answer-first key=value pairs (structural, alias-driven)
    IF answer_first
      AND single_entity
      AND rows.get_size > 0
      AND req IS NOT NULL
      AND req.get_size > 0
    THEN
      FOR i IN 0 .. req.get_size-1 LOOP
        DECLARE
          alias  VARCHAR2(256)  := req.get_string(i);
          forced VARCHAR2(10)   := NULL;
          val    VARCHAR2(4000) := NULL;
        BEGIN
          -- if there is a reduction_policy override, use it
          IF pol IS NOT NULL AND pol.has(alias) THEN
            forced := UPPER(pol.get_string(alias));
          END IF;

          -- choose reducer
          IF forced = 'LATEST' THEN
            val := value_from_latest(rows, alias, tcol);
          ELSIF forced = 'MAX' THEN
            val := value_max_numeric(rows, alias);
          ELSE
            -- heuristic: numeric MAX first; if null, latest-by-time
            val := value_max_numeric(rows, alias);
            IF val IS NULL THEN
              val := value_from_latest(rows, alias, tcol);
            END IF;
          END IF;

          -- if nothing found across rows
          IF val IS NULL THEN
            answer := answer || alias || ' = not in results' || CHR(10);
          ELSE
            answer := answer || alias || ' = ' || FormatNumber(val) || CHR(10);
          END IF;
        END;
      END LOOP;

      has_answer := (DBMS_LOB.getlength(answer) > 0);
    END IF;

    -- Compose final sections
    IF has_answer THEN out := out || answer; END IF;

    -- Overview
    out := out || c_h_overview || CHR(10);
    IF meta.has('is_complete') AND NOT meta.get_boolean('is_complete') THEN
      out := out || 'This is a partial result set; interpretations apply only to the visible rows.' || CHR(10);
    ELSE
      IF answer_first AND single_entity THEN
        out := out || 'Scoped to one entity within the requested time window; figures reflect only the visible rows.' || CHR(10);
      ELSE
        out := out || 'These rows reflect the visible subset relevant to the request.' || CHR(10);
      END IF;
    END IF;

    -- Details
    out := out || c_h_details || CHR(10) || '- See table for notable records and ranges.' || CHR(10);

    -- Aggregates (in these results)
    out := out || c_h_aggs || CHR(10) ||
           '- Count of rows: '|| rows.get_size || CHR(10);

    -- Observations
    out := out || c_h_insights || CHR(10) ||
           'Patterns or outliers here apply only to the visible rows; broader conclusions require aggregates over the full dataset.';

    CHATBOT_CORE_IO_PKG.logc(
      p_ctx, c_phase, p_req_id,
      'Render:ok', NULL, p_log_id, p_chat_id
    );

    RETURN clamp_words(out, c_max_words);
  EXCEPTION
    WHEN OTHERS THEN
      -- error path with payload for troubleshooting
      CHATBOT_CORE_IO_PKG.log_any(
        p_ctx, c_phase, 'ERROR', p_req_id, p_log_id, p_chat_id,
        'Render:error '||SQLERRM, p_rows_json
      );
      RETURN c_h_overview||CHR(10)||
             'Summary unavailable due to an internal error.'||CHR(10)||
             c_h_details||CHR(10)||
             '- See table for full row set.'||CHR(10)||
             c_h_aggs||CHR(10)||
             '- —'||CHR(10)||
             c_h_insights||CHR(10)||
             '—';
  END Render;

  ----------------------------------------------------------------------
  -- PUBLIC: Render_Redacted  (tokenize → render → optional detokenize)
  ----------------------------------------------------------------------
  FUNCTION Render_Redacted(
    p_context_query      IN CLOB,
    p_plan_json          IN CLOB,
    p_rows_json          IN CLOB,
    p_meta_json          IN CLOB,
    p_ctx                IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id             IN VARCHAR2,
    p_log_id             IN NUMBER,
    p_chat_id            IN NUMBER,
    p_redaction_enabled  IN BOOLEAN DEFAULT FALSE,
    p_detokenize_output  IN BOOLEAN DEFAULT TRUE
  ) RETURN CLOB IS
    plan_tok   CLOB;
    rows_tok   CLOB;
    cq_tok     CLOB;
    token_map  CLOB;
    summary_md CLOB;
  BEGIN
    IF NOT p_redaction_enabled THEN
      RETURN Render(
        p_context_query => p_context_query,
        p_plan_json     => p_plan_json,
        p_rows_json     => p_rows_json,
        p_meta_json     => p_meta_json,
        p_ctx           => p_ctx,
        p_req_id        => p_req_id,
        p_log_id        => p_log_id,
        p_chat_id       => p_chat_id
      );
    END IF;

    Tokenize_For_Summary(
      p_plan_json      => p_plan_json,
      p_rows_json      => p_rows_json,
      p_context_query  => p_context_query,
      p_ctx            => p_ctx,
      p_req_id         => p_req_id,
      p_log_id         => p_log_id,
      p_chat_id        => p_chat_id,
      o_plan_tokenized => plan_tok,
      o_rows_tokenized => rows_tok,
      o_cq_tokenized   => cq_tok,
      o_token_map      => token_map
    );

    summary_md := Render(
      p_context_query => cq_tok,
      p_plan_json     => plan_tok,
      p_rows_json     => rows_tok,
      p_meta_json     => p_meta_json,
      p_ctx           => p_ctx,
      p_req_id        => p_req_id,
      p_log_id        => p_log_id,
      p_chat_id       => p_chat_id
    );

    IF p_detokenize_output THEN
      summary_md := Detokenize_Summary(summary_md, token_map);
    END IF;

    RETURN summary_md;
  EXCEPTION
    WHEN OTHERS THEN
      CHATBOT_CORE_IO_PKG.log_any(
        p_ctx, c_phase, 'ERROR', p_req_id, p_log_id, p_chat_id,
        'Render_Redacted:error '||SQLERRM, NULL
      );
      RETURN c_h_overview||CHR(10)||
             'Summary unavailable due to an internal error.'||CHR(10)||
             c_h_details||CHR(10)||
             '- See table for full row set.'||CHR(10)||
             c_h_aggs||CHR(10)||
             '- —'||CHR(10)||
             c_h_insights||CHR(10)||
             '—';
  END Render_Redacted;

END CHATBOT_CORE_SUMMARY_PKG;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_ENV_PKG" authid definer as
  subtype t_env is varchar2(4);
  c_env_test constant t_env := 'TEST';
  c_env_prod constant t_env := 'PROD';

  -- Set once per request (APEX Initialization PL/SQL Code)
  procedure set_env(p_env in varchar2);

  -- Read current env (defaults to PROD if unset)
  function get_env return t_env;

  -- Map a logical name → fully-qualified physical table for current env
  function tbl(p in varchar2) return varchar2;
end CHATBOT_ENV_PKG;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_ENV_PKG" as
  procedure set_env(p_env in varchar2) is
    l_env t_env := case upper(nvl(p_env, c_env_prod))
                     when c_env_test then c_env_test
                     else c_env_prod
                   end;
  begin
    dbms_session.set_context('CHATBOT_ENV','ENV', l_env);
  end;

  function get_env return t_env is
    l_env t_env := sys_context('CHATBOT_ENV','ENV');
  begin
    return case upper(nvl(l_env, c_env_prod))
             when c_env_test then c_env_test
             else c_env_prod
           end;
  end;

  function tbl(p in varchar2) return varchar2 is
    l_env t_env := get_env;
  begin
    case upper(p)
      when 'CHATBOT_NL2SQL_LOG' then
        return case when l_env = c_env_test
               then 'TEST_CHATBOT_NL2SQL_LOG'
               else 'CHATBOT_NL2SQL_LOG' end;

      when 'CHATBOT_NL2SQL_CONVERSATION' then
        return case when l_env = c_env_test
               then 'TEST_CHATBOT_NL2SQL_CONVERSATION'
               else 'CHATBOT_NL2SQL_CONVERSATION' end;

      when 'CHATBOT_JOB_DEBUG' then
        return case when get_env() = c_env_test
                then 'TEST_CHATBOT_JOB_DEBUG'
                else 'CHATBOT_JOB_DEBUG' end;

      when 'CHATBOT_NL2SQL_SUMMARY' then
        return case when get_env() = c_env_test
                then 'TEST_CHATBOT_NL2SQL_SUMMARY'
                else 'CHATBOT_NL2SQL_SUMMARY' end;

      when 'TEST_CHATBOT_PARAMETERS' then
        return case when get_env() = c_env_test
                then 'TEST_CHATBOT_PARAMETERS'
                else 'TEST_CHATBOT_PARAMETERS' end;

      when 'AI_MODEL_CONFIG' then
        return case when get_env() = c_env_test
                then 'AI_MODEL_CONFIG'
                else 'AI_MODEL_CONFIG' end;

      -- Add more logical names here if needed, same pattern ↑

      else
        raise_application_error(-20001, 'Unknown logical table: '||p);
    end case;
  end;
end CHATBOT_ENV_PKG;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_FOLLOWUP_PKG" AS
  /*----------------------------------------------------------------------------*
   * PACKAGE: CHATBOT_FOLLOWUP_PKG
   *
   * PURPOSE
   *   Owns the FOLLOWUP_CLARIFY flow end-to-end:
   *     - Classify follow-up intent: answer_directly | modify_previous_sql | new_query | ask_clarifying
   *     - Handle direct/clarifying text responses immediately (no SQL)
   *     - Orchestrate SQL work asynchronously via child NL2SQL rows/jobs
   *     - Build stitched NL2SQL prompts for SQL rewrites (prev SQL + follow-up)
   *
   * LOGGING
   *   - All logging MUST go through CHATBOT_CORE_IO_PKG.logc / logv.
   *     This package NEVER writes logs directly.
   *
   * DEPENDENCIES
   *   - CHATBOT_CORE_CTX_PARAMS_PKG (load model/system components)
   *   - CHATBOT_CORE_IO_PKG        (LLM calls, logc/logv, generic I/O)
   *   - CHATBOT_CORE_SQL_PKG       (history/context helpers, table extraction)
   *   - CHATBOT_NL2SQL_LOG         (parent/child rows, statuses)
   *
   * EXECUTION MODES (stored on CHILD NL2SQL rows)
   *   - 'INITIAL'           : Fresh user query (non-followup)
   *   - 'FOLLOWUP_REWRITE'  : Child created to modify previous SQL
   *   - 'FOLLOWUP_NEW'      : Child created for a new query
   *
   * PARENT (FOLLOWUP) STATUS LIFECYCLE
   *   QUEUED → RUNNING → (SUCCEEDED | ESCALATED_TO_NL2SQL | FAILED)
   *     - SUCCEEDED          : Only for answer_directly / ask_clarifying (no child)
   *     - ESCALATED_TO_NL2SQL: Child row & job created (modify_previous_sql / new_query)
   *----------------------------------------------------------------------------*/

  -- Parent statuses
  c_status_queued              CONSTANT VARCHAR2(30) := 'QUEUED';
  c_status_running             CONSTANT VARCHAR2(30) := 'RUNNING';
  c_status_succeeded           CONSTANT VARCHAR2(30) := 'SUCCEEDED';
  c_status_escalated_to_nl2sql CONSTANT VARCHAR2(30) := 'ESCALATED_TO_NL2SQL';
  c_status_failed              CONSTANT VARCHAR2(30) := 'FAILED';

  -- Child execution modes
  c_mode_initial          CONSTANT VARCHAR2(30) := 'INITIAL';
  c_mode_followup_rewrite CONSTANT VARCHAR2(30) := 'FOLLOWUP_REWRITE';
  c_mode_followup_new     CONSTANT VARCHAR2(30) := 'FOLLOWUP_NEW';

  -- Follow-up intent labels (DECIDER output)
  c_intent_answer_directly     CONSTANT VARCHAR2(40) := 'answer_directly';
  c_intent_modify_previous_sql CONSTANT VARCHAR2(40) := 'modify_previous_sql';
  c_intent_new_query           CONSTANT VARCHAR2(40) := 'new_query';
  c_intent_ask_clarifying      CONSTANT VARCHAR2(40) := 'ask_clarifying';

  TYPE followup_decision_t IS RECORD (
    intent           VARCHAR2(40),
    confidence       NUMBER,
    reason           VARCHAR2(4000),
    answer_text      CLOB,
    clarify_question CLOB,
    transform_json   CLOB
  );

  PROCEDURE run_followup(
    p_log_id         IN NUMBER,
    p_model_id       IN VARCHAR2,
    p_chat_id        IN NUMBER,
    p_app_user       IN VARCHAR2,
    p_app_session    IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_dataset        IN VARCHAR2 DEFAULT NULL,
    p_environment    IN VARCHAR2 DEFAULT NULL
  );

  -- Map FOLLOWUP decider JSON into a stable intent label for persistence.
  -- Returns: FOLLOWUP_REWRITE | FOLLOWUP_ANSWER | FOLLOWUP_CLARIFY
  function normalize_followup_label(
    p_decision_json in clob,
    p_prev_sql      in clob,
    p_user_text     in clob
  ) return varchar2;

  FUNCTION classify_followup_decision(
    p_ctx            IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_prev_user      IN CLOB,
    p_prev_summary   IN CLOB,
    p_prev_sql       IN CLOB,
    p_history_block  IN CLOB,
    p_user_text      IN CLOB,
    p_api_format     IN VARCHAR2,
    p_model_id       IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_endpoint       IN VARCHAR2,
    p_req_id         IN VARCHAR2,
    p_log_id         IN NUMBER,
    p_chat_id        IN NUMBER
  ) RETURN followup_decision_t;

  FUNCTION build_nl2sql_rewrite_prompt(
    p_ctx           IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_prev_sql      IN CLOB,
    p_followup_text IN CLOB,
    p_prev_user     IN CLOB,
    p_prev_summary  IN CLOB
  ) RETURN CLOB;

  PROCEDURE escalate_to_nl2sql_rewrite(
    p_parent_log_id  IN NUMBER,
    p_prev_sql       IN CLOB,
    p_followup_text_eff   IN CLOB,  -- normalized / effective
    p_followup_text_ui    IN CLOB,  -- original, for UI
    p_prev_user      IN CLOB,
    p_prev_summary   IN CLOB,
    p_model_id       IN VARCHAR2,
    p_chat_id        IN NUMBER,
    p_app_user       IN VARCHAR2,
    p_app_session    IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_dataset        IN VARCHAR2,
    p_environment    IN VARCHAR2,
    p_ctx            IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t
  );

  PROCEDURE escalate_to_nl2sql_fresh(
    p_parent_log_id  IN NUMBER,
    p_user_text      IN CLOB,
    p_model_id       IN VARCHAR2,
    p_chat_id        IN NUMBER,
    p_app_user       IN VARCHAR2,
    p_app_session    IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_dataset        IN VARCHAR2,
    p_environment    IN VARCHAR2,
    p_user_prompt_override IN CLOB DEFAULT NULL
  );

  -- Status & summary helpers (logging-wrapper signatures)
  PROCEDURE mark_status(
    p_ctx     IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id  IN VARCHAR2,
    p_log_id  IN NUMBER,
    p_chat_id IN NUMBER,
    p_status  IN VARCHAR2,
    p_errmsg  IN VARCHAR2 DEFAULT NULL,
    p_start   IN BOOLEAN  DEFAULT FALSE,
    p_finish  IN BOOLEAN  DEFAULT FALSE
  );

  PROCEDURE write_summary(
    p_ctx         IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id      IN VARCHAR2,
    p_log_id      IN NUMBER,
    p_chat_id     IN NUMBER,
    p_summary_txt IN CLOB
  );

END CHATBOT_FOLLOWUP_PKG;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_FOLLOWUP_PKG" AS

  -- Lightweight wrappers for logging
  PROCEDURE log_info(
    p_ctx     IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id  IN VARCHAR2,
    p_log_id  IN NUMBER,
    p_chat_id IN NUMBER,
    p_msg     IN VARCHAR2
  ) IS
  BEGIN
    CHATBOT_CORE_IO_PKG.logv(p_ctx, 'FOLLOWUP/INFO', p_req_id, p_msg, p_log_id, p_chat_id);
  EXCEPTION WHEN OTHERS THEN NULL; END;

  PROCEDURE log_clob(
    p_ctx     IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id  IN VARCHAR2,
    p_log_id  IN NUMBER,
    p_chat_id IN NUMBER,
    p_phase   IN VARCHAR2,
    p_label   IN VARCHAR2,
    p_c       IN CLOB
  ) IS
  BEGIN
    CHATBOT_CORE_IO_PKG.logc(p_ctx, p_phase, p_req_id, p_label, p_c, p_log_id, p_chat_id);
  EXCEPTION WHEN OTHERS THEN NULL; END;

  ------------------------------------------------------------------------------
  -- PUBLIC (autonomous) helpers used by internal wrappers
  ------------------------------------------------------------------------------
  PROCEDURE mark_status(
    p_log_id  IN NUMBER,
    p_status  IN VARCHAR2,
    p_errmsg  IN VARCHAR2 DEFAULT NULL,
    p_start   IN BOOLEAN  DEFAULT FALSE,
    p_finish  IN BOOLEAN  DEFAULT FALSE
  ) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    IF p_start THEN
      UPDATE CHATBOT_NL2SQL_LOG
         SET status = p_status, started_at = SYSTIMESTAMP
       WHERE id = p_log_id;
    ELSIF p_finish THEN
      UPDATE CHATBOT_NL2SQL_LOG
         SET status = p_status,
             finished_at = SYSTIMESTAMP,
             error_message = p_errmsg
       WHERE id = p_log_id;
    ELSE
      UPDATE CHATBOT_NL2SQL_LOG
         SET status = p_status
       WHERE id = p_log_id;
    END IF;
    COMMIT;
  EXCEPTION WHEN OTHERS THEN ROLLBACK; END;

  PROCEDURE write_summary(
    p_log_id      IN NUMBER,
    p_summary_txt IN CLOB
  ) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    UPDATE CHATBOT_NL2SQL_LOG
       SET summary_text = p_summary_txt
     WHERE id = p_log_id;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
  END;

  ------------------------------------------------------------------------------
  -- INTERNAL wrappers (log + delegate to PUBLIC helpers)
  ------------------------------------------------------------------------------
  PROCEDURE mark_status(
    p_ctx     IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id  IN VARCHAR2,
    p_log_id  IN NUMBER,
    p_chat_id IN NUMBER,
    p_status  IN VARCHAR2,
    p_errmsg  IN VARCHAR2 DEFAULT NULL,
    p_start   IN BOOLEAN  DEFAULT FALSE,
    p_finish  IN BOOLEAN  DEFAULT FALSE
  ) IS
  BEGIN
    log_info(p_ctx, p_req_id, p_log_id, p_chat_id,
             'STATUS='||p_status||CASE WHEN p_errmsg IS NOT NULL THEN ' ERR='||SUBSTR(p_errmsg,1,400) END);
    CHATBOT_FOLLOWUP_PKG.mark_status(p_log_id, p_status, p_errmsg, p_start, p_finish);
  END;

  PROCEDURE write_summary(
    p_ctx         IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_req_id      IN VARCHAR2,
    p_log_id      IN NUMBER,
    p_chat_id     IN NUMBER,
    p_summary_txt IN CLOB
  ) IS
  BEGIN
    log_info(p_ctx, p_req_id, p_log_id, p_chat_id, 'WRITE_SUMMARY len='||NVL(DBMS_LOB.GETLENGTH(p_summary_txt),0));
    CHATBOT_FOLLOWUP_PKG.write_summary(p_log_id, p_summary_txt);
  END;

  FUNCTION normalize_followup_label(
    p_decision_json IN CLOB,
    p_prev_sql      IN CLOB,
    p_user_text     IN CLOB
  ) RETURN VARCHAR2
  IS
    j   JSON_OBJECT_T;
    act VARCHAR2(64) := 'ask_clarifying';
  BEGIN
    BEGIN
      j := JSON_OBJECT_T.PARSE(NVL(REGEXP_SUBSTR(NVL(p_decision_json,''), '\{.*\}', 1, 1, 'n'), '{}'));
      act := LOWER(NVL(j.get_string('intent'),'ask_clarifying'));
    EXCEPTION WHEN OTHERS THEN NULL; END;

    IF act = 'answer_directly' THEN
      RETURN 'FOLLOWUP_ANSWER';
    ELSIF act = 'modify_previous_sql' THEN
      RETURN 'FOLLOWUP_REWRITE';
    ELSIF act = 'new_query' THEN
      RETURN 'FOLLOWUP_NEW';
    ELSE
      RETURN 'FOLLOWUP_CLARIFY';
    END IF;
  EXCEPTION WHEN OTHERS THEN
    RETURN 'FOLLOWUP_CLARIFY';
  END;

  ------------------------------------------------------------------------------
  -- DECIDER (baseline stub; persists JSON to reasoned_message)
  ------------------------------------------------------------------------------
  FUNCTION classify_followup_decision(
    p_ctx            IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_prev_user      IN CLOB,
    p_prev_summary   IN CLOB,
    p_prev_sql       IN CLOB,
    p_history_block  IN CLOB,
    p_user_text      IN CLOB,
    p_api_format     IN VARCHAR2,
    p_model_id       IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_endpoint       IN VARCHAR2,
    p_req_id         IN VARCHAR2,
    p_log_id         IN NUMBER,
    p_chat_id        IN NUMBER
  ) RETURN followup_decision_t
  IS
    l_dec         followup_decision_t;
    l_prompt      CLOB;
    l_payload     CLOB;
    l_resp        CLOB;
    l_text        CLOB;
    l_json        CLOB;
    l_conf        NUMBER := 0;
    l_rules       CLOB;
    PROCEDURE persist(a CLOB) IS
    BEGIN
      BEGIN
        UPDATE CHATBOT_NL2SQL_LOG
          SET reasoned_message = NVL(reasoned_message,'')||CHR(10)||
                                  '[FOLLOWUP_DECIDER]'||CHR(10)||
                                  NVL(a,'{}')
        WHERE id = p_log_id;
        COMMIT;
      EXCEPTION WHEN OTHERS THEN NULL; END;
    END;
  BEGIN
    -- Build a minimal, data-agnostic, schema-bound instruction
    BEGIN
      l_prompt := CHATBOT_CORE_CTX_PARAMS_PKG.load_component(p_ctx,'FOLLOWUP_DECIDER_SYSTEM');

      IF l_prompt IS NULL THEN
        l_prompt := 'You are a FOLLOW-UP DECIDER (fallback)...';
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        l_prompt :=
          'You are a FOLLOW-UP DECIDER (fallback).'||CHR(10)||
          'Decide whether to answer directly, rewrite SQL, or ask for clarification.'||CHR(10)||
          'Return JSON only.';
    END;

    l_prompt := l_prompt || CHR(10) ||
      'You must decide if the latest user message is:'||CHR(10)||
      ' - "answer_directly": answer now in natural language.'||CHR(10)||
      ' - "modify_previous_sql": refine/adjust the immediately previous result (carry over the same intent, tweak filters/time/columns/limits/etc.).'||CHR(10)||
      ' - "new_query": start a brand-new request unrelated to the last result.'||CHR(10)||
      ''||CHR(10)||
      'Return strict JSON with fields:'||CHR(10)||
      '  {'||CHR(10)||
      '    "intent": "answer_directly" | "modify_previous_sql" | "new_query" | "ask_clarifying",'||CHR(10)||
      '    "confidence": <0..1>,'||CHR(10)||
      '    "refers_previous": true | false,'||CHR(10)||
      '    "answer_text": null | "<plain text>",'||CHR(10)||
      '    "clarify_question": null | "<plain text>",'||CHR(10)||
      '    "evidence_ok": true | false'||CHR(10)||
      '  }'||CHR(10)||
      ''||CHR(10)||
      'Rules (STRICT):'||CHR(10)||
      ' - PRIOR SUMMARY is narrative-only and UNSAFE for factual lookups; NEVER extract facts or ID→name mappings from it.'||CHR(10)||
      ' - Choose "answer_directly" ONLY when the full answer string appears verbatim in the immediately previous tabular result or in the RECENT HISTORY block. If unsure, do not answer directly.'||CHR(10)||
      ' - If the follow-up requests a data lookup/mapping (e.g., ID→name, code→description) and the value is not verbatim in those sources, choose "modify_previous_sql" (if previous SQL exists) or "new_query".'||CHR(10)||
      ' - If the follow-up implies the same query but tweaks timeframe/filters/scope, use "modify_previous_sql" and set refers_previous=true.'||CHR(10)||
      ' - If unrelated, use "new_query" and refers_previous=false.'||CHR(10)||
      ''||CHR(10)||
      'Context below.'||CHR(10)||
      '-- PRIOR USER QUESTION --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.one_line(p_prev_user),'')||CHR(10)||
      '-- PRIOR SUMMARY (UNSAFE FOR LOOKUPS) --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.clamp_clob(p_prev_summary,2000),'')||CHR(10)||
      '-- PRIOR SQL --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.clamp_clob(p_prev_sql,1200),'')||CHR(10)||
      '-- RECENT HISTORY (compact) --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.clamp_clob(p_history_block,1500),'')||CHR(10)||
      '-- LATEST FOLLOW-UP --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.one_line(p_user_text),'')||CHR(10)||
      '-- JSON ONLY BELOW THIS LINE --';

    -- Deterministic: temp≈0, top_p=1, top_k=1
    l_payload := CHATBOT_CORE_IO_PKG.build_payload_chat(
                  p_api_format, p_model_id, p_compartment_id,
                  l_prompt, 0, 1, 1);

    CHATBOT_CORE_IO_PKG.logc(p_ctx, 'FOLLOWUP_DECIDER', p_req_id, 'Payload', l_payload, p_log_id, p_chat_id);

    l_resp := CHATBOT_CORE_IO_PKG.call_model(
                p_ctx, 'FOLLOWUP_DECIDER', p_endpoint, l_payload, p_req_id, p_log_id, p_chat_id);

    l_text := CHATBOT_CORE_IO_PKG.extract_text_from_chat_response(l_resp);

    -- Extract the single JSON object robustly
    BEGIN
      l_json := REGEXP_SUBSTR(l_text, '\{.*\}', 1, 1, 'n');
    EXCEPTION WHEN OTHERS THEN
      l_json := NULL;
    END;

    IF l_json IS NULL THEN
      -- Fallback: ask to clarify
      l_dec.intent           := c_intent_ask_clarifying;
      l_dec.confidence       := 0.5;
      l_dec.reason           := 'No JSON returned from decider.';
      l_dec.clarify_question := 'Do you want me to adjust the previous SQL, start a new query, or answer in plain English?';
      l_dec.transform_json   := '{"intent":"ask_clarifying","confidence":0.5}';
      persist(l_dec.transform_json);
      RETURN l_dec;
    END IF;

    -- Map fields
    l_dec.intent           := LOWER(JSON_VALUE(l_json, '$.intent' RETURNING VARCHAR2(40)));
    l_conf                 := NVL(JSON_VALUE(l_json, '$.confidence' RETURNING NUMBER), 0);
    l_dec.confidence       := l_conf;
    l_dec.answer_text      := JSON_VALUE(l_json, '$.answer_text' RETURNING CLOB);
    l_dec.clarify_question := JSON_VALUE(l_json, '$.clarify_question' RETURNING CLOB);
    l_dec.reason           := 'LLM-decided.';
    l_dec.transform_json   := l_json;

    -- Read evidence_ok (default false)
    DECLARE
      l_ev_flag  VARCHAR2(5);
      l_ev_ok    BOOLEAN := FALSE;
    BEGIN
      l_ev_flag := LOWER(NVL(JSON_VALUE(l_json, '$.evidence_ok' RETURNING VARCHAR2(5)),'false'));
      l_ev_ok   := (l_ev_flag = 'true');

      -- If model tried to answer directly without evidence, downgrade to a SQL path.
      IF l_dec.intent = 'answer_directly' AND NOT l_ev_ok THEN
        IF p_prev_sql IS NOT NULL THEN
          l_dec.intent := c_intent_modify_previous_sql;
        ELSE
          l_dec.intent := c_intent_new_query;
        END IF;
        l_dec.answer_text := NULL; -- force downstream to execute the proper path
      END IF;
    END;

    DECLARE
      l_refers_prev VARCHAR2(5) := LOWER(NVL(JSON_VALUE(l_json, '$.refers_previous' RETURNING VARCHAR2(5)),'false'));
    BEGIN
      -- If model said new_query but it admits it refers to the previous, force modify_previous_sql
      IF l_dec.intent = c_intent_new_query AND l_refers_prev = 'true' THEN
        l_dec.intent := c_intent_modify_previous_sql;
      END IF;
    END;

    -- Safety rails:
    -- If model chose modify_previous_sql but we have no prior SQL, force new_query.
    IF l_dec.intent = c_intent_modify_previous_sql AND p_prev_sql IS NULL THEN
      l_dec.intent := c_intent_new_query;
    END IF;

    -- If confidence too low, ask to clarify (prevents errant escalations)
    IF l_conf < 0.60 THEN
      l_dec.intent := c_intent_ask_clarifying;
    END IF;

    persist(l_dec.transform_json);
    CHATBOT_CORE_IO_PKG.logv(p_ctx, 'FOLLOWUP_DECIDER', p_req_id,
      'Intent='||NVL(l_dec.intent,'?')||' conf='||TO_CHAR(l_dec.confidence,'FM990D99'), p_log_id, p_chat_id);

    RETURN l_dec;
  END;

  ------------------------------------------------------------------------------
  -- Build stitched prompt for FOLLOWUP_REWRITE children
  ------------------------------------------------------------------------------
  FUNCTION build_nl2sql_rewrite_prompt(
    p_ctx           IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_prev_sql      IN CLOB,
    p_followup_text IN CLOB,
    p_prev_user     IN CLOB,
    p_prev_summary  IN CLOB
  ) RETURN CLOB
  IS
  BEGIN
    RETURN
      'Apply this follow-up to the previous SQL.'||CHR(10)||
      '--- FOLLOW-UP ---'||CHR(10)||
      NVL(CHATBOT_CORE_IO_PKG.one_line(p_followup_text),'(missing)')||CHR(10)||
      '--- PREVIOUS SQL ---'||CHR(10)||
      NVL(p_prev_sql,'(missing)')||CHR(10)||
      '--- RULES ---'||CHR(10)||
      '- Use ONLY columns that exist in the referenced tables.'||CHR(10)||
      '- If the follow-up mentions a field with no matching column, OMIT it; do not invent or rename.'||CHR(10)||
      '- Preserve existing filters/joins/windows unless explicitly changed.'||CHR(10)||
      '--- OUTPUT ---'||CHR(10)||
      'Return exactly one Oracle SQL SELECT and nothing else. No markdown, no code fences, no prose.';
  END;

  FUNCTION build_nl2sql_rewrite_from_prev_question(
    p_prev_user     IN CLOB,
    p_prev_summary  IN CLOB,
    p_followup_text IN CLOB
  ) RETURN CLOB
  IS
  BEGIN
    RETURN
      'Rewrite the original request with this follow-up change.'||CHR(10)||
      '--- FOLLOW-UP ---'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.one_line(p_followup_text),'(missing)')||CHR(10)||
      '--- PREVIOUS ANSWER (summary) ---'||CHR(10)||
      NVL(CHATBOT_CORE_IO_PKG.clamp_clob(p_prev_summary, 1000),'(none)')||CHR(10)||
      '--- ORIGINAL REQUEST ---'||CHR(10)||
      NVL(CHATBOT_CORE_IO_PKG.one_line(p_prev_user),'(missing)')||CHR(10)||
      '--- OUTPUT ---'||CHR(10)||
      'Return exactly one Oracle SQL SELECT and nothing else. No markdown, no code fences, no prose.';
  END;

  /* Resolve pronouns / implicit refs against previous result JSON and history.
    Returns strict JSON:
    {
      "normalized_question": "<string>|null",
      "refers_previous": true|false,
      "disambiguation_needed": true|false,
      "ask": "<clarify question>|null"
    }
  */
  /*FUNCTION interpret_followup(
    p_ctx            IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_prev_user      IN CLOB,
    p_prev_summary   IN CLOB,
    p_prev_sql       IN CLOB,
    p_prev_rows_json IN CLOB,         -- full/preview JSON; may be NULL
    p_user_text      IN CLOB,
    p_api_format     IN VARCHAR2,
    p_model_id       IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_endpoint       IN VARCHAR2,
    p_req_id         IN VARCHAR2,
    p_log_id         IN NUMBER,
    p_chat_id        IN NUMBER
  ) RETURN CLOB
  IS
    l_prompt  CLOB;
    l_payload CLOB;
    l_resp    CLOB;
    l_text    CLOB;
    l_json    CLOB;
    l_rows    CLOB := NVL(p_prev_rows_json,'{}');
  BEGIN
    -- Clamp rows JSON to keep the call small
    l_rows := CHATBOT_CORE_IO_PKG.clamp_clob(l_rows, 24000);

    l_prompt :=
      'You are interpreting a short user follow-up in a data-agnostic way.'||CHR(10)||
      'Goal: normalize the follow-up by resolving pronouns/ellipses ONLY from the given previous context.'||CHR(10)||
      'NEVER invent facts that are not present in the inputs.'||CHR(10)||
      'Return STRICT JSON with keys: normalized_question, refers_previous (bool), disambiguation_needed (bool), ask (string|null).'||CHR(10)||
      CHR(10)||
      '-- PREVIOUS USER QUESTION --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.one_line(p_prev_user),'')||CHR(10)||
      '-- PREVIOUS SUMMARY (narrative; not authoritative for lookups) --'||CHR(10)||
      NVL(CHATBOT_CORE_IO_PKG.clamp_clob(p_prev_summary,1500),'')||CHR(10)||
      '-- PREVIOUS SQL --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.clamp_clob(p_prev_sql,1200),'')||CHR(10)||
      '-- PREVIOUS RESULT ROWS (JSON; authoritative) --'||CHR(10)||l_rows||CHR(10)||
      '-- FOLLOW-UP --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.one_line(p_user_text),'')||CHR(10)||
      CHR(10)||
      'Rules:'||CHR(10)||
      ' - Use previous RESULT ROWS as the primary evidence.'||CHR(10)||
      ' - If the follow-up clearly refers to an entity in those rows (e.g., by position or recent mention), set refers_previous=true and rewrite the question with explicit mention.'||CHR(10)||
      ' - If multiple candidates match and you cannot pick one, set disambiguation_needed=true and populate "ask" with a targeted question.'||CHR(10)||
      ' - If there is no reference to the previous result, set refers_previous=false.'||CHR(10)||
      '-- JSON ONLY BELOW THIS LINE --';

    l_payload := CHATBOT_CORE_IO_PKG.build_payload_chat(
                  p_api_format, p_model_id, p_compartment_id,
                  l_prompt, 0, 1, 1);  -- deterministic

    CHATBOT_CORE_IO_PKG.logc(p_ctx, 'FUP_INTERPRET', p_req_id, 'Payload', l_payload, p_log_id, p_chat_id);

    l_resp := CHATBOT_CORE_IO_PKG.call_model(
                p_ctx, 'FUP_INTERPRET', p_endpoint, l_payload, p_req_id, p_log_id, p_chat_id);

    l_text := CHATBOT_CORE_IO_PKG.extract_text_from_chat_response(l_resp);

    BEGIN
      l_json := REGEXP_SUBSTR(l_text, '\{.*\}', 1, 1, 'n');
    EXCEPTION WHEN OTHERS THEN
      l_json := NULL;
    END;

    IF l_json IS NULL THEN
      l_json := '{"normalized_question":null,"refers_previous":false,"disambiguation_needed":false,"ask":null}';
    END IF;

    -- Persist for trace
    BEGIN
      UPDATE CHATBOT_NL2SQL_LOG
        SET reasoned_message = NVL(reasoned_message,'')||CHR(10)||
                                '[FUP_INTERPRET]'||CHR(10)||l_json
      WHERE id = p_log_id;
      COMMIT;
    EXCEPTION WHEN OTHERS THEN NULL; END;

    RETURN l_json;
  END;*/
  FUNCTION interpret_followup(
    p_ctx            IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t,
    p_prev_user      IN CLOB,
    p_prev_summary   IN CLOB,
    p_prev_sql       IN CLOB,
    p_prev_rows_json IN CLOB,         -- full/preview JSON; may be NULL
    p_user_text      IN CLOB,
    p_api_format     IN VARCHAR2,
    p_model_id       IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_endpoint       IN VARCHAR2,
    p_req_id         IN VARCHAR2,
    p_log_id         IN NUMBER,
    p_chat_id        IN NUMBER
  ) RETURN CLOB
  IS
    l_prompt      CLOB;
    l_payload     CLOB;
    l_resp        CLOB;
    l_text        CLOB;
    l_json        CLOB;

    l_rows_raw    CLOB := NVL(p_prev_rows_json,'{}');
    l_ctx_raw     CLOB;
    l_ctx_token   CLOB;
    l_dummy_plan  CLOB;
    l_dummy_rows  CLOB;
    l_token_map   CLOB;
  BEGIN
    -- Clamp rows JSON to keep the call small
    l_rows_raw := CHATBOT_CORE_IO_PKG.clamp_clob(l_rows_raw, 24000);

    -- Build the full CONTEXT block that we will tokenize
    l_ctx_raw :=
      '-- PREVIOUS USER QUESTION --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.one_line(p_prev_user),'')||CHR(10)||
      '-- PREVIOUS SUMMARY (narrative; not authoritative for lookups) --'||CHR(10)||
      NVL(CHATBOT_CORE_IO_PKG.clamp_clob(p_prev_summary,1500),'')||CHR(10)||
      '-- PREVIOUS SQL --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.clamp_clob(p_prev_sql,1200),'')||CHR(10)||
      '-- PREVIOUS RESULT ROWS (JSON; authoritative) --'||CHR(10)||l_rows_raw||CHR(10)||
      '-- FOLLOW-UP --'||CHR(10)||NVL(CHATBOT_CORE_IO_PKG.one_line(p_user_text),'')||CHR(10);

    -- Tokenize rows + context using the existing SUMMARY redaction logic
    BEGIN
      CHATBOT_CORE_SUMMARY_PKG.Tokenize_For_Summary(
        p_plan_json      => NULL,
        p_rows_json      => l_rows_raw,
        p_context_query  => l_ctx_raw,
        p_ctx            => p_ctx,
        p_req_id         => p_req_id,
        p_log_id         => p_log_id,
        p_chat_id        => p_chat_id,
        o_plan_tokenized => l_dummy_plan,
        o_rows_tokenized => l_dummy_rows,
        o_cq_tokenized   => l_ctx_token,
        o_token_map      => l_token_map
      );
    EXCEPTION
      WHEN OTHERS THEN
        -- Fail-safe: if tokenization fails, fall back to raw context
        l_ctx_token := l_ctx_raw;
        l_token_map := NULL;
    END;

    -- Build the final prompt using the TOKENIZED context
    l_prompt :=
      'You are interpreting a short user follow-up in a data-agnostic way.'||CHR(10)||
      'Goal: normalize the follow-up by resolving pronouns/ellipses ONLY from the given previous context.'||CHR(10)||
      'NEVER invent facts that are not present in the inputs.'||CHR(10)||
      'Return STRICT JSON with keys: normalized_question, refers_previous (bool), disambiguation_needed (bool), ask (string|null).'||CHR(10)||
      CHR(10)||
      'NOTE: Sensitive values from the previous result may appear as opaque tokens like «STR:...». '||
      'Do NOT try to decode or guess them; treat them as abstract identifiers.'||CHR(10)||
      CHR(10)||
      l_ctx_token||CHR(10)||
      'Rules:'||CHR(10)||
      ' - Use previous RESULT ROWS as the primary evidence.'||CHR(10)||
      ' - If the follow-up clearly refers to an entity in those rows (e.g., by position or recent mention), set refers_previous=true and rewrite the question with explicit mention.'||CHR(10)||
      ' - If multiple candidates match and you cannot pick one, set disambiguation_needed=true and populate "ask" with a targeted question.'||CHR(10)||
      ' - If there is no reference to the previous result, set refers_previous=false.'||CHR(10)||
      ' - When writing "ask", refer to entities descriptively (e.g., "this customer") and avoid showing token strings like «STR:...». '||CHR(10)||
      '-- JSON ONLY BELOW THIS LINE --';

    -- Deterministic call as before
    l_payload := CHATBOT_CORE_IO_PKG.build_payload_chat(
                  p_api_format, p_model_id, p_compartment_id,
                  l_prompt, 0, 1, 1);  -- deterministic

    CHATBOT_CORE_IO_PKG.logc(p_ctx, 'FUP_INTERPRET', p_req_id, 'Payload', l_payload, p_log_id, p_chat_id);

    l_resp := CHATBOT_CORE_IO_PKG.call_model(
                p_ctx, 'FUP_INTERPRET', p_endpoint, l_payload, p_req_id, p_log_id, p_chat_id);

    l_text := CHATBOT_CORE_IO_PKG.extract_text_from_chat_response(l_resp);

    BEGIN
      l_json := REGEXP_SUBSTR(l_text, '\{.*\}', 1, 1, 'n');
    EXCEPTION WHEN OTHERS THEN
      l_json := NULL;
    END;

    IF l_json IS NULL THEN
      l_json := '{"normalized_question":null,"refers_previous":false,"disambiguation_needed":false,"ask":null}';
    END IF;

    -- Persist for trace (this will now contain ONLY tokenized content)
    BEGIN
      UPDATE CHATBOT_NL2SQL_LOG
        SET reasoned_message = NVL(reasoned_message,'')||CHR(10)||
                                '[FUP_INTERPRET]'||CHR(10)||l_json
      WHERE id = p_log_id;
      COMMIT;
    EXCEPTION WHEN OTHERS THEN NULL; END;

    RETURN l_json;
  END;

  FUNCTION last_result_json_for_chat(p_chat_id IN NUMBER, p_before_log_id IN NUMBER) RETURN CLOB IS
    v CLOB;
  BEGIN
    BEGIN
      SELECT execution_data
        INTO v
        FROM (
          SELECT execution_data
            FROM CHATBOT_NL2SQL_LOG
          WHERE chat_id = p_chat_id
            AND id      < p_before_log_id
            AND status  = 'SUCCEEDED'
            AND execution_data IS NOT NULL
          ORDER BY id DESC
        )
      WHERE ROWNUM = 1;
    EXCEPTION WHEN NO_DATA_FOUND THEN v := NULL; END;
    RETURN v;
  END;

  ------------------------------------------------------------------------------
  -- ESCALATION HELPERS
  ------------------------------------------------------------------------------
  PROCEDURE escalate_to_general_child(
    p_parent_log_id  IN NUMBER,
    p_user_text      IN CLOB,
    p_model_id       IN VARCHAR2,
    p_chat_id        IN NUMBER,
    p_app_user       IN VARCHAR2,
    p_app_session    IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_dataset        IN VARCHAR2,
    p_environment    IN VARCHAR2
  ) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    l_child_id           NUMBER;
    l_job_name           VARCHAR2(128);
    l_parent_session_id  VARCHAR2(255);
  BEGIN
    BEGIN
      SELECT session_id INTO l_parent_session_id
        FROM CHATBOT_NL2SQL_LOG
      WHERE id = p_parent_log_id;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      l_parent_session_id := NULL;
    END;

    INSERT INTO CHATBOT_NL2SQL_LOG (
      chat_id, parent_id, session_id, app_user,
      user_prompt,
      intent_label, status, reasoned_message,
      exec_mode, model_id, compartment_id, use_history, created_at
    )
    VALUES (
      p_chat_id, p_parent_log_id, l_parent_session_id, p_app_user,
      CHATBOT_CORE_IO_PKG.one_line(p_user_text),
      'GENERAL_CHAT', 'QUEUED',
      '[FOLLOWUP_ANSWER]',  -- tiny breadcrumb for trace
      'FOLLOWUP_ANSWER', p_model_id, p_compartment_id, 'N', SYSTIMESTAMP
    )
    RETURNING id INTO l_child_id;

    -- keep score parity with parent if present
    BEGIN
      UPDATE CHATBOT_NL2SQL_LOG c
        SET c.intent_score10 =
            (SELECT p.intent_score10 FROM CHATBOT_NL2SQL_LOG p WHERE p.id = p_parent_log_id)
      WHERE c.id = l_child_id;
    EXCEPTION WHEN OTHERS THEN NULL; END;

    l_job_name := 'CHATBOT_NL2SQL_JOB_'||l_child_id;
    UPDATE CHATBOT_NL2SQL_LOG
      SET job_name = l_job_name
    WHERE id = l_child_id;

    -- Hide the parent like we do for NL2SQL rewrites
    UPDATE CHATBOT_NL2SQL_LOG
      SET status       = 'ESCALATED_TO_GENERAL',  -- or c_status_escalated_to_general if you have a constant
          finished_at  = SYSTIMESTAMP,
          intent_label    = 'GENERAL_CHAT',
          reasoned_message = NVL(reasoned_message,'')||
                              CHR(10)||'[FOLLOWUP] Escalated → child '||l_child_id||' (FOLLOWUP_ANSWER)'
    WHERE id = p_parent_log_id;

    DBMS_SCHEDULER.CREATE_JOB(
      job_name   => l_job_name,
      job_type   => 'PLSQL_BLOCK',
      job_action =>
        'begin OCI_FOCUS_REPORTS.chatbot_core_runner_pkg.run_job('||
        l_child_id||','||
        DBMS_ASSERT.ENQUOTE_LITERAL(p_model_id)||','||
        p_chat_id||','||
        DBMS_ASSERT.ENQUOTE_LITERAL(p_app_user)||','||
        CASE WHEN p_app_session IS NULL THEN 'null' ELSE DBMS_ASSERT.ENQUOTE_LITERAL(p_app_session) END||','||
        DBMS_ASSERT.ENQUOTE_LITERAL(p_compartment_id)||','||
        DBMS_ASSERT.ENQUOTE_LITERAL('N')||','||
        CASE WHEN p_dataset IS NULL THEN 'null' ELSE DBMS_ASSERT.ENQUOTE_LITERAL(p_dataset) END||','||
        CASE WHEN p_environment IS NULL THEN 'null' ELSE DBMS_ASSERT.ENQUOTE_LITERAL(p_environment) END||
        '); end;',
      start_date => SYSTIMESTAMP + INTERVAL '1' SECOND,
      enabled    => TRUE,
      auto_drop  => TRUE
    );

    COMMIT;

    log_info(CHATBOT_CORE_CTX_PARAMS_PKG.make_ctx(p_dataset,p_environment),
            'FUP-ESC-'||p_parent_log_id, p_parent_log_id, p_chat_id,
            'ESCALATE_GENERAL → child='||l_child_id||' job='||l_job_name);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      log_info(CHATBOT_CORE_CTX_PARAMS_PKG.make_ctx(p_dataset,p_environment),
              'FUP-ESC-'||p_parent_log_id, p_parent_log_id, p_chat_id,
              'ESCALATE_GENERAL ERROR: '||SUBSTR(SQLERRM,1,400));
      RAISE;
  END;


  PROCEDURE escalate_to_nl2sql_rewrite(
    p_parent_log_id  IN NUMBER,
    p_prev_sql       IN CLOB,
    p_followup_text_eff   IN CLOB,  -- normalized / effective
    p_followup_text_ui    IN CLOB,  -- original, for UI
    p_prev_user      IN CLOB,
    p_prev_summary   IN CLOB,
    p_model_id       IN VARCHAR2,
    p_chat_id        IN NUMBER,
    p_app_user       IN VARCHAR2,
    p_app_session    IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_dataset        IN VARCHAR2,
    p_environment    IN VARCHAR2,
    p_ctx            IN CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t
  ) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    l_child_id           NUMBER;
    l_job_name           VARCHAR2(128);
    l_prompt             CLOB;
    l_parent_session_id  VARCHAR2(255);
  BEGIN
    l_prompt := build_nl2sql_rewrite_prompt(
              p_ctx      => p_ctx,
              p_prev_sql => p_prev_sql,
              p_followup_text => p_followup_text_eff,
              p_prev_user    => p_prev_user,
              p_prev_summary => p_prev_summary
            );

    BEGIN
      SELECT session_id INTO l_parent_session_id
        FROM CHATBOT_NL2SQL_LOG
       WHERE id = p_parent_log_id;
    EXCEPTION WHEN NO_DATA_FOUND THEN l_parent_session_id := NULL; END;

    INSERT INTO CHATBOT_NL2SQL_LOG (
      chat_id, parent_id, session_id, app_user,
      user_prompt, generated_sql,
      intent_label, status, reasoned_message,
      exec_mode, model_id, compartment_id, use_history, created_at
    )
    VALUES (
      p_chat_id, p_parent_log_id, l_parent_session_id, p_app_user,
      -- UI should show the ORIGINAL follow-up
      CHATBOT_CORE_IO_PKG.one_line(p_followup_text_ui),
      p_prev_sql,
      'NL2SQL', 'QUEUED',
      'JOBHINT:FOLLOWUP_USE_PREV_SQL'                      -- <-- tell runner to stitch prev SQL + follow-up
      || chr(10) || '[FOLLOWUP_STITCH_PROMPT]' || chr(10)  -- optional: keep stitched prompt for debug
      || l_prompt,
      c_mode_followup_rewrite, p_model_id, p_compartment_id, 'N', SYSTIMESTAMP
    )
    RETURNING id INTO l_child_id;

    -- Copy intent score from parent for UI consistency
    BEGIN
      UPDATE CHATBOT_NL2SQL_LOG c
        SET c.intent_score10 =
              (SELECT p.intent_score10 FROM CHATBOT_NL2SQL_LOG p WHERE p.id = p_parent_log_id)
      WHERE c.id = l_child_id;
    EXCEPTION WHEN OTHERS THEN NULL; END;

    UPDATE CHATBOT_NL2SQL_LOG
       SET status = c_status_escalated_to_nl2sql,
           finished_at = SYSTIMESTAMP,
           reasoned_message = NVL(reasoned_message,'')||
                              CHR(10)||'[FOLLOWUP] Escalated → child '||l_child_id||' (FOLLOWUP_REWRITE)'
     WHERE id = p_parent_log_id;

    l_job_name := 'CHATBOT_NL2SQL_JOB_'||l_child_id;

    UPDATE CHATBOT_NL2SQL_LOG
      SET job_name = l_job_name,
          intent_label = 'NL2SQL'
    WHERE id = l_child_id;

    DBMS_SCHEDULER.CREATE_JOB(
      job_name   => l_job_name,
      job_type   => 'PLSQL_BLOCK',
      job_action =>
        'begin OCI_FOCUS_REPORTS.chatbot_core_runner_pkg.run_job('||
        l_child_id||','||
        DBMS_ASSERT.ENQUOTE_LITERAL(p_model_id)||','||
        p_chat_id||','||
        DBMS_ASSERT.ENQUOTE_LITERAL(p_app_user)||','||
        CASE WHEN p_app_session IS NULL THEN 'null' ELSE DBMS_ASSERT.ENQUOTE_LITERAL(p_app_session) END||','||
        DBMS_ASSERT.ENQUOTE_LITERAL(p_compartment_id)||','||
        DBMS_ASSERT.ENQUOTE_LITERAL('N')||','||
        CASE WHEN p_dataset IS NULL THEN 'null' ELSE DBMS_ASSERT.ENQUOTE_LITERAL(p_dataset) END||','||
        CASE WHEN p_environment IS NULL THEN 'null' ELSE DBMS_ASSERT.ENQUOTE_LITERAL(p_environment) END||
        '); end;',
      start_date => SYSTIMESTAMP + INTERVAL '1' SECOND,
      enabled    => TRUE,
      auto_drop  => TRUE
    );

    COMMIT;

    log_info(p_ctx, 'FUP-ESC-'||p_parent_log_id, p_parent_log_id, p_chat_id,
             'ESCALATE_REWRITE → child='||l_child_id||' job='||l_job_name);

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      log_info(p_ctx, 'FUP-ESC-'||p_parent_log_id, p_parent_log_id, p_chat_id,
               'ESCALATE_REWRITE ERROR: '||SUBSTR(SQLERRM,1,400));
      RAISE;
  END;

  PROCEDURE escalate_to_nl2sql_fresh(
    p_parent_log_id  IN NUMBER,
    p_user_text      IN CLOB,
    p_model_id       IN VARCHAR2,
    p_chat_id        IN NUMBER,
    p_app_user       IN VARCHAR2,
    p_app_session    IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_dataset        IN VARCHAR2,
    p_environment    IN VARCHAR2,
    p_user_prompt_override IN CLOB DEFAULT NULL 
  ) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    l_child_id           NUMBER;
    l_job_name           VARCHAR2(128);
    l_parent_session_id  VARCHAR2(255);
  BEGIN
    BEGIN
      SELECT session_id INTO l_parent_session_id
        FROM CHATBOT_NL2SQL_LOG
       WHERE id = p_parent_log_id;
    EXCEPTION WHEN NO_DATA_FOUND THEN l_parent_session_id := NULL; END;

    INSERT INTO CHATBOT_NL2SQL_LOG (
      chat_id, parent_id, session_id, app_user,
      user_prompt,
      intent_label, status, reasoned_message,
      exec_mode, model_id, compartment_id, use_history, created_at
    )
    VALUES (
      p_chat_id, p_parent_log_id, l_parent_session_id, p_app_user,
      CHATBOT_CORE_IO_PKG.one_line(p_user_text),           -- <-- short user text only
      'NL2SQL', 'QUEUED',
      CASE
        WHEN p_user_prompt_override IS NOT NULL THEN
          '[FOLLOWUP_REWRITE_FROM_ORIGINAL]'||chr(10)||p_user_prompt_override -- <-- keep the big rewrite prompt hidden
        ELSE NULL
      END,
      c_mode_followup_new, p_model_id, p_compartment_id, 'N', SYSTIMESTAMP
    )
    RETURNING id INTO l_child_id;

    -- Copy intent score from parent for UI consistency
    BEGIN
      UPDATE CHATBOT_NL2SQL_LOG c
        SET c.intent_score10 =
              (SELECT p.intent_score10 FROM CHATBOT_NL2SQL_LOG p WHERE p.id = p_parent_log_id)
      WHERE c.id = l_child_id;
    EXCEPTION WHEN OTHERS THEN NULL; END;

    UPDATE CHATBOT_NL2SQL_LOG
       SET status = c_status_escalated_to_nl2sql,
           finished_at = SYSTIMESTAMP,
           reasoned_message = NVL(reasoned_message,'')||
                              CHR(10)||'[FOLLOWUP] Escalated → child '||l_child_id||' (FOLLOWUP_NEW)'
     WHERE id = p_parent_log_id;

    l_job_name := 'CHATBOT_NL2SQL_JOB_'||l_child_id;
    UPDATE CHATBOT_NL2SQL_LOG
      SET job_name = l_job_name,
          intent_label = 'NL2SQL'
    WHERE id = l_child_id;

    DBMS_SCHEDULER.CREATE_JOB(
      job_name   => l_job_name,
      job_type   => 'PLSQL_BLOCK',
      job_action =>
        'begin OCI_FOCUS_REPORTS.chatbot_core_runner_pkg.run_job('||
        l_child_id||','||
        DBMS_ASSERT.ENQUOTE_LITERAL(p_model_id)||','||
        p_chat_id||','||
        DBMS_ASSERT.ENQUOTE_LITERAL(p_app_user)||','||
        CASE WHEN p_app_session IS NULL THEN 'null' ELSE DBMS_ASSERT.ENQUOTE_LITERAL(p_app_session) END||','||
        DBMS_ASSERT.ENQUOTE_LITERAL(p_compartment_id)||','||
        DBMS_ASSERT.ENQUOTE_LITERAL('N')||','||
        CASE WHEN p_dataset IS NULL THEN 'null' ELSE DBMS_ASSERT.ENQUOTE_LITERAL(p_dataset) END||','||
        CASE WHEN p_environment IS NULL THEN 'null' ELSE DBMS_ASSERT.ENQUOTE_LITERAL(p_environment) END||
        '); end;',
      start_date => SYSTIMESTAMP + INTERVAL '1' SECOND,
      enabled    => TRUE,
      auto_drop  => TRUE
    );

    COMMIT;

    -- Build a ctx for logging (don’t rely on NULL ctx)
    DECLARE
      l_ctx CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t :=
              CHATBOT_CORE_CTX_PARAMS_PKG.make_ctx(p_dataset, p_environment);
    BEGIN
      log_info(l_ctx, 'FUP-ESC-'||p_parent_log_id, p_parent_log_id, p_chat_id,
               'ESCALATE_FRESH → child='||l_child_id||' job='||l_job_name);
    END;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      DECLARE
        l_ctx CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t :=
                CHATBOT_CORE_CTX_PARAMS_PKG.make_ctx(p_dataset, p_environment);
      BEGIN
        log_info(l_ctx, 'FUP-ESC-'||p_parent_log_id, p_parent_log_id, p_chat_id,
                 'ESCALATE_FRESH ERROR: '||SUBSTR(SQLERRM,1,400));
      END;
      RAISE;
  END;

  ------------------------------------------------------------------------------
  -- MAIN ENTRYPOINT
  ------------------------------------------------------------------------------
  PROCEDURE run_followup(
      p_log_id         IN NUMBER,
      p_model_id       IN VARCHAR2,
      p_chat_id        IN NUMBER,
      p_app_user       IN VARCHAR2,
      p_app_session    IN VARCHAR2,
      p_compartment_id IN VARCHAR2,
      p_dataset        IN VARCHAR2,
      p_environment    IN VARCHAR2
  )
  IS
      l_ctx           CHATBOT_CORE_CTX_PARAMS_PKG.run_ctx_t := CHATBOT_CORE_CTX_PARAMS_PKG.make_ctx(p_dataset, p_environment);
      l_prev_user     CLOB := NULL;
      l_prev_summary  CLOB := NULL;
      l_prev_sql      CLOB := NULL;
      l_user_text     CLOB := NULL;
      l_effective_text CLOB := NULL;
      l_api_format    VARCHAR2(32) := 'json';
      l_endpoint      VARCHAR2(4000) := NULL;
      l_req_id        VARCHAR2(64);
      l_dec           followup_decision_t;
      l_context_turns NUMBER := 3;
      l_hist_max      NUMBER := 1500;
      l_hist_block    CLOB;
      v_len           NUMBER := 0;
      -- Variables for model config
      l_region        VARCHAR2(50);
      l_model_id2     VARCHAR2(1000);
      l_api_fmt       VARCHAR2(50);
      l_temp          NUMBER;
      l_top_p         NUMBER;
      l_top_k         NUMBER;
      l_followup_label VARCHAR2(40);
  BEGIN
      l_req_id := 'FUP-' || TO_CHAR(p_log_id);
      log_info(l_ctx, l_req_id, p_log_id, p_chat_id, 'RUN_FOLLOWUP start');
      mark_status(l_ctx, l_req_id, p_log_id, p_chat_id, c_status_running, p_start => TRUE);

      -- Load the user text for this followup
      BEGIN
          SELECT user_prompt INTO l_user_text
          FROM CHATBOT_NL2SQL_LOG
          WHERE id = p_log_id;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN
              l_user_text := NULL;
      END;

      -- Get previous user, summary, and SQL context
      BEGIN
          CHATBOT_CORE_SQL_PKG.get_context_and_history(
              p_chat_id           => p_chat_id,
              p_log_id            => p_log_id,
              p_mode              => 'ALL',
              p_context_turns     => l_context_turns,
              p_history_max_chars => l_hist_max,
              p_prev_user         => l_prev_user,
              p_prev_summary      => l_prev_summary,
              p_prev_sql          => l_prev_sql,
              p_history_block     => l_hist_block
          );
          -- After get_context_and_history(...)
          IF l_prev_sql IS NULL THEN
            BEGIN
              SELECT generated_sql, user_prompt
                INTO l_prev_sql, l_prev_user
                FROM (
                  SELECT generated_sql, user_prompt
                    FROM CHATBOT_NL2SQL_LOG
                  WHERE chat_id      = p_chat_id
                    AND id          < p_log_id
                    AND status      = 'SUCCEEDED'
                    AND generated_sql IS NOT NULL
                  ORDER BY id DESC
                )
              WHERE ROWNUM = 1;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;
          END IF;
      EXCEPTION
          WHEN OTHERS THEN
              NULL;
      END;

      /*-- Ultra-short follow-up without prev_sql? Ask to clarify (no child)
      v_len := NVL(LENGTH(REGEXP_REPLACE(l_user_text, '\s+', '')), 0);
      IF v_len <= 12 AND l_prev_sql IS NULL THEN
          write_summary(l_ctx, l_req_id, p_log_id, p_chat_id,
              'I need the previous result to refine. Which one should I adjust, and how?');
          mark_status(l_ctx, l_req_id, p_log_id, p_chat_id, c_status_succeeded, p_finish => TRUE);
          log_info(l_ctx, l_req_id, p_log_id, p_chat_id, 'SHORT_FOLLOWUP nudged to clarify');
          RETURN;
      END IF;
      */

      -- Model configuration and endpoint resolution
      DECLARE
        l_cfg CHATBOT_CORE_CTX_PARAMS_PKG.model_cfg_t;
      BEGIN
        CHATBOT_CORE_CTX_PARAMS_PKG.get_model_config(p_model_id, l_cfg);
        l_api_format := l_cfg.api_format;
        l_endpoint   := CHATBOT_CORE_CTX_PARAMS_PKG.endpoint_for_region(l_cfg.region);
        l_model_id2  := l_cfg.model_id_out;

      -- Call the decider function
      l_dec := classify_followup_decision(
        l_ctx, l_prev_user, l_prev_summary, l_prev_sql, l_hist_block, 
        l_user_text,
        l_api_format, l_model_id2, p_compartment_id, l_endpoint,
        l_req_id, p_log_id, p_chat_id
      );
      END;
      -- Compute & persist the improved (context-aware) follow-up label + score on the parent row
      l_followup_label := normalize_followup_label(
                            p_decision_json => l_dec.transform_json,
                            p_prev_sql      => l_prev_sql,
                            p_user_text     => l_user_text
                          );

      DECLARE
        l_score10 NUMBER;
      BEGIN
        l_score10 := LEAST(GREATEST(ROUND(10 * NVL(l_dec.confidence, 0)), 0), 10);
        UPDATE CHATBOT_NL2SQL_LOG
          SET intent_label   = l_followup_label,
              intent_score10 = l_score10
        WHERE id = p_log_id;
        COMMIT;
      EXCEPTION WHEN OTHERS THEN NULL; END;

      -- Try to interpret/normalize the follow-up using previous rows JSON
      DECLARE
        l_rows_json   CLOB := last_result_json_for_chat(p_chat_id, p_log_id);
        l_interp      CLOB;
        l_norm        CLOB;
        l_ref_prev    VARCHAR2(5);
        l_need_disamb VARCHAR2(5);
        l_ask         CLOB;
      BEGIN
        -- Build model cfg once (reuse the cfg you already fetched above if available)
        DECLARE
          l_cfg CHATBOT_CORE_CTX_PARAMS_PKG.model_cfg_t;
        BEGIN
          CHATBOT_CORE_CTX_PARAMS_PKG.get_model_config(p_model_id, l_cfg);

          l_interp := interpret_followup(
                        p_ctx            => l_ctx,
                        p_prev_user      => l_prev_user,
                        p_prev_summary   => l_prev_summary,
                        p_prev_sql       => l_prev_sql,
                        p_prev_rows_json => l_rows_json,
                        p_user_text      => l_user_text,
                        p_api_format     => l_cfg.api_format,
                        p_model_id       => l_cfg.model_id_out,
                        p_compartment_id => p_compartment_id,
                        p_endpoint       => CHATBOT_CORE_CTX_PARAMS_PKG.endpoint_for_region(l_cfg.region),
                        p_req_id         => l_req_id,
                        p_log_id         => p_log_id,
                        p_chat_id        => p_chat_id
                      );
        END;

        l_norm        := JSON_VALUE(l_interp, '$.normalized_question' RETURNING CLOB);
        l_ref_prev    := LOWER(NVL(JSON_VALUE(l_interp, '$.refers_previous' RETURNING VARCHAR2(5)),'false'));
        l_need_disamb := LOWER(NVL(JSON_VALUE(l_interp, '$.disambiguation_needed' RETURNING VARCHAR2(5)),'false'));
        l_ask         := JSON_VALUE(l_interp, '$.ask' RETURNING CLOB);

        -- If ambiguous, surface a targeted clarify and finish early
        IF l_need_disamb = 'true' AND l_ask IS NOT NULL THEN
          write_summary(l_ctx, l_req_id, p_log_id, p_chat_id, l_ask);
          mark_status(l_ctx, l_req_id, p_log_id, p_chat_id, c_status_succeeded, p_finish => TRUE);
          RETURN;
        END IF;

        -- If the interpreter says it refers to the previous result and we DO have prev SQL,
        -- prefer FOLLOWUP_REWRITE, even if the decider labeled it NEW.
        IF l_ref_prev = 'true' AND l_prev_sql IS NOT NULL THEN
          l_followup_label := 'FOLLOWUP_REWRITE';
        END IF;

        -- Decide which text the engine should use (effective), but KEEP l_user_text for UI.
        l_effective_text :=
          CASE
            WHEN l_norm IS NOT NULL AND DBMS_LOB.getlength(l_norm) > 0
              THEN l_norm
            ELSE l_user_text
          END;

        -- Optionally persist normalized text for trace only
        IF l_norm IS NOT NULL AND DBMS_LOB.getlength(l_norm) > 0 THEN
          BEGIN
            UPDATE CHATBOT_NL2SQL_LOG
               SET reasoned_message = NVL(reasoned_message,'')||
                                      CHR(10)||'[FUP_NORMALIZED]'||CHR(10)||l_norm
             WHERE id = p_log_id;
            COMMIT;
          EXCEPTION WHEN OTHERS THEN NULL; END;
        END IF;
      END;

      -- Branch by the normalized FOLLOWUP label (context-aware)
      IF l_followup_label = 'FOLLOWUP_ANSWER' THEN
        IF l_dec.answer_text IS NOT NULL AND DBMS_LOB.GETLENGTH(l_dec.answer_text) > 0 THEN
          -- The decider returned a full answer → surface it and finish.
          write_summary(
            l_ctx, l_req_id, p_log_id, p_chat_id, l_dec.answer_text
          );
          mark_status(l_ctx, l_req_id, p_log_id, p_chat_id, c_status_succeeded, p_finish => TRUE);
        ELSE
          -- No answer body from decider → escalate to GENERAL child so runner can fetch/browse if needed
          escalate_to_general_child(
            p_parent_log_id  => p_log_id,
            p_user_text      => l_user_text,
            p_model_id       => p_model_id,
            p_chat_id        => p_chat_id,
            p_app_user       => p_app_user,
            p_app_session    => p_app_session,
            p_compartment_id => p_compartment_id,
            p_dataset        => p_dataset,
            p_environment    => p_environment
          );
          -- mark_status(l_ctx, l_req_id, p_log_id, p_chat_id, 'SCHEDULED', p_finish => TRUE);
        END IF;

      ELSIF l_followup_label = 'FOLLOWUP_CLARIFY' THEN
        write_summary(l_ctx, l_req_id, p_log_id, p_chat_id,
          NVL(l_dec.clarify_question, 'Could you clarify the change you want on the previous result?'));
        mark_status(l_ctx, l_req_id, p_log_id, p_chat_id, c_status_succeeded, p_finish => TRUE);

      ELSIF l_followup_label = 'FOLLOWUP_REWRITE' THEN
        IF l_prev_sql IS NOT NULL THEN
          -- Normal rewrite: child with stitched prompt and prev SQL
          escalate_to_nl2sql_rewrite(
            p_parent_log_id  => p_log_id,
            p_prev_sql       => l_prev_sql,
            p_followup_text_eff => l_effective_text,
            p_followup_text_ui  => l_user_text,
            p_prev_user      => l_prev_user,       -- NEW
            p_prev_summary   => l_prev_summary,    -- NEW
            p_model_id       => p_model_id,
            p_chat_id        => p_chat_id,
            p_app_user       => p_app_user,
            p_app_session    => p_app_session,
            p_compartment_id => p_compartment_id,
            p_dataset        => p_dataset,
            p_environment    => p_environment,
            p_ctx            => l_ctx
          );
        ELSE
          -- No prev SQL: still a refinement → create a fresh child with a rewrite-style prompt
          DECLARE
            l_rewrite_prompt CLOB :=
              build_nl2sql_rewrite_from_prev_question(
                l_prev_user,
                l_prev_summary,
                l_effective_text  -- engine sees normalized text
              );
          BEGIN
            -- UI still shows original follow-up
            escalate_to_nl2sql_fresh(
              p_parent_log_id        => p_log_id,
              p_user_text            => l_user_text,
              p_model_id             => p_model_id,
              p_chat_id              => p_chat_id,
              p_app_user             => p_app_user,
              p_app_session          => p_app_session,
              p_compartment_id       => p_compartment_id,
              p_dataset              => p_dataset,
              p_environment          => p_environment,
              p_user_prompt_override => l_rewrite_prompt
            );
          END;
        END IF;
        mark_status(l_ctx, l_req_id, p_log_id, p_chat_id, c_status_escalated_to_nl2sql, p_finish => TRUE);

      ELSE  -- FOLLOWUP_NEW (or anything unexpected)
        DECLARE
          r_intent CHATBOT_CORE_SQL_PKG.intent_result_t;
          l_cfg    CHATBOT_CORE_CTX_PARAMS_PKG.model_cfg_t;
        BEGIN
          CHATBOT_CORE_CTX_PARAMS_PKG.get_model_config(p_model_id, l_cfg);

          CHATBOT_CORE_SQL_PKG.resolve_intent(
            p_ctx            => l_ctx,
            p_text           => l_user_text,
            p_api_format     => l_cfg.api_format,
            p_model_id       => l_cfg.model_id_out,
            p_compartment_id => p_compartment_id,
            p_region         => l_cfg.region,
            p_req_id         => l_req_id,
            p_log_id         => p_log_id,
            p_chat_id        => p_chat_id,
            p_threshold      => NULL,
            p_persist        => FALSE,
            p_result         => r_intent
          );

          CHATBOT_CORE_IO_PKG.logv(
            l_ctx,
            'FOLLOWUP_NEW',
            l_req_id,
            'FOLLOWUP_NEW resolver=' || NVL(r_intent.label,'?') ||
            ' needs_clarify=' || CASE WHEN r_intent.needs_clarify THEN 'Y' ELSE 'N' END,
            p_log_id,
            p_chat_id
          );

          -- Treat FOLLOWUP_CLARIFY with needs_clarify = N as NL2SQL (fresh)
          IF     r_intent.label = 'NL2SQL'
             OR (r_intent.label = 'FOLLOWUP_CLARIFY' AND NOT r_intent.needs_clarify)
          THEN
            -- NL2SQL → escalate to NL2SQL_FRESH
            escalate_to_nl2sql_fresh(
              p_parent_log_id  => p_log_id,
              p_user_text      => l_user_text,
              p_model_id       => p_model_id,
              p_chat_id        => p_chat_id,
              p_app_user       => p_app_user,
              p_app_session    => p_app_session,
              p_compartment_id => p_compartment_id,
              p_dataset        => p_dataset,
              p_environment    => p_environment
            );
            mark_status(l_ctx, l_req_id, p_log_id, p_chat_id, c_status_escalated_to_nl2sql, p_finish => TRUE);

          ELSIF r_intent.label = 'FOLLOWUP_CLARIFY' AND r_intent.needs_clarify THEN
            -- True clarification → ask the question here and finish
            write_summary(
              l_ctx, l_req_id, p_log_id, p_chat_id,
              NVL(l_dec.clarify_question, 'Could you clarify the change you want on the previous result?')
            );
            mark_status(l_ctx, l_req_id, p_log_id, p_chat_id, c_status_succeeded, p_finish => TRUE);

          ELSE
            -- default → GENERAL
            escalate_to_general_child(
              p_parent_log_id  => p_log_id,
              p_user_text      => l_user_text,
              p_model_id       => p_model_id,
              p_chat_id        => p_chat_id,
              p_app_user       => p_app_user,
              p_app_session    => p_app_session,
              p_compartment_id => p_compartment_id,
              p_dataset        => p_dataset,
              p_environment    => p_environment
            );
          END IF;
        END;
      END IF;

      log_info(l_ctx, l_req_id, p_log_id, p_chat_id, 'RUN_FOLLOWUP end');

  EXCEPTION
      WHEN OTHERS THEN
          log_info(l_ctx, l_req_id, p_log_id, p_chat_id, 'ERROR ' || SQLERRM);
          mark_status(l_ctx, l_req_id, p_log_id, p_chat_id, c_status_failed, p_errmsg => SQLERRM, p_finish => TRUE);
          RAISE;
  END run_followup;

END CHATBOT_FOLLOWUP_PKG;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_JSON_CONVERTER_PKG" AS
  ----------------------------------------------------------------------------
  -- DDL -> JSON converters
  ----------------------------------------------------------------------------
  PROCEDURE convert_ddl_and_desc(
    p_ddl_text        IN  CLOB,
    p_desc_text       IN  CLOB,
    o_schema_json     OUT CLOB,
    o_tabledesc_json  OUT CLOB
  );

  PROCEDURE upsert_parameters(
    p_dataset         IN VARCHAR2,
    p_environment     IN VARCHAR2,
    p_schema_json     IN CLOB,
    p_tabledesc_json  IN CLOB
  );

  ----------------------------------------------------------------------------
  -- LLM call helper (OCI GenAI chat)
  ----------------------------------------------------------------------------
  FUNCTION llm_call_text(
    p_message        IN  CLOB,
    p_model_id       IN  VARCHAR2,
    p_compartment_id IN  VARCHAR2
  ) RETURN CLOB;

  ----------------------------------------------------------------------------
  -- DDL summarization + upsert into summary table
  ----------------------------------------------------------------------------
  PROCEDURE summarize_ddl_and_upsert(
    p_ddl_text        IN  CLOB,        -- raw CREATE TABLE ... ;
    p_dataset         IN  VARCHAR2,    -- e.g. 'LATEST'
    p_environment     IN  VARCHAR2,    -- e.g. 'TEST'
    p_model_id        IN  VARCHAR2 DEFAULT NULL,  -- override; else APP_CONFIG.MODEL_ID
    p_target_table    IN  VARCHAR2 DEFAULT 'CHATBOT_NL2SQL_SUMMARY',
    p_id_sequence     IN  VARCHAR2 DEFAULT NULL,  -- set if target table needs ID via sequence
    p_auto_commit     IN  BOOLEAN  DEFAULT FALSE, -- caller controls commit
    -- outs
    p_summary_json    OUT CLOB,
    p_summary_row_op  OUT VARCHAR2
  );
END CHATBOT_JSON_CONVERTER_PKG;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_JSON_CONVERTER_PKG" AS

  /* === Local types === */
  TYPE t_clob_list IS TABLE OF CLOB;

  /* === Utility: trim quotes === */
  FUNCTION unquote(p IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF p IS NULL THEN RETURN NULL; END IF;
    IF SUBSTR(p,1,1) = '"' AND SUBSTR(p,-1) = '"' THEN
      RETURN SUBSTR(p,2,LENGTH(p)-2);
    ELSE
      RETURN p;
    END IF;
  END;

  /* === NEW: build alias from table name (no owner) === */
  FUNCTION make_alias(p_table_name IN VARCHAR2) RETURN VARCHAR2 IS
    v        VARCHAR2(512) := UPPER(unquote(p_table_name));
    res      VARCHAR2(128) := '';
    token    VARCHAR2(512);
    occ      PLS_INTEGER   := 1;
  BEGIN
    IF v IS NULL THEN
      RETURN NULL;
    END IF;

    -- take first letter of each alphanumeric "word" (split on underscores etc.)
    LOOP
      token := REGEXP_SUBSTR(v, '[A-Z0-9]+', 1, occ);
      EXIT WHEN token IS NULL;
      res := res || LOWER(SUBSTR(token, 1, 1));
      occ := occ + 1;
    END LOOP;

    RETURN res;
  END make_alias;

  /* === Utility: remove inline and block comments === */
  FUNCTION strip_sql_comments(p IN CLOB) RETURN CLOB IS
    s CLOB := p;
  BEGIN
    -- block comments /* ... */
    s := REGEXP_REPLACE(s, '/\*.*?\*/', '', 1, 0, 'n');
    -- line comments -- ... (preserve newline)
    s := REGEXP_REPLACE(s, '--.*?(?:\r?\n|$)', CHR(10), 1, 0, 'n');
    RETURN s;
  END;

  /* === Extract all CREATE TABLE blocks from raw DDL === */
  PROCEDURE parse_create_blocks(
    p_ddl   IN  CLOB,
    o_names OUT SYS.ODCIVARCHAR2LIST,
    o_defs  OUT t_clob_list
  ) IS
    pos    PLS_INTEGER := 1;
    s_pos  PLS_INTEGER;
    e_pos  PLS_INTEGER;
    src    CLOB := strip_sql_comments(p_ddl); -- strip comments first
    blk    CLOB;
    name   VARCHAR2(512);
  BEGIN
    o_names := SYS.ODCIVARCHAR2LIST();
    o_defs  := t_clob_list();

    LOOP
      -- find next CREATE TABLE
      s_pos := REGEXP_INSTR(src, 'CREATE[[:space:]]+TABLE[[:space:]]+', pos, 1, 0, 'in');
      EXIT WHEN s_pos = 0;

      -- end at the next semicolon (or end of CLOB)
      e_pos := REGEXP_INSTR(src, ';', s_pos, 1, 0, 'n');
      IF e_pos = 0 THEN
        e_pos := DBMS_LOB.getlength(src) + 1;
      END IF;

      -- grab the block (without the trailing semicolon)
      blk := DBMS_LOB.SUBSTR(src, (e_pos - s_pos), s_pos);

      ----------------------------------------------------------------
      -- Table name extraction
      ----------------------------------------------------------------
      name := REGEXP_SUBSTR(
                blk,
                '"[^"]+"\s*\.\s*"[^"]+"',
                1, 1, 'n'
              );

      IF name IS NULL THEN
        name := REGEXP_SUBSTR(
                  blk,
                  '[A-Za-z0-9_$.#]+\s*\.\s*[A-Za-z0-9_$.#]+',
                  1, 1, 'n'
                );
      END IF;

      IF name IS NULL THEN
        name := REGEXP_SUBSTR(
                  blk,
                  '"[^"]+"',
                  1, 1, 'n'
                );
      END IF;

      IF name IS NULL THEN
        name := REGEXP_SUBSTR(
                  blk,
                  '[A-Za-z0-9_$.#]+',
                  1, 1, 'n'
                );
      END IF;

      o_names.EXTEND; 
      o_defs.EXTEND;
      o_names(o_names.COUNT) := name;
      o_defs(o_defs.COUNT)   := blk;

      pos := e_pos + 1;
    END LOOP;
  END;

  /* === Split column section into items by commas at paren depth 0 === */
  PROCEDURE split_columns_block(p_block IN CLOB, o_items OUT t_clob_list) IS
    body   CLOB;
    ch     VARCHAR2(1);
    depth  PLS_INTEGER := 0;
    startp PLS_INTEGER := 1;
    len    PLS_INTEGER;
  BEGIN
    body := REGEXP_SUBSTR(p_block, '\((.*)\)', 1, 1, 'n', 1);
    IF body IS NULL THEN
      o_items := t_clob_list();
      RETURN;
    END IF;

    body := strip_sql_comments(body);  -- remove comments first
    len := DBMS_LOB.getlength(body);
    o_items := t_clob_list();

    FOR p IN 1 .. len LOOP
      ch := DBMS_LOB.SUBSTR(body, 1, p);
      IF ch = '(' THEN depth := depth + 1; END IF;
      IF ch = ')' AND depth > 0 THEN depth := depth - 1; END IF;

      IF ch = ',' AND depth = 0 THEN
        o_items.EXTEND;
        o_items(o_items.COUNT) := TRIM(DBMS_LOB.SUBSTR(body, p - startp, startp));
        startp := p + 1;
      END IF;
    END LOOP;

    IF startp <= len THEN
      o_items.EXTEND;
      o_items(o_items.COUNT) := TRIM(DBMS_LOB.SUBSTR(body, len - startp + 1, startp));
    END IF;
  END;

  /* === Parse one column line (skip constraints) === */
  PROCEDURE parse_column_line(p_line IN CLOB, o_name OUT VARCHAR2, o_type OUT VARCHAR2) IS
    line  VARCHAR2(32767) := TRIM(REGEXP_REPLACE(p_line, '\s+', ' '));
    nm    VARCHAR2(512);
    rest  VARCHAR2(32767);
  BEGIN
    o_name := NULL; o_type := NULL;

    IF REGEXP_LIKE(line, '^(CONSTRAINT|PRIMARY|FOREIGN|UNIQUE|CHECK)([[:space:]]|$)', 'i') THEN
      RETURN;
    END IF;

    nm := REGEXP_SUBSTR(line, '^"[^"]+"|^[A-Za-z0-9_$.#]+', 1, 1, 'i');
    IF nm IS NULL THEN RETURN; END IF;

    rest := TRIM(SUBSTR(line, LENGTH(nm) + 1));
    IF rest IS NULL THEN RETURN; END IF;

    rest := REGEXP_SUBSTR(
      rest,
      '.*?((?=[[:space:]]+(DEFAULT|NOT|NULL|CONSTRAINT|PRIMARY|REFERENCES)([[:space:]]|$))|$)',
      1, 1, 'i'
    );

    o_name := unquote(nm);
    o_type := TRIM(rest);
  END;

  /* === Build schema and description JSON === */
  PROCEDURE convert_ddl_and_desc(
    p_ddl_text        IN  CLOB,
    p_desc_text       IN  CLOB,
    o_schema_json     OUT CLOB,
    o_tabledesc_json  OUT CLOB
  ) IS
    tnames   SYS.ODCIVARCHAR2LIST;
    tdefs    t_clob_list;
    colitems t_clob_list;

    j_tables    JSON_ARRAY_T := JSON_ARRAY_T();
    j_descs     JSON_ARRAY_T := JSON_ARRAY_T();
  BEGIN
    /* ---- DDL -> schema JSON ---- */
    parse_create_blocks(p_ddl_text, tnames, tdefs);

    FOR i IN 1 .. NVL(tnames.COUNT,0) LOOP
      split_columns_block(tdefs(i), colitems);

      DECLARE
        full_name    VARCHAR2(512) := tnames(i);
        owner_part   VARCHAR2(256);
        table_part   VARCHAR2(256);
        display_name VARCHAR2(512);
        alias_name   VARCHAR2(128);
        j_cols       JSON_ARRAY_T := JSON_ARRAY_T();
      BEGIN
        IF INSTR(full_name, '.') > 0 THEN
          owner_part   := unquote(REGEXP_SUBSTR(full_name, '^[^.]+'));
          table_part   := unquote(REGEXP_SUBSTR(full_name, '[^.]+$', 1, 1));
          display_name := UPPER(owner_part)||'.'||UPPER(table_part);
          alias_name   := make_alias(table_part);        -- ignore owner
        ELSE
          display_name := UPPER(unquote(full_name));
          alias_name   := make_alias(full_name);
        END IF;

        FOR k IN 1 .. NVL(colitems.COUNT,0) LOOP
          DECLARE
            cn         VARCHAR2(512);
            ct         VARCHAR2(512);
            ct_up      VARCHAR2(512);
            base_type  VARCHAR2(128);
            jo         JSON_OBJECT_T;
          BEGIN
            parse_column_line(colitems(k), cn, ct);
            IF cn IS NOT NULL AND ct IS NOT NULL THEN
              ct_up     := UPPER(ct);
              -- simplify type: take leading token (e.g. VARCHAR2 from VARCHAR2(100 BYTE))
              base_type := REGEXP_SUBSTR(ct_up, '^[A-Z0-9_]+');
              IF base_type IS NULL THEN
                base_type := ct_up;
              END IF;

              jo := JSON_OBJECT_T();
              jo.put('name', UPPER(cn));
              jo.put('type', base_type);  -- simplified type
              j_cols.append(jo);
            END IF;
          EXCEPTION WHEN OTHERS THEN NULL; END;
        END LOOP;

        DECLARE
          jt JSON_OBJECT_T;
        BEGIN
          jt := JSON_OBJECT_T();
          jt.put('name',  display_name);
          jt.put('alias', alias_name);
          jt.put('columns', j_cols);
          j_tables.append(jt);
        END;
      END;
    END LOOP;

    DECLARE
      root JSON_OBJECT_T;
    BEGIN
      root := JSON_OBJECT_T();
      -- back to plural "tables"
      root.put('tables', j_tables);
      o_schema_json := root.to_clob();
    END;

    /* ---- Descriptions -> descriptions JSON ---- */
    IF p_desc_text IS NOT NULL THEN
      DECLARE
        txt         CLOB := REPLACE(p_desc_text, CHR(13), '');
        line        CLOB;
        startp      PLS_INTEGER := 1;
        endp        PLS_INTEGER;
        len         PLS_INTEGER := DBMS_LOB.getlength(txt);

        nm_raw        VARCHAR2(512);
        display_name  VARCHAR2(512);
        table_desc    VARCHAR2(4000);

        j_colsdesc    JSON_ARRAY_T := JSON_ARRAY_T();

        c_name_q   VARCHAR2(512);
        c_desc_q   VARCHAR2(4000);
        c_name_u   VARCHAR2(512);
        c_desc_u   VARCHAR2(4000);
        c_name     VARCHAR2(512);
        c_desc     VARCHAR2(4000);

        have_header BOOLEAN := FALSE;
      BEGIN
        LOOP
          EXIT WHEN startp > len;
          endp := INSTR(txt, CHR(10), startp);
          IF endp = 0 THEN endp := len + 1; END IF;
          line := TRIM(DBMS_LOB.SUBSTR(txt, endp - startp, startp));
          startp := endp + 1;

          -- 1) Table header line
          IF NOT have_header AND REGEXP_LIKE(line, '^\s*Table\s+', 'i') THEN
            nm_raw := REGEXP_SUBSTR(
                        line,
                        'Table\s+("([^"]+)"(\s*\.\s*"[^"]+")?|[A-Za-z0-9_$.#]+(\s*\.\s*[A-Za-z0-9_$.#]+)?)',
                        1, 1, 'i', 1);
            nm_raw := REGEXP_REPLACE(nm_raw, '^\s*Table\s+', '', 1, 1, 'i');

            IF nm_raw IS NOT NULL THEN
              IF INSTR(nm_raw, '.') > 0 THEN
                display_name := UPPER(unquote(REGEXP_SUBSTR(nm_raw, '^[^.]+'))) ||'.'|| 
                                UPPER(unquote(REGEXP_SUBSTR(nm_raw, '[^.]+$',1,1)));
              ELSE
                display_name := UPPER(unquote(nm_raw));
              END IF;

              -- prefer text after ":"; else after the word "contains"
              table_desc := TRIM(REGEXP_SUBSTR(line, ':\s*(.+)$', 1, 1, 'n', 1));
              table_desc := REGEXP_REPLACE(table_desc, '\r+$', '');
              IF table_desc IS NULL THEN
                table_desc := TRIM(REGEXP_SUBSTR(line, '\bcontains\b\s*(.+)$', 1, 1, 'i', 1));
                table_desc := REGEXP_REPLACE(table_desc, '\r+$', '');
              END IF;

              have_header := TRUE;
            END IF;

          -- 2) Column bullet lines (after we've seen the header)
          ELSIF have_header THEN
            -- ignore section labels like "Columns:"
            IF REGEXP_LIKE(line, '^\s*Columns\s*:?\s*$', 'i') THEN
              NULL;

            ELSIF REGEXP_LIKE(line, '^\s*-\s*') THEN
              DECLARE
                nm VARCHAR2(512);
                ds VARCHAR2(4000);
                jcol JSON_OBJECT_T;
                line_no_cr VARCHAR2(4000);
              BEGIN
                line_no_cr := REGEXP_REPLACE(line, '\r+$', '');

                -- try quoted name first: - "col" : desc
                nm := REGEXP_SUBSTR(line_no_cr, '^\s*-\s*"([^"]+)"', 1, 1, 'n', 1);
                IF nm IS NOT NULL THEN
                  ds := REGEXP_REPLACE(line_no_cr, '^\s*-\s*"[^"]+"\s*(?:->|→|:)\s*', '', 1, 1, 'n');
                ELSE
                  -- unquoted: - col : desc
                  nm := REGEXP_SUBSTR(line_no_cr, '^\s*-\s*([A-Za-z0-9_$.#]+)', 1, 1, 'n', 1);
                  IF nm IS NOT NULL THEN
                    ds := REGEXP_REPLACE(line_no_cr, '^\s*-\s*[A-Za-z0-9_$.#]+\s*(?:->|→|:)\s*', '', 1, 1, 'n');
                  END IF;
                END IF;

                IF nm IS NOT NULL AND ds IS NOT NULL THEN
                  jcol := JSON_OBJECT_T();
                  jcol.put('name', UPPER(unquote(nm)));
                  jcol.put('description', TRIM(ds));
                  j_colsdesc.append(jcol);
                END IF;
              END;
            END IF;
          END IF;
        END LOOP;

        -- finalize one table object
        IF have_header THEN
          DECLARE
            jt JSON_OBJECT_T;
          BEGIN
            jt := JSON_OBJECT_T();
            jt.put('name', display_name);
            IF table_desc IS NOT NULL THEN
              jt.put('description', 'Table '||display_name||': '||TRIM(table_desc));
            END IF;
            IF j_colsdesc.get_size > 0 THEN
              jt.put('columns', j_colsdesc);
            END IF;
            j_descs.append(jt);
          END;
        END IF;
      END;

      -- pack into top-level JSON
      DECLARE
        root JSON_OBJECT_T;
      BEGIN
        root := JSON_OBJECT_T();
        root.put('tables', j_descs);
        o_tabledesc_json := root.to_clob();
      END;

    ELSE
      DECLARE
        root JSON_OBJECT_T;
      BEGIN
        root := JSON_OBJECT_T();
        root.put('tables', JSON_ARRAY_T());
        o_tabledesc_json := root.to_clob();
      END;
    END IF;
  END convert_ddl_and_desc;

  /* === Optional persistence === */
  PROCEDURE upsert_parameters(
    p_dataset         IN VARCHAR2,
    p_environment     IN VARCHAR2,
    p_schema_json     IN CLOB,
    p_tabledesc_json  IN CLOB
  ) IS
  BEGIN
    INSERT INTO chatbot_parameters(component_type, dataset, environment, active, content)
      VALUES ('SCHEMA', p_dataset, p_environment, 'TRUE', p_schema_json);

    INSERT INTO chatbot_parameters(component_type, dataset, environment, active, content)
      VALUES ('TABLE_DESCRIPTIONS', p_dataset, p_environment, 'TRUE', p_tabledesc_json);
  EXCEPTION
    WHEN dup_val_on_index THEN
      UPDATE chatbot_parameters
         SET active = 'TRUE', content = p_schema_json
       WHERE component_type='SCHEMA'
         AND NVL(dataset,'$') = NVL(p_dataset,'$')
         AND NVL(environment,'$') = NVL(p_environment,'$');

      UPDATE chatbot_parameters
         SET active = 'TRUE', content = p_tabledesc_json
       WHERE component_type='TABLE_DESCRIPTIONS'
         AND NVL(dataset,'$') = NVL(p_dataset,'$')
         AND NVL(environment,'$') = NVL(p_environment,'$');
  END upsert_parameters;

  ----------------------------------------------------------------------------
  -- LLM call helper (OCI GenAI chat) + local helpers
  ----------------------------------------------------------------------------

  FUNCTION clob_to_blob_utf8(p_clob IN CLOB) RETURN BLOB IS
    l_blob        BLOB;
    l_dest_offset INTEGER := 1;
    l_src_offset  INTEGER := 1;
    l_lang_ctx    INTEGER := 0;
    l_warning     INTEGER := 0;
  BEGIN
    DBMS_LOB.createtemporary(l_blob, TRUE);
    DBMS_LOB.convertToBlob(
      dest_lob     => l_blob,
      src_clob     => p_clob,
      amount       => DBMS_LOB.lobmaxsize,
      dest_offset  => l_dest_offset,
      src_offset   => l_src_offset,
      blob_csid    => NLS_CHARSET_ID('AL32UTF8'),
      lang_context => l_lang_ctx,
      warning      => l_warning
    );
    RETURN l_blob;
  END clob_to_blob_utf8;

  FUNCTION extract_text(p_json IN CLOB) RETURN CLOB IS
    jo   JSON_OBJECT_T;
    cr   JSON_OBJECT_T;
    txt  CLOB;
  BEGIN
    jo := JSON_OBJECT_T.parse(p_json);

    -- error payload?
    IF jo.has('error') THEN
      RAISE_APPLICATION_ERROR(-20990,
        'OCI GenAI error: '||SUBSTR(p_json,1,2000));
    END IF;

    IF NOT jo.has('chatResponse') THEN
      RETURN NULL;
    END IF;

    cr := jo.get_object('chatResponse');

    -- Cohere-style single string
    IF cr.has('text') THEN
      txt := cr.get_string('text');
      IF txt IS NOT NULL AND TRIM(txt) IS NOT NULL THEN
        RETURN txt;
      END IF;
    END IF;

    -- Generic-style choices[0].message.content[*].text
    IF cr.has('choices') THEN
      DECLARE
        ca   JSON_ARRAY_T := cr.get_array('choices');
        ch   JSON_OBJECT_T;
        msg  JSON_OBJECT_T;
        cont JSON_ARRAY_T;
        i    PLS_INTEGER;
        part JSON_OBJECT_T;
        acc  CLOB := EMPTY_CLOB();
      BEGIN
        IF ca.get_size > 0 THEN
          ch := TREAT(ca.get(0) AS JSON_OBJECT_T);
          IF ch.has('message') THEN
            msg := TREAT(ch.get('message') AS JSON_OBJECT_T);
            IF msg.has('content') THEN
              cont := TREAT(msg.get('content') AS JSON_ARRAY_T);
              i := 0;
              WHILE i < cont.get_size LOOP
                part := TREAT(cont.get(i) AS JSON_OBJECT_T);
                IF part.has('type') AND UPPER(part.get_string('type')) = 'TEXT' THEN
                  acc := acc || part.get_string('text');
                END IF;
                i := i + 1;
              END LOOP;
              IF acc IS NOT NULL AND TRIM(acc) IS NOT NULL THEN
                RETURN acc;
              END IF;
            END IF;
          END IF;
        END IF;
      EXCEPTION WHEN OTHERS THEN
        NULL;
      END;
    END IF;

    -- fallback: sometimes providers put text under output_text
    IF cr.has('output_text') THEN
      txt := cr.get_string('output_text');
    END IF;

    RETURN txt;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20991,
        'Failed to parse chat response: '||SUBSTR(p_json,1,2000));
  END extract_text;

  FUNCTION llm_call_text (
    p_message        IN  CLOB,
    p_model_id       IN  VARCHAR2,
    p_compartment_id IN  VARCHAR2
  ) RETURN CLOB
  AS
    l_region              VARCHAR2(50);
    l_model_cfg_model_id  VARCHAR2(1000);
    l_api_format          VARCHAR2(50);
    l_temperature         NUMBER;
    l_top_p               NUMBER;
    l_top_k               NUMBER;
    l_endpoint            VARCHAR2(1000);
    l_payload             CLOB;
    l_resp                DBMS_CLOUD_TYPES.resp;
    l_body_json           CLOB;
    l_text                CLOB;
  BEGIN
    -- 1) Load model config
    SELECT region, model_id, api_format,
           NVL(temperature,1), NVL(top_p,1), NVL(top_k,1)
      INTO l_region, l_model_cfg_model_id, l_api_format,
           l_temperature, l_top_p, l_top_k
      FROM ai_model_config
     WHERE model_id = p_model_id;

    l_endpoint :=
      'https://inference.generativeai.'||LOWER(l_region)||
      '.oci.oraclecloud.com/20231130/actions/chat';

    -- 2) Build payload (one-turn chat)
    IF UPPER(l_api_format) = 'GENERIC' THEN
      l_payload :=
        JSON_OBJECT(
          'compartmentId' VALUE p_compartment_id,
          'servingMode' VALUE JSON_OBJECT(
            'modelId' VALUE l_model_cfg_model_id,
            'servingType' VALUE 'ON_DEMAND'
          ),
          'chatRequest' VALUE JSON_OBJECT(
            'apiFormat' VALUE 'GENERIC',
            'maxTokens' VALUE 3999,
            'temperature' VALUE l_temperature,
            'topP' VALUE l_top_p,
            'topK' VALUE l_top_k,
            'messages' VALUE JSON_ARRAY(
              JSON_OBJECT(
                'role' VALUE 'USER',
                'content' VALUE JSON_ARRAY(
                  JSON_OBJECT('type' VALUE 'TEXT', 'text' VALUE p_message)
                )
              )
            )
          )
        );
    ELSE
      l_payload :=
        JSON_OBJECT(
          'compartmentId' VALUE p_compartment_id,
          'servingMode' VALUE JSON_OBJECT(
            'modelId' VALUE l_model_cfg_model_id,
            'servingType' VALUE 'ON_DEMAND'
          ),
          'chatRequest' VALUE JSON_OBJECT(
            'apiFormat' VALUE 'COHERE',
            'maxTokens' VALUE 3999,
            'temperature' VALUE l_temperature,
            'topP' VALUE l_top_p,
            'topK' VALUE l_top_k,
            'message' VALUE p_message
          )
        );
    END IF;

    -- 3) Call OCI GenAI endpoint (UTF-8 body)
    l_resp := DBMS_CLOUD.send_request(
      credential_name => 'OCI$RESOURCE_PRINCIPAL',
      uri             => l_endpoint,
      method          => 'POST',
      headers         => JSON_OBJECT('Content-Type' VALUE 'application/json'),
      body            => clob_to_blob_utf8(l_payload)
    );

    l_body_json := DBMS_CLOUD.get_response_text(l_resp);

    -- 4) Robust extraction
    l_text := extract_text(l_body_json);

    IF l_text IS NULL OR TRIM(l_text) IS NULL THEN
      RAISE_APPLICATION_ERROR(-20992,
        'Empty assistant text. Body: '||SUBSTR(l_body_json,1,2000));
    END IF;

    RETURN l_text;
  END llm_call_text;

  ----------------------------------------------------------------------------
  -- DDL summarization + upsert
  ----------------------------------------------------------------------------
  PROCEDURE summarize_ddl_and_upsert
  (
    p_ddl_text        IN  CLOB,
    p_dataset         IN  VARCHAR2,
    p_environment     IN  VARCHAR2,
    p_model_id        IN  VARCHAR2 DEFAULT NULL,
    p_target_table    IN  VARCHAR2 DEFAULT 'CHATBOT_NL2SQL_SUMMARY',
    p_id_sequence     IN  VARCHAR2 DEFAULT NULL,
    p_auto_commit     IN  BOOLEAN  DEFAULT FALSE,
    p_summary_json    OUT CLOB,
    p_summary_row_op  OUT VARCHAR2
  )
  AS
    l_model_id        VARCHAR2(1000);
    l_compartment_id  VARCHAR2(4000);
    l_chat_id         NUMBER := TRUNC(DBMS_RANDOM.value(10000,99999));
    l_app_user        VARCHAR2(128)  := COALESCE(v('APP_USER'), SYS_CONTEXT('USERENV','SESSION_USER'));
    l_app_session     VARCHAR2(4000) := COALESCE(v('APP_SESSION'), 'N/A');

    l_prompt           CLOB;
    l_final_aimessage  CLOB;

    l_json_obj         JSON_OBJECT_T;
    l_table_name       VARCHAR2(256);
    l_summary_text     CLOB;
    l_op               VARCHAR2(10);

    l_table_override   VARCHAR2(256);
  BEGIN
    IF p_ddl_text IS NULL THEN
      RAISE_APPLICATION_ERROR(-20050, 'DDL text is required.');
    END IF;
    IF p_dataset IS NULL OR p_environment IS NULL THEN
      RAISE_APPLICATION_ERROR(-20051, 'DATASET and ENVIRONMENT are required.');
    END IF;

    -- Resolve model/compartment from APP_CONFIG
    DECLARE
      v_model_id_app       VARCHAR2(1000);
      v_compartment_id_app VARCHAR2(4000);
    BEGIN
      BEGIN
        SELECT config_value INTO v_model_id_app
          FROM app_config WHERE UPPER(config_key) = 'MODEL_ID';
      EXCEPTION WHEN NO_DATA_FOUND THEN v_model_id_app := NULL; END;

      BEGIN
        SELECT config_value INTO v_compartment_id_app
          FROM app_config WHERE UPPER(config_key) = 'COMPARTMENT_ID';
      EXCEPTION WHEN NO_DATA_FOUND THEN v_compartment_id_app := NULL; END;

      l_model_id       := COALESCE(p_model_id, v_model_id_app);
      l_compartment_id := v_compartment_id_app;
    END;

    IF l_model_id IS NULL THEN
      RAISE_APPLICATION_ERROR(-20060, 'MODEL_ID is not set (p_model_id is NULL and APP_CONFIG.MODEL_ID missing).');
    END IF;
    IF l_compartment_id IS NULL THEN
      RAISE_APPLICATION_ERROR(-20061, 'COMPARTMENT_ID is not set in APP_CONFIG.');
    END IF;

    -- LLM instruction
    l_prompt := q'[
        You are a precise SQL DDL + metadata summarization engine that converts table definitions
        into a structured JSON description for an NL2SQL router.

        You ALWAYS receive TWO JSON inputs referring to the SAME table:

        1) Create table JSON (structural authority):
          - Table owner/name
          - Optional alias
          - Columns with name + type

        2) Table Description JSON (business-semantics authority, REQUIRED):
          - Table-level "description"
          - Per-column "description" for one or more columns

        You MUST use BOTH inputs. The Description JSON is the PRIMARY source of meaning.

        Your output MUST be ONLY one valid JSON object (no markdown, no code fences, no comments,
        no extra text).

        TARGET JSON SHAPE
        {
          "table_name": "<OWNER>.<TABLE_NAME>",
          "summary": "One detailed sentence (≤1000 chars) describing the table in business terms.",
          "keys": ["<COL>", "..."],
          "metrics": ["<COL>", "..."],
          "attributes": ["<COL>", "..."],
          "column_comments": { "<COL>": "<2–6 word semantic label>", ... },
          "keywords": ["<keyword>", "..."],
          "sample_questions": ["<natural-language question>", "..."]
        }

        GLOBAL RULES
        - Use ONLY columns present in the Create table JSON. Do NOT invent columns.
        - For every column in the Create table JSON, you MUST produce exactly one entry
          in column_comments with the same column name (uppercased).
        - Uppercase all column names in keys, metrics, attributes, and column_comments keys.
        - Use the Table Description JSON as the main semantic source; do not contradict it.
        - When a column has a description, base its classification and comment on that description.
        - When a column has no description, derive meaning only from its name; do not invent
          external business knowledge.
        - Be conservative: if unsure whether something is a key or metric, prefer attributes.
        - Arrays must always be present; use [] if no items.
        - The final output MUST be syntactically valid JSON.

        STEP 1 – table_name
        - Read the table name from the Create table JSON.
        - If it contains OWNER.TABLE, use that form fully uppercased.
        - If owner/schema is missing, use "UNKNOWN.<TABLE_NAME>" (TABLE_NAME uppercased).

        STEP 2 – column_comments (MANDATORY)
        - For EVERY column from the Create table JSON, create a short semantic label
          (2–6 words) describing what it represents.
        - Use the column’s description text when available:
          - Compress the description, do not add new information.
          - Example transformations:
            - "The customer's loyalty number (FFN)" → "customer loyalty number"
            - "flag (1/0) denoting coupon issued via Aegean Pass" → "Aegean Pass promo flag"
            - "the local timezone date on which the coupon flies" → "coupon flight date"
        - If no description exists, infer only from the column name:
          - MEMBERSHIP_TIER → "membership tier"
          - TOTAL_COST → "total cost amount"
        - Do NOT skip any column. Do NOT leave any column without a comment.

        STEP 3 – keys
        - Goal: smallest set of columns that uniquely identifies a row.
        - If a PRIMARY KEY is specified in the DDL, use its columns in declared order.
        - Otherwise infer keys using both name and description:
          - Prefer columns named or described as: key, identifier, id, loyalty number, coupon id,
            fulltrip id, pass id, etc.
          - Name patterns: *_ID, *_NO, *_CODE are strong candidates when descriptions
            confirm they are identifiers.
        - Avoid using dates or metrics as keys unless the description explicitly says they are
          part of the identifier.
        - If there is no reliable identifier, set keys to [].

        STEP 4 – metrics
        - A column is a metric if:
          1) Its data type is numeric (NUMBER, DECIMAL, FLOAT, INTEGER, etc.), AND
          2) Its name or description indicates a quantity, amount, balance, count, rate,
            duration, days, distance, percentage, or monetary value, OR it is a 0/1-style flag
            representing an important business event or state.
        - Use these name/description cues as strong hints: COUNT, AMOUNT, TOTAL, SUM, AVG,
          RATE, SCORE, BALANCE, QUANTITY, VALUE, USAGE, COST, REVENUE, DAYS, DURATION,
          TRIPS, MILES, LEAD_TIME, FLAG when clearly behavioural.
        - Do NOT treat identifiers (IDs, codes) as metrics even if numeric.
        - Do NOT treat dates/timestamps as metrics.
        - When in doubt, classify as attribute, not metric.

        STEP 5 – attributes
        - All columns that are not in keys and not in metrics.
        - Typical attributes:
          - statuses, tiers, segments, markets, channels, products, routes, airports,
            cities, countries, age bands, passenger types, program flags that are not
            core metrics.
          - all date/time columns (enrolment dates, validity, flight dates, first/last usage).
        - Use descriptions to decide; if a column answers “what kind / which category”
          rather than “how much”, it is an attribute.

        STEP 6 – summary (≤1000 chars)
        - Build ONE detailed, information-dense sentence based mainly on:
          - table-level description,
          - key identifiers,
          - the most important metrics and attributes.
        - Clearly state:
          - what entity/population the table stores (e.g., youth loyalty members,
            flight coupons, Aegean Pass products, customer analytics),
          - what aspects are tracked (status, age, revenues, trips, promotions, validity),
          - any important program names (Miles & Bonus, genAIRation, Aegean Pass, etc.),
          - any clear lifecycle/time angle (enrolment, flight date, pass validity, lifetime).
        - Do not list columns; describe the business meaning.

        STEP 7 – keywords
        - Produce 5–15 short business-oriented nouns or noun phrases.
        - Derive directly from table and column descriptions and column_comments.
        - Include:
          - main entity/entities,
          - main processes or programs,
          - key metrics/behaviours,
          - lifecycle/time concepts.
        - Avoid generic filler such as “table”, “data” alone.

        STEP 8 – sample_questions
        - Produce 3–6 realistic natural-language questions that can be answered using THIS
          table alone.
        - Use terminology and codes exactly as in the descriptions (e.g., program names,
          status codes, tiers, age bands).
        - Include a mix of:
          - Aggregated questions (counts, sums, averages) over metrics,
          - Filtered/segmented questions by attributes (tier, status, market, age band, date).
        - Do NOT reference joins or other tables.
        - Each question must be directly answerable with a SELECT over this table.

        FINAL CHECK
        - Ensure every column appears in column_comments.
        - Ensure keys, metrics, and attributes are disjoint sets (a column must not appear
          in more than one of these arrays).
        - Ensure the JSON is syntactically valid and matches the target shape exactly.

        DDL:
        Description:
        ]' || p_ddl_text;

    -- Call package-local LLM helper
    l_final_aimessage := llm_call_text(
      p_message        => l_prompt,
      p_model_id       => l_model_id,
      p_compartment_id => l_compartment_id
    );

    IF l_final_aimessage IS NULL OR TRIM(l_final_aimessage) IS NULL THEN
      RAISE_APPLICATION_ERROR(-20052, 'LLM returned empty content.');
    END IF;

    -- Validate JSON
    DECLARE
      v_dummy NUMBER;
    BEGIN
      SELECT 1 INTO v_dummy FROM dual WHERE l_final_aimessage IS JSON STRICT;
    EXCEPTION WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20053, 'LLM did not return valid JSON.');
    END;

    l_json_obj := JSON_OBJECT_T.parse(l_final_aimessage);

    IF NOT l_json_obj.has('summary')
       OR NOT l_json_obj.has('table_name')
       OR NOT l_json_obj.has('keys')
       OR NOT l_json_obj.has('metrics')
       OR NOT l_json_obj.has('attributes')
    THEN
      RAISE_APPLICATION_ERROR(-20054, 'JSON missing required core fields (summary/table_name/keys/metrics/attributes).');
    END IF;

    -- Optional but highly recommended for ROUTER
    IF NOT l_json_obj.has('keywords') THEN
      -- force an empty array if missing to keep downstream logic simple
      l_json_obj.put('keywords', JSON_ARRAY_T());
    END IF;

    IF NOT l_json_obj.has('sample_questions') THEN
      l_json_obj.put('sample_questions', JSON_ARRAY_T());
    END IF;


    -- Fix table_name if UNKNOWN.<TABLE>
    DECLARE
      v_raw   VARCHAR2(4000);
      v_owner VARCHAR2(128) := UPPER(NVL(SYS_CONTEXT('USERENV','CURRENT_SCHEMA'),'UNKNOWN'));
      v_name  VARCHAR2(4000);
    BEGIN
      v_raw := REGEXP_SUBSTR(p_ddl_text,
              'create\s+table\s+((?:\"?[[:alnum:]_]+\"?\.)?\"?[[:alnum:]_]+\"?)',
              1, 1, 'in', 1);
      v_raw := REPLACE(UPPER(NVL(v_raw,'')),'"','');

      IF v_raw IS NOT NULL THEN
        IF INSTR(v_raw,'.') > 0 THEN
          l_table_override := v_raw;
        ELSE
          l_table_override := v_owner||'.'||v_raw;
        END IF;
      ELSE
        v_name := REPLACE(UPPER(REGEXP_SUBSTR(p_ddl_text,'([[:alnum:]_"]+)\s*\(',1,1,'in',1)),'"','');
        IF v_name IS NOT NULL THEN
          l_table_override := v_owner||'.'||v_name;
        END IF;
      END IF;
    END;

    l_table_name := UPPER(l_json_obj.get_string('table_name'));
    IF l_table_override IS NOT NULL AND l_table_name LIKE 'UNKNOWN.%' THEN
      l_table_name := l_table_override;
    END IF;

    -- Make sure we store the possibly-normalized JSON, not the original text
    l_summary_text := l_json_obj.to_clob();


    -- MERGE into target table
    DECLARE
      l_sql   CLOB;
      l_count INTEGER;
    BEGIN
      IF p_id_sequence IS NULL THEN
        l_sql :=
          'merge into '||p_target_table||' t '||
          'using (select :dataset as dataset, :env as environment, :tname as table_name, '||
          '              systimestamp as last_refreshed, :sumtxt as summary_text from dual) s '||
          'on (t.dataset = s.dataset and t.environment = s.environment and t.table_name = s.table_name) '||
          'when matched then update set t.last_refreshed = s.last_refreshed, t.summary_text = s.summary_text '||
          'when not matched then insert (dataset, environment, table_name, last_refreshed, summary_text) '||
          'values (s.dataset, s.environment, s.table_name, s.last_refreshed, s.summary_text)';
        EXECUTE IMMEDIATE l_sql USING p_dataset, p_environment, l_table_name, l_summary_text;
      ELSE
        l_sql :=
          'merge into '||p_target_table||' t '||
          'using (select :dataset as dataset, :env as environment, :tname as table_name, '||
          '              systimestamp as last_refreshed, :sumtxt as summary_text from dual) s '||
          'on (t.dataset = s.dataset and t.environment = s.environment and t.table_name = s.table_name) '||
          'when matched then update set t.last_refreshed = s.last_refreshed, t.summary_text = s.summary_text '||
          'when not matched then insert (id, dataset, environment, table_name, last_refreshed, summary_text) '||
          'values ('||p_id_sequence||'.nextval, s.dataset, s.environment, s.table_name, s.last_refreshed, s.summary_text)';
        EXECUTE IMMEDIATE l_sql USING p_dataset, p_environment, l_table_name, l_summary_text;
      END IF;

      -- detect op (insert vs update)
      l_sql :=
        'select count(*) from '||p_target_table||
        ' where dataset = :1 and environment = :2 and table_name = :3'||
        '   and last_refreshed >= systimestamp - interval ''1'' minute';
      EXECUTE IMMEDIATE l_sql INTO l_count USING p_dataset, p_environment, l_table_name;
      l_op := CASE WHEN l_count = 1 THEN 'UPDATE' ELSE 'INSERT' END;
    END;

    p_summary_json   := l_summary_text;
    p_summary_row_op := l_op;

    IF p_auto_commit THEN COMMIT; END IF;
  END summarize_ddl_and_upsert;

END CHATBOT_JSON_CONVERTER_PKG;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "CHATBOT_ROUTER_PKG" AS

  -- Normalize owner.table
  FUNCTION norm_table(p IN VARCHAR2) RETURN VARCHAR2;

  -- Parse router tables
  FUNCTION parse_router_tables(p_json CLOB)
    RETURN SYS.ODCIVARCHAR2LIST;

  -- Build router catalog
  FUNCTION build_router_catalog(
    p_ctx    IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_tables IN SYS.ODCIVARCHAR2LIST
  ) RETURN CLOB;

  -- Get authored schema chunks (matches your CORE SQL version)
  FUNCTION get_schema_for_table(
    p_ctx   IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_table IN VARCHAR2
  ) RETURN CLOB;

  -- Get authored table description chunks (matches your CORE SQL version)
  FUNCTION get_desc_for_table(
    p_ctx   IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_table IN VARCHAR2
  ) RETURN CLOB;

  -- Prefilter table candidates (token/summaries/column boost)
  FUNCTION prefilter_table_candidates(
    p_ctx      IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_question IN CLOB,
    p_k        IN NUMBER   DEFAULT 12,
    p_req_id   IN VARCHAR2 DEFAULT NULL,
    p_log_id   IN NUMBER   DEFAULT NULL,
    p_chat_id  IN NUMBER   DEFAULT NULL
  ) RETURN SYS.ODCIVARCHAR2LIST;

  -- LLM table router (matches your CORE SQL pattern)
  FUNCTION route_tables(
    p_ctx            IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_question       IN CLOB,
    p_candidates     IN SYS.ODCIVARCHAR2LIST,
    p_req_id         IN VARCHAR2,
    p_log_id         IN NUMBER,
    p_chat_id        IN NUMBER,
    p_api_format     IN VARCHAR2,
    p_model_id       IN VARCHAR2,
    p_compartment_id IN VARCHAR2,
    p_temperature    IN NUMBER,
    p_top_p          IN NUMBER,
    p_top_k          IN NUMBER,
    p_endpoint       IN VARCHAR2
  ) RETURN CLOB;

  -- Business glossar
  FUNCTION get_glossary_hints(
    p_ctx      IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_question IN CLOB
  ) RETURN CLOB;

  FUNCTION build_glossary_json (
    p_ctx IN chatbot_core_ctx_params_pkg.run_ctx_t
  ) RETURN CLOB;

END CHATBOT_ROUTER_PKG;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "CHATBOT_ROUTER_PKG" AS

  -----------------------------------------------------------------------------
  -- Normalize owner.table
  -----------------------------------------------------------------------------
  FUNCTION norm_table(p IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN UPPER(
             REGEXP_REPLACE(
               p,
               '^\s*"?([^".]+)"?\."?([^".]+)"?\s*$',
               '\1.\2'
             )
           );
  END norm_table;

  -----------------------------------------------------------------------------
  -- Helper: stringify table list for logging
  -----------------------------------------------------------------------------
  FUNCTION join_table_list(p_list sys.odcivarchar2list) RETURN VARCHAR2 IS
    l_res VARCHAR2(32767) := NULL;
  BEGIN
    IF p_list IS NULL THEN
      RETURN NULL;
    END IF;

    FOR i IN 1 .. p_list.COUNT LOOP
      IF l_res IS NULL THEN
        l_res := p_list(i);
      ELSE
        l_res := l_res || ',' || p_list(i);
      END IF;
    END LOOP;

    RETURN l_res;
  END join_table_list;


  -----------------------------------------------------------------------------
  -- Parse router tables
  -----------------------------------------------------------------------------
  FUNCTION parse_router_tables(p_json CLOB)
    RETURN sys.odcivarchar2list
  IS
    l_res sys.odcivarchar2list := sys.odcivarchar2list();
    j     json_object_t;
    a     json_array_t;
  BEGIN
    IF p_json IS NULL THEN
      RETURN l_res;
    END IF;

    j := json_object_t.parse(p_json);
    a := j.get_array('tables');

    FOR i IN 0 .. a.get_size - 1 LOOP
      l_res.EXTEND;
      l_res(l_res.COUNT) := a.get_string(i);
    END LOOP;

    RETURN l_res;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_res;
  END parse_router_tables;

  -----------------------------------------------------------------------------
  -- Build router catalog
  -----------------------------------------------------------------------------
  FUNCTION build_router_catalog(
        p_ctx    IN chatbot_core_ctx_params_pkg.run_ctx_t,
        p_tables IN sys.odcivarchar2list
    ) RETURN CLOB
  IS
    l_out CLOB;
  BEGIN
    IF p_tables IS NULL OR p_tables.COUNT = 0 THEN
      RETURN NULL;
    END IF;

    DBMS_LOB.CREATETEMPORARY(l_out, TRUE);

    FOR i IN 1 .. p_tables.COUNT LOOP
      FOR r IN (
        SELECT s.table_name,

              /* Base summary: prefer JSON $.summary, else legacy plain text */
              CASE
                WHEN JSON_EXISTS(s.summary_text, '$.summary') THEN
                  TO_CLOB(JSON_VALUE(s.summary_text, '$.summary' RETURNING VARCHAR2(4000)))
                WHEN s.summary_text IS NOT NULL THEN
                  -- fall back to first 4000 chars of legacy plain text
                  TO_CLOB(DBMS_LOB.SUBSTR(s.summary_text, 4000, 1))
                ELSE
                  TO_CLOB('')
              END AS summary_line,

              /* Optional: JSON arrays → comma-separated lists (keys / metrics / attributes / keywords) */
              CASE
                WHEN JSON_EXISTS(s.summary_text, '$.keys') THEN
                  REPLACE(
                    REPLACE(
                      REGEXP_REPLACE(
                        JSON_QUERY(s.summary_text, '$.keys' RETURNING VARCHAR2(4000)),
                        '^\[|\]$'
                      ),
                      '"'
                    ),
                    ',', ', '
                  )
              END AS keys_list,

              CASE
                WHEN JSON_EXISTS(s.summary_text, '$.metrics') THEN
                  REPLACE(
                    REPLACE(
                      REGEXP_REPLACE(
                        JSON_QUERY(s.summary_text, '$.metrics' RETURNING VARCHAR2(4000)),
                        '^\[|\]$'
                      ),
                      '"'
                    ),
                    ',', ', '
                  )
              END AS metrics_list,

              CASE
                WHEN JSON_EXISTS(s.summary_text, '$.attributes') THEN
                  REPLACE(
                    REPLACE(
                      REGEXP_REPLACE(
                        JSON_QUERY(s.summary_text, '$.attributes' RETURNING VARCHAR2(4000)),
                        '^\[|\]$'
                      ),
                      '"'
                    ),
                    ',', ', '
                  )
              END AS attributes_list,

              CASE
                WHEN JSON_EXISTS(s.summary_text, '$.keywords') THEN
                  REPLACE(
                    REPLACE(
                      REGEXP_REPLACE(
                        JSON_QUERY(s.summary_text, '$.keywords' RETURNING VARCHAR2(4000)),
                        '^\[|\]$'
                      ),
                      '"'
                    ),
                    ',', ', '
                  )
              END AS keywords_list,

              /* Optional: column_comments object → compact "COL:desc, COL:desc, ..." text (truncated) */
              CASE
                WHEN JSON_EXISTS(s.summary_text, '$.column_comments') THEN
                  REPLACE(
                    REGEXP_REPLACE(
                      DBMS_LOB.SUBSTR(
                        JSON_QUERY(s.summary_text, '$.column_comments' RETURNING CLOB),
                        2000, 1
                      ),
                      '^\{|\}$'
                    ),
                    '"'
                  )
              END AS column_comments_text

          FROM chatbot_nl2sql_summary s
        WHERE s.table_name = norm_table(p_tables(i))  -- normalize OWNER.TABLE
          AND (s.dataset     IN (p_ctx.dataset, '#')     OR s.dataset     IS NULL)
          AND (s.environment IN (p_ctx.environment, '#') OR s.environment IS NULL)
        FETCH FIRST 1 ROW ONLY
      ) LOOP
        DBMS_LOB.APPEND(l_out, TO_CLOB('- '));
        DBMS_LOB.APPEND(l_out, TO_CLOB(r.table_name));
        DBMS_LOB.APPEND(l_out, TO_CLOB(': '));
        DBMS_LOB.APPEND(l_out, r.summary_line);

        IF r.keys_list IS NOT NULL THEN
          DBMS_LOB.APPEND(l_out, TO_CLOB(' Keys: ' || r.keys_list));
        END IF;

        IF r.metrics_list IS NOT NULL THEN
          DBMS_LOB.APPEND(l_out, TO_CLOB(' Metrics: ' || r.metrics_list));
        END IF;

        IF r.attributes_list IS NOT NULL THEN
          DBMS_LOB.APPEND(l_out, TO_CLOB(' Attributes: ' || r.attributes_list));
        END IF;

        IF r.keywords_list IS NOT NULL THEN
          DBMS_LOB.APPEND(l_out, TO_CLOB(' Keywords: ' || r.keywords_list));
        END IF;

        IF r.column_comments_text IS NOT NULL THEN
          DBMS_LOB.APPEND(l_out, TO_CLOB(' Column details: ' || r.column_comments_text));
        END IF;

        DBMS_LOB.APPEND(l_out, TO_CLOB(CHR(10)));
      END LOOP;
    END LOOP;

    RETURN chatbot_core_io_pkg.clamp_clob(l_out, 32000);

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        IF l_out IS NOT NULL AND DBMS_LOB.ISTEMPORARY(l_out) = 1 THEN
          DBMS_LOB.FREETEMPORARY(l_out);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN NULL;
      END;
      RAISE;
  END build_router_catalog;


  -----------------------------------------------------------------------------
  -- Get authored schema chunks
  -----------------------------------------------------------------------------
  FUNCTION get_schema_for_table(
    p_ctx   IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_table IN VARCHAR2
  ) RETURN CLOB
  IS
    l_out   CLOB;
    l_owner VARCHAR2(128);
    l_tab   VARCHAR2(128);
    l_full  VARCHAR2(261);
  BEGIN
    l_full  := norm_table(p_table); -- UPPER(OWNER.TAB)
    l_owner := REGEXP_SUBSTR(l_full, '^([^\.]+)', 1, 1, 'i');
    l_tab   := REGEXP_SUBSTR(l_full, '([^\.]+)$', 1, 1, 'i');

    FOR r IN (
      SELECT p.content,
             NVL( TO_NUMBER(JSON_VALUE(h.head, '$.order' RETURNING VARCHAR2)), p.id ) AS ord,
             CASE
               WHEN p.dataset = p_ctx.dataset AND p.environment = p_ctx.environment THEN 1
               WHEN p.dataset = p_ctx.dataset AND p.environment IS NULL            THEN 2
               WHEN p.dataset IS NULL        AND p.environment = p_ctx.environment THEN 3
               WHEN p.dataset IS NULL        AND p.environment IS NULL             THEN 4
               ELSE 9
             END AS rnk
        FROM chatbot_parameters p
        CROSS APPLY (
          SELECT REGEXP_SUBSTR(DBMS_LOB.SUBSTR(p.content, 4000, 1), '^\s*\{.*?\}', 1, 1, 'n') AS head
          FROM dual
        ) h
      WHERE p.component_type = 'SCHEMA'
        AND p.active = 'TRUE'
        AND (p.dataset = p_ctx.dataset OR p.dataset IS NULL)
        AND (p.environment = p_ctx.environment OR p.environment IS NULL)
        AND UPPER(JSON_VALUE(h.head, '$.table' RETURNING VARCHAR2)) = l_full
      ORDER BY rnk, ord
    ) LOOP
      EXIT WHEN r.rnk >= 9;
      IF l_out IS NULL THEN DBMS_LOB.createtemporary(l_out, TRUE); END IF;
      DBMS_LOB.append(l_out, r.content||CHR(10)||CHR(10));
    END LOOP;

    RETURN l_out;
  END get_schema_for_table;

  -----------------------------------------------------------------------------
  -- Get authored table description chunks
  -----------------------------------------------------------------------------
  FUNCTION get_desc_for_table(
    p_ctx   IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_table IN VARCHAR2
  ) RETURN CLOB
  IS
    l_out   CLOB;
    l_owner VARCHAR2(128);
    l_tab   VARCHAR2(128);
    l_full  VARCHAR2(261);
  BEGIN
    l_full  := norm_table(p_table); -- UPPER(OWNER.TAB)
    l_owner := REGEXP_SUBSTR(l_full, '^([^\.]+)', 1, 1, 'i');
    l_tab   := REGEXP_SUBSTR(l_full, '([^\.]+)$', 1, 1, 'i');

    FOR r IN (
      SELECT p.content,
             NVL( TO_NUMBER(JSON_VALUE(h.head, '$.order' RETURNING VARCHAR2)), p.id ) AS ord,
             CASE
               WHEN p.dataset = p_ctx.dataset AND p.environment = p_ctx.environment THEN 1
               WHEN p.dataset = p_ctx.dataset AND p.environment IS NULL            THEN 2
               WHEN p.dataset IS NULL        AND p.environment = p_ctx.environment THEN 3
               WHEN p.dataset IS NULL        AND p.environment IS NULL             THEN 4
               ELSE 9
             END AS rnk
        FROM chatbot_parameters p
        CROSS APPLY (
          SELECT REGEXP_SUBSTR(DBMS_LOB.SUBSTR(p.content, 4000, 1), '^\s*\{.*?\}', 1, 1, 'n') AS head
          FROM dual
        ) h
      WHERE p.component_type = 'TABLE_DESCRIPTIONS'
        AND p.active = 'TRUE'
        AND (p.dataset = p_ctx.dataset OR p.dataset IS NULL)
        AND (p.environment = p_ctx.environment OR p.environment IS NULL)
        AND UPPER(JSON_VALUE(h.head, '$.table' RETURNING VARCHAR2)) = l_full
      ORDER BY rnk, ord
    ) LOOP
      EXIT WHEN r.rnk >= 9;
      IF l_out IS NULL THEN DBMS_LOB.createtemporary(l_out, TRUE); END IF;
      DBMS_LOB.append(l_out, r.content||CHR(10)||CHR(10));
    END LOOP;

    RETURN l_out;
  END get_desc_for_table;

  -----------------------------------------------------------------------------
  -- Prefilter table candidates
  -----------------------------------------------------------------------------
  FUNCTION prefilter_table_candidates(
    p_ctx      IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_question IN CLOB,
    p_k        IN NUMBER   DEFAULT 12,
    p_req_id   IN VARCHAR2 DEFAULT NULL,
    p_log_id   IN NUMBER   DEFAULT NULL,
    p_chat_id  IN NUMBER   DEFAULT NULL
  ) RETURN sys.odcivarchar2list
  IS
    l_res   sys.odcivarchar2list := sys.odcivarchar2list();
    l_limit NUMBER := LEAST(NVL(p_k,12),20);
    toks    sys.odcivarchar2list := chatbot_core_sql_pkg.to_tokens(TO_CHAR(p_question), 20);
    t1 VARCHAR2(64); t2 VARCHAR2(64); t3 VARCHAR2(64); t4 VARCHAR2(64);
    t5 VARCHAR2(64); t6 VARCHAR2(64); t7 VARCHAR2(64); t8 VARCHAR2(64);
  BEGIN
    IF toks IS NULL OR toks.COUNT = 0 THEN
      RETURN l_res;
    END IF;

    IF chatbot_core_io_pkg.debug_on(p_ctx) THEN
      chatbot_core_io_pkg.logc(
        p_ctx, 'ROUTER', p_req_id,
        'Router input (prefilter tokens)',
        TO_CLOB('Tokens='||chatbot_core_sql_pkg.listagg_token_debug(toks)),
        p_log_id, p_chat_id
      );
    END IF;

    IF toks.COUNT >= 1 THEN t1 := toks(1); END IF;
    IF toks.COUNT >= 2 THEN t2 := toks(2); END IF;
    IF toks.COUNT >= 3 THEN t3 := toks(3); END IF;
    IF toks.COUNT >= 4 THEN t4 := toks(4); END IF;
    IF toks.COUNT >= 5 THEN t5 := toks(5); END IF;
    IF toks.COUNT >= 6 THEN t6 := toks(6); END IF;
    IF toks.COUNT >= 7 THEN t7 := toks(7); END IF;
    IF toks.COUNT >= 8 THEN t8 := toks(8); END IF;

    FOR r IN (
      SELECT s.table_name,
             (
               (CASE WHEN t1 IS NOT NULL AND INSTR(UPPER(NVL(s.summary_text,'')), t1) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t2 IS NOT NULL AND INSTR(UPPER(NVL(s.summary_text,'')), t2) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t3 IS NOT NULL AND INSTR(UPPER(NVL(s.summary_text,'')), t3) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t4 IS NOT NULL AND INSTR(UPPER(NVL(s.summary_text,'')), t4) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t5 IS NOT NULL AND INSTR(UPPER(NVL(s.summary_text,'')), t5) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t6 IS NOT NULL AND INSTR(UPPER(NVL(s.summary_text,'')), t6) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t7 IS NOT NULL AND INSTR(UPPER(NVL(s.summary_text,'')), t7) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t8 IS NOT NULL AND INSTR(UPPER(NVL(s.summary_text,'')), t8) > 0 THEN 1 ELSE 0 END)
             ) * 2
             +
             (
               (CASE WHEN t1 IS NOT NULL AND INSTR(UPPER(s.table_name), t1) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t2 IS NOT NULL AND INSTR(UPPER(s.table_name), t2) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t3 IS NOT NULL AND INSTR(UPPER(s.table_name), t3) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t4 IS NOT NULL AND INSTR(UPPER(s.table_name), t4) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t5 IS NOT NULL AND INSTR(UPPER(s.table_name), t5) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t6 IS NOT NULL AND INSTR(UPPER(s.table_name), t6) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t7 IS NOT NULL AND INSTR(UPPER(s.table_name), t7) > 0 THEN 1 ELSE 0 END) +
               (CASE WHEN t8 IS NOT NULL AND INSTR(UPPER(s.table_name), t8) > 0 THEN 1 ELSE 0 END)
             )
             +
             (
               SELECT COUNT(*)
                 FROM all_tab_columns c
                WHERE c.table_name = UPPER(s.table_name)
                  AND (
                    (t1 IS NOT NULL AND INSTR(UPPER(c.column_name), t1) > 0) OR
                    (t2 IS NOT NULL AND INSTR(UPPER(c.column_name), t2) > 0) OR
                    (t3 IS NOT NULL AND INSTR(UPPER(c.column_name), t3) > 0) OR
                    (t4 IS NOT NULL AND INSTR(UPPER(c.column_name), t4) > 0) OR
                    (t5 IS NOT NULL AND INSTR(UPPER(c.column_name), t5) > 0) OR
                    (t6 IS NOT NULL AND INSTR(UPPER(c.column_name), t6) > 0) OR
                    (t7 IS NOT NULL AND INSTR(UPPER(c.column_name), t7) > 0) OR
                    (t8 IS NOT NULL AND INSTR(UPPER(c.column_name), t8) > 0)
                  )
             ) AS score
        FROM chatbot_nl2sql_summary s
       WHERE (s.dataset IN (p_ctx.dataset,'#') OR s.dataset IS NULL)
         AND (s.environment IN (p_ctx.environment,'#') OR s.environment IS NULL)
       ORDER BY score DESC, s.table_name
       FETCH FIRST l_limit ROWS ONLY
    ) LOOP
      l_res.EXTEND; l_res(l_res.COUNT) := r.table_name;
    END LOOP;

    IF l_res.COUNT = 0 THEN
      FOR r2 IN (
        SELECT table_name
          FROM chatbot_nl2sql_summary s
         WHERE (s.dataset IN (p_ctx.dataset,'#') OR s.dataset IS NULL)
           AND (s.environment IN (p_ctx.environment,'#') OR s.environment IS NULL)
         ORDER BY table_name
         FETCH FIRST l_limit ROWS ONLY
      ) LOOP
        l_res.EXTEND; l_res(l_res.COUNT) := r2.table_name;
      END LOOP;

      IF chatbot_core_io_pkg.debug_on(p_ctx) THEN
        chatbot_core_io_pkg.logc(
          p_ctx, 'ROUTER', p_req_id,
          'Router input (prefilter fallback)',
          TO_CLOB('Prefilter fallback: returned '||l_res.COUNT||' unscored tables.'),
          p_log_id, p_chat_id
        );
      END IF;
    END IF;

    RETURN l_res;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_res;
  END prefilter_table_candidates;

  -----------------------------------------------------------------------------
  -- Build business glossary JSON
  -----------------------------------------------------------------------------
  FUNCTION build_glossary_json (
    p_ctx IN chatbot_core_ctx_params_pkg.run_ctx_t
  ) RETURN CLOB
  IS
    l_root    json_object_t := json_object_t();
    l_rules   json_array_t  := json_array_t();
    l_rule_o  json_object_t;
    l_kw_arr  json_array_t;
    l_target  json_object_t;
    l_fr_obj  json_object_t;
  BEGIN
    FOR r IN (
      SELECT *
      FROM   CHATBOT_GLOSSARY_RULES g
      WHERE  g.active = 'TRUE'
         AND (g.dataset     = p_ctx.dataset     OR g.dataset     IS NULL)
         AND (g.environment = p_ctx.environment OR g.environment IS NULL)
      ORDER BY NVL(g.priority, 0) DESC, g.id
    ) LOOP
      l_rule_o := json_object_t();

      l_kw_arr := json_array_t();
      FOR k IN (
        SELECT keyword
        FROM   CHATBOT_GLOSSARY_KEYWORDS kw
        WHERE  kw.rule_id = r.id
        ORDER BY kw.ord
      ) LOOP
        l_kw_arr.append(k.keyword);
      END LOOP;
      l_rule_o.put('keywords', l_kw_arr);

      IF r.match_mode IS NOT NULL THEN
        l_rule_o.put('match_mode', LOWER(r.match_mode));
      END IF;

      IF r.role IS NOT NULL THEN
        l_rule_o.put('role', r.role);
      END IF;

      IF r.priority IS NOT NULL THEN
        l_rule_o.put('priority', r.priority);
      END IF;

      IF r.description IS NOT NULL THEN
        l_rule_o.put('description', r.description);
      END IF;

      IF r.target_table IS NOT NULL THEN
        l_target := json_object_t();
        l_target.put('table', r.target_table);

        IF r.target_column IS NOT NULL THEN
          l_target.put('column', r.target_column);
        END IF;

        IF r.target_role IS NOT NULL THEN
          l_target.put('role', r.target_role);
        END IF;

        IF r.target_filter IS NOT NULL THEN
          BEGIN
            l_target.put('filter', json_object_t.parse(r.target_filter));
          EXCEPTION
            WHEN OTHERS THEN NULL;
          END;
        END IF;

        l_rule_o.put('target', l_target);
      END IF;

      IF r.filter_rule IS NOT NULL THEN
        BEGIN
          l_fr_obj := json_object_t.parse(r.filter_rule);
          l_rule_o.put('filter_rule', l_fr_obj);
        EXCEPTION
          WHEN OTHERS THEN NULL;
        END;
      END IF;

      l_rules.append(l_rule_o);
    END LOOP;

    IF l_rules.get_size = 0 THEN
      RETURN NULL;
    END IF;

    l_root.put('rules', l_rules);
    RETURN l_root.to_clob();
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END build_glossary_json;

  -----------------------------------------------------------------------------
  -- Business glossary: build hints for the router + reasoning prompts
  -- Returns the raw JSON rules (one per matched rule, separated by blank lines)
  -----------------------------------------------------------------------------
  FUNCTION get_glossary_hints(
    p_ctx      IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_question IN CLOB
  ) RETURN CLOB
  IS
    l_glossary   CLOB;
    l_root       json_object_t;
    l_rules      json_array_t;
    l_rule       json_object_t;
    l_keywords   json_array_t;
    l_hint       CLOB;
    l_qtext      VARCHAR2(4000);
    l_match_mode VARCHAR2(20);
    l_desc       VARCHAR2(4000);
    l_kw         VARCHAR2(200);
    l_kw_list    VARCHAR2(1000);
    l_matched    BOOLEAN;
    l_primary_kw VARCHAR2(200);
    i            PLS_INTEGER;
    k            PLS_INTEGER;
  BEGIN
    -- Build glossary JSON from tables
    BEGIN
      l_glossary := build_glossary_json(p_ctx);
    EXCEPTION
      WHEN OTHERS THEN
        l_glossary := NULL;
    END;

    IF l_glossary IS NULL THEN
      RETURN NULL;
    END IF;

    -- Normalize question once (uppercase, single line)
    l_qtext := UPPER(
                 chatbot_core_io_pkg.one_line(
                   chatbot_core_io_pkg.clamp_clob(p_question, 600)
                 )
               );

    l_root  := json_object_t.parse(l_glossary);
    l_rules := l_root.get_array('rules');

    IF l_rules IS NULL OR l_rules.get_size = 0 THEN
      RETURN NULL;
    END IF;

    DBMS_LOB.createtemporary(l_hint, TRUE);

    FOR i IN 0 .. l_rules.get_size - 1 LOOP
      l_rule := TREAT(l_rules.get(i) AS json_object_t);

      l_keywords   := NULL;
      l_match_mode := 'ANY';
      l_desc       := NULL;
      l_kw_list    := NULL;
      l_matched    := FALSE;
      l_primary_kw := NULL;

      BEGIN
        l_keywords := l_rule.get_array('keywords');
      EXCEPTION
        WHEN OTHERS THEN
          l_keywords := NULL;
      END;

      l_match_mode := UPPER(NVL(l_rule.get_string('match_mode'), 'ANY'));
      l_desc       := NVL(l_rule.get_string('description'), '');

      IF l_keywords IS NULL THEN
        CONTINUE;
      END IF;

      ----------------------------------------------------------------------
      -- Keyword matching (ANY / ALL) with word boundaries for ALL keywords
      ----------------------------------------------------------------------
      DECLARE
        l_any_hit  BOOLEAN := FALSE;
        l_all_ok   BOOLEAN := TRUE;
        l_has_kw   BOOLEAN := FALSE;
        l_hit      BOOLEAN;
        l_pattern  VARCHAR2(4000);
        l_kw_sing  VARCHAR2(200);
      BEGIN
        FOR k IN 0 .. l_keywords.get_size - 1 LOOP
          l_kw := UPPER(NVL(l_keywords.get_string(k), ''));
          IF l_kw IS NULL OR l_kw = '' THEN
            CONTINUE;
          END IF;

          l_has_kw := TRUE;
          l_hit    := FALSE;

          IF LENGTH(l_kw) <= 3 THEN
            -- Short keywords: strict whole-word match (no plural flexibility)
            l_pattern := '(^|[^A-Z0-9])' || l_kw || '([^A-Z0-9]|$)';
          ELSE
            -- Longer keywords:
            -- 1) Strip a trailing S from the glossary keyword (base form).
            -- 2) Require a word boundary at the start (no matches inside other words).
            -- 3) Allow optional S and extra trailing letters/digits in the question,
            --    so shorter glossary phrases match longer question words.
            --    e.g. glossary: "3RD SPEC"  → question: "3RD SPECIFICATION"
            --         glossary: "3RD SPECIFICATIONS" ↔ question: "3RD SPECIFICATION"
            l_kw_sing := l_kw;
            IF SUBSTR(l_kw_sing, -1) = 'S' THEN
              l_kw_sing := SUBSTR(l_kw_sing, 1, LENGTH(l_kw_sing) - 1);
            END IF;

            l_pattern :=
              '(^|[^A-Z0-9])' ||   -- word boundary at start
              l_kw_sing        ||   -- base form from glossary
              'S?[A-Z0-9]*'    ||   -- optional S + trailing letters/digits
              '([^A-Z0-9]|$)';      -- word boundary at end
          END IF;

          IF REGEXP_INSTR(l_qtext, l_pattern) > 0 THEN
            l_hit := TRUE;
          END IF;

          IF l_hit THEN
            l_any_hit := TRUE;

            IF l_kw_list IS NULL THEN
              l_kw_list := l_kw;
            ELSE
              l_kw_list := l_kw_list || ', ' || l_kw;
            END IF;

            IF l_primary_kw IS NULL THEN
              l_primary_kw := l_kw;
            END IF;
          ELSE
            l_all_ok := FALSE;
          END IF;
        END LOOP;

        IF l_match_mode = 'ANY' THEN
          l_matched := l_any_hit;
        ELSIF l_match_mode = 'ALL' THEN
          l_matched := (l_has_kw AND l_all_ok);
        ELSE
          l_matched := l_any_hit;
        END IF;
      END;

      IF NOT l_matched THEN
        CONTINUE;
      END IF;

      ----------------------------------------------------------------------
      -- At this point the rule is matched → materialize matched_keyword
      -- so downstream REASONING does not need to re-resolve templates.
      ----------------------------------------------------------------------
      BEGIN
        -- Attach resolved keyword
        IF l_primary_kw IS NOT NULL THEN
          l_rule.put('matched_keyword', l_primary_kw);
        END IF;

        -- If target.filter.value contains %{matched_keyword}%, expand it now
        DECLARE
          l_target json_object_t;
          l_filt   json_object_t;
          l_val    VARCHAR2(4000);
        BEGIN
          l_target := TREAT(l_rule.get('target') AS json_object_t);
          IF l_target IS NOT NULL THEN
            l_filt := TREAT(l_target.get('filter') AS json_object_t);
            IF l_filt IS NOT NULL THEN
              l_val := l_filt.get_string('value');
              IF l_val IS NOT NULL
                 AND l_primary_kw IS NOT NULL
                 AND INSTR(l_val, '{matched_keyword}') > 0
              THEN
                l_filt.put('value', REPLACE(l_val, '{matched_keyword}', l_primary_kw));
                l_target.put('filter', l_filt);
                l_rule.put('target', l_target);
              END IF;
            END IF;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN NULL;
        END;
      EXCEPTION
        WHEN OTHERS THEN NULL;
      END;

      DBMS_LOB.append(
        l_hint,
        chatbot_core_io_pkg.clamp_clob(l_rule.to_clob, 1000)
      );
      DBMS_LOB.append(l_hint, TO_CLOB(CHR(10)||CHR(10)));

    END LOOP; -- rules

    IF l_hint IS NULL OR DBMS_LOB.getlength(l_hint) = 0 THEN
      RETURN NULL;
    END IF;

    RETURN chatbot_core_io_pkg.clamp_clob(l_hint, 20000);

  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END get_glossary_hints;

  -----------------------------------------------------------------------------
  -- LLM table router 
  -----------------------------------------------------------------------------
  FUNCTION route_tables(
    p_ctx              IN chatbot_core_ctx_params_pkg.run_ctx_t,
    p_question         IN CLOB,
    p_candidates       IN sys.odcivarchar2list,
    p_req_id           IN VARCHAR2,
    p_log_id           IN NUMBER,
    p_chat_id          IN NUMBER,
    p_api_format       IN VARCHAR2,
    p_model_id         IN VARCHAR2,
    p_compartment_id   IN VARCHAR2,
    p_temperature      IN NUMBER,
    p_top_p            IN NUMBER,
    p_top_k            IN NUMBER,
    p_endpoint         IN VARCHAR2
  ) RETURN CLOB
  IS
    l_catalog        CLOB := build_router_catalog(p_ctx, p_candidates);
    l_glossary_hints CLOB := get_glossary_hints(p_ctx, p_question);
    l_joins          CLOB;
    l_prompt         CLOB;
    l_payload        CLOB;
    l_resp           CLOB;
    l_text           CLOB;
    l_router_sys     CLOB := chatbot_core_ctx_params_pkg.load_component(p_ctx, 'ROUTER_SYSTEM');
    l_router_fallback CONSTANT CLOB := TO_CLOB(
      'You are a SQL table router. Given a user question and candidate tables with brief summaries,'||CHR(10)||
      'choose the minimal set of tables and the likely join pairs. Output STRICT JSON only.'||CHR(10)||
      '{"tables":["OWNER.TAB1","OWNER.TAB2"], "joins":[{"left":"OWNER.TAB1.COL","right":"OWNER.TAB2.COL","type":"inner"}], "reason":"..."}'
    );
  BEGIN
    IF chatbot_core_io_pkg.debug_on(p_ctx) THEN
      chatbot_core_io_pkg.logc(
        p_ctx, 'ROUTER', p_req_id,
        'Router input',
        TO_CLOB(
          'candidates='||NVL(join_table_list(p_candidates),'(none)')
          ||'; question='||
          chatbot_core_io_pkg.one_line(
            chatbot_core_io_pkg.clamp_clob(p_question, 600)
          )
        ),
        p_log_id, p_chat_id
      );
    END IF;

    IF l_catalog IS NULL THEN
      chatbot_core_io_pkg.logc(
        p_ctx, 'ROUTER', p_req_id,
        'Router catalog',
        TO_CLOB('Router: catalog is NULL (no candidates or no summaries).'),
        p_log_id, p_chat_id
      );
      RETURN '{"tables":[],"joins":[],"reason":"no_catalog"}';
    END IF;

    IF chatbot_core_io_pkg.debug_on(p_ctx) THEN
      chatbot_core_io_pkg.logc(
        p_ctx, 'ROUTER', p_req_id,
        'Router catalog length',
        TO_CLOB(
          'Catalog length='||
          CASE WHEN l_catalog IS NULL THEN 0 ELSE DBMS_LOB.getlength(l_catalog) END
        ),
        p_log_id, p_chat_id
      );
    END IF;

    l_joins := chatbot_core_ctx_params_pkg.load_component(p_ctx, 'TABLE_JOINS');

    l_prompt :=
         NVL(chatbot_core_io_pkg.clamp_clob(l_router_sys, 4000), l_router_fallback)
      || CHR(10) || 'Question: '
      || chatbot_core_io_pkg.one_line(chatbot_core_io_pkg.clamp_clob(p_question, 600))
      || CHR(10) || 'Candidates:' || CHR(10) || l_catalog;

    IF l_glossary_hints IS NOT NULL THEN
      l_prompt := l_prompt
                  || CHR(10) || 'Business glossary hints:' || CHR(10)
                  || l_glossary_hints;
    END IF;

    IF l_joins IS NOT NULL THEN
      IF chatbot_core_io_pkg.debug_on(p_ctx) THEN
        chatbot_core_io_pkg.logc(
          p_ctx, 'ROUTER', p_req_id,
          'Router TABLE_JOINS length',
          TO_CLOB(
            'TABLE_JOINS length='||
            CASE WHEN l_joins IS NULL THEN 0 ELSE DBMS_LOB.getlength(l_joins) END
          ),
          p_log_id, p_chat_id
        );
      END IF;

      l_prompt := l_prompt
                  || CHR(10) || 'Join metadata (TABLE_JOINS):' || CHR(10)
                  || chatbot_core_io_pkg.clamp_clob(l_joins, 4000);
    END IF;

    l_payload := chatbot_core_io_pkg.build_payload_chat(
                   p_api_format, p_model_id, p_compartment_id, l_prompt,
                   0 /*temperature*/, 1 /*top_p*/, 1 /*top_k*/
                 );

    l_resp := chatbot_core_io_pkg.call_model(
                p_ctx, 'ROUTER', p_endpoint, l_payload, p_req_id, p_log_id, p_chat_id
              );

    l_text := chatbot_core_io_pkg.extract_text_from_chat_response(l_resp);

    BEGIN
      DECLARE j json_object_t := json_object_t.parse(l_text); BEGIN NULL; END;
    EXCEPTION WHEN OTHERS THEN
      l_text := REGEXP_SUBSTR(NVL(l_text,''), '\{.*\}', 1, 1, 'n');
    END;

    IF l_text IS NULL THEN
      chatbot_core_io_pkg.logc(
        p_ctx, 'ROUTER', p_req_id,
        'Router JSON issue',
        TO_CLOB('Router: no JSON found in model response.'),
        p_log_id, p_chat_id
      );
      RETURN '{"tables":[],"joins":[],"reason":"no_json_in_response"}';
    END IF;

    -- Post-validate tables and joins
    BEGIN
      DECLARE
        j       json_object_t;
        a_in    json_array_t;
        a_out   json_array_t := json_array_t();
        cands   sys.odcivarchar2list := p_candidates;
        tset    VARCHAR2(32767) := '|';
        tname   VARCHAR2(256);
        i       PLS_INTEGER;
      BEGIN
        IF cands IS NOT NULL THEN
          FOR k IN 1 .. cands.COUNT LOOP
            tset := tset || UPPER(norm_table(cands(k))) || '|';
          END LOOP;
        END IF;

        j    := json_object_t.parse(l_text);
        a_in := j.get_array('tables');

        IF a_in IS NOT NULL THEN
          FOR i IN 0 .. a_in.get_size - 1 LOOP
            tname := UPPER(norm_table(a_in.get_string(i)));
            IF INSTR(tset, '|'||tname||'|') > 0 THEN
              a_out.append(tname);
            END IF;
          END LOOP;
          j.put('tables', a_out);
        END IF;

        DECLARE
          jarr  json_array_t := j.get_array('joins');
          jout  json_array_t := json_array_t();
          jo    json_object_t;
          lft   VARCHAR2(512);
          rgt   VARCHAR2(512);
          lt    VARCHAR2(256);
          rt    VARCHAR2(256);
        BEGIN
          IF jarr IS NOT NULL THEN
            FOR i IN 0 .. jarr.get_size - 1 LOOP
              jo  := TREAT(jarr.get(i) AS json_object_t);
              lft := UPPER(NVL(jo.get_string('left'),  ''));
              rgt := UPPER(NVL(jo.get_string('right'), ''));
              lt  := REGEXP_SUBSTR(lft, '^[^\.]+\.[^\.]+');
              rt  := REGEXP_SUBSTR(rgt, '^[^\.]+\.[^\.]+');

              IF INSTR(tset, '|'||lt||'|') > 0 AND INSTR(tset, '|'||rt||'|') > 0 THEN
                jout.append(jo);
              END IF;
            END LOOP;
            j.put('joins', jout);
          END IF;
        END;

        -- Attach glossary hints into final JSON if present
        BEGIN
          IF l_glossary_hints IS NOT NULL THEN
            j.put(
              'glossary_hints',
              chatbot_core_io_pkg.clamp_clob(l_glossary_hints, 2000)
            );
          END IF;
        EXCEPTION
          WHEN OTHERS THEN NULL;
        END;

        l_text := j.to_string;
      EXCEPTION
        WHEN OTHERS THEN NULL;
      END;
    END;

    -- Final decision log as CLOB (with log_id/chat_id)
    BEGIN
      DECLARE
        j        json_object_t;
        arr      json_array_t;
        joins    json_array_t;
        jo       json_object_t;
        v_tables VARCHAR2(4000) := NULL;
        v_joins  VARCHAR2(4000) := NULL;
        v_reason VARCHAR2(4000) := NULL;
        i        PLS_INTEGER;
        lft      VARCHAR2(512);
        rgt      VARCHAR2(512);
        jtype    VARCHAR2(64);
      BEGIN
        j := json_object_t.parse(l_text);

        BEGIN
          v_reason := j.get_string('reason');
        EXCEPTION
          WHEN OTHERS THEN v_reason := NULL;
        END;

        BEGIN
          arr := j.get_array('tables');
          IF arr IS NOT NULL THEN
            FOR i IN 0 .. arr.get_size - 1 LOOP
              IF v_tables IS NOT NULL THEN
                v_tables := v_tables || ',';
              END IF;
              v_tables := v_tables || arr.get_string(i);
            END LOOP;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN NULL;
        END;

        BEGIN
          joins := j.get_array('joins');
          IF joins IS NOT NULL THEN
            FOR i IN 0 .. joins.get_size - 1 LOOP
              jo   := TREAT(joins.get(i) AS json_object_t);
              lft  := NVL(jo.get_string('left'),  '');
              rgt  := NVL(jo.get_string('right'), '');
              jtype:= NVL(jo.get_string('type'),  '');
              IF v_joins IS NOT NULL THEN
                v_joins := v_joins || '; ';
              END IF;
              v_joins := v_joins || lft || ' -> ' || rgt ||
                         CASE WHEN jtype IS NOT NULL AND jtype <> '' THEN ' ('||jtype||')' ELSE '' END;
            END LOOP;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN NULL;
        END;

        chatbot_core_io_pkg.logc(
          p_ctx, 'ROUTER', p_req_id,
          'Router decision',
          TO_CLOB(
            'tables=['||NVL(v_tables,'')||
            '] joins=['||NVL(v_joins,'')||
            '] reason='||NVL(v_reason,'')
          ),
          p_log_id, p_chat_id
        );
      EXCEPTION
        WHEN OTHERS THEN NULL;
      END;
    END;

    RETURN l_text;
  END route_tables;

END CHATBOT_ROUTER_PKG;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "OCI_ADB_SCALE_PKG" AS
  ------------------------------------------------------------------------------
  -- Defaults are read from APP_CONFIG:
  --   ADB_OCID
  --   ADB_COMPUTE_COUNT_UP
  --   ADB_COMPUTE_COUNT_DOWN
  --   OCI_CREDENTIAL_NAME (default OCI$RESOURCE_PRINCIPAL)
  --   FC_ADB_REGION (optional)
  --   OCI_ENDPOINT (optional)
  ------------------------------------------------------------------------------
  PROCEDURE scale_up(
    p_adb_ocid       IN VARCHAR2 DEFAULT NULL,
    p_compute_count  IN NUMBER   DEFAULT NULL
  );

  PROCEDURE scale_down(
    p_adb_ocid       IN VARCHAR2 DEFAULT NULL,
    p_compute_count  IN NUMBER   DEFAULT NULL
  );

  -- Worker (public so you can reuse it from other packages/jobs)
  PROCEDURE set_compute_count(
    p_action         IN VARCHAR2,  -- 'UP' or 'DOWN' (for logging only)
    p_adb_ocid       IN VARCHAR2,
    p_compute_count  IN NUMBER
  );
END oci_adb_scale_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "OCI_ADB_SCALE_PKG" AS
  ------------------------------------------------------------------------------
  -- Config helpers
  ------------------------------------------------------------------------------
  FUNCTION cfg(p_key VARCHAR2, p_default VARCHAR2 := NULL) RETURN VARCHAR2 IS
    l_val VARCHAR2(32767);
  BEGIN
    SELECT MAX(config_value)
      INTO l_val
      FROM oci_focus_reports.app_config
     WHERE config_key = p_key;

    RETURN NVL(l_val, p_default);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN p_default;
  END cfg;

  FUNCTION cfg_num(p_key VARCHAR2, p_default NUMBER := NULL) RETURN NUMBER IS
    l_txt VARCHAR2(32767);
    l_num NUMBER;
  BEGIN
    l_txt := cfg(p_key, NULL);
    IF l_txt IS NULL THEN
      RETURN p_default;
    END IF;

    l_num := TO_NUMBER(TRIM(l_txt));
    RETURN l_num;
  EXCEPTION
    WHEN VALUE_ERROR THEN
      RETURN p_default;
  END cfg_num;

  FUNCTION escape_json_str(p_str VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF p_str IS NULL THEN
      RETURN NULL;
    END IF;
    RETURN REPLACE(REPLACE(REPLACE(p_str, '\', '\\'), '"', '\"'), CHR(10), '\n');
  END;

  FUNCTION ts_ms(p_start TIMESTAMP, p_end TIMESTAMP) RETURN NUMBER IS
    l_int INTERVAL DAY TO SECOND;
  BEGIN
    l_int := p_end - p_start;
    RETURN  (EXTRACT(DAY    FROM l_int) * 86400000)
          + (EXTRACT(HOUR   FROM l_int) * 3600000)
          + (EXTRACT(MINUTE FROM l_int) * 60000)
          + (EXTRACT(SECOND FROM l_int) * 1000);
  END;

  ------------------------------------------------------------------------------
  -- Worker
  ------------------------------------------------------------------------------
  PROCEDURE set_compute_count(
    p_action         IN VARCHAR2,  -- 'UP' or 'DOWN'
    p_adb_ocid       IN VARCHAR2,
    p_compute_count  IN NUMBER
  ) IS
    l_run_id      NUMBER;
    l_params      CLOB;
    l_cred        VARCHAR2(128)  := cfg('OCI_CREDENTIAL_NAME', 'OCI$RESOURCE_PRINCIPAL');
    l_region      VARCHAR2(128)  := cfg('FC_ADB_REGION', NULL);
    l_endpoint    VARCHAR2(4000) := cfg('OCI_ENDPOINT', NULL);

    l_details     DBMS_CLOUD_OCI_DATABASE_UPDATE_AUTONOMOUS_DATABASE_DETAILS_T;
    l_resp        DBMS_CLOUD_OCI_DB_DATABASE_UPDATE_AUTONOMOUS_DATABASE_RESPONSE_T;

    l_t0          TIMESTAMP;
    l_elapsed_ms  NUMBER;
    l_hdrs_clob   CLOB;
    l_level       VARCHAR2(10);
  BEGIN
    IF p_adb_ocid IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001, 'ADB OCID is required.');
    END IF;

    IF p_compute_count IS NULL OR p_compute_count <= 0 THEN
      RAISE_APPLICATION_ERROR(-20002, 'Compute count must be a positive number.');
    END IF;

    l_params :=
      '{"action":"' || escape_json_str(UPPER(NVL(p_action,'?'))) ||
      '","adb_ocid":"' || escape_json_str(p_adb_ocid) ||
      '","compute_count":' || TO_CHAR(p_compute_count) ||
      ',"credential_name":"' || escape_json_str(l_cred) ||
      '","region":"' || escape_json_str(l_region) ||
      '","endpoint":"' || escape_json_str(l_endpoint) || '"}';

    oci_log_pkg.start_run(
      p_job_name    => 'ADB_SCALE_' || UPPER(NVL(p_action,'?')),
      p_module      => 'OCI_ADB_SCALE_PKG.SET_COMPUTE_COUNT',
      p_params_json => l_params,
      p_run_id      => l_run_id
    );

    oci_log_pkg.log_msg(l_run_id, 'INFO', 'INPUTS',
      'Scaling ' || UPPER(NVL(p_action,'?')) || ' to compute_count=' || p_compute_count,
      l_params);

    -- Build details
    l_details := DBMS_CLOUD_OCI_DATABASE_UPDATE_AUTONOMOUS_DATABASE_DETAILS_T();
    l_details.compute_count := p_compute_count;

    -- Call
    l_t0 := SYSTIMESTAMP;

    oci_log_pkg.log_msg(l_run_id, 'INFO', 'OCI_CALL',
      'Calling DBMS_CLOUD_OCI_DB_DATABASE.UPDATE_AUTONOMOUS_DATABASE');

    l_resp :=
      DBMS_CLOUD_OCI_DB_DATABASE.UPDATE_AUTONOMOUS_DATABASE(
        autonomous_database_id             => p_adb_ocid,
        update_autonomous_database_details => l_details,
        if_match                           => NULL,
        opc_request_id                     => NULL,
        region                             => l_region,
        endpoint                           => l_endpoint,
        credential_name                    => l_cred
      );

    l_elapsed_ms := ts_ms(l_t0, SYSTIMESTAMP);

    -- Best-effort headers stringify
    BEGIN
      l_hdrs_clob := l_resp.headers.to_clob;
    EXCEPTION
      WHEN OTHERS THEN
        l_hdrs_clob := NULL;
    END;

    l_level := CASE WHEN l_resp.status_code BETWEEN 200 AND 299 THEN 'INFO' ELSE 'ERROR' END;

    oci_log_pkg.log_msg(
      p_run_id       => l_run_id,
      p_level        => l_level,
      p_step         => 'OCI_CALL',
      p_message      => 'update_autonomous_database status_code=' || l_resp.status_code,
      p_details_json => l_hdrs_clob,
      p_elapsed_ms   => l_elapsed_ms
    );

    IF l_resp.status_code BETWEEN 200 AND 299 THEN
      oci_log_pkg.end_run_success(l_run_id);
    ELSE
      oci_log_pkg.end_run_error(
        p_run_id     => l_run_id,
        p_error_code => -20003,
        p_error_msg  => 'OCI update_autonomous_database failed, status_code=' || l_resp.status_code
      );
      RAISE_APPLICATION_ERROR(-20003, 'OCI update_autonomous_database failed, status_code=' || l_resp.status_code);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        IF l_run_id IS NOT NULL THEN
          oci_log_pkg.log_msg(l_run_id, 'ERROR', 'EXCEPTION', SUBSTR(SQLERRM,1,4000));
          oci_log_pkg.end_run_error(
            p_run_id     => l_run_id,
            p_error_code => SQLCODE,
            p_error_msg  => SUBSTR(SQLERRM,1,4000)
          );
        END IF;
      EXCEPTION
        WHEN OTHERS THEN NULL;
      END;
      RAISE;
  END set_compute_count;

  ------------------------------------------------------------------------------
  -- Public wrappers (use APP_CONFIG defaults if params omitted)
  ------------------------------------------------------------------------------
  PROCEDURE scale_up(
    p_adb_ocid       IN VARCHAR2 DEFAULT NULL,
    p_compute_count  IN NUMBER   DEFAULT NULL
  ) IS
    l_adb_ocid VARCHAR2(4000) := NVL(p_adb_ocid, cfg('ADB_OCID', NULL));
    l_cc       NUMBER         := NVL(p_compute_count, cfg_num('ADB_COMPUTE_COUNT_UP', NULL));
  BEGIN
    set_compute_count(
      p_action        => 'UP',
      p_adb_ocid      => l_adb_ocid,
      p_compute_count => l_cc
    );
  END scale_up;

  PROCEDURE scale_down(
    p_adb_ocid       IN VARCHAR2 DEFAULT NULL,
    p_compute_count  IN NUMBER   DEFAULT NULL
  ) IS
    l_adb_ocid VARCHAR2(4000) := NVL(p_adb_ocid, cfg('ADB_OCID', NULL));
    l_cc       NUMBER         := NVL(p_compute_count, cfg_num('ADB_COMPUTE_COUNT_DOWN', NULL));
  BEGIN
    set_compute_count(
      p_action        => 'DOWN',
      p_adb_ocid      => l_adb_ocid,
      p_compute_count => l_cc
    );
  END scale_down;

END oci_adb_scale_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "OCI_APP_CONFIG_PKG" as
  function get_value(p_key in varchar2, p_required in boolean default true)
    return varchar2;
end oci_app_config_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "OCI_APP_CONFIG_PKG" as
  function get_value(p_key in varchar2, p_required in boolean default true)
    return varchar2
  is
    l_val oci_focus_reports.app_config.config_value%type;
  begin
    select c.config_value
      into l_val
      from oci_focus_reports.app_config c
     where c.config_key = p_key;

    return l_val;
  exception
    when no_data_found then
      if p_required then
        raise_application_error(-20001, 'Missing APP_CONFIG key: ' || p_key);
      end if;
      return null;
  end;
end oci_app_config_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "OCI_AVAILABILITY_METRICS_PKG" as
  procedure run(p_run_id out number);
end oci_availability_metrics_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "OCI_AVAILABILITY_METRICS_PKG" as
  c_cred constant varchar2(128) := 'OCI$RESOURCE_PRINCIPAL';

  type t_metric_row is record (
    resourcedisplayname  varchar2(1000),
    ts                   timestamp(6),
    namespace            varchar2(64),
    compartment_id       varchar2(256),
    value                number,
    metric_name          varchar2(128)
  );

  type t_metric_tab is table of t_metric_row index by pls_integer;

  -- Split comma-separated string into SYS.ODCIVARCHAR2LIST (no APEX dependency)
  function split_csv(p_csv in varchar2) return sys.odcivarchar2list is
    l_list sys.odcivarchar2list := sys.odcivarchar2list();
    l_i    pls_integer := 1;
    l_val  varchar2(4000);
  begin
    if p_csv is null then
      return l_list;
    end if;

    loop
      l_val := regexp_substr(p_csv, '[^,]+', 1, l_i);
      exit when l_val is null;
      l_list.extend;
      l_list(l_list.count) := trim(l_val);
      l_i := l_i + 1;
    end loop;

    return l_list;
  end;

  -- 19c-safe: use PL/SQL JSON DOM only (no SQL JSON_VALUE)
  function json_dim_first(
    p_dims_json  in json_element_t,
    p_keys       in sys.odcivarchar2list
  ) return varchar2 is
    l_obj json_object_t;
    l_key varchar2(200);
    l_el  json_element_t;
  begin
    if p_dims_json is null or p_keys is null or p_keys.count = 0 then
      return null;
    end if;

    -- dimensions must be an object
    begin
      l_obj := treat(p_dims_json as json_object_t);
    exception
      when others then
        return null;
    end;

    if l_obj is null then
      return null;
    end if;

    for i in 1 .. p_keys.count loop
      l_key := p_keys(i);
      if l_key is null then
        continue;
      end if;

      if l_obj.has(l_key) then
        -- try string first
        begin
          return l_obj.get_string(l_key);
        exception
          when others then
            -- fallback stringify non-string values
            l_el := l_obj.get(l_key);
            if l_el is not null then
              return substr(l_el.to_string, 1, 1000);
            end if;
        end;
      end if;
    end loop;

    return null;
  exception
    when others then
      return null;
  end;

  procedure run(p_run_id out number) is
    l_root_ocid    varchar2(4000);
    l_regions_csv  varchar2(4000);
    l_days_back    number;
    l_table_name   varchar2(4000);
    l_groups_clob  clob;

    l_resolution   varchar2(20);
    l_query_suffix varchar2(20);

    l_params_json  clob;
    l_regions      sys.odcivarchar2list;

    -- request objects
    l_list_det     c##cloud$service.dbms_cloud_oci_monitoring_list_metrics_details_t;
    l_sum_det      c##cloud$service.dbms_cloud_oci_monitoring_summarize_metrics_data_details_t;

    -- responses
    l_list_resp    c##cloud$service.dbms_cloud_oci_mn_monitoring_list_metrics_response_t;
    l_sum_resp     c##cloud$service.dbms_cloud_oci_mn_monitoring_summarize_metrics_data_response_t;

    -- group fields from JSON_TABLE
    l_grp_idx      number;
    l_namespace    varchar2(200);
    l_resource_grp varchar2(200);

    l_keys         sys.odcivarchar2list;
    l_metric_name  varchar2(200);

    l_start_ts     timestamp with time zone;
    l_end_ts       timestamp with time zone;

    -- temp values
    l_res_name     varchar2(1000);
    l_ts           timestamp(6);
    l_val          number;
    l_compartment  varchar2(256);

    l_cnt_points   number := 0;

    -- bulk buffer
    l_rows     t_metric_tab;
    l_row_idx  pls_integer := 0;

    l_t0_run      timestamp;
    l_t0_region   timestamp;
    l_elapsed_ms  number;
  begin
    -- load config
    l_root_ocid   := oci_app_config_pkg.get_value('OCI_ROOT_COMPARTMENT_OCID');
    l_regions_csv := oci_app_config_pkg.get_value('AVAILABILITY_REGIONS');
    l_days_back   := to_number(oci_app_config_pkg.get_value('AVAILABILITY_DAYS_BACK'));
    l_table_name  := oci_app_config_pkg.get_value('AVAILABILITY_METRICS_TABLE');
    l_groups_clob := oci_app_config_pkg.get_value('AVAILABILITY_METRIC_GROUPS_JSON');

    l_resolution   := nvl(oci_app_config_pkg.get_value('AVAILABILITY_RESOLUTION', false), '1h');
    l_query_suffix := nvl(oci_app_config_pkg.get_value('AVAILABILITY_QUERY_SUFFIX', false), '.mean()');

    -- harden suffix: if user configured ".mean" add "()"
    if regexp_like(l_query_suffix, '\.\s*mean\s*$', 'i') then
      l_query_suffix := regexp_replace(l_query_suffix, '\.\s*mean\s*$', '.mean()', 1, 1, 'i');
    end if;

    l_regions := split_csv(l_regions_csv);

    select json_object(
             'root_compartment_ocid' value l_root_ocid,
             'regions'              value l_regions_csv,
             'days_back'            value l_days_back,
             'resolution'           value l_resolution,
             'table'                value l_table_name
           returning clob)
      into l_params_json
      from dual;

    oci_log_pkg.start_run(
      p_job_name    => 'OCI_AVAILABILITY_METRICS',
      p_module      => 'oci_availability_metrics_pkg.run',
      p_params_json => l_params_json,
      p_run_id      => p_run_id
    );

    l_t0_run := systimestamp;

    oci_log_pkg.log_msg(
      p_run_id  => p_run_id,
      p_level   => 'INFO',
      p_step    => 'START',
      p_message => 'Run started'
    );

    l_end_ts   := systimestamp at time zone 'UTC';
    l_start_ts := (systimestamp at time zone 'UTC') - numtodsinterval(l_days_back, 'DAY');

    ---------------------------------------------------------------------------
    -- region loop
    ---------------------------------------------------------------------------
    for r in 1 .. l_regions.count loop
      if l_regions(r) is null then
        continue;
      end if;

      l_t0_region := systimestamp;

      oci_log_pkg.log_msg(
        p_run_id  => p_run_id,
        p_level   => 'INFO',
        p_step    => 'REGION_START',
        p_message => 'Region=' || l_regions(r)
      );

      -------------------------------------------------------------------------
      -- Iterate group/metric pairs (19c-safe JSON_TABLE on CLOB)
      -------------------------------------------------------------------------
      for gm in (
        select
          jt.grp_idx,
          jt.namespace,
          jt.resource_group,
          jt.metric_name
        from json_table(
               l_groups_clob,
               '$[*]'
               columns (
                 grp_idx        for ordinality,
                 namespace      varchar2(200) path '$.namespace',
                 resource_group varchar2(200) path '$.resource_group',
                 nested path '$.metrics[*]'
                   columns (
                     metric_name varchar2(200) path '$'
                   )
               )
             ) jt
      ) loop
        l_grp_idx      := gm.grp_idx;
        l_namespace    := gm.namespace;
        l_resource_grp := gm.resource_group;
        l_metric_name  := gm.metric_name;

        oci_log_pkg.log_msg(
          p_run_id  => p_run_id,
          p_level   => 'INFO',
          p_step    => 'METRIC_START',
          p_message => 'Region=' || l_regions(r)
                       || ' ns=' || l_namespace
                       || ' rg=' || nvl(l_resource_grp, '<null>')
                       || ' metric=' || l_metric_name
        );

        if l_namespace is null or l_metric_name is null then
          continue;
        end if;

        -----------------------------------------------------------------------
        -- Load resource_display_keys for this group (19c-safe JSON_TABLE)
        -----------------------------------------------------------------------
        select k.key_val
        bulk collect into l_keys
        from json_table(
               l_groups_clob,
               '$[*]'
               columns (
                 grp_idx for ordinality,
                 nested path '$.resource_display_keys[*]'
                   columns (
                     key_val varchar2(200) path '$'
                   )
               )
             ) k
        where k.grp_idx = l_grp_idx;

        if l_keys is null or l_keys.count = 0 then
          l_keys := sys.odcivarchar2list('resourceDisplayName');
        end if;

        -----------------------------------------------------------------------
        -- LIST_METRICS existence check
        -----------------------------------------------------------------------
        l_list_det := c##cloud$service.dbms_cloud_oci_monitoring_list_metrics_details_t(
                        name              => l_metric_name,
                        namespace         => l_namespace,
                        resource_group    => l_resource_grp,
                        dimension_filters => null,
                        group_by          => null,
                        sort_by           => null,
                        sort_order        => null
                      );

        l_list_resp :=
          c##cloud$service.dbms_cloud_oci_mn_monitoring.list_metrics(
            compartment_id             => l_root_ocid,
            list_metrics_details       => l_list_det,
            opc_request_id             => null,
            page                       => null,
            limit                      => 1,
            compartment_id_in_subtree  => 1,
            region                     => l_regions(r),
            endpoint                   => null,
            credential_name            => c_cred
          );

        if l_list_resp.status_code not between 200 and 299 then
          oci_log_pkg.log_msg(
            p_run_id  => p_run_id,
            p_level   => 'WARN',
            p_step    => 'LIST_METRICS',
            p_message => 'LIST_METRICS non-2xx for region=' || l_regions(r)
                         || ' ns=' || l_namespace || ' metric=' || l_metric_name
          );
          continue;
        end if;

        if l_list_resp.response_body is null
           or l_list_resp.response_body.count = 0 then
          continue;
        end if;

        -----------------------------------------------------------------------
        -- SUMMARIZE_METRICS_DATA
        -----------------------------------------------------------------------
        l_sum_det := c##cloud$service.dbms_cloud_oci_monitoring_summarize_metrics_data_details_t(
                       namespace      => l_namespace,
                       resource_group => l_resource_grp,
                       query          => l_metric_name || '[' || l_resolution || ']' || l_query_suffix,
                       start_time     => l_start_ts,
                       end_time       => l_end_ts,
                       resolution     => l_resolution
                     );

        l_sum_resp :=
          c##cloud$service.dbms_cloud_oci_mn_monitoring.summarize_metrics_data(
            compartment_id                 => l_root_ocid,
            summarize_metrics_data_details => l_sum_det,
            opc_request_id                 => null,
            compartment_id_in_subtree      => 1,
            region                         => l_regions(r),
            endpoint                       => null,
            credential_name                => c_cred
          );

        if l_sum_resp.status_code not between 200 and 299 then
          oci_log_pkg.log_msg(
            p_run_id  => p_run_id,
            p_level   => 'WARN',
            p_step    => 'SUMMARIZE',
            p_message => 'SUMMARIZE non-2xx for region=' || l_regions(r)
                         || ' ns=' || l_namespace || ' metric=' || l_metric_name
          );
          continue;
        end if;

        oci_log_pkg.log_msg(
          p_run_id        => p_run_id,
          p_level         => 'INFO',
          p_step          => 'SUMMARIZE_OK',
          p_message       => 'Summarize OK for metric',
          p_rows_affected => case
                               when l_sum_resp.response_body is null then 0
                               else l_sum_resp.response_body.count
                             end
        );

        -----------------------------------------------------------------------
        -- Iterate metric data + aggregated datapoints in pure PL/SQL
        -----------------------------------------------------------------------
        if l_sum_resp.response_body is not null then
          for i in 1 .. l_sum_resp.response_body.count loop
            l_compartment := l_sum_resp.response_body(i).compartment_id;

            l_res_name := json_dim_first(
                            l_sum_resp.response_body(i).dimensions,
                            l_keys
                          );
            if l_res_name is null then
              continue;
            end if;

            if l_sum_resp.response_body(i).aggregated_datapoints is null then
              continue;
            end if;

            for j in 1 .. l_sum_resp.response_body(i).aggregated_datapoints.count loop
              -- adjust field names if needed (l_timestamp / value)
              l_ts  := cast(
                         l_sum_resp.response_body(i).aggregated_datapoints(j).l_timestamp
                         at time zone 'UTC' as timestamp
                       );
              l_val := l_sum_resp.response_body(i).aggregated_datapoints(j).value;

              -- buffer row
              l_row_idx := l_row_idx + 1;
              l_rows(l_row_idx).resourcedisplayname := l_res_name;
              l_rows(l_row_idx).ts                  := l_ts;
              l_rows(l_row_idx).namespace           := l_namespace;
              l_rows(l_row_idx).compartment_id      := l_compartment;
              l_rows(l_row_idx).value               := l_val;
              l_rows(l_row_idx).metric_name         := lower(l_metric_name);

              l_cnt_points := l_cnt_points + 1;
            end loop;
          end loop;
        end if;

      end loop; -- gm

      l_elapsed_ms := (extract(day    from (systimestamp - l_t0_region)) * 24 * 60 * 60 * 1000)
                    + (extract(hour   from (systimestamp - l_t0_region)) * 60 * 60 * 1000)
                    + (extract(minute from (systimestamp - l_t0_region)) * 60 * 1000)
                    + (extract(second from (systimestamp - l_t0_region)) * 1000);

      oci_log_pkg.log_msg(
        p_run_id        => p_run_id,
        p_level         => 'INFO',
        p_step          => 'REGION_DONE',
        p_message       => 'Region complete: ' || l_regions(r),
        p_rows_affected => l_cnt_points,
        p_elapsed_ms    => l_elapsed_ms
      );
    end loop; -- regions

    ---------------------------------------------------------------------------
    -- Bulk write buffered datapoints: staging table + single MERGE
    ---------------------------------------------------------------------------
    if l_row_idx > 0 then
      -- for permanent staging table, clear first; for GTT it's per-session
      begin
        delete from oci_availability_metrics_stg;
      exception
        when others then
          null;
      end;

      oci_log_pkg.log_msg(
        p_run_id        => p_run_id,
        p_level         => 'INFO',
        p_step          => 'STAGE_INSERT',
        p_message       => 'Inserting into staging table',
        p_rows_affected => l_row_idx
      );

      forall i in 1 .. l_row_idx
        insert into oci_availability_metrics_stg (
          resourcedisplayname,
          "TIMESTAMP",
          namespace,
          compartment_id,
          value,
          metric_name
        ) values (
          l_rows(i).resourcedisplayname,
          l_rows(i).ts,
          l_rows(i).namespace,
          l_rows(i).compartment_id,
          l_rows(i).value,
          l_rows(i).metric_name
        );

      execute immediate '
        merge into ' || l_table_name || ' t
        using oci_availability_metrics_stg s
        on (t.resourcedisplayname = s.resourcedisplayname
            and t."TIMESTAMP"     = s."TIMESTAMP"
            and t.metric_name     = s.metric_name)
        when matched then update set
          t.namespace      = s.namespace,
          t.compartment_id = s.compartment_id,
          t.value          = s.value
        when not matched then insert (
          resourcedisplayname, "TIMESTAMP", namespace, compartment_id, value, metric_name
        ) values (
          s.resourcedisplayname, s."TIMESTAMP", s.namespace, s.compartment_id, s.value, s.metric_name
        )';

      oci_log_pkg.log_msg(
        p_run_id  => p_run_id,
        p_level   => 'INFO',
        p_step    => 'MERGE_DONE',
        p_message => 'MERGE completed into ' || l_table_name
      );

    end if;

    l_elapsed_ms := (extract(day    from (systimestamp - l_t0_run)) * 24 * 60 * 60 * 1000)
              + (extract(hour   from (systimestamp - l_t0_run)) * 60 * 60 * 1000)
              + (extract(minute from (systimestamp - l_t0_run)) * 60 * 1000)
              + (extract(second from (systimestamp - l_t0_run)) * 1000);

    oci_log_pkg.log_msg(
      p_run_id        => p_run_id,
      p_level         => 'INFO',
      p_step          => 'DONE',
      p_message       => 'Run completed (datapoints staged/processed)',
      p_rows_affected => l_cnt_points,
      p_elapsed_ms    => l_elapsed_ms
    );

    oci_log_pkg.end_run_success(p_run_id);

  exception
    when others then
      oci_log_pkg.log_msg(
        p_run_id       => p_run_id,
        p_level        => 'ERROR',
        p_step         => 'FAILED',
        p_message      => sqlerrm,
        p_details_json => to_clob(dbms_utility.format_error_backtrace)
      );
      oci_log_pkg.end_run_error(p_run_id, sqlcode, sqlerrm);
      raise;
  end run;

end oci_availability_metrics_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "OCI_EXA_MAINTENANCE_LOADER_PKG" AS
  PROCEDURE run(p_run_id OUT NUMBER);
END oci_exa_maintenance_loader_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "OCI_EXA_MAINTENANCE_LOADER_PKG" AS
  ------------------------------------------------------------------------------
  -- Config
  ------------------------------------------------------------------------------
  c_cred CONSTANT VARCHAR2(128) := 'OCI$RESOURCE_PRINCIPAL';

  FUNCTION cfg(p_key VARCHAR2, p_default VARCHAR2 := NULL) RETURN VARCHAR2 IS
    l_val VARCHAR2(32767);
  BEGIN
    SELECT MAX(config_value)
      INTO l_val
      FROM app_config
     WHERE config_key = p_key;

    RETURN NVL(l_val, p_default);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN p_default;
  END cfg;

  -- comma-separated -> SYS.ODCIVARCHAR2LIST
  FUNCTION split_csv(p_csv IN VARCHAR2) RETURN SYS.ODCIVARCHAR2LIST IS
    l_list SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST();
    l_i    PLS_INTEGER := 1;
    l_val  VARCHAR2(4000);
  BEGIN
    IF p_csv IS NULL THEN
      RETURN l_list;
    END IF;

    LOOP
      l_val := REGEXP_SUBSTR(p_csv, '[^,]+', 1, l_i);
      EXIT WHEN l_val IS NULL;
      l_list.EXTEND;
      l_list(l_list.COUNT) := TRIM(l_val);
      l_i := l_i + 1;
    END LOOP;

    RETURN l_list;
  END split_csv;

  -- escape JSON string
  FUNCTION json_escape(p_str VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF p_str IS NULL THEN
      RETURN NULL;
    END IF;
    RETURN REPLACE(
             REPLACE(
               REPLACE(
                 REPLACE(p_str, '\', '\\'),
               '"', '\"'),
             CHR(10), '\n'),
           CHR(13), '\r');
  END;

  FUNCTION json_quote(p_str VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF p_str IS NULL THEN
      RETURN 'null';
    END IF;
    RETURN '"' || json_escape(p_str) || '"';
  END;

  FUNCTION json_bool(p_val VARCHAR2) RETURN VARCHAR2 IS
    l VARCHAR2(50) := LOWER(TRIM(p_val));
  BEGIN
    IF l IN ('true','t','y','yes','1') THEN
      RETURN 'true';
    ELSIF l IN ('false','f','n','no','0') THEN
      RETURN 'false';
    ELSE
      RETURN 'null';
    END IF;
  END;

  FUNCTION json_num(p_val NUMBER) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN
      RETURN 'null';
    END IF;
    RETURN TO_CHAR(p_val, 'TM9', 'NLS_NUMERIC_CHARACTERS=.,');
  END;

  FUNCTION json_ts(p_val TIMESTAMP) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN
      RETURN 'null';
    END IF;
    -- ISO-ish
    RETURN '"' || TO_CHAR(p_val, 'YYYY-MM-DD"T"HH24:MI:SS.FF3') || '"';
  END;

  FUNCTION json_tstz(p_val TIMESTAMP WITH TIME ZONE) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN
      RETURN 'null';
    END IF;

    -- Normalize to UTC and output ISO-like string
    RETURN '"' || TO_CHAR(p_val AT TIME ZONE 'UTC',
                          'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"') || '"';
  END;

  -- Convert SDK response_body collection -> JSON array CLOB
  FUNCTION mrun_hist_tbl_to_json(
    p_tbl IN C##CLOUD$SERVICE.DBMS_CLOUD_OCI_DATABASE_MAINTENANCE_RUN_HISTORY_SUMMARY_TBL
  ) RETURN CLOB IS
    l_json  CLOB;
    l_first BOOLEAN := TRUE;

    d C##CLOUD$SERVICE.DBMS_CLOUD_OCI_DATABASE_MAINTENANCE_RUN_SUMMARY_T;
    e C##CLOUD$SERVICE.DBMS_CLOUD_OCI_DATABASE_ESTIMATED_PATCHING_TIME_T;
  BEGIN
    DBMS_LOB.createtemporary(l_json, TRUE);
    DBMS_LOB.append(l_json, '[');

    IF p_tbl IS NOT NULL THEN
      FOR i IN 1 .. p_tbl.COUNT LOOP
        d := p_tbl(i).maintenance_run_details;
        e := d.estimated_patching_time;

        IF l_first THEN
          l_first := FALSE;
        ELSE
          DBMS_LOB.append(l_json, ',');
        END IF;

        DBMS_LOB.append(l_json,
          '{' ||
            '"id":' || json_quote(p_tbl(i).id) || ',' ||
            '"maintenanceRunDetails":{' ||

              '"compartmentId":' || json_quote(d.compartment_id) || ',' ||
              '"displayName":'   || json_quote(d.display_name)   || ',' ||
              '"description":'   || json_quote(d.description)    || ',' ||

              '"estimatedPatchingTime":{' ||
                '"estimatedDbServerPatchingTime":'        || json_num(e.estimated_db_server_patching_time)        || ',' ||
                '"estimatedNetworkSwitchesPatchingTime":' || json_num(e.estimated_network_switches_patching_time) || ',' ||
                '"estimatedStorageServerPatchingTime":'   || json_num(e.estimated_storage_server_patching_time)   || ',' ||
                '"totalEstimatedPatchingTime":'           || json_num(e.total_estimated_patching_time) ||
              '},' ||

              '"lifecycleState":'   || json_quote(d.lifecycle_state)   || ',' ||
              '"lifecycleDetails":' || json_quote(d.lifecycle_details) || ',' ||
              '"timeScheduled":'    || json_tstz(d.time_scheduled)     || ',' ||
              '"timeStarted":'      || json_tstz(d.time_started)       || ',' ||
              '"timeEnded":'        || json_tstz(d.time_ended)         || ',' ||
              '"targetResourceType":'|| json_quote(d.target_resource_type) || ',' ||
              '"targetResourceId":'  || json_quote(d.target_resource_id)   || ',' ||
              '"maintenanceType":'   || json_quote(d.maintenance_type)     || ',' ||
              '"maintenanceSubtype":'|| json_quote(d.maintenance_subtype)  || ',' ||
              '"patchId":'           || json_quote(d.patch_id)             || ',' ||
              '"isDstFileUpdateEnabled":' || json_num(d.is_dst_file_update_enabled) || ',' ||
              '"peerMaintenanceRunId":'   || json_quote(d.peer_maintenance_run_id)  || ',' ||
              '"patchingMode":'           || json_quote(d.patching_mode)            || ',' ||
              '"patchFailureCount":'      || json_num(d.patch_failure_count)        || ',' ||
              '"targetDbServerVersion":'      || json_quote(d.target_db_server_version)      || ',' ||
              '"targetStorageServerVersion":' || json_quote(d.target_storage_server_version) || ',' ||
              '"isCustomActionTimeoutEnabled":'     || json_num(d.is_custom_action_timeout_enabled)      || ',' ||
              '"customActionTimeoutInMins":'        || json_num(d.custom_action_timeout_in_mins)         || ',' ||
              '"currentCustomActionTimeoutInMins":' || json_num(d.current_custom_action_timeout_in_mins) || ',' ||
              '"patchingStatus":'    || json_quote(d.patching_status)    || ',' ||
              '"patchingStartTime":' || json_tstz(d.patching_start_time) || ',' ||
              '"patchingEndTime":'   || json_tstz(d.patching_end_time)   || ',' ||
              '"currentPatchingComponent":' || json_quote(d.current_patching_component) || ',' ||
              '"estimatedComponentPatchingStartTime":' || json_tstz(d.estimated_component_patching_start_time) ||
            '}' ||
          '}'
        );
      END LOOP;
    END IF;

    DBMS_LOB.append(l_json, ']');
    RETURN l_json;
  END;

  ------------------------------------------------------------------------------
  -- Main
  ------------------------------------------------------------------------------
  PROCEDURE run(p_run_id OUT NUMBER) IS
    l_job_name    VARCHAR2(128) := 'EXA_MAINTENANCE_LOADER';
    l_module      VARCHAR2(128) := 'OCI_EXA_MAINTENANCE_LOADER_PKG.RUN';
    l_params_json CLOB;

    l_table_name  VARCHAR2(4000) := cfg('EXA_MAINTENANCE_METRICS_TABLE');
    l_regions     SYS.ODCIVARCHAR2LIST := split_csv(cfg('AVAILABILITY_REGIONS'));
    l_tenancy_id  VARCHAR2(4000) := cfg('OCI_ROOT_COMPARTMENT_OCID');

    l_rows_loaded NUMBER := 0;
    l_has_infra   BOOLEAN;
    l_hist_json   CLOB;
  BEGIN
    IF l_table_name IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001, 'Missing APP_CONFIG EXA_MAINTENANCE_METRICS_TABLE');
    END IF;

    IF l_tenancy_id IS NULL THEN
      RAISE_APPLICATION_ERROR(-20002, 'Missing APP_CONFIG OCI_ROOT_COMPARTMENT_OCID');
    END IF;

    IF l_regions IS NULL OR l_regions.COUNT = 0 THEN
      RAISE_APPLICATION_ERROR(-20003, 'Missing APP_CONFIG AVAILABILITY_REGIONS (comma-separated)');
    END IF;

    l_params_json :=
      '{"table":"'   || REPLACE(NVL(l_table_name,'?'),'"','\"') || '",' ||
      '"regions":"'  || REPLACE(NVL(cfg('AVAILABILITY_REGIONS'),'?'),'"','\"') || '",' ||
      '"tenancy":"'  || REPLACE(NVL(l_tenancy_id,'?'),'"','\"') || '"}';

    oci_log_pkg.start_run(
      p_job_name    => l_job_name,
      p_module      => l_module,
      p_params_json => l_params_json,
      p_run_id      => p_run_id
    );

    oci_log_pkg.log_msg(
      p_run_id  => p_run_id,
      p_level   => 'INFO',
      p_step    => 'START',
      p_message => 'Starting loader'
    );

    --------------------------------------------------------------------------
    -- 1) List compartments (subtree)
    --------------------------------------------------------------------------
    DECLARE
      l_all_comp_ids SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST();
      l_page         VARCHAR2(4000);
      l_comp_resp    DBMS_CLOUD_OCI_ID_IDENTITY_LIST_COMPARTMENTS_RESPONSE_T;
      l_identity_region VARCHAR2(200) := cfg('OCI_HOME_REGION');
    BEGIN
      l_page := NULL;

      IF l_identity_region IS NULL THEN
        l_identity_region := CASE WHEN l_regions.COUNT > 0 THEN l_regions(1) ELSE NULL END;
        IF l_identity_region IS NULL THEN
          RAISE_APPLICATION_ERROR(-20004, 'Missing APP_CONFIG OCI_HOME_REGION (required for list_compartments)');
        END IF;
      END IF;

      LOOP
        l_comp_resp :=
          DBMS_CLOUD_OCI_ID_IDENTITY.list_compartments(
            compartment_id            => l_tenancy_id,
            page                      => l_page,
            access_level              => 'ANY',
            compartment_id_in_subtree => 1,
            region                    => l_identity_region,
            endpoint                  => NULL,
            credential_name           => c_cred
          );

        IF l_comp_resp.status_code >= 400 THEN
          RAISE_APPLICATION_ERROR(-20010, 'list_compartments failed, status=' || l_comp_resp.status_code);
        END IF;

        IF l_comp_resp.response_body IS NOT NULL THEN
          FOR i IN 1 .. l_comp_resp.response_body.COUNT LOOP
            l_all_comp_ids.EXTEND;
            l_all_comp_ids(l_all_comp_ids.COUNT) := l_comp_resp.response_body(i).id;
          END LOOP;
        END IF;

        l_page := l_comp_resp.headers.get_string('opc-next-page');
        EXIT WHEN l_page IS NULL;
      END LOOP;

      -- add root tenancy compartment
      l_all_comp_ids.EXTEND;
      l_all_comp_ids(l_all_comp_ids.COUNT) := l_tenancy_id;

      oci_log_pkg.log_msg(
        p_run_id  => p_run_id,
        p_level   => 'INFO',
        p_step    => 'DISCOVER_COMPARTMENTS',
        p_message => 'Compartments discovered: ' || l_all_comp_ids.COUNT,
        p_rows_affected => l_all_comp_ids.COUNT
      );

      ------------------------------------------------------------------------
      -- 2) Truncate target table
      ------------------------------------------------------------------------
      EXECUTE IMMEDIATE 'TRUNCATE TABLE ' || l_table_name;
      oci_log_pkg.log_msg(
        p_run_id  => p_run_id,
        p_level   => 'INFO',
        p_step    => 'TRUNCATE',
        p_message => 'Truncated table ' || l_table_name
      );


      ------------------------------------------------------------------------
      -- 3) For each region:
      --    - detect compartments with Exadata infra
      --    - fetch maintenance run history and insert
      ------------------------------------------------------------------------
      FOR r IN 1 .. l_regions.COUNT LOOP
        DECLARE
          l_region    VARCHAR2(200) := l_regions(r);

          l_exa_resp  DBMS_CLOUD_OCI_DB_DATABASE_LIST_EXADATA_INFRASTRUCTURES_RESPONSE_T;
          l_cexa_resp DBMS_CLOUD_OCI_DB_DATABASE_LIST_CLOUD_EXADATA_INFRASTRUCTURES_RESPONSE_T;
          l_hist_page VARCHAR2(4000);
          l_hist_resp DBMS_CLOUD_OCI_DB_DATABASE_LIST_MAINTENANCE_RUN_HISTORY_RESPONSE_T;
        BEGIN
          oci_log_pkg.log_msg(
            p_run_id  => p_run_id,
            p_level   => 'INFO',
            p_step    => 'SCAN_REGION',
            p_message => 'Scanning region: ' || l_region
          );


          FOR c IN 1 .. l_all_comp_ids.COUNT LOOP
            l_has_infra := FALSE;

            BEGIN
              -- Cloud Exadata
              l_exa_resp :=
                DBMS_CLOUD_OCI_DB_DATABASE.list_exadata_infrastructures(
                  compartment_id  => l_all_comp_ids(c),
                  page            => NULL,
                  limit           => NULL,
                  region          => l_region,
                  endpoint        => NULL,
                  credential_name => c_cred
                );

              IF l_exa_resp.status_code < 400
                 AND l_exa_resp.response_body IS NOT NULL
                 AND l_exa_resp.response_body.COUNT > 0
              THEN
                l_has_infra := TRUE;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;

            BEGIN
              -- Cloud@Customer Exadata
              l_cexa_resp :=
                DBMS_CLOUD_OCI_DB_DATABASE.list_cloud_exadata_infrastructures(
                  compartment_id  => l_all_comp_ids(c),
                  page            => NULL,
                  limit           => NULL,
                  region          => l_region,
                  endpoint        => NULL,
                  credential_name => c_cred
                );

              IF l_cexa_resp.status_code < 400
                 AND l_cexa_resp.response_body IS NOT NULL
                 AND l_cexa_resp.response_body.COUNT > 0
              THEN
                l_has_infra := TRUE;
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;

            IF l_has_infra THEN
              oci_log_pkg.log_msg(
                p_run_id  => p_run_id,
                p_level   => 'INFO',
                p_step    => 'FOUND_INFRA',
                p_message => 'Found Exadata infra. Region=' || l_region || ' Compartment=' || l_all_comp_ids(c)
              );

              -- 4) Fetch maintenance run history (paged)
              l_hist_page := NULL;

              LOOP
                l_hist_resp :=
                  DBMS_CLOUD_OCI_DB_DATABASE.list_maintenance_run_history(
                    compartment_id  => l_all_comp_ids(c),
                    page            => l_hist_page,
                    limit           => NULL,
                    region          => l_region,
                    endpoint        => NULL,
                    credential_name => c_cred
                  );

                -- Convert the typed response_body (collection) to JSON CLOB
                BEGIN
                  l_hist_json := mrun_hist_tbl_to_json(l_hist_resp.response_body);
                EXCEPTION
                  WHEN OTHERS THEN
                    l_hist_json := NULL;
                    oci_log_pkg.log_msg(
                      p_run_id  => p_run_id,
                      p_level   => 'WARN',
                      p_step    => 'HIST_JSON',
                      p_message => 'Could not serialize history response_body: ' || SQLERRM
                    );

                END;

                IF l_hist_json IS NOT NULL THEN
                  oci_log_pkg.log_msg(
                    p_run_id  => p_run_id,
                    p_level   => 'INFO',
                    p_step    => 'HIST_JSON_SAMPLE',
                    p_message => SUBSTR(l_hist_json, 1, 1000)
                  );
                END IF;

                IF l_hist_resp.status_code >= 400 THEN
                  oci_log_pkg.log_msg(
                    p_run_id  => p_run_id,
                    p_level   => 'WARN',
                    p_step    => 'HIST_FAIL',
                    p_message => 'list_maintenance_run_history failed. status=' || l_hist_resp.status_code ||
                                 ' region=' || l_region || ' compartment=' || l_all_comp_ids(c)
                  );
                  EXIT;
                END IF;

                DECLARE
                  l_sql VARCHAR2(32767);
                BEGIN
                  l_sql :=
                    'INSERT /*+ APPEND */ INTO ' || l_table_name || ' (
                       id,
                       compartment_id,
                       current_custom_action_timeout_in_mins,
                       current_patching_component,
                       custom_action_timeout_in_mins,
                       database_software_image_id,
                       description,
                       display_name,
                       estimated_db_server_patching_time,
                       estimated_network_switches_patching_time,
                       estimated_storage_server_patching_time,
                       total_estimated_patching_time,
                       is_custom_action_timeout_enabled,
                       is_dst_file_update_enabled,
                       is_maintenance_run_granular,
                       lifecycle_details,
                       lifecycle_state,
                       maintenance_subtype,
                       maintenance_type,
                       patch_failure_count,
                       patch_id,
                       patching_end_time,
                       patching_mode,
                       patching_start_time,
                       patching_status,
                       peer_maintenance_run_id,
                       peer_maintenance_run_ids,
                       target_db_server_version,
                       target_resource_id,
                       target_resource_type,
                       target_storage_server_version,
                       time_ended,
                       time_scheduled,
                       time_started,
                       total_time_taken_in_mins
                     )
                     SELECT
                       jt.id,
                       jt.compartment_id,
                       jt.current_custom_action_timeout_in_mins,
                       jt.current_patching_component,
                       jt.custom_action_timeout_in_mins,
                       jt.database_software_image_id,
                       jt.description,
                       jt.display_name,
                       jt.estimated_db_server_patching_time,
                       jt.estimated_network_switches_patching_time,
                       jt.estimated_storage_server_patching_time,
                       jt.total_estimated_patching_time,
                       jt.is_custom_action_timeout_enabled,
                       jt.is_dst_file_update_enabled,
                       jt.is_maintenance_run_granular,
                       jt.lifecycle_details,
                       jt.lifecycle_state,
                       jt.maintenance_subtype,
                       jt.maintenance_type,
                       jt.patch_failure_count,
                       jt.patch_id,
                       jt.patching_end_time,
                       jt.patching_mode,
                       jt.patching_start_time,
                       jt.patching_status,
                       jt.peer_maintenance_run_id,
                       jt.peer_maintenance_run_ids,
                       jt.target_db_server_version,
                       jt.target_resource_id,
                       jt.target_resource_type,
                       jt.target_storage_server_version,
                       jt.time_ended,
                       jt.time_scheduled,
                       jt.time_started,
                       jt.total_time_taken_in_mins
                     FROM JSON_TABLE(
                       :p_json,
                       ''$[*]''
                       COLUMNS
                         id VARCHAR2(1000) PATH ''$.id'',
                         compartment_id VARCHAR2(1000) PATH ''$.maintenanceRunDetails.compartmentId'',
                         current_custom_action_timeout_in_mins NUMBER PATH ''$.maintenanceRunDetails.currentCustomActionTimeoutInMins'',
                         current_patching_component VARCHAR2(1000) PATH ''$.maintenanceRunDetails.currentPatchingComponent'',
                         custom_action_timeout_in_mins NUMBER PATH ''$.maintenanceRunDetails.customActionTimeoutInMins'',
                         database_software_image_id VARCHAR2(1000) PATH ''$.maintenanceRunDetails.databaseSoftwareImageId'',
                         description VARCHAR2(10000) PATH ''$.maintenanceRunDetails.description'',
                         display_name VARCHAR2(500) PATH ''$.maintenanceRunDetails.displayName'',

                         estimated_db_server_patching_time NUMBER PATH ''$.maintenanceRunDetails.estimatedPatchingTime.estimatedDbServerPatchingTime'',
                         estimated_network_switches_patching_time NUMBER PATH ''$.maintenanceRunDetails.estimatedPatchingTime.estimatedNetworkSwitchesPatchingTime'',
                         estimated_storage_server_patching_time NUMBER PATH ''$.maintenanceRunDetails.estimatedPatchingTime.estimatedStorageServerPatchingTime'',
                         total_estimated_patching_time NUMBER PATH ''$.maintenanceRunDetails.estimatedPatchingTime.totalEstimatedPatchingTime'',

                         is_custom_action_timeout_enabled VARCHAR2(10) PATH ''$.maintenanceRunDetails.isCustomActionTimeoutEnabled'',
                         is_dst_file_update_enabled VARCHAR2(10) PATH ''$.maintenanceRunDetails.isDstFileUpdateEnabled'',
                         is_maintenance_run_granular VARCHAR2(10) PATH ''$.maintenanceRunDetails.isMaintenanceRunGranular'',
                         lifecycle_details VARCHAR2(10000) PATH ''$.maintenanceRunDetails.lifecycleDetails'',
                         lifecycle_state VARCHAR2(50) PATH ''$.maintenanceRunDetails.lifecycleState'',
                         maintenance_subtype VARCHAR2(1000) PATH ''$.maintenanceRunDetails.maintenanceSubtype'',
                         maintenance_type VARCHAR2(1000) PATH ''$.maintenanceRunDetails.maintenanceType'',
                         patch_failure_count NUMBER PATH ''$.maintenanceRunDetails.patchFailureCount'',
                         patch_id VARCHAR2(50) PATH ''$.maintenanceRunDetails.patchId'',

                         patching_end_time TIMESTAMP PATH ''$.maintenanceRunDetails.patchingEndTime'',
                         patching_mode VARCHAR2(50) PATH ''$.maintenanceRunDetails.patchingMode'',
                         patching_start_time TIMESTAMP PATH ''$.maintenanceRunDetails.patchingStartTime'',
                         patching_status VARCHAR2(50) PATH ''$.maintenanceRunDetails.patchingStatus'',

                         peer_maintenance_run_id VARCHAR2(1000) PATH ''$.maintenanceRunDetails.peerMaintenanceRunId'',
                         peer_maintenance_run_ids CLOB FORMAT JSON PATH ''$.maintenanceRunDetails.peerMaintenanceRunIds'',

                         target_db_server_version VARCHAR2(1000) PATH ''$.maintenanceRunDetails.targetDbServerVersion'',
                         target_resource_id VARCHAR2(200) PATH ''$.maintenanceRunDetails.targetResourceId'',
                         target_resource_type VARCHAR2(1000) PATH ''$.maintenanceRunDetails.targetResourceType'',
                         target_storage_server_version VARCHAR2(1000) PATH ''$.maintenanceRunDetails.targetStorageServerVersion'',

                         time_ended TIMESTAMP PATH ''$.maintenanceRunDetails.timeEnded'',
                         time_scheduled TIMESTAMP PATH ''$.maintenanceRunDetails.timeScheduled'',
                         time_started TIMESTAMP PATH ''$.maintenanceRunDetails.timeStarted'',
                         total_time_taken_in_mins NUMBER PATH ''$.maintenanceRunDetails.totalTimeTakenInMins''
                     ) jt';

                  EXECUTE IMMEDIATE l_sql USING l_hist_json;

                  oci_log_pkg.log_msg(
                    p_run_id  => p_run_id,
                    p_level   => 'INFO',
                    p_step    => 'LOAD_PAGE',
                    p_message => 'Loaded history page (region=' || l_region || ', comp=' || l_all_comp_ids(c) || ')'
                  );
                END;

                l_hist_page := l_hist_resp.headers.get_string('opc-next-page');
                EXIT WHEN l_hist_page IS NULL;
              END LOOP; -- history pages
            END IF; -- l_has_infra

          END LOOP; -- compartments in region

        END; -- region block
      END LOOP; -- regions

      COMMIT;
      oci_log_pkg.log_msg(
        p_run_id        => p_run_id,
        p_level         => 'INFO',
        p_step          => 'DONE',
        p_message       => 'Run completed',
        p_rows_affected => l_rows_loaded
      );
    END; -- inner DECLARE

    oci_log_pkg.end_run_success(p_run_id);
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      oci_log_pkg.log_msg(
        p_run_id       => p_run_id,
        p_level        => 'ERROR',
        p_step         => 'FAILED',
        p_message      => SQLERRM,
        p_details_json => to_clob(dbms_utility.format_error_backtrace)
      );
      oci_log_pkg.end_run_error(p_run_id, SQLCODE, SQLERRM);
      RAISE;
  END run;

END oci_exa_maintenance_loader_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "OCI_FOCUS_REPORTS_COMPARTMENTS_PKG" as
  procedure run(
    p_scope  in     varchar2 default 'ROOT',
    p_run_id in out number
  );
end;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "OCI_FOCUS_REPORTS_COMPARTMENTS_PKG" as

  ------------------------------------------------------------------------------
  -- Local data model
  ------------------------------------------------------------------------------
  type t_comp_rec is record(
    compartment_id  varchar2(4000),
    name            varchar2(4000),
    description     varchar2(4000),
    lifecycle_state varchar2(4000),
    time_created    varchar2(4000),
    parent_id       varchar2(4000),
    parent_name     varchar2(4000),
    path            varchar2(4000),
    tenancy_id      varchar2(2000)
  );
  type t_comp_tab is table of t_comp_rec index by pls_integer;

  type t_idx_by_id is table of pls_integer index by varchar2(4000);
  type t_path_by_id is table of varchar2(4000) index by varchar2(4000);

  ------------------------------------------------------------------------------
  -- Config helpers
  ------------------------------------------------------------------------------
  function cfg(p_key varchar2, p_default varchar2 := null) return varchar2 is
    l_val oci_focus_reports.app_config.config_value%type;
  begin
    select max(config_value)
      into l_val
      from oci_focus_reports.app_config
    where config_key = p_key;

    return nvl(l_val, p_default);
  end;

  function get_root_ocid(p_scope varchar2) return varchar2 is
    l_scope varchar2(30) := upper(trim(nvl(p_scope,'ROOT')));
    l_key   varchar2(100);
    l_val   varchar2(4000);
  begin
    if l_scope = 'ROOT' then
      l_key := 'OCI_ROOT_COMPARTMENT_OCID';
    else
      l_key := 'OCI_ROOT_'||l_scope||'_COMPARTMENT_OCID'; -- e.g. OCI_ROOT_CHILD1_COMPARTMENT_OCID
    end if;

    l_val := cfg(l_key);

    if l_val is null then
      raise_application_error(-20020, 'APP_CONFIG missing key '||l_key);
    end if;

    return l_val;
  end;

  function get_path_prefix(p_scope varchar2) return varchar2 is
    l_scope  varchar2(30) := upper(trim(nvl(p_scope,'ROOT')));
    l_prefix varchar2(4000);
  begin
    l_prefix := cfg('COMPARTMENTS_PATH_PREFIX_'||l_scope);

    if l_prefix is null then
      return null;
    end if;

    -- normalize: no leading/trailing slashes
    l_prefix := trim(both '/' from l_prefix);

    return l_prefix;
  end;

  ------------------------------------------------------------------------------
  -- Build PATH + Parent name (multi-level)
  ------------------------------------------------------------------------------
  procedure build_hierarchy(
    p_rows         in out nocopy t_comp_tab,
    p_tenancy_ocid in varchar2,
    p_path_prefix  in varchar2
  ) is
    l_idx  t_idx_by_id;
    l_path t_path_by_id;

    function get_path(p_id varchar2) return varchar2 is
      l_parent_id varchar2(4000);
      l_parent_path varchar2(4000);
      l_name varchar2(4000);
    begin
      if p_id is null then
        return null;
      end if;

      if l_path.exists(p_id) then
        return l_path(p_id);
      end if;

      if p_id = p_tenancy_ocid then
        l_path(p_id) := '';
        return '';
      end if;

      if not l_idx.exists(p_id) then
        l_path(p_id) := '';
        return '';
      end if;

      l_parent_id := p_rows(l_idx(p_id)).parent_id;
      l_name      := p_rows(l_idx(p_id)).name;

      if l_parent_id is null then
        l_parent_id := p_tenancy_ocid;
      end if;

      l_parent_path := get_path(l_parent_id);

      if l_parent_path is null or l_parent_path = '' then
        l_path(p_id) := l_name;
      else
        l_path(p_id) := l_parent_path || '/' || l_name;
      end if;

      -- prepend prefix once (top-level only)
      if p_path_prefix is not null then
        l_path(p_id) := p_path_prefix || '/' || l_path(p_id);
      end if;

      return l_path(p_id);
    end;
  begin
    for i in 1 .. p_rows.count loop
      l_idx(p_rows(i).compartment_id) := i;
    end loop;

    for i in 1 .. p_rows.count loop
      p_rows(i).path := get_path(p_rows(i).compartment_id);
    end loop;

    for i in 1 .. p_rows.count loop
      if p_rows(i).parent_id is null or p_rows(i).parent_id = p_tenancy_ocid then
        p_rows(i).parent_name := 'Root';
      elsif l_idx.exists(p_rows(i).parent_id) then
        p_rows(i).parent_name := p_rows(l_idx(p_rows(i).parent_id)).name;
      else
        p_rows(i).parent_name := null;
      end if;
    end loop;
  end;

  ------------------------------------------------------------------------------
  -- Fetch compartments (pagination) via OCI PL/SQL SDK
  ------------------------------------------------------------------------------
  function fetch_compartments(
    p_run_id        number,
    p_tenancy_ocid  varchar2,
    p_region        varchar2,
    p_credential    varchar2
  ) return t_comp_tab is
    l_rows t_comp_tab;
    l_n    pls_integer := 0;

    l_page varchar2(4000) := null;
    l_next varchar2(4000);

    l_resp dbms_cloud_oci_id_identity_list_compartments_response_t;
    l_body dbms_cloud_oci_identity_compartment_tbl;

    l_t0 timestamp := systimestamp;
  begin
    oci_log_pkg.log_msg(
      p_run_id       => p_run_id,
      p_level        => 'INFO',
      p_step         => 'FETCH',
      p_message      => 'Listing compartments (paginated)...',
      p_details_json => to_clob('{"region":"' || replace(p_region,'"','\"') ||
                               '","credential":"' || replace(p_credential,'"','\"') || '"}')
    );

    loop
      l_resp := dbms_cloud_oci_id_identity.list_compartments(
                  compartment_id            => p_tenancy_ocid,
                  page                      => l_page,
                  limit                     => 1000,
                  access_level              => 'ACCESSIBLE',
                  compartment_id_in_subtree => 1,
                  region                    => p_region,
                  credential_name           => p_credential
                );

      l_body := l_resp.response_body;

      if l_body is not null then
        for i in 1 .. l_body.count loop
          l_n := l_n + 1;
          l_rows(l_n).compartment_id  := l_body(i).id;
          l_rows(l_n).name            := l_body(i).name;
          l_rows(l_n).description     := l_body(i).description;
          l_rows(l_n).lifecycle_state := l_body(i).lifecycle_state;
          l_rows(l_n).time_created    := case
                                           when l_body(i).time_created is not null
                                           then to_char(l_body(i).time_created, 'YYYY-MM-DD"T"HH24:MI:SS.FF3TZH:TZM')
                                           else null
                                         end;
          l_rows(l_n).parent_id       := l_body(i).compartment_id;
          l_rows(l_n).parent_name     := null;
          l_rows(l_n).path            := null;
          l_rows(l_n).tenancy_id      := substr(p_tenancy_ocid,1,2000);
        end loop;
      end if;

      l_next := null;
      begin
        l_next := l_resp.headers.get_string('opc-next-page');
      exception
        when others then l_next := null;
      end;

      exit when l_next is null;
      l_page := l_next;
    end loop;

    oci_log_pkg.log_msg(
      p_run_id        => p_run_id,
      p_level         => 'INFO',
      p_step          => 'FETCH',
      p_message       => 'Fetched ' || l_n || ' compartments.',
      p_rows_affected => l_n,
      p_elapsed_ms    => round(extract(second from (systimestamp - l_t0))*1000
                           + extract(minute from (systimestamp - l_t0))*60000
                           + extract(hour   from (systimestamp - l_t0))*3600000)
    );

    return l_rows;
  end;

  ------------------------------------------------------------------------------
  -- Merge into OCI_COMPARTMENTS_PY (dynamic table name)
  ------------------------------------------------------------------------------
  procedure merge_rows(
    p_run_id      number,
    p_rows        t_comp_tab,
    p_table_name  varchar2
  ) is
    l_sql varchar2(32767);
    l_t0  timestamp := systimestamp;
    l_rows_affected number := 0;
  begin
    if p_rows.count = 0 then
      oci_log_pkg.log_msg(
        p_run_id  => p_run_id,
        p_level   => 'WARN',
        p_step    => 'MERGE',
        p_message => 'No rows to merge.'
      );
      return;
    end if;

    if not regexp_like(p_table_name, '^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)?$') then
      raise_application_error(-20001, 'Invalid table name: '||p_table_name);
    end if;

    l_sql :=
      'merge into '||p_table_name||' tgt '||
      'using (select :1 compartment_id, :2 name, :3 description, :4 lifecycle_state, :5 time_created, '||
      '             :6 parent_id, :7 parent, :8 path, :9 tenancy_id from dual) src '||
      'on (tgt.compartment_id = src.compartment_id) '||
      'when matched then update set '||
      '  tgt.name = src.name, '||
      '  tgt.description = src.description, '||
      '  tgt.lifecycle_state = src.lifecycle_state, '||
      '  tgt.time_created = src.time_created, '||
      '  tgt.parent_id = src.parent_id, '||
      '  tgt.parent = src.parent, '||
      '  tgt.path = src.path, '||
      '  tgt.tenancy_id = src.tenancy_id '||
      'when not matched then insert '||
      ' (compartment_id, name, description, lifecycle_state, time_created, parent_id, parent, path, tenancy_id) '||
      'values '||
      ' (src.compartment_id, src.name, src.description, src.lifecycle_state, src.time_created, src.parent_id, src.parent, src.path, src.tenancy_id)';

    oci_log_pkg.log_msg(
      p_run_id  => p_run_id,
      p_level   => 'INFO',
      p_step    => 'MERGE',
      p_message => 'Merging into ' || p_table_name || '...'
    );

    for i in 1 .. p_rows.count loop
      execute immediate l_sql
        using
          p_rows(i).compartment_id,
          p_rows(i).name,
          p_rows(i).description,
          p_rows(i).lifecycle_state,
          p_rows(i).time_created,
          p_rows(i).parent_id,
          p_rows(i).parent_name,
          p_rows(i).path,
          p_rows(i).tenancy_id;
      l_rows_affected := l_rows_affected + sql%rowcount;
    end loop;

    commit;

    oci_log_pkg.log_msg(
      p_run_id        => p_run_id,
      p_level         => 'INFO',
      p_step          => 'MERGE',
      p_message       => 'Merge complete.',
      p_rows_affected => l_rows_affected,
      p_elapsed_ms    => round(extract(second from (systimestamp - l_t0))*1000
                           + extract(minute from (systimestamp - l_t0))*60000
                           + extract(hour   from (systimestamp - l_t0))*3600000)
    );
  end;

  ------------------------------------------------------------------------------
  -- Public entry
  ------------------------------------------------------------------------------
  procedure run(
    p_scope  in     varchar2 default 'ROOT',
    p_run_id in out number
  ) is
    l_run_id number := p_run_id;
    l_job_name     varchar2(128) := cfg('COMPARTMENTS_JOB_NAME_'||upper(trim(p_scope)), cfg('COMPARTMENTS_JOB_NAME_ROOT','COMPARTMENTS_REFRESH'));
    l_module       varchar2(128) := cfg('COMPARTMENTS_MODULE_'||upper(trim(p_scope)), cfg('COMPARTMENTS_MODULE_ROOT','COMPARTMENTS'));

    l_comp_ocid    varchar2(4000) := cfg('OCI_ROOT_COMPARTMENT_OCID');
    l_tenancy_ocid varchar2(4000) := get_root_ocid(p_scope);
    l_region       varchar2(200)  := cfg('OCI_HOME_REGION');
    l_credential   varchar2(128)  := cfg('CREDENTIAL_NAME', 'OCI$RESOURCE_PRINCIPAL');
    l_table_name   varchar2(4000) := cfg('COMPARTMENTS_TABLE',  'OCI_COMPARTMENTS_PY');
    l_path_prefix  varchar2(4000) := get_path_prefix(p_scope);

    l_params_json  clob;
    l_rows         t_comp_tab;
  begin
    if l_comp_ocid is null then
      raise_application_error(-20010, 'APP_CONFIG missing key comp_ocid');
    end if;
    if l_region is null then
      raise_application_error(-20011, 'APP_CONFIG missing key oci_region');
    end if;

    l_params_json :=
      '{'||
      '"comp_ocid":"'    || replace(l_comp_ocid,'"','\"')    || '",'||
      '"tenancy_ocid":"' || replace(l_tenancy_ocid,'"','\"') || '",'||
      '"region":"'       || replace(l_region,'"','\"')       || '",'||
      '"credential":"'   || replace(l_credential,'"','\"')   || '",'||
      '"table":"'        || replace(l_table_name,'"','\"')   || '"'||
      '}';

    if l_run_id is null then
      oci_log_pkg.start_run(
        p_job_name    => l_job_name,
        p_module      => l_module,
        p_params_json => l_params_json,
        p_run_id      => l_run_id
      );
    end if;

    oci_log_pkg.log_msg(
      p_run_id  => l_run_id,
      p_level   => 'INFO',
      p_step    => 'START',
      p_message => 'Starting compartments refresh.'
    );

    l_rows := fetch_compartments(l_run_id, l_tenancy_ocid, l_region, l_credential);

    -- Add synthetic root row (match your Python behavior)
    l_rows(l_rows.count+1).compartment_id  := l_tenancy_ocid;
    l_rows(l_rows.count).name             := 'Root';
    l_rows(l_rows.count).description      := null;
    l_rows(l_rows.count).lifecycle_state  := null;
    l_rows(l_rows.count).time_created     := null;
    l_rows(l_rows.count).parent_id        := null;
    l_rows(l_rows.count).parent_name      := null;
    l_rows(l_rows.count).path             := case when l_path_prefix is not null then l_path_prefix else '' end;
    l_rows(l_rows.count).tenancy_id       := substr(l_tenancy_ocid,1,2000);

    oci_log_pkg.log_msg(
      p_run_id  => l_run_id,
      p_level   => 'INFO',
      p_step    => 'HIERARCHY',
      p_message => 'Building PATH hierarchy...'
    );
    build_hierarchy(l_rows, l_tenancy_ocid, l_path_prefix);
    oci_log_pkg.log_msg(
      p_run_id        => l_run_id,
      p_level         => 'INFO',
      p_step          => 'HIERARCHY',
      p_message       => 'Hierarchy built.',
      p_rows_affected => l_rows.count
    );

    merge_rows(l_run_id, l_rows, l_table_name);

    oci_log_pkg.end_run_success(l_run_id);

    -- return run id to caller
    p_run_id := l_run_id;
  exception
    when others then
      if l_run_id is not null then
        oci_log_pkg.log_msg(
          p_run_id       => l_run_id,
          p_level        => 'ERROR',
          p_step         => 'FAILED',
          p_message      => sqlerrm,
          p_details_json => to_clob(dbms_utility.format_error_backtrace)
        );
        oci_log_pkg.end_run_error(l_run_id, sqlcode, sqlerrm);
      end if;
      raise;
  end;

end oci_focus_reports_compartments_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "OCI_FOCUS_REPORTS_LOADER_PKG" 
AUTHID CURRENT_USER
AS
  /**
   * Load OCI FOCUS csv.gz files from Object Storage into stage table,
   * refresh target table, and execute configurable post-processors.
   */
  PROCEDURE run;
END oci_focus_reports_loader_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "OCI_FOCUS_REPORTS_LOADER_PKG" AS

  ------------------------------------------------------------------------------
  -- Config helpers
  ------------------------------------------------------------------------------
  FUNCTION cfg(p_key IN VARCHAR2, p_default IN VARCHAR2 := NULL)
    RETURN VARCHAR2
  IS
    l_val oci_focus_reports.app_config.config_value%TYPE;
  BEGIN
    SELECT config_value
      INTO l_val
      FROM oci_focus_reports.app_config
     WHERE config_key = p_key;

    RETURN l_val;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN p_default;
  END;

  FUNCTION cfg_num(p_key IN VARCHAR2, p_default IN NUMBER := NULL)
    RETURN NUMBER
  IS
    l_val VARCHAR2(4000);
  BEGIN
    l_val := cfg(p_key, NULL);
    IF l_val IS NULL THEN
      RETURN p_default;
    END IF;
    RETURN TO_NUMBER(l_val);
  EXCEPTION
    WHEN OTHERS THEN
      RETURN p_default;
  END;

  FUNCTION cfg_bool(p_key IN VARCHAR2, p_default IN VARCHAR2 := 'N')
    RETURN BOOLEAN
  IS
  BEGIN
    RETURN UPPER(NVL(cfg(p_key, p_default), p_default)) = 'Y';
  END;

  ------------------------------------------------------------------------------
  -- Split a "FIELD_LIST" by commas, but ignore commas inside (...) such as DECIMAL(38,12)
  ------------------------------------------------------------------------------
  FUNCTION split_field_list(p IN CLOB) RETURN SYS.ODCIVARCHAR2LIST IS
    l_txt   VARCHAR2(32767) := REPLACE(REPLACE(DBMS_LOB.SUBSTR(p, 32767, 1), CHR(13), ''), CHR(10), ' ');
    l_out   SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST();
    l_buf   VARCHAR2(32767) := '';
    l_depth PLS_INTEGER := 0;
    c       CHAR(1);
  BEGIN
    IF p IS NULL THEN
      RETURN l_out;
    END IF;

    FOR i IN 1 .. LENGTH(l_txt) LOOP
      c := SUBSTR(l_txt, i, 1);

      IF c = '(' THEN
        l_depth := l_depth + 1;
        l_buf := l_buf || c;
      ELSIF c = ')' THEN
        l_depth := GREATEST(l_depth - 1, 0);
        l_buf := l_buf || c;
      ELSIF c = ',' AND l_depth = 0 THEN
        l_out.EXTEND;
        l_out(l_out.COUNT) := TRIM(l_buf);
        l_buf := '';
      ELSE
        l_buf := l_buf || c;
      END IF;
    END LOOP;

    IF TRIM(l_buf) IS NOT NULL THEN
      l_out.EXTEND;
      l_out(l_out.COUNT) := TRIM(l_buf);
    END IF;

    RETURN l_out;
  END;

  ------------------------------------------------------------------------------
  -- Name parsing: accept OWNER.TABLE or TABLE (defaults to current schema)
  ------------------------------------------------------------------------------
  PROCEDURE split_owner_table(
    p_table IN  VARCHAR2,
    p_owner OUT VARCHAR2,
    p_name  OUT VARCHAR2
  ) IS
    l VARCHAR2(4000) := TRIM(p_table);
  BEGIN
    IF INSTR(l, '.') > 0 THEN
      p_owner := UPPER(REGEXP_SUBSTR(l, '^[^.]+'));
      p_name  := UPPER(REGEXP_SUBSTR(l, '[^.]+$'));
    ELSE
      p_owner := UPPER(SYS_CONTEXT('USERENV','CURRENT_SCHEMA'));
      p_name  := UPPER(l);
    END IF;
  END;

  ------------------------------------------------------------------------------
  -- Build DBMS_CLOUD column_list from CSV_FIELD_LIST (one column per line)
  --   "NAME TYPE..." => column_list with proper SQL types
  ------------------------------------------------------------------------------
  FUNCTION build_column_list_from_field_list(p_field_list IN CLOB)
    RETURN CLOB
  IS
    l_line   VARCHAR2(32767);
    l_name   VARCHAR2(128);
    l_type   VARCHAR2(4000);
    l_out    CLOB := EMPTY_CLOB();
    l_pos    PLS_INTEGER := 1;
    l_next   PLS_INTEGER;
    l_txt    VARCHAR2(32767);

    FUNCTION map_type(p IN VARCHAR2) RETURN VARCHAR2 IS
      t   VARCHAR2(4000) := UPPER(TRIM(p));
      n   NUMBER;
    BEGIN
      t := REGEXP_REPLACE(t, '\s+', ' ');

      -- CHAR(n) / VARCHAR(n) / VARCHAR2(n)
      IF REGEXP_LIKE(t, '^CHAR\s*\(\s*(\d+)\s*\)\s*$') THEN
        n := TO_NUMBER(REGEXP_SUBSTR(t, '\d+'));
        IF n > 4000 THEN RETURN 'CLOB'; END IF;
        RETURN 'VARCHAR2('||n||')';

      ELSIF REGEXP_LIKE(t, '^VARCHAR\s*\(\s*(\d+)\s*\)\s*$') THEN
        n := TO_NUMBER(REGEXP_SUBSTR(t, '\d+'));
        IF n > 4000 THEN RETURN 'CLOB'; END IF;
        RETURN 'VARCHAR2('||n||')';

      ELSIF REGEXP_LIKE(t, '^VARCHAR2\s*\(\s*(\d+)\s*\)\s*$') THEN
        n := TO_NUMBER(REGEXP_SUBSTR(t, '\d+'));
        IF n > 4000 THEN RETURN 'CLOB'; END IF;
        RETURN 'VARCHAR2('||n||')';

      ELSIF REGEXP_LIKE(t, '^CLOB$') THEN
        RETURN 'CLOB';

      -- INTEGER / DECIMAL(p,s) / NUMBER
      ELSIF t = 'INTEGER' THEN
        RETURN 'NUMBER';

      ELSIF REGEXP_LIKE(t, '^DECIMAL\s*\(\s*\d+\s*,\s*\d+\s*\)\s*$') THEN
        RETURN REGEXP_REPLACE(t, '^DECIMAL', 'NUMBER', 1, 1, 'i');

      ELSIF REGEXP_LIKE(t, '^NUMBER(\s*\(\s*\d+(\s*,\s*\d+)?\s*\))?$') THEN
        RETURN t;

      -- Date-ish
      ELSIF t = 'DATE' THEN
        RETURN 'DATE';

      ELSIF REGEXP_LIKE(t, '^TIMESTAMP') THEN
        RETURN t;

      ELSE
        RETURN 'VARCHAR2(4000)';
      END IF;
    END;

    PROCEDURE append_col(p_col IN VARCHAR2) IS
    BEGIN
      IF DBMS_LOB.GETLENGTH(l_out) = 0 THEN
        DBMS_LOB.CREATETEMPORARY(l_out, TRUE);
        DBMS_LOB.WRITEAPPEND(l_out, LENGTH(p_col), p_col);
      ELSE
        DBMS_LOB.WRITEAPPEND(l_out, 2, ', ');
        DBMS_LOB.WRITEAPPEND(l_out, LENGTH(p_col), p_col);
      END IF;
    END;
  BEGIN
    IF p_field_list IS NULL THEN
      RAISE_APPLICATION_ERROR(-20072, 'CSV_FIELD_LIST is NULL; cannot build column_list.');
    END IF;

    l_txt := DBMS_LOB.SUBSTR(p_field_list, 32767, 1);
    l_txt := REPLACE(l_txt, CHR(13), '');

    LOOP
      l_next := INSTR(l_txt, CHR(10), l_pos);
      IF l_next = 0 THEN
        l_line := SUBSTR(l_txt, l_pos);
      ELSE
        l_line := SUBSTR(l_txt, l_pos, l_next - l_pos);
      END IF;

      l_line := TRIM(l_line);
      IF l_line IS NOT NULL THEN
        IF SUBSTR(l_line, -1) = ',' THEN
          l_line := RTRIM(SUBSTR(l_line, 1, LENGTH(l_line)-1));
        END IF;

        -- NAME <space> TYPE...
        l_name := UPPER(
                    REGEXP_SUBSTR(
                      l_line,
                      '^\s*"?([A-Z0-9_$#]+)"?\s+',
                      1, 1, NULL, 1
                    )
                  );
        l_type := TRIM(
                    REGEXP_REPLACE(
                      l_line,
                      '^\s*"?[A-Z0-9_$#]+"?\s+',
                      ''
                    )
                  );

        IF l_name IS NULL OR l_type IS NULL THEN
          RAISE_APPLICATION_ERROR(-20072,
            'Bad CSV_FIELD_LIST line: '||SUBSTR(l_line,1,200));
        END IF;

        append_col('"'||l_name||'" '||map_type(l_type));
      END IF;

      EXIT WHEN l_next = 0;
      l_pos := l_next + 1;
    END LOOP;

    IF DBMS_LOB.GETLENGTH(l_out) = 0 THEN
      RAISE_APPLICATION_ERROR(-20072, 'Could not build column_list from CSV_FIELD_LIST.');
    END IF;

    RETURN l_out;
  END;

  ------------------------------------------------------------------------------
  -- Build DBMS_CLOUD field_list for FILE layout (all CHAR, large enough)
  -- Uses the same CSV_FIELD_LIST lines but only the column name:
  --   "NAME TYPE..." => "NAME" CHAR(4000)
  ------------------------------------------------------------------------------
  FUNCTION build_loader_field_list(p_field_list IN CLOB)
    RETURN CLOB
  IS
    l_txt   VARCHAR2(32767);
    l_pos   PLS_INTEGER := 1;
    l_next  PLS_INTEGER;
    l_line  VARCHAR2(32767);
    l_name  VARCHAR2(128);
    l_out   CLOB := EMPTY_CLOB();

    PROCEDURE append_field(p_field IN VARCHAR2) IS
    BEGIN
      IF DBMS_LOB.GETLENGTH(l_out) = 0 THEN
        DBMS_LOB.CREATETEMPORARY(l_out, TRUE);
        DBMS_LOB.WRITEAPPEND(l_out, LENGTH(p_field), p_field);
      ELSE
        DBMS_LOB.WRITEAPPEND(l_out, 2, ', ');
        DBMS_LOB.WRITEAPPEND(l_out, LENGTH(p_field), p_field);
      END IF;
    END;
  BEGIN
    IF p_field_list IS NULL THEN
      RAISE_APPLICATION_ERROR(-20073, 'CSV_FIELD_LIST is NULL; cannot build field_list.');
    END IF;

    l_txt := DBMS_LOB.SUBSTR(p_field_list, 32767, 1);
    l_txt := REPLACE(l_txt, CHR(13), '');

    LOOP
      l_next := INSTR(l_txt, CHR(10), l_pos);
      IF l_next = 0 THEN
        l_line := SUBSTR(l_txt, l_pos);
      ELSE
        l_line := SUBSTR(l_txt, l_pos, l_next - l_pos);
      END IF;

      l_line := TRIM(l_line);
      IF l_line IS NOT NULL THEN
        l_name := UPPER(
                    REGEXP_SUBSTR(
                      l_line,
                      '^\s*"?([A-Z0-9_$#]+)"?\s+',
                      1, 1, NULL, 1
                    )
                  );

        IF l_name IS NULL THEN
          RAISE_APPLICATION_ERROR(-20073,
            'Bad CSV_FIELD_LIST line (field_list): '||SUBSTR(l_line,1,200));
        END IF;

        -- File field sizes (not table column sizes); use large CHAR
        append_field('"' || l_name || '" CHAR(4000)');
      END IF;

      EXIT WHEN l_next = 0;
      l_pos := l_next + 1;
    END LOOP;

    IF DBMS_LOB.GETLENGTH(l_out) = 0 THEN
      RAISE_APPLICATION_ERROR(-20073, 'Could not build field_list from CSV_FIELD_LIST.');
    END IF;

    RETURN l_out;
  END;

  ------------------------------------------------------------------------------
  -- POST_PROCS handling (JSON array preferred)
  ------------------------------------------------------------------------------
  FUNCTION get_post_procs
    RETURN SYS.ODCIVARCHAR2LIST
  IS
    l_txt  VARCHAR2(4000);
    l_list SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST();
    j_arr  JSON_ARRAY_T;
  BEGIN
    l_txt := cfg('POST_PROCS', NULL);
    IF l_txt IS NULL THEN
      RETURN l_list;
    END IF;

    l_txt := TRIM(l_txt);

    IF SUBSTR(l_txt, 1, 1) = '[' THEN
      j_arr := JSON_ARRAY_T.parse(l_txt);
      FOR i IN 0 .. j_arr.get_size - 1 LOOP
        l_list.EXTEND;
        l_list(l_list.COUNT) := TRIM(j_arr.get_string(i));
      END LOOP;
      RETURN l_list;
    ELSE
      RETURN split_field_list(l_txt);
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN split_field_list(l_txt);
  END;

  FUNCTION is_allowed_call(p_call IN VARCHAR2)
    RETURN BOOLEAN
  IS
    l VARCHAR2(4000) := UPPER(TRIM(p_call));
  BEGIN
    IF REGEXP_LIKE(l, '^[A-Z0-9_$#]+(\.[A-Z0-9_$#]+){0,2}$') THEN
      RETURN TRUE;
    ELSIF REGEXP_LIKE(l, '^DBMS_MVIEW\.REFRESH\s*\(.*\)\s*$', 'n') THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END;

  PROCEDURE run_post_procs(p_run_id IN NUMBER) IS
    l_calls SYS.ODCIVARCHAR2LIST := get_post_procs;
    l_call  VARCHAR2(4000);
  BEGIN
    IF l_calls.COUNT = 0 THEN
      oci_log_pkg.log_msg(
        p_run_id  => p_run_id,
        p_level   => 'INFO',
        p_step    => 'POST_PROCS',
        p_message => 'No post-procs configured.'
      );
      RETURN;
    END IF;

    FOR i IN 1 .. l_calls.COUNT LOOP
      l_call := TRIM(l_calls(i));
      IF l_call IS NULL THEN
        CONTINUE;
      END IF;

      IF NOT is_allowed_call(l_call) THEN
        oci_log_pkg.log_msg(
          p_run_id       => p_run_id,
          p_level        => 'ERROR',
          p_step         => 'POST_PROCS',
          p_message      => 'Rejected call in POST_PROCS',
          p_details_json => to_clob('{"call":"' || replace(substr(l_call,1,1000),'"','\"') || '"}')
        );
        RAISE_APPLICATION_ERROR(-20050, 'POST_PROCS contains disallowed call.');
      END IF;

      BEGIN
        oci_log_pkg.log_msg(p_run_id,'INFO','POST_PROC','Executing: '||l_call);
        EXECUTE IMMEDIATE 'BEGIN '||l_call||'; END;';
        oci_log_pkg.log_msg(p_run_id,'INFO','POST_PROC','Completed: '||l_call);
      EXCEPTION
        WHEN OTHERS THEN
          oci_log_pkg.log_msg(p_run_id,'ERROR','POST_PROC',
            'Failed: '||l_call||' => '||SQLERRM);
          RAISE;
      END;
    END LOOP;
  END;

  ------------------------------------------------------------------------------
  -- URL escaping (PL/SQL only; do NOT call from SQL)
  ------------------------------------------------------------------------------
  FUNCTION url_escape(p IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN UTL_URL.ESCAPE(p, FALSE, 'AL32UTF8');
  END;

  ------------------------------------------------------------------------------
  -- Main loader
  ------------------------------------------------------------------------------
  PROCEDURE run IS
    l_run_id         NUMBER;
    l_job_name       VARCHAR2(128) := 'FOCUS_REPORTS_LOAD';
    l_module         VARCHAR2(128) := 'OCI_FOCUS_REPORTS';

    l_cred           VARCHAR2(128)  := cfg('CREDENTIAL_NAME','OCI$RESOURCE_PRINCIPAL');
    l_base_uri       VARCHAR2(4000) := cfg('OBJECT_BASE_URI');
    l_stage_table    VARCHAR2(4000) := cfg('STAGE_TABLE','OCI_FOCUS_REPORTS.FOCUS_REPORTS_STAGE');
    l_target_table   VARCHAR2(4000) := cfg('TARGET_TABLE','OCI_FOCUS_REPORTS.FOCUS_REPORTS_PY');
    l_key_col        VARCHAR2(128)  := cfg('KEY_COLUMN','OCI_REFERENCENUMBER');

    l_use_dynamic    BOOLEAN := cfg_bool('USE_DYNAMIC_PREFIX','Y');
    l_prefix_base    VARCHAR2(4000) := cfg('PREFIX_BASE','FOCUS Reports');
    l_days_back      PLS_INTEGER    := NVL(cfg_num('DAYS_BACK',1),1);
    l_prefix_file    VARCHAR2(4000) := cfg('PREFIX_FILE');
    l_field_list     VARCHAR2(4000) := cfg('CSV_FIELD_LIST', NULL);

    l_file_suffix    VARCHAR2(50)   := cfg('FILE_SUFFIX','.csv.gz');
    l_filter_created BOOLEAN        := cfg_bool('FILTER_BY_CREATED_SINCE','Y');

    l_prefix         VARCHAR2(4000);
    l_cutoff_ts      TIMESTAMP;

    l_location_uri   VARCHAR2(4000);
    l_format_json    VARCHAR2(4000);
    l_ext_table      VARCHAR2(128);

    l_rows           NUMBER;

    l_failed_files PLS_INTEGER := 0;
    l_loaded_files PLS_INTEGER := 0;
    l_loaded_rows  NUMBER := 0;

    l_column_list CLOB;
    l_field_spec  CLOB;
    l_t0_run timestamp := systimestamp;
    l_elapsed_ms number;

    -- ref cursor for list_objects
    TYPE t_rc IS REF CURSOR;
    rc               t_rc;
    l_object_name    VARCHAR2(4000);
    l_created_ts     TIMESTAMP;
  BEGIN
    oci_log_pkg.start_run(
      p_job_name    => l_job_name,
      p_module      => l_module,
      p_params_json => to_clob(
                        '{"base_uri":"'     || replace(nvl(l_base_uri,'?'),'"','\"') || '",' ||
                        '"stage_table":"'   || replace(nvl(l_stage_table,'?'),'"','\"') || '",' ||
                        '"target_table":"'  || replace(nvl(l_target_table,'?'),'"','\"') || '",' ||
                        '"key_column":"'    || replace(nvl(l_key_col,'?'),'"','\"') || '",' ||
                        '"days_back":'      || nvl(to_char(l_days_back),'null') || ',' ||
                        '"file_suffix":"'   || replace(nvl(l_file_suffix,'?'),'"','\"') || '",' ||
                        '"filter_created":"'||
                          case when l_filter_created then 'true' else 'false' end ||
                        '}'
                      ),
      p_run_id      => l_run_id
    );

    -- Ensure no parallel DML in this scheduler session
    EXECUTE IMMEDIATE 'ALTER SESSION DISABLE PARALLEL DML';
    oci_log_pkg.log_msg(
      p_run_id  => l_run_id,
      p_level   => 'INFO',
      p_step    => 'START',
      p_message => 'Starting loader'
    );

    IF l_field_list IS NULL THEN
      RAISE_APPLICATION_ERROR(-20070,'CSV_FIELD_LIST is required');
    END IF;

    IF l_base_uri IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001,'OBJECT_BASE_URI is required');
    END IF;

    -- Compute prefix and cutoff
    IF l_use_dynamic THEN
      DECLARE
        d DATE;
      BEGIN
        d := TRUNC(CAST(SYS_EXTRACT_UTC(SYSTIMESTAMP) AS DATE)) - l_days_back;
        l_prefix :=
          l_prefix_base||'/'||
          TO_CHAR(d,'YYYY')||'/'||
          TO_CHAR(d,'MM')||'/'||
          TO_CHAR(d,'DD');
        l_cutoff_ts :=
          TO_TIMESTAMP(TO_CHAR(d,'YYYY-MM-DD')||' 00:00:00',
                       'YYYY-MM-DD HH24:MI:SS');
      END;
    ELSE
      IF l_prefix_file IS NULL THEN
        RAISE_APPLICATION_ERROR(-20002,'PREFIX_FILE required when USE_DYNAMIC_PREFIX=N');
      END IF;
      l_prefix := l_prefix_file;
      l_cutoff_ts := NULL;
    END IF;

    oci_log_pkg.log_msg(
      p_run_id  => l_run_id,
      p_level   => 'INFO',
      p_step    => 'PREFIX',
      p_message => 'Using prefix ' || l_prefix
    );

    -- Build location_uri OUTSIDE SQL
    l_location_uri := l_base_uri || url_escape(l_prefix || '/');
    oci_log_pkg.log_msg(l_run_id,'INFO','LIST_OBJECTS','location_uri='||l_location_uri);

    -- Build COPY_DATA format JSON text
    l_format_json :=
      '{'||
      '"type":"csv",'||
      '"compression":"gzip",'||
      '"skipheaders":1,'||
      '"delimiter":",",'||
      '"quote":"\"",'||
      '"endquote":"\"",'||
      '"blankasnull":true,'||
      '"ignoremissingcolumns":true,'||
      '"conversionerrors":"reject_record",'||
      '"rejectlimit":' || NVL(cfg_num('REJECT_LIMIT', 0), 0) || ','||
      '"logprefix":"EXTFOCUS",'||
      '"enablelogs":true'||
      '}';

    EXECUTE IMMEDIATE 'TRUNCATE TABLE '||l_stage_table;

    l_column_list := build_column_list_from_field_list(l_field_list);
    oci_log_pkg.log_msg(
      p_run_id       => l_run_id,
      p_level        => 'INFO',
      p_step         => 'COLUMN_LIST',
      p_message      => 'Built column_list',
      p_details_json => to_clob(DBMS_LOB.SUBSTR(l_column_list, 4000, 1))
    );

    l_field_spec := build_loader_field_list(l_field_list);
    oci_log_pkg.log_msg(
      p_run_id       => l_run_id,
      p_level        => 'INFO',
      p_step         => 'FIELD_LIST',
      p_message      => 'Built column_list',
      p_details_json => to_clob(DBMS_LOB.SUBSTR(l_column_list, 4000, 1))
    );

    ----------------------------------------------------------------------------
    -- LIST_OBJECTS via ref cursor
    ----------------------------------------------------------------------------
    oci_log_pkg.log_msg(l_run_id,'INFO','LIST_OBJECTS_OPEN',
                        'cred='||l_cred||' loc='||SUBSTR(l_location_uri,1,3500));

    OPEN rc FOR
      'SELECT object_name, CAST(created AS TIMESTAMP) created_ts '||
      '  FROM TABLE(DBMS_CLOUD.LIST_OBJECTS(credential_name => :cred, location_uri => :loc))'
      USING l_cred, l_location_uri;

    oci_log_pkg.log_msg(l_run_id,'INFO','LIST_OBJECTS_OPEN','Cursor opened');

    LOOP
      FETCH rc INTO l_object_name, l_created_ts;
      EXIT WHEN rc%NOTFOUND;

      -- Apply suffix and created cutoff in PL/SQL
      IF l_file_suffix IS NOT NULL AND NOT (l_object_name LIKE '%'||l_file_suffix) THEN
        CONTINUE;
      END IF;

      IF l_filter_created AND l_cutoff_ts IS NOT NULL AND l_created_ts < l_cutoff_ts THEN
        CONTINUE;
      END IF;

      BEGIN
        DECLARE
          l_obj_path VARCHAR2(4000);
          l_hash     PLS_INTEGER;
        BEGIN
          IF INSTR(l_object_name, '/') > 0 THEN
            l_obj_path := l_object_name;
          ELSE
            l_obj_path := l_prefix || '/' || l_object_name;
          END IF;

          -- External table name (unique-ish per run + file)
          l_hash := ABS(DBMS_UTILITY.get_hash_value(l_obj_path, 1, 99999999));
          l_ext_table := 'EXT_FOCUS_'||TO_CHAR(l_run_id)||'_'||TO_CHAR(l_hash);
          IF LENGTH(l_ext_table) > 128 THEN
            l_ext_table := SUBSTR(l_ext_table, 1, 128);
          END IF;

          -- Drop ext table if exists (ignore errors)
          BEGIN
            EXECUTE IMMEDIATE 'DROP TABLE '||l_ext_table||' PURGE';
          EXCEPTION
            WHEN OTHERS THEN NULL;
          END;

          oci_log_pkg.log_msg(l_run_id,'INFO','EXT_CREATE',
            'ext='||l_ext_table||
            ' uri='||SUBSTR(l_base_uri || url_escape(l_obj_path),1,800)||
            ' col_list='||SUBSTR(l_column_list,1,800)||
            ' field_spec='||SUBSTR(l_field_spec,1,800)
          );

          -- Create external table with explicit file field_list (CHARs)
          BEGIN
            DBMS_CLOUD.CREATE_EXTERNAL_TABLE(
              table_name      => l_ext_table,
              credential_name => l_cred,
              file_uri_list   => l_base_uri || url_escape(l_obj_path),
              format          => l_format_json,
              column_list     => l_column_list,
              field_list      => l_field_spec
            );
          EXCEPTION
            WHEN OTHERS THEN
              oci_log_pkg.log_msg(l_run_id,'ERROR','EXT_CREATE',
                'Create ext failed: '||l_ext_table||' => '||SQLERRM);
              RAISE;
          END;

          DECLARE
            l_op_id NUMBER;
          BEGIN
            DBMS_CLOUD.VALIDATE_EXTERNAL_TABLE(
              table_name    => l_ext_table,
              operation_id  => l_op_id,
              rowcount      => 50,
              stop_on_error => FALSE
            );

            oci_log_pkg.log_msg(l_run_id,'INFO','EXT_VALIDATE',
              'Validated ext='||l_ext_table||' op_id='||l_op_id);
          END;

          -- Load into stage
          EXECUTE IMMEDIATE
            'INSERT /*+ APPEND */ INTO '||l_stage_table||' (
              availabilityzone,billedcost,billingaccountid,billingaccountname,billingcurrency,
              billingperiodend,billingperiodstart,chargecategory,chargedescription,chargefrequency,
              chargeperiodend,chargeperiodstart,chargesubcategory,commitmentdiscountcategory,commitmentdiscountid,
              commitmentdiscountname,commitmentdiscounttype,effectivecost,invoiceissuer,listcost,
              listunitprice,pricingcategory,pricingquantity,pricingunit,provider,
              publisher,region,resourceid,resourcename,resourcetype,
              servicecategory,servicename,skuid,skupriceid,subaccountid,
              subaccountname,tags,usagequantity,usageunit,oci_referencenumber,
              oci_compartmentid,oci_compartmentname,oci_overageflag,oci_unitpriceoverage,oci_billedquantityoverage,
              oci_costoverage,oci_attributedusage,oci_attributedcost,oci_backreferencenumber
            )
            SELECT
              availabilityzone,billedcost,billingaccountid,billingaccountname,billingcurrency,
              billingperiodend,billingperiodstart,chargecategory,chargedescription,chargefrequency,
              chargeperiodend,chargeperiodstart,chargesubcategory,commitmentdiscountcategory,commitmentdiscountid,
              commitmentdiscountname,commitmentdiscounttype,effectivecost,invoiceissuer,listcost,
              listunitprice,pricingcategory,pricingquantity,pricingunit,provider,
              publisher,region,resourceid,resourcename,resourcetype,
              servicecategory,servicename,skuid,skupriceid,subaccountid,
              subaccountname,
              TO_CLOB(tags) tags,
              usagequantity,usageunit,oci_referencenumber,
              oci_compartmentid,oci_compartmentname,oci_overageflag,oci_unitpriceoverage,oci_billedquantityoverage,
              oci_costoverage,oci_attributedusage,oci_attributedcost,oci_backreferencenumber
            FROM '||l_ext_table;

          l_rows := SQL%ROWCOUNT;

          -- Drop ext table
          BEGIN
            EXECUTE IMMEDIATE 'DROP TABLE '||l_ext_table||' PURGE';
          EXCEPTION
            WHEN OTHERS THEN
              oci_log_pkg.log_msg(l_run_id,'WARN','DROP_EXT',
                'Drop failed for '||l_ext_table||' => '||SQLERRM);
          END;

          l_loaded_files := l_loaded_files + 1;
          l_loaded_rows  := l_loaded_rows + NVL(l_rows,0);

          oci_log_pkg.log_msg(
            l_run_id,'INFO','LOAD_FILE',
            'Loaded '||l_obj_path||' rows='||l_rows,
            NULL,l_rows
          );

          COMMIT;
        END;
      EXCEPTION
        WHEN OTHERS THEN
          -- best-effort cleanup
          BEGIN
            IF l_ext_table IS NOT NULL THEN
              BEGIN
                EXECUTE IMMEDIATE 'DROP TABLE '||l_ext_table||' PURGE';
              EXCEPTION
                WHEN OTHERS THEN
                  oci_log_pkg.log_msg(l_run_id,'WARN','DROP_EXT',
                    'Drop failed for '||l_ext_table||' => '||SQLERRM);
              END;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN NULL;
          END;

          oci_log_pkg.log_msg(
            l_run_id,'ERROR','LOAD_FILE',
            'Failed '||l_object_name||' => '||SQLERRM
          );
          l_failed_files := l_failed_files + 1;
          ROLLBACK;
      END;
    END LOOP;

    CLOSE rc;

    IF l_failed_files > 0 THEN
      RAISE_APPLICATION_ERROR(
        -20060,
        'One or more files failed to load. failed_files='||l_failed_files||
        ', loaded_files='||l_loaded_files||
        ', loaded_rows='||l_loaded_rows
      );
    END IF;

    IF l_loaded_rows = 0 THEN
      RAISE_APPLICATION_ERROR(-20061, 'No rows loaded into stage; aborting target refresh.');
    END IF;

    ----------------------------------------------------------------------------
    -- Refresh target
    ----------------------------------------------------------------------------
    EXECUTE IMMEDIATE
      'DELETE FROM '||l_target_table||' t '||
      ' WHERE t.'||l_key_col||
      ' IN (SELECT DISTINCT '||l_key_col||' FROM '||l_stage_table||')';

    oci_log_pkg.log_msg(
      p_run_id        => l_run_id,
      p_level         => 'INFO',
      p_step          => 'DELETE_TARGET',
      p_message       => 'Deleted rows=' || SQL%ROWCOUNT,
      p_rows_affected => SQL%ROWCOUNT
    );

    EXECUTE IMMEDIATE
      'INSERT /*+ APPEND */ INTO '||l_target_table||'
      SELECT
        availabilityzone,
        billedcost,
        billingaccountid,
        billingaccountname,
        billingcurrency,

        /* BILLING PERIOD END */
        CAST(
          CASE
            WHEN REGEXP_LIKE(billingperiodend, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}Z$'')
              THEN TO_TIMESTAMP_TZ(billingperiodend, ''YYYY-MM-DD"T"HH24:MI"Z"'')
            WHEN REGEXP_LIKE(billingperiodend, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$'')
              THEN TO_TIMESTAMP_TZ(billingperiodend, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
            WHEN REGEXP_LIKE(billingperiodend, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z$'')
              THEN TO_TIMESTAMP_TZ(billingperiodend, ''YYYY-MM-DD"T"HH24:MI:SS.FF"Z"'')
            ELSE NULL
          END AT TIME ZONE ''UTC''
        AS TIMESTAMP) AS billingperiodend,

        /* BILLING PERIOD START */
        CAST(
          CASE
            WHEN REGEXP_LIKE(billingperiodstart, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}Z$'')
              THEN TO_TIMESTAMP_TZ(billingperiodstart, ''YYYY-MM-DD"T"HH24:MI"Z"'')
            WHEN REGEXP_LIKE(billingperiodstart, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$'')
              THEN TO_TIMESTAMP_TZ(billingperiodstart, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
            WHEN REGEXP_LIKE(billingperiodstart, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z$'')
              THEN TO_TIMESTAMP_TZ(billingperiodstart, ''YYYY-MM-DD"T"HH24:MI:SS.FF"Z"'')
            ELSE NULL
          END AT TIME ZONE ''UTC''
        AS TIMESTAMP) AS billingperiodstart,

        chargecategory,
        chargedescription,
        chargefrequency,

        /* CHARGE PERIOD END */
        CAST(
          CASE
            WHEN REGEXP_LIKE(chargeperiodend, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}Z$'')
              THEN TO_TIMESTAMP_TZ(chargeperiodend, ''YYYY-MM-DD"T"HH24:MI"Z"'')
            WHEN REGEXP_LIKE(chargeperiodend, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$'')
              THEN TO_TIMESTAMP_TZ(chargeperiodend, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
            WHEN REGEXP_LIKE(chargeperiodend, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z$'')
              THEN TO_TIMESTAMP_TZ(chargeperiodend, ''YYYY-MM-DD"T"HH24:MI:SS.FF"Z"'')
            ELSE NULL
          END AT TIME ZONE ''UTC''
        AS TIMESTAMP) AS chargeperiodend,

        /* CHARGE PERIOD START */
        CAST(
          CASE
            WHEN REGEXP_LIKE(chargeperiodstart, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}Z$'')
              THEN TO_TIMESTAMP_TZ(chargeperiodstart, ''YYYY-MM-DD"T"HH24:MI"Z"'')
            WHEN REGEXP_LIKE(chargeperiodstart, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$'')
              THEN TO_TIMESTAMP_TZ(chargeperiodstart, ''YYYY-MM-DD"T"HH24:MI:SS"Z"'')
            WHEN REGEXP_LIKE(chargeperiodstart, ''^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z$'')
              THEN TO_TIMESTAMP_TZ(chargeperiodstart, ''YYYY-MM-DD"T"HH24:MI:SS.FF"Z"'')
            ELSE NULL
          END AT TIME ZONE ''UTC''
        AS TIMESTAMP) AS chargeperiodstart,

        chargesubcategory,
        commitmentdiscountcategory,
        commitmentdiscountid,
        commitmentdiscountname,
        commitmentdiscounttype,
        effectivecost,
        invoiceissuer,
        listcost,
        listunitprice,
        pricingcategory,
        pricingquantity,
        pricingunit,
        provider,
        publisher,
        region,
        resourceid,
        resourcename,
        resourcetype,
        servicecategory,
        servicename,
        skuid,
        skupriceid,
        subaccountid,
        subaccountname,
        tags,
        usagequantity,
        usageunit,
        oci_referencenumber,
        oci_compartmentid,
        oci_compartmentname,
        oci_overageflag,
        oci_unitpriceoverage,
        oci_billedquantityoverage,
        oci_costoverage,
        oci_attributedusage,
        oci_attributedcost,
        oci_backreferencenumber
      FROM '||l_stage_table;

    oci_log_pkg.log_msg(
      l_run_id,'INFO','INSERT_TARGET',
      'Inserted rows='||SQL%ROWCOUNT,
      NULL,SQL%ROWCOUNT
    );

    COMMIT;

    ----------------------------------------------------------------------------
    -- Post-processing (configurable)
    ----------------------------------------------------------------------------
    run_post_procs(l_run_id);

    oci_log_pkg.log_msg(
      p_run_id        => l_run_id,
      p_level         => 'INFO',
      p_step          => 'SUMMARY',
      p_message       => 'Files loaded=' || l_loaded_files ||
                         ', failed=' || l_failed_files ||
                         ', rows loaded=' || l_loaded_rows
    );

    oci_log_pkg.end_run_success(l_run_id);

  EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        IF rc%ISOPEN THEN
          CLOSE rc;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN NULL;
      END;

      -- Always try to log details first (backtrace as CLOB)
      BEGIN
        IF l_run_id IS NOT NULL THEN
          oci_log_pkg.log_msg(
            p_run_id       => l_run_id,
            p_level        => 'ERROR',
            p_step         => 'FAILED',
            p_message      => SQLERRM,
            p_details_json => to_clob(dbms_utility.format_error_backtrace)
          );
          oci_log_pkg.end_run_error(l_run_id, SQLCODE, SQLERRM);
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL; -- do not mask original error
      END;

      ROLLBACK;
      RAISE;
        l_elapsed_ms := round(extract(second from (systimestamp - l_t0_run))*1000
                       + extract(minute from (systimestamp - l_t0_run))*60000
                       + extract(hour   from (systimestamp - l_t0_run))*3600000);

    oci_log_pkg.log_msg(
      p_run_id     => l_run_id,
      p_level      => 'INFO',
      p_step       => 'DONE',
      p_message    => 'Completed',
      p_elapsed_ms => l_elapsed_ms
    );
  END run;

END oci_focus_reports_loader_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "OCI_LOG_PKG" as
  procedure start_run(
    p_job_name    in varchar2,
    p_module      in varchar2,
    p_params_json in clob,
    p_run_id      out number
  );

  procedure log_msg(
    p_run_id        in number,
    p_level         in varchar2,
    p_step          in varchar2,
    p_message       in varchar2,
    p_details_json  in clob default null,
    p_rows_affected in number default null,
    p_elapsed_ms    in number default null
  );

  procedure end_run_success(p_run_id in number);

  procedure end_run_error(
    p_run_id     in number,
    p_error_code in number,
    p_error_msg  in varchar2
  );
end oci_log_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "OCI_LOG_PKG" as
  procedure start_run(
    p_job_name    in varchar2,
    p_module      in varchar2,
    p_params_json in clob,
    p_run_id      out number
  ) is
  begin
    insert into oci_job_runs(job_name, module, status, params_json)
    values (p_job_name, p_module, 'RUNNING', p_params_json)
    returning run_id into p_run_id;
    commit;
  end;

  procedure log_msg(
    p_run_id        in number,
    p_level         in varchar2,
    p_step          in varchar2,
    p_message       in varchar2,
    p_details_json  in clob default null,
    p_rows_affected in number default null,
    p_elapsed_ms    in number default null
  ) is
  begin
    insert into oci_job_run_log(
      run_id, level_name, step_name, message, details_json, rows_affected, elapsed_ms
    )
    values (
      p_run_id, upper(p_level), p_step, substr(p_message,1,4000),
      p_details_json, p_rows_affected, p_elapsed_ms
    );
    commit;
  end;

  procedure end_run_success(p_run_id in number) is
  begin
    update oci_job_runs
       set status = 'SUCCESS', end_ts = systimestamp
     where run_id = p_run_id;
    commit;
  end;

  procedure end_run_error(
    p_run_id     in number,
    p_error_code in number,
    p_error_msg  in varchar2
  ) is
  begin
    update oci_job_runs
       set status = 'ERROR',
           end_ts = systimestamp,
           error_code = p_error_code,
           error_msg  = substr(p_error_msg,1,4000)
     where run_id = p_run_id;
    commit;
  end;
end oci_log_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "OCI_RESOURCES_LOADER_PKG" as
  procedure run(p_job_name in varchar2 default 'RESOURCES_PY');
end oci_resources_loader_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "OCI_RESOURCES_LOADER_PKG" as

  ------------------------------------------------------------------------------
  -- Config helper (APP_CONFIG: KEY, VALUE)
  ------------------------------------------------------------------------------
  function cfg(p_key varchar2, p_default varchar2 := null) return varchar2 is
    l_val varchar2(32767);
  begin
    select max(config_value)
      into l_val
      from app_config
     where config_key = p_key;

    return nvl(l_val, p_default);
  exception
    when no_data_found then
      return p_default;
  end cfg;

  ------------------------------------------------------------------------------
  -- Split comma-separated list into ODCIVARCHAR2LIST
  ------------------------------------------------------------------------------
  function split_csv(p_csv in varchar2) return sys.odcivarchar2list is
    l_list sys.odcivarchar2list := sys.odcivarchar2list();
    l_i    pls_integer := 1;
    l_val  varchar2(4000);
  begin
    if p_csv is null then
      return l_list;
    end if;

    loop
      l_val := regexp_substr(p_csv, '[^,]+', 1, l_i);
      exit when l_val is null;
      l_list.extend;
      l_list(l_list.count) := trim(l_val);
      l_i := l_i + 1;
    end loop;

    return l_list;
  end split_csv;

  ------------------------------------------------------------------------------
  -- Regions from APP_CONFIG: AVAILABILITY_REGIONS
  ------------------------------------------------------------------------------
  function get_regions(p_run_id number) return sys.odcivarchar2list is
    l_csv varchar2(32767);
    l_res sys.odcivarchar2list;
  begin
    l_csv := cfg('AVAILABILITY_REGIONS', null);
    if l_csv is null then
      raise_application_error(-20001, 'APP_CONFIG key AVAILABILITY_REGIONS is required.');
    end if;

    l_res := split_csv(l_csv);
    oci_log_pkg.log_msg(
      p_run_id        => p_run_id,
      p_level         => 'INFO',
      p_step          => 'REGIONS',
      p_message       => 'Regions loaded from AVAILABILITY_REGIONS',
      p_rows_affected => l_res.count
    );
    return l_res;
  end;

  ------------------------------------------------------------------------------
  -- Resolve target tables from APP_CONFIG
  -- Keys:
  --   RESOURCES_TABLE                 (e.g. OCI_FOCUS_REPORTS.OCI_RESOURCES_PY)
  --   RESOURCE_RELATIONSHIPS_PROC     (default POPULATE_RESOURCE_RELATIONSHIPS_PROC)
  --   RESOURCE_OKE_RELATIONSHIPS_PROC (default POPULATE_OKE_RELATIONSHIPS_PROC)
  ------------------------------------------------------------------------------
  procedure get_targets(
    p_run_id        number,
    p_resources_tbl out varchar2,
    p_rel_proc      out varchar2,
    p_oke_proc      out varchar2
  ) is
  begin
    p_resources_tbl := cfg('RESOURCES_TABLE', null);
    if p_resources_tbl is null then
      raise_application_error(-20002, 'APP_CONFIG key RESOURCES_TABLE is required.');
    end if;

    p_rel_proc := cfg('RESOURCE_RELATIONSHIPS_PROC', 'POPULATE_RESOURCE_RELATIONSHIPS_PROC');
    p_oke_proc := cfg('RESOURCE_OKE_RELATIONSHIPS_PROC', 'POPULATE_OKE_RELATIONSHIPS_PROC');

    oci_log_pkg.log_msg(
      p_run_id  => p_run_id,
      p_level   => 'INFO',
      p_step    => 'TARGETS',
      p_message => 'Targets resolved',
      p_details_json => to_clob(
        '{"RESOURCES_TABLE":"' || replace(p_resources_tbl,'"','\"') ||
        '","REL_PROC":"'       || replace(p_rel_proc,'"','\"')      ||
        '","OKE_PROC":"'       || replace(p_oke_proc,'"','\"')      ||
        '"}'
      )
    );
  end;

  ------------------------------------------------------------------------------
  -- Load one region (Resource Search)
  ------------------------------------------------------------------------------
  procedure load_region(
    p_run_id        number,
    p_region        varchar2,
    p_cred          varchar2,
    p_resources_tbl varchar2
  ) is
    l_page   varchar2(32767) := null;
    l_limit  number := to_number(cfg('RESOURCES_PAGE_LIMIT', '1000'));

    l_resp   c##cloud$service.dbms_cloud_oci_rs_resource_search_search_resources_response_t;
    l_det    c##cloud$service.dbms_cloud_oci_resource_search_structured_search_details_t;

    l_ins_cnt number;

  begin
    -- SearchDetails (your type only has L_TYPE + MATCHING_CONTEXT_TYPE)
    l_det := c##cloud$service.dbms_cloud_oci_resource_search_structured_search_details_t(
               l_type                => 'Structured',
               matching_context_type => null,
               query  => 'query all resources'
             );

    loop
      l_resp :=
        dbms_cloud_oci_rs_resource_search.search_resources(
          search_details   => l_det,
          limit            => l_limit,
          page             => l_page,
          tenant_id        => null,
          opc_request_id   => null,
          region           => p_region,
          endpoint         => null,
          credential_name  => p_cred
        );

      declare
        type t_vc1000_tab is table of varchar2(1000) index by pls_integer;
        type t_vc255_tab  is table of varchar2(255)  index by pls_integer;
        type t_vc100_tab  is table of varchar2(100)  index by pls_integer;
        type t_vc60_tab   is table of varchar2(60)   index by pls_integer;
        type t_vc100_tab2 is table of varchar2(100)  index by pls_integer;
        type t_ts_tab     is table of timestamp      index by pls_integer;
        type t_clob_tab   is table of clob           index by pls_integer;

        l_n pls_integer := 0;

        l_display_name   t_vc1000_tab;
        l_identifier     t_vc1000_tab;
        l_region         t_vc60_tab;
        l_resource_type  t_vc100_tab;
        l_compartment_id t_vc255_tab;
        l_ad             t_vc100_tab2;
        l_time_created   t_ts_tab;

        l_defined_tags   t_clob_tab;
        l_freeform_tags  t_clob_tab;
        l_system_tags    t_clob_tab;
        l_add_details    t_clob_tab;

        function je_to_clob(p in json_element_t) return clob is
        begin
          if p is null then
            return to_clob('{}');
          end if;

          return to_clob(p.to_string());
        exception
          when others then
            return to_clob('{}');
        end;

      begin
        if l_resp.response_body.items is not null then
          for i in 1 .. l_resp.response_body.items.count loop
            l_n := l_n + 1;

            l_display_name(l_n)   := l_resp.response_body.items(i).display_name;
            l_identifier(l_n)     := l_resp.response_body.items(i).identifier;
            l_region(l_n)         := p_region;
            l_resource_type(l_n)  := l_resp.response_body.items(i).resource_type;
            l_compartment_id(l_n) := l_resp.response_body.items(i).compartment_id;
            l_ad(l_n)             := nvl(l_resp.response_body.items(i).availability_domain, 'N/A');

            -- target column is TIMESTAMP (no TZ)
            l_time_created(l_n)   := cast(l_resp.response_body.items(i).time_created as timestamp);

            l_defined_tags(l_n)   := je_to_clob(l_resp.response_body.items(i).defined_tags);
            l_freeform_tags(l_n)  := je_to_clob(l_resp.response_body.items(i).freeform_tags);
            l_system_tags(l_n)    := je_to_clob(l_resp.response_body.items(i).system_tags);
            l_add_details(l_n)    := je_to_clob(l_resp.response_body.items(i).additional_details);
          end loop;

          forall j in 1 .. l_n
            execute immediate
              'insert into '||p_resources_tbl||' ('||
              ' display_name, identifier, region, resource_type,'||
              ' defined_tags, freeform_tags, system_tags,'||
              ' compartment_id, availability_domain, time_created, additional_details'||
              ') values (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11)'
              using
                l_display_name(j),
                l_identifier(j),
                l_region(j),
                l_resource_type(j),
                l_defined_tags(j),
                l_freeform_tags(j),
                l_system_tags(j),
                l_compartment_id(j),
                l_ad(j),
                l_time_created(j),
                l_add_details(j);
        end if;

        -- make SQL%ROWCOUNT reflect inserted rows for your existing log below
        -- (FORALL updates SQL%ROWCOUNT in this scope only, so return l_n via bind)
        l_ins_cnt := l_n;
      end;

      -- inserted count from the PL/SQL block above
      oci_log_pkg.log_msg(
        p_run_id        => p_run_id,
        p_level         => 'INFO',
        p_step          => 'SEARCH_PAGE',
        p_message       => 'Region=' || p_region || ' status=' || nvl(to_char(l_resp.status_code),'?'),
        p_rows_affected => nvl(l_ins_cnt,0)
      );

      commit;

      -- opc-next-page in headers (JSON_OBJECT_T)
      begin
        l_page := l_resp.headers.get_string('opc-next-page');
      exception
        when others then
          l_page := null;
      end;

      exit when l_page is null;
    end loop;

  exception
    when others then
      oci_log_pkg.log_msg(
        p_run_id       => p_run_id,
        p_level        => 'ERROR',
        p_step         => 'REGION_FAILED',
        p_message      => 'Region failed: ' || p_region || ' => ' || sqlerrm,
        p_details_json => to_clob(dbms_utility.format_error_backtrace)
      );
      raise;
  end load_region;

  ------------------------------------------------------------------------------
  -- Main
  ------------------------------------------------------------------------------
  procedure run(p_job_name in varchar2 default 'RESOURCES_PY') is
    l_run_id number;

    l_regions sys.odcivarchar2list;

    l_cred          varchar2(128) := cfg('CREDENTIAL_NAME', 'OCI$RESOURCE_PRINCIPAL');
    l_resources_tbl varchar2(32767);
    l_rel_proc      varchar2(32767);
    l_oke_proc      varchar2(32767);

    l_trunc_sql     varchar2(4000);
  begin
    oci_log_pkg.start_run(
      p_job_name    => p_job_name,
      p_module      => 'oci_resources_loader_pkg.run',
      p_params_json => to_clob('{"credential":"' || replace(l_cred,'"','\"') || '"}'),
      p_run_id      => l_run_id
    );

    oci_log_pkg.log_msg(
      p_run_id  => l_run_id,
      p_level   => 'INFO',
      p_step    => 'START',
      p_message => 'Start job=' || p_job_name
    );

    get_targets(l_run_id, l_resources_tbl, l_rel_proc, l_oke_proc);

    l_trunc_sql := 'truncate table '||l_resources_tbl;
    oci_log_pkg.log_msg(
      p_run_id  => l_run_id,
      p_level   => 'INFO',
      p_step    => 'TRUNCATE',
      p_message => 'Truncating: ' || l_resources_tbl
    );
    execute immediate l_trunc_sql;
    commit;

    l_regions := get_regions(l_run_id);

    for i in 1 .. l_regions.count loop
      load_region(
        p_run_id        => l_run_id,
        p_region        => l_regions(i),
        p_cred          => l_cred,
        p_resources_tbl => l_resources_tbl
      );
    end loop;

    oci_log_pkg.log_msg(
      p_run_id  => l_run_id,
      p_level   => 'INFO',
      p_step    => 'POST_PROC',
      p_message => 'Calling ' || l_rel_proc
    );
    execute immediate 'begin '||l_rel_proc||'; end;';
    oci_log_pkg.log_msg(
      p_run_id  => l_run_id,
      p_level   => 'INFO',
      p_step    => 'POST_PROC',
      p_message => 'Calling ' || l_oke_proc
    );
    execute immediate 'begin '||l_oke_proc||'; end;';
    commit;

    oci_log_pkg.log_msg(
      p_run_id  => l_run_id,
      p_level   => 'INFO',
      p_step    => 'DONE',
      p_message => 'Success'
    );
    oci_log_pkg.end_run_success(l_run_id);

  exception
    when others then
      if l_run_id is not null then
        begin
          oci_log_pkg.log_msg(
            p_run_id       => l_run_id,
            p_level        => 'ERROR',
            p_step         => 'FAILED',
            p_message      => sqlerrm,
            p_details_json => to_clob(dbms_utility.format_error_backtrace)
          );
          oci_log_pkg.end_run_error(l_run_id, sqlcode, sqlerrm);
        exception
          when others then null;
        end;
      end if;
      raise;
  end run;

end oci_resources_loader_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "OCI_SCHEDULER_ADMIN_PKG" AUTHID DEFINER AS
  PROCEDURE run_job   (p_job_name IN VARCHAR2);
  PROCEDURE stop_job  (p_job_name IN VARCHAR2);
  PROCEDURE enable_job(p_job_name IN VARCHAR2);
  PROCEDURE disable_job(p_job_name IN VARCHAR2);
  PROCEDURE drop_job  (p_job_name IN VARCHAR2);

  PROCEDURE update_job(
    p_job_name        IN VARCHAR2,
    p_enabled         IN VARCHAR2,  -- 'Y' / 'N'
    p_repeat_interval IN VARCHAR2,
    p_comments        IN VARCHAR2,
    p_job_action      IN CLOB
  );
END oci_scheduler_admin_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "OCI_SCHEDULER_ADMIN_PKG" AS

  PROCEDURE run_job(p_job_name IN VARCHAR2) IS
  BEGIN
    DBMS_SCHEDULER.run_job(
      job_name            => p_job_name,
      use_current_session => FALSE
    );
  END run_job;

  PROCEDURE stop_job(p_job_name IN VARCHAR2) IS
  BEGIN
    DBMS_SCHEDULER.stop_job(
      job_name => p_job_name,
      force    => TRUE
    );
  END stop_job;

  PROCEDURE enable_job(p_job_name IN VARCHAR2) IS
  BEGIN
    DBMS_SCHEDULER.enable(
      name => p_job_name
    );
  END enable_job;

  PROCEDURE disable_job(p_job_name IN VARCHAR2) IS
  BEGIN
    DBMS_SCHEDULER.disable(
      name => p_job_name
    );
  END disable_job;

  PROCEDURE drop_job(p_job_name IN VARCHAR2) IS
  BEGIN
    DBMS_SCHEDULER.drop_job(
      job_name => p_job_name,
      force    => TRUE
    );
  END drop_job;

  PROCEDURE update_job(
    p_job_name        IN VARCHAR2,
    p_enabled         IN VARCHAR2,
    p_repeat_interval IN VARCHAR2,
    p_comments        IN VARCHAR2,
    p_job_action      IN CLOB
  ) IS
  BEGIN
    IF p_repeat_interval IS NOT NULL THEN
      DBMS_SCHEDULER.set_attribute(
        name      => p_job_name,
        attribute => 'repeat_interval',
        value     => p_repeat_interval
      );
    END IF;

    IF p_comments IS NOT NULL THEN
      DBMS_SCHEDULER.set_attribute(
        name      => p_job_name,
        attribute => 'comments',
        value     => p_comments
      );
    END IF;

    IF p_job_action IS NOT NULL THEN
      DBMS_SCHEDULER.set_attribute(
        name      => p_job_name,
        attribute => 'job_action',
        value     => p_job_action
      );
    END IF;

    IF p_enabled = 'Y' THEN
      DBMS_SCHEDULER.enable(
        name => p_job_name
      );
    ELSIF p_enabled = 'N' THEN
      DBMS_SCHEDULER.disable(
        name => p_job_name
      );
    END IF;
  END update_job;

END oci_scheduler_admin_pkg;
/

  CREATE OR REPLACE EDITIONABLE PACKAGE "OCI_SUBSCRIPTIONS_PKG" as
  procedure run(p_run_id out number);
end oci_subscriptions_pkg;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "OCI_SUBSCRIPTIONS_PKG" as
  c_cred constant varchar2(128) := 'OCI$RESOURCE_PRINCIPAL';

  -- Format TIMESTAMP WITH TIME ZONE like Python: 2024-02-09T23:59:59+00:00
  function ts_tz_to_iso_utc(p_ts in timestamp with time zone) return varchar2 is
  begin
    if p_ts is null then
      return null;
    end if;

    return to_char(p_ts at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"+00:00"');
  end;

  -- Build JSON array CLOB for commitment services
  function commitment_services_to_clob(
    p_tbl in c##cloud$service.dbms_cloud_oci_onesubscription_commitment_service_tbl
  ) return clob is
    l_arr json_array_t := json_array_t();
    l_obj json_object_t;
    l_clob clob;
  begin
    if p_tbl is null then
      return null;
    end if;

    for i in 1 .. p_tbl.count loop
      l_obj := json_object_t();
      l_obj.put('time_start', ts_tz_to_iso_utc(p_tbl(i).time_start));
      l_obj.put('time_end',   ts_tz_to_iso_utc(p_tbl(i).time_end));
      l_obj.put('quantity',   p_tbl(i).quantity);
      l_obj.put('available_amount', p_tbl(i).available_amount);
      l_obj.put('line_net_amount',  p_tbl(i).line_net_amount);
      l_obj.put('funded_allocation_value', p_tbl(i).funded_allocation_value);
      l_arr.append(l_obj);
    end loop;

    l_clob := l_arr.to_clob;
    return l_clob;
  end;

  procedure run(p_run_id out number) is
    l_root_ocid varchar2(4000);
    l_region    varchar2(200);
    l_subs_tab  varchar2(4000);
    l_comm_tab  varchar2(4000);

    l_org_resp  c##cloud$service.dbms_cloud_oci_os_organization_subscription_list_organization_subscriptions_response_t;
    l_sub_resp  c##cloud$service.dbms_cloud_oci_os_subscription_list_subscriptions_response_t;

    l_step_start pls_integer;
    l_rows_subs  number;
    l_rows_comm  number;

  begin
    l_root_ocid := oci_app_config_pkg.get_value('OCI_ROOT_COMPARTMENT_OCID');
    l_region    := oci_app_config_pkg.get_value('OCI_HOME_REGION');
    l_subs_tab  := oci_app_config_pkg.get_value('SUBSCRIPTIONS_TARGET_TABLE');
    l_comm_tab  := oci_app_config_pkg.get_value('SUBSCRIPTION_COMMIT_TARGET_TABLE');

    declare
      l_params_json clob;
    begin
      select json_object(
              'root_compartment_ocid' value l_root_ocid,
              'region' value l_region,
              'subs_table' value l_subs_tab,
              'comm_table' value l_comm_tab
            returning clob)
        into l_params_json
        from dual;

      oci_log_pkg.start_run(
        p_job_name    => 'OCI_SUBSCRIPTIONS',
        p_module      => 'oci_subscriptions_pkg.run',
        p_params_json => l_params_json,
        p_run_id      => p_run_id
      );
    end;

    -- truncate targets
    l_step_start := dbms_utility.get_time;
    execute immediate 'truncate table ' || l_subs_tab;
    execute immediate 'truncate table ' || l_comm_tab;

    oci_log_pkg.log_msg(
      p_run_id     => p_run_id,
      p_level      => 'INFO',
      p_step       => 'TRUNCATE',
      p_message    => 'Truncated target tables',
      p_elapsed_ms => (dbms_utility.get_time - l_step_start) * 10
    );

    -- list organization subscriptions
    l_step_start := dbms_utility.get_time;
    l_org_resp :=
      c##cloud$service.dbms_cloud_oci_os_organization_subscription.list_organization_subscriptions(
        compartment_id  => l_root_ocid,
        limit           => 500,
        page            => null,
        region          => l_region,
        credential_name => c_cred
      );

    if l_org_resp.status_code not between 200 and 299 then
      oci_log_pkg.log_msg(
        p_run_id  => p_run_id,
        p_level   => 'ERROR',
        p_step    => 'LIST_ORG_SUBSCRIPTIONS',
        p_message => 'Non-2xx status_code=' || l_org_resp.status_code
      );
      raise_application_error(-20010, 'list_organization_subscriptions failed, status=' || l_org_resp.status_code);
    end if;

    if l_org_resp.response_body is null or l_org_resp.response_body.count = 0 then
      oci_log_pkg.log_msg(
        p_run_id  => p_run_id,
        p_level   => 'WARN',
        p_step    => 'LIST_ORG_SUBSCRIPTIONS',
        p_message => 'No organization subscriptions returned'
      );
      -- nothing to do
      oci_log_pkg.end_run_success(p_run_id);
      return;
    end if;

    oci_log_pkg.log_msg(
      p_run_id     => p_run_id,
      p_level      => 'INFO',
      p_step       => 'LIST_ORG_SUBSCRIPTIONS',
      p_message    => 'Fetched organization subscriptions',
      p_rows_affected => l_org_resp.response_body.count,
      p_elapsed_ms => (dbms_utility.get_time - l_step_start) * 10
    );

    -- loop each org subscription id
    for orgs in (
      select t.id as subscription_id
      from table(l_org_resp.response_body) t
    ) loop
      l_rows_subs := 0;
      l_rows_comm := 0;

      -- pull subscription summaries (with commit info)
      l_step_start := dbms_utility.get_time;
      l_sub_resp :=
        c##cloud$service.dbms_cloud_oci_os_subscription.list_subscriptions(
          compartment_id          => l_root_ocid,
          subscription_id         => orgs.subscription_id,
          is_commit_info_required => 1,
          limit                   => 500,
          page                    => null,
          region                  => l_region,
          credential_name         => c_cred
        );

      if l_sub_resp.status_code not between 200 and 299 then
        oci_log_pkg.log_msg(
          p_run_id  => p_run_id,
          p_level   => 'WARN',
          p_step    => 'LIST_SUBSCRIPTIONS',
          p_message => 'Non-2xx for org_subscription_id=' || orgs.subscription_id ||
                       ' status_code=' || l_sub_resp.status_code
        );
        continue;
      end if;

      if l_sub_resp.response_body is null or l_sub_resp.response_body.count = 0 then
        oci_log_pkg.log_msg(
          p_run_id  => p_run_id,
          p_level   => 'INFO',
          p_step    => 'LIST_SUBSCRIPTIONS',
          p_message => 'No subscription summaries for org_subscription_id=' || orgs.subscription_id
        );
        continue;
      end if;

      oci_log_pkg.log_msg(
        p_run_id       => p_run_id,
        p_level        => 'INFO',
        p_step         => 'LIST_SUBSCRIPTIONS',
        p_message      => 'Fetched subscription summaries for org_subscription_id=' || orgs.subscription_id,
        p_rows_affected => l_sub_resp.response_body.count,
        p_elapsed_ms   => (dbms_utility.get_time - l_step_start) * 10
      );

      -- insert subscribed services + commitments
      for sub in (
        select t.*
        from table(l_sub_resp.response_body) t
      ) loop
        if sub.subscribed_services is not null then
          for svc in (
            select s.*
            from table(sub.subscribed_services) s
          ) loop
            -- subscribed services row
            execute immediate '
              insert into ' || l_subs_tab || '(
                subscription_id,
                iso_code,
                name,
                std_precision,
                service_name,
                status,
                available_amount,
                booking_opty_number,
                commitment_services,
                csi,
                data_center_region,
                funded_allocation_value,
                is_intent_to_pay,
                net_unit_price,
                operation_type,
                order_number,
                original_promo_amount,
                partner_transaction_type,
                pricing_model,
                product_name,
                product_part_number,
                product_provisioning_group,
                product_unit_of_measure,
                program_type,
                promo_type,
                quantity,
                substatus,
                time_end,
                time_start,
                total_value,
                used_amount,
                subscription_line_id
              ) values (
                :subscription_id,
                :iso_code,
                :currency_name,
                :std_precision,
                :service_name,
                :status,
                :available_amount,
                :booking_opty_number,
                :commitment_services,
                :csi,
                :data_center_region,
                :funded_allocation_value,
                :is_intent_to_pay,
                :net_unit_price,
                :operation_type,
                :order_number,
                :original_promo_amount,
                :partner_transaction_type,
                :pricing_model,
                :product_name,
                :product_part_number,
                :product_provisioning_group,
                :product_unit_of_measure,
                :program_type,
                :promo_type,
                :quantity,
                :substatus,
                :time_end,
                :time_start,
                :total_value,
                :used_amount,
                :subscription_line_id
              )'
            using
              orgs.subscription_id,                                  -- subscription_id
              sub.currency.iso_code,                                 -- iso_code
              sub.currency.name,                                     -- currency_name
              sub.currency.std_precision,                            -- std_precision
              sub.service_name,                                      -- service_name
              sub.status,                                            -- status
              svc.available_amount,                                  -- available_amount
              svc.booking_opty_number,                               -- booking_opty_number
              commitment_services_to_clob(svc.commitment_services),  -- commitment_services
              to_char(svc.csi),                                      -- csi
              svc.data_center_region,                                -- data_center_region
              svc.funded_allocation_value,                           -- funded_allocation_value
              case when svc.is_intent_to_pay = 1 then 'True' else 'False' end,
              svc.net_unit_price,
              svc.operation_type,
              to_char(svc.order_number),
              svc.original_promo_amount,
              svc.partner_transaction_type,
              svc.pricing_model,
              svc.product.name,
              svc.product.part_number,
              svc.product.provisioning_group,
              svc.product.unit_of_measure,
              svc.program_type,
              svc.promo_type,
              svc.quantity,
              svc.status,
              ts_tz_to_iso_utc(svc.time_end),
              ts_tz_to_iso_utc(svc.time_start),
              svc.total_value,
              svc.used_amount,
              svc.id;

            l_rows_subs := l_rows_subs + 1;

            -- commitment services rows
            if svc.commitment_services is not null then
              for c in (
                select x.*
                from table(svc.commitment_services) x
              ) loop
                execute immediate '
                  insert into ' || l_comm_tab || '(
                    subscription_id,
                    subscription_line_id,
                    commitment_time_start,
                    commitment_time_end,
                    commitment_quantity,
                    commitment_available_amt,
                    commitment_line_net_amt,
                    commitment_fa_value
                  ) values (
                      :subscription_id,
                      :subscription_line_id,
                      :commitment_time_start,
                      :commitment_time_end,
                      :commitment_quantity,
                      :commitment_available_amt,
                      :commitment_line_net_amt,
                      :commitment_fa_value
                    )'
                using
                  orgs.subscription_id,
                  svc.id,
                  cast(c.time_start as timestamp),
                  cast(c.time_end as timestamp),
                  c.quantity,
                  c.available_amount,
                  c.line_net_amount,
                  c.funded_allocation_value;

                l_rows_comm := l_rows_comm + 1;
              end loop;
            end if;

          end loop;
        end if;
      end loop;

      oci_log_pkg.log_msg(
        p_run_id        => p_run_id,
        p_level         => 'INFO',
        p_step          => 'INSERT_SUBS',
        p_message       => 'Inserted subscription rows for org_subscription_id=' || orgs.subscription_id,
        p_rows_affected => l_rows_subs
      );

      oci_log_pkg.log_msg(
        p_run_id        => p_run_id,
        p_level         => 'INFO',
        p_step          => 'INSERT_COMMIT',
        p_message       => 'Inserted commitment rows for org_subscription_id=' || orgs.subscription_id,
        p_rows_affected => l_rows_comm
      );
    end loop;

    -- post-load procedures from config (optional)
    declare
      l_p1 varchar2(4000) := oci_app_config_pkg.get_value('POST_SUBS_PROC_1', p_required => false);
      l_p2 varchar2(4000) := oci_app_config_pkg.get_value('POST_SUBS_PROC_2', p_required => false);

      function is_allowed_call(p_call varchar2) return boolean is
        l varchar2(4000) := upper(trim(p_call));
      begin
        return regexp_like(l, '^[A-Z0-9_$#]+(\.[A-Z0-9_$#]+){0,2}$');
      end;
    begin
      if l_p1 is not null then
        if not is_allowed_call(l_p1) then
          raise_application_error(-20050, 'POST_SUBS_PROC_1 contains disallowed call.');
        end if;

        oci_log_pkg.log_msg(
          p_run_id  => p_run_id,
          p_level   => 'INFO',
          p_step    => 'POST_PROC',
          p_message => 'Executing: ' || l_p1
        );
        execute immediate 'begin ' || l_p1 || '; end;';
      end if;

      if l_p2 is not null then
        if not is_allowed_call(l_p2) then
          raise_application_error(-20050, 'POST_SUBS_PROC_2 contains disallowed call.');
        end if;

        oci_log_pkg.log_msg(
          p_run_id  => p_run_id,
          p_level   => 'INFO',
          p_step    => 'POST_PROC',
          p_message => 'Executing: ' || l_p2
        );
        execute immediate 'begin ' || l_p2 || '; end;';
      end if;
    end;

    oci_log_pkg.end_run_success(p_run_id);

  exception
    when others then
      oci_log_pkg.log_msg(
        p_run_id       => p_run_id,
        p_level        => 'ERROR',
        p_step         => 'FAILED',
        p_message      => sqlerrm,
        p_details_json => to_clob(dbms_utility.format_error_backtrace)
      );
      oci_log_pkg.end_run_error(p_run_id, sqlcode, sqlerrm);
      raise;
  end run;

end oci_subscriptions_pkg;
/
