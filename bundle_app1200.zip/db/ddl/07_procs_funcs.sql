
  CREATE OR REPLACE EDITIONABLE FUNCTION "COST_PIVOT_DYNAMIC_DAILY_HTML" (
    p_tenant             IN VARCHAR2,
    p_subscription_id    IN VARCHAR2,
    p_region             IN VARCHAR2,
    p_compartment        IN VARCHAR2,
    p_service_category   IN VARCHAR2,
    p_service_name       IN VARCHAR2,
    p_charge_description IN VARCHAR2,
    p_resource_type      IN VARCHAR2,
    p_resource_name      IN VARCHAR2,
    p_fromdate           IN VARCHAR2,
    p_todate             IN VARCHAR2,
    p_group_level1       IN VARCHAR2,
    p_group_level2       IN VARCHAR2,
    p_group_level3       IN VARCHAR2
) RETURN CLOB IS
    v_html         CLOB := '';
    v_key          VARCHAR2(1000);
    v_cost         NUMBER := 0;
    v_sql          CLOB;
    TYPE rc IS REF CURSOR;

    TYPE pivot_map_type IS TABLE OF NUMBER INDEX BY VARCHAR2(1000);
    v_data_map     pivot_map_type;
    v_totals       pivot_map_type;

    TYPE t_header_row IS TABLE OF VARCHAR2(1000) INDEX BY PLS_INTEGER;
    TYPE int_map_type IS TABLE OF INTEGER INDEX BY VARCHAR2(500);

    v_lvl1_col VARCHAR2(100);
    v_lvl2_col VARCHAR2(100);
    v_lvl3_col VARCHAR2(100);

    v_lvl1_map    t_header_row;
    v_lvl2_map    t_header_row;
    v_lvl3_map    t_header_row;
    v_columns     t_header_row;
    v_idx         INTEGER := 0;

    v_group_cursor rc;
    v_cursor       rc;

    -- Track previous day's cost per column (for highlighting)
    v_prev_costs  pivot_map_type;
    l_prev_cost   NUMBER;
    l_delta       NUMBER;
    l_delta_pct   NUMBER;
    l_style       VARCHAR2(200);
    l_cost_text   VARCHAR2(100);

    CURSOR cur_dates IS
        SELECT DISTINCT TO_CHAR(DATE_BUCKET, 'DD-Mon') AS day_label, DATE_BUCKET
        FROM COST_USAGE_TIMESERIES_DAILY
        WHERE DATE_BUCKET BETWEEN TO_DATE(p_fromdate, 'DD-MON-YYYY HH24:MI:SS') AND TO_DATE(p_todate, 'DD-MON-YYYY HH24:MI:SS')
        ORDER BY DATE_BUCKET;

    FUNCTION add_filter(col_name VARCHAR2, param_val VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        IF param_val IS NULL OR TRIM(param_val) IS NULL THEN
            RETURN '';
        ELSE
            RETURN ' AND ' || col_name || ' IN (
                SELECT TRIM(COLUMN_VALUE)
                FROM TABLE(apex_string.split(''' || REPLACE(param_val, '''', '''''') || ''', '',''))
            )';
        END IF;
    END;

BEGIN
    v_lvl1_col := p_group_level1;
    v_lvl2_col := p_group_level2;
    v_lvl3_col := p_group_level3;

    -- HTML Table Start
    v_html := '<div class="pivot-scroll"><table id="pivot-table" class="pivot-table" border="1"><thead><tr><th class="pivot-day-col" rowspan="3">Day</th>';

    -- Build dynamic SQL for columns
    v_sql := 'SELECT DISTINCT NVL(' || v_lvl1_col || ', ''None''), NVL(' || v_lvl2_col || ', ''Unknown''), NVL(' || v_lvl3_col || ', ''Unknown'') '
          || 'FROM COST_USAGE_TIMESERIES_DAILY '
          || 'WHERE DATE_BUCKET BETWEEN TO_DATE(:1, ''DD-MON-YYYY HH24:MI:SS'') AND TO_DATE(:2, ''DD-MON-YYYY HH24:MI:SS'') '
          || add_filter('SUBACCOUNTNAME', p_tenant)
          || add_filter('BILLINGACCOUNTID', p_subscription_id)
          || add_filter('REGION', p_region)
          || add_filter('OCI_COMPARTMENTID', p_compartment)
          || add_filter('SERVICECATEGORY', p_service_category)
          || add_filter('SERVICENAME', p_service_name)
          || add_filter('CHARGEDESCRIPTION', p_charge_description)
          || add_filter('RESOURCETYPE', p_resource_type)
          || add_filter('RESOURCEID', p_resource_name)
          || ' ORDER BY 1, 2, 3';

    OPEN v_group_cursor FOR v_sql USING p_fromdate, p_todate;
    LOOP
        FETCH v_group_cursor INTO v_lvl1_map(v_idx + 1), v_lvl2_map(v_idx + 1), v_lvl3_map(v_idx + 1);
        EXIT WHEN v_group_cursor%NOTFOUND;
        v_idx := v_idx + 1;
        v_columns(v_idx) := v_lvl1_map(v_idx) || '|' || v_lvl2_map(v_idx) || '|' || v_lvl3_map(v_idx);
    END LOOP;
    CLOSE v_group_cursor;

    -- Header Rows
    DECLARE
        TYPE temp_map IS TABLE OF INTEGER INDEX BY VARCHAR2(500);
        v_colspan_map temp_map;
        col_key VARCHAR2(500);
    BEGIN
        FOR i IN 1 .. v_idx LOOP
            col_key := v_lvl1_map(i);
            IF v_colspan_map.EXISTS(col_key) THEN
                v_colspan_map(col_key) := v_colspan_map(col_key) + 1;
            ELSE
                v_colspan_map(col_key) := 1;
            END IF;
        END LOOP;

        col_key := v_colspan_map.FIRST;
        WHILE col_key IS NOT NULL LOOP
            v_html := v_html || '<th colspan="' || v_colspan_map(col_key) || '">' || col_key || '</th>';
            col_key := v_colspan_map.NEXT(col_key);
        END LOOP;
    END;

    v_html := v_html || '</tr><tr>';
    FOR i IN 1 .. v_idx LOOP
        v_html := v_html || '<th>' || v_lvl2_map(i) || '</th>';
    END LOOP;
    v_html := v_html || '</tr><tr>';
    FOR i IN 1 .. v_idx LOOP
        v_html := v_html || '<th>' || v_lvl3_map(i) || '</th>';
    END LOOP;
    v_html := v_html || '</tr></thead><tbody>';

    -- Build pivot data
    v_sql := '
        SELECT TO_CHAR(DATE_BUCKET, ''DD-Mon'') || ''|'' ||
               NVL(' || v_lvl1_col || ', ''None'') || ''|'' ||
               NVL(' || v_lvl2_col || ', ''Unknown'') || ''|'' ||
               NVL(' || v_lvl3_col || ', ''Unknown'') AS map_key,
               SUM(COST)
        FROM COST_USAGE_TIMESERIES_DAILY
        WHERE DATE_BUCKET BETWEEN TO_DATE(:1, ''DD-MON-YYYY HH24:MI:SS'') AND TO_DATE(:2, ''DD-MON-YYYY HH24:MI:SS'') '
        || add_filter('SUBACCOUNTNAME', p_tenant)
        || add_filter('BILLINGACCOUNTID', p_subscription_id)
        || add_filter('REGION', p_region)
        || add_filter('OCI_COMPARTMENTID', p_compartment)
        || add_filter('SERVICECATEGORY', p_service_category)
        || add_filter('SERVICENAME', p_service_name)
        || add_filter('CHARGEDESCRIPTION', p_charge_description)
        || add_filter('RESOURCETYPE', p_resource_type)
        || add_filter('RESOURCEID', p_resource_name)
        || ' GROUP BY TO_CHAR(DATE_BUCKET, ''DD-Mon''), NVL(' || v_lvl1_col || ', ''None''), NVL(' || v_lvl2_col || ', ''Unknown''), NVL(' || v_lvl3_col || ', ''Unknown'')';

    OPEN v_cursor FOR v_sql USING p_fromdate, p_todate;
    LOOP
        FETCH v_cursor INTO v_key, v_cost;
        EXIT WHEN v_cursor%NOTFOUND;
        v_data_map(v_key) := v_cost;
    END LOOP;
    CLOSE v_cursor;

    -- Output data rows
    FOR date_rec IN cur_dates LOOP
        v_html := v_html || '<tr><td class="pivot-day-col">' || date_rec.day_label || '</td>';

        FOR i IN 1 .. v_idx LOOP
            v_key := date_rec.day_label || '|' || v_lvl1_map(i) || '|' || v_lvl2_map(i) || '|' || v_lvl3_map(i);

            -- Current cost
            v_cost := CASE
                        WHEN v_data_map.EXISTS(v_key) THEN v_data_map(v_key)
                        ELSE 0
                      END;

            -- Previous day's cost for this column (if any)
            l_prev_cost := NULL;
            IF v_prev_costs.EXISTS(v_columns(i)) THEN
                l_prev_cost := v_prev_costs(v_columns(i));
            END IF;

            -- Store current as "previous" for next day
            v_prev_costs(v_columns(i)) := v_cost;

            -- Default: no special style
            l_style := NULL;

            -- Compute % change vs previous day and decide color
            IF l_prev_cost IS NOT NULL AND l_prev_cost > 0 THEN
                l_delta     := v_cost - l_prev_cost;
                l_delta_pct := l_delta / l_prev_cost;

                -- Absolute change >= 10% → highlight
                IF ABS(l_delta_pct) >= 0.10 THEN
                    IF l_delta_pct > 0 THEN
                        -- ≥ +10% vs previous day: light red
                        l_style := ' class="pivot-cell-up"';
                    ELSE
                        -- ≤ −10% vs previous day: light green
                        l_style := ' class="pivot-cell-down"';
                    END IF;
                END IF;
            END IF;

            -- Format cost
            l_cost_text := CASE
                             WHEN v_cost < 1 THEN '0' || TO_CHAR(v_cost, 'FM.00')
                             ELSE TO_CHAR(v_cost, 'FM999G999G999G990D00')
                           END;

            -- Emit cell with optional style
            v_html := v_html || '<td' || NVL(l_style, '') || '>' || l_cost_text || '</td>';

            -- Accumulate column totals
            IF v_totals.EXISTS(v_columns(i)) THEN
                v_totals(v_columns(i)) := v_totals(v_columns(i)) + v_cost;
            ELSE
                v_totals(v_columns(i)) := v_cost;
            END IF;
        END LOOP;

        v_html := v_html || '</tr>';
    END LOOP;

    -- Totals row
    v_html := v_html || '<tr><td class="pivot-day-col"><b>Total</b></td>';
    FOR i IN 1 .. v_idx LOOP
        v_cost := NVL(v_totals(v_columns(i)), 0);
        v_html := v_html || '<td><b>' || CASE
                                            WHEN v_cost < 1 THEN '0' || TO_CHAR(v_cost, 'FM.00')
                                            ELSE TO_CHAR(v_cost, 'FM999G999G999G990D00')
                                         END || '</b></td>';
    END LOOP;
    v_html := v_html || '</tr>';

    v_html := v_html || '</tbody></table></div>';
    RETURN v_html;
END;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "COST_PIVOT_DYNAMIC_MONTHLY_HTML" (
    p_tenant             IN VARCHAR2,
    p_subscription_id    IN VARCHAR2,
    p_region             IN VARCHAR2,
    p_compartment        IN VARCHAR2,
    p_service_category   IN VARCHAR2,
    p_service_name       IN VARCHAR2,
    p_charge_description IN VARCHAR2,
    p_resource_type      IN VARCHAR2,
    p_resource_name      IN VARCHAR2,
    p_fromdate           IN VARCHAR2,
    p_todate             IN VARCHAR2,
    p_group_level1       IN VARCHAR2,
    p_group_level2       IN VARCHAR2,
    p_group_level3       IN VARCHAR2
) RETURN CLOB IS
    v_html         CLOB := '';
    v_key          VARCHAR2(1000);
    v_cost         NUMBER := 0;
    v_sql          CLOB;
    TYPE rc IS REF CURSOR;

    TYPE pivot_map_type IS TABLE OF NUMBER INDEX BY VARCHAR2(1000);
    v_data_map     pivot_map_type;
    v_totals       pivot_map_type;

    TYPE t_header_row IS TABLE OF VARCHAR2(1000) INDEX BY PLS_INTEGER;

    v_lvl1_col VARCHAR2(100);
    v_lvl2_col VARCHAR2(100);
    v_lvl3_col VARCHAR2(100);

    v_lvl1_map    t_header_row;
    v_lvl2_map    t_header_row;
    v_lvl3_map    t_header_row;
    v_columns     t_header_row;
    v_idx         INTEGER := 0;

    v_group_cursor rc;
    v_cursor       rc;

    CURSOR cur_dates IS
        SELECT DISTINCT TO_CHAR(TRUNC(DATE_BUCKET, 'MM'), 'Mon YYYY') AS month_label,
                        TRUNC(DATE_BUCKET, 'MM') AS month_bucket
        FROM COST_USAGE_TIMESERIES_MONTHLY
        WHERE DATE_BUCKET BETWEEN TO_DATE(p_fromdate, 'DD-MON-YYYY HH24:MI:SS')
                              AND TO_DATE(p_todate,   'DD-MON-YYYY HH24:MI:SS')
        ORDER BY 2;

    FUNCTION add_filter(col_name VARCHAR2, param_val VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        IF param_val IS NULL OR TRIM(param_val) IS NULL THEN
            RETURN '';
        ELSE
            RETURN ' AND ' || col_name || ' IN (
                SELECT TRIM(COLUMN_VALUE)
                FROM TABLE(apex_string.split(''' || REPLACE(param_val, '''', '''''') || ''', '',''))
            )';
        END IF;
    END;
BEGIN
    v_lvl1_col := p_group_level1;
    v_lvl2_col := p_group_level2;
    v_lvl3_col := p_group_level3;

    -- NOTE: first header cell gets pivot-day-col for sticky behavior
    v_html := '<div class="pivot-scroll"><table id="pivot-table" class="pivot-table" border="1">' ||
              '<thead><tr><th class="pivot-day-col" rowspan="3">Month</th>';

    -- Build column headers
    v_sql := 'SELECT DISTINCT NVL(' || v_lvl1_col || ', ''None''), ' ||
                           'NVL(' || v_lvl2_col || ', ''Unknown''), ' ||
                           'NVL(' || v_lvl3_col || ', ''Unknown'') ' ||
             'FROM COST_USAGE_TIMESERIES_MONTHLY ' ||
             'WHERE DATE_BUCKET BETWEEN TO_DATE(:1, ''DD-MON-YYYY HH24:MI:SS'') ' ||
                                   'AND TO_DATE(:2, ''DD-MON-YYYY HH24:MI:SS'') ' ||
             add_filter('SUBACCOUNTNAME', p_tenant) ||
             add_filter('BILLINGACCOUNTID', p_subscription_id) ||
             add_filter('REGION', p_region) ||
             add_filter('OCI_COMPARTMENTID', p_compartment) ||
             add_filter('SERVICECATEGORY', p_service_category) ||
             add_filter('SERVICENAME', p_service_name) ||
             add_filter('CHARGEDESCRIPTION', p_charge_description) ||
             add_filter('RESOURCETYPE', p_resource_type) ||
             add_filter('RESOURCEID', p_resource_name) ||
             ' ORDER BY 1, 2, 3';

    OPEN v_group_cursor FOR v_sql USING p_fromdate, p_todate;
    LOOP
        FETCH v_group_cursor INTO v_lvl1_map(v_idx + 1),
                                v_lvl2_map(v_idx + 1),
                                v_lvl3_map(v_idx + 1);
        EXIT WHEN v_group_cursor%NOTFOUND;
        v_idx := v_idx + 1;
        v_columns(v_idx) := v_lvl1_map(v_idx) || '|' ||
                            v_lvl2_map(v_idx) || '|' ||
                            v_lvl3_map(v_idx);
    END LOOP;
    CLOSE v_group_cursor;

    -- Header row level 1
    DECLARE
        TYPE temp_map IS TABLE OF INTEGER INDEX BY VARCHAR2(500);
        v_colspan_map temp_map;
        col_key VARCHAR2(500);
    BEGIN
        FOR i IN 1 .. v_idx LOOP
            col_key := v_lvl1_map(i);
            IF v_colspan_map.EXISTS(col_key) THEN
                v_colspan_map(col_key) := v_colspan_map(col_key) + 1;
            ELSE
                v_colspan_map(col_key) := 1;
            END IF;
        END LOOP;

        col_key := v_colspan_map.FIRST;
        WHILE col_key IS NOT NULL LOOP
            v_html := v_html || '<th colspan="' || v_colspan_map(col_key) || '">' ||
                      col_key || '</th>';
            col_key := v_colspan_map.NEXT(col_key);
        END LOOP;
    END;

    -- Header level 2
    v_html := v_html || '</tr><tr>';
    FOR i IN 1 .. v_idx LOOP
        v_html := v_html || '<th>' || v_lvl2_map(i) || '</th>';
    END LOOP;

    -- Header level 3
    v_html := v_html || '</tr><tr>';
    FOR i IN 1 .. v_idx LOOP
        v_html := v_html || '<th>' || v_lvl3_map(i) || '</th>';
    END LOOP;
    v_html := v_html || '</tr></thead><tbody>';

    -- Pivot data
    v_sql := '
        SELECT TO_CHAR(TRUNC(DATE_BUCKET, ''MM''), ''Mon YYYY'') || ''|'' ||
               NVL(' || v_lvl1_col || ', ''None'') || ''|'' ||
               NVL(' || v_lvl2_col || ', ''Unknown'') || ''|'' ||
               NVL(' || v_lvl3_col || ', ''Unknown'') AS map_key,
               SUM(COST)
        FROM COST_USAGE_TIMESERIES_MONTHLY
        WHERE DATE_BUCKET BETWEEN TO_DATE(:1, ''DD-MON-YYYY HH24:MI:SS'')
                              AND TO_DATE(:2, ''DD-MON-YYYY HH24:MI:SS'') ' ||
        add_filter('SUBACCOUNTNAME', p_tenant) ||
        add_filter('BILLINGACCOUNTID', p_subscription_id) ||
        add_filter('REGION', p_region) ||
        add_filter('OCI_COMPARTMENTID', p_compartment) ||
        add_filter('SERVICECATEGORY', p_service_category) ||
        add_filter('SERVICENAME', p_service_name) ||
        add_filter('CHARGEDESCRIPTION', p_charge_description) ||
        add_filter('RESOURCETYPE', p_resource_type) ||
        add_filter('RESOURCEID', p_resource_name) ||
        ' GROUP BY TRUNC(DATE_BUCKET, ''MM''), ' ||
                  'NVL(' || v_lvl1_col || ', ''None''), ' ||
                  'NVL(' || v_lvl2_col || ', ''Unknown''), ' ||
                  'NVL(' || v_lvl3_col || ', ''Unknown'')';

    OPEN v_cursor FOR v_sql USING p_fromdate, p_todate;
    LOOP
        FETCH v_cursor INTO v_key, v_cost;
        EXIT WHEN v_cursor%NOTFOUND;
        v_data_map(v_key) := v_cost;
    END LOOP;
    CLOSE v_cursor;

    -- Data rows
    FOR date_rec IN cur_dates LOOP
        -- NOTE: first cell in row gets pivot-day-col
        v_html := v_html || '<tr><td class="pivot-day-col">' ||
                  date_rec.month_label || '</td>';
        FOR i IN 1 .. v_idx LOOP
            v_key := date_rec.month_label || '|' ||
                     v_lvl1_map(i)        || '|' ||
                     v_lvl2_map(i)        || '|' ||
                     v_lvl3_map(i);

            v_cost := CASE
                        WHEN v_data_map.EXISTS(v_key) THEN v_data_map(v_key)
                        ELSE 0
                      END;

            v_html := v_html || '<td>' ||
                      CASE
                        WHEN v_cost < 1 THEN '0' || TO_CHAR(v_cost, 'FM.00')
                        ELSE TO_CHAR(v_cost, 'FM999G999G999G990D00')
                      END || '</td>';

            IF v_totals.EXISTS(v_columns(i)) THEN
                v_totals(v_columns(i)) := v_totals(v_columns(i)) + v_cost;
            ELSE
                v_totals(v_columns(i)) := v_cost;
            END IF;
        END LOOP;
        v_html := v_html || '</tr>';
    END LOOP;

    -- Totals row – first cell also sticky
    v_html := v_html || '<tr><td class="pivot-day-col"><b>Total</b></td>';
    FOR i IN 1 .. v_idx LOOP
        v_cost := NVL(v_totals(v_columns(i)), 0);
        v_html := v_html || '<td><b>' ||
                  CASE
                    WHEN v_cost < 1 THEN '0' || TO_CHAR(v_cost, 'FM.00')
                    ELSE TO_CHAR(v_cost, 'FM999G999G999G990D00')
                  END || '</b></td>';
    END LOOP;
    v_html := v_html || '</tr>';

    v_html := v_html || '</tbody></table></div>';
    RETURN v_html;
END;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "COST_PIVOT_DYNAMIC_WEEKLY_HTML" (
    p_tenant             IN VARCHAR2,
    p_subscription_id    IN VARCHAR2,
    p_region             IN VARCHAR2,
    p_compartment        IN VARCHAR2,
    p_service_category   IN VARCHAR2,
    p_service_name       IN VARCHAR2,
    p_charge_description IN VARCHAR2,
    p_resource_type      IN VARCHAR2,
    p_resource_name      IN VARCHAR2,
    p_fromdate           IN VARCHAR2,
    p_todate             IN VARCHAR2,
    p_group_level1       IN VARCHAR2,
    p_group_level2       IN VARCHAR2,
    p_group_level3       IN VARCHAR2
) RETURN CLOB IS
    v_html         CLOB := '';
    v_key          VARCHAR2(1000);
    v_cost         NUMBER := 0;
    v_sql          CLOB;
    TYPE rc IS REF CURSOR;

    TYPE pivot_map_type IS TABLE OF NUMBER INDEX BY VARCHAR2(1000);
    v_data_map     pivot_map_type;
    v_totals       pivot_map_type;

    TYPE t_header_row IS TABLE OF VARCHAR2(1000) INDEX BY PLS_INTEGER;
    TYPE int_map_type IS TABLE OF INTEGER INDEX BY VARCHAR2(500);

    v_lvl1_col VARCHAR2(100);
    v_lvl2_col VARCHAR2(100);
    v_lvl3_col VARCHAR2(100);

    v_lvl1_map    t_header_row;
    v_lvl2_map    t_header_row;
    v_lvl3_map    t_header_row;
    v_columns     t_header_row;
    v_idx         INTEGER := 0;

    v_group_cursor rc;
    v_cursor       rc;

    CURSOR cur_dates IS
        SELECT DISTINCT TO_CHAR(DATE_BUCKET, 'DD-Mon') || ' (W' || TO_CHAR(DATE_BUCKET, 'IW') || ')' AS week_label,
                        DATE_BUCKET
        FROM COST_USAGE_TIMESERIES_WEEKLY
        WHERE DATE_BUCKET BETWEEN TO_DATE(p_fromdate, 'DD-MON-YYYY HH24:MI:SS')
                              AND TO_DATE(p_todate,   'DD-MON-YYYY HH24:MI:SS')
        ORDER BY DATE_BUCKET;

    FUNCTION add_filter(col_name VARCHAR2, param_val VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        IF param_val IS NULL OR TRIM(param_val) IS NULL THEN
            RETURN '';
        ELSE
            RETURN ' AND ' || col_name || ' IN (
                SELECT TRIM(COLUMN_VALUE)
                FROM TABLE(apex_string.split(''' || REPLACE(param_val, '''', '''''') || ''', '',''))
            )';
        END IF;
    END;
BEGIN
    v_lvl1_col := p_group_level1;
    v_lvl2_col := p_group_level2;
    v_lvl3_col := p_group_level3;

    -- Note: first header cell gets pivot-day-col (for sticky column)
    v_html := '<div class="pivot-scroll"><table id="pivot-table" class="pivot-table" border="1">' ||
              '<thead><tr><th class="pivot-day-col" rowspan="3">Week</th>';

    -- Distinct column headers
    v_sql := 'SELECT DISTINCT NVL(' || v_lvl1_col || ', ''None''), ' ||
                           'NVL(' || v_lvl2_col || ', ''Unknown''), ' ||
                           'NVL(' || v_lvl3_col || ', ''Unknown'') ' ||
             'FROM COST_USAGE_TIMESERIES_WEEKLY ' ||
             'WHERE DATE_BUCKET BETWEEN TO_DATE(:1, ''DD-MON-YYYY HH24:MI:SS'') ' ||
                                   'AND TO_DATE(:2, ''DD-MON-YYYY HH24:MI:SS'') ' ||
             add_filter('SUBACCOUNTNAME', p_tenant) ||
             add_filter('BILLINGACCOUNTID', p_subscription_id) ||
             add_filter('REGION', p_region) ||
             add_filter('OCI_COMPARTMENTID', p_compartment) ||
             add_filter('SERVICECATEGORY', p_service_category) ||
             add_filter('SERVICENAME', p_service_name) ||
             add_filter('CHARGEDESCRIPTION', p_charge_description) ||
             add_filter('RESOURCETYPE', p_resource_type) ||
             add_filter('RESOURCEID', p_resource_name) ||
             ' ORDER BY 1, 2, 3';

    OPEN v_group_cursor FOR v_sql USING p_fromdate, p_todate;
    LOOP
        FETCH v_group_cursor INTO v_lvl1_map(v_idx + 1),
                                v_lvl2_map(v_idx + 1),
                                v_lvl3_map(v_idx + 1);
        EXIT WHEN v_group_cursor%NOTFOUND;
        v_idx := v_idx + 1;
        v_columns(v_idx) := v_lvl1_map(v_idx) || '|' ||
                            v_lvl2_map(v_idx) || '|' ||
                            v_lvl3_map(v_idx);
    END LOOP;
    CLOSE v_group_cursor;

    -- Header: Level 1
    DECLARE
        TYPE temp_map IS TABLE OF INTEGER INDEX BY VARCHAR2(500);
        v_colspan_map temp_map;
        col_key VARCHAR2(500);
    BEGIN
        FOR i IN 1 .. v_idx LOOP
            col_key := v_lvl1_map(i);
            IF v_colspan_map.EXISTS(col_key) THEN
                v_colspan_map(col_key) := v_colspan_map(col_key) + 1;
            ELSE
                v_colspan_map(col_key) := 1;
            END IF;
        END LOOP;

        col_key := v_colspan_map.FIRST;
        WHILE col_key IS NOT NULL LOOP
            v_html := v_html || '<th colspan="' || v_colspan_map(col_key) || '">' ||
                      col_key || '</th>';
            col_key := v_colspan_map.NEXT(col_key);
        END LOOP;
    END;

    -- Header: Level 2 and 3
    v_html := v_html || '</tr><tr>';
    FOR i IN 1 .. v_idx LOOP
        v_html := v_html || '<th>' || v_lvl2_map(i) || '</th>';
    END LOOP;
    v_html := v_html || '</tr><tr>';
    FOR i IN 1 .. v_idx LOOP
        v_html := v_html || '<th>' || v_lvl3_map(i) || '</th>';
    END LOOP;
    v_html := v_html || '</tr></thead><tbody>';

    -- Load pivot data
    v_sql := '
        SELECT TO_CHAR(DATE_BUCKET, ''DD-Mon'') || '' (W'' || TO_CHAR(DATE_BUCKET, ''IW'') || '')'' || ''|'' ||
               NVL(' || v_lvl1_col || ', ''None'') || ''|'' ||
               NVL(' || v_lvl2_col || ', ''Unknown'') || ''|'' ||
               NVL(' || v_lvl3_col || ', ''Unknown'') AS map_key,
               SUM(COST)
        FROM COST_USAGE_TIMESERIES_WEEKLY
        WHERE DATE_BUCKET BETWEEN TO_DATE(:1, ''DD-MON-YYYY HH24:MI:SS'')
                              AND TO_DATE(:2, ''DD-MON-YYYY HH24:MI:SS'') ' ||
        add_filter('SUBACCOUNTNAME', p_tenant) ||
        add_filter('BILLINGACCOUNTID', p_subscription_id) ||
        add_filter('REGION', p_region) ||
        add_filter('OCI_COMPARTMENTID', p_compartment) ||
        add_filter('SERVICECATEGORY', p_service_category) ||
        add_filter('SERVICENAME', p_service_name) ||
        add_filter('CHARGEDESCRIPTION', p_charge_description) ||
        add_filter('RESOURCETYPE', p_resource_type) ||
        add_filter('RESOURCEID', p_resource_name) ||
        ' GROUP BY TO_CHAR(DATE_BUCKET, ''DD-Mon''), ' ||
                  'TO_CHAR(DATE_BUCKET, ''IW''), ' ||
                  'NVL(' || v_lvl1_col || ', ''None''), ' ||
                  'NVL(' || v_lvl2_col || ', ''Unknown''), ' ||
                  'NVL(' || v_lvl3_col || ', ''Unknown'')';

    OPEN v_cursor FOR v_sql USING p_fromdate, p_todate;
    LOOP
        FETCH v_cursor INTO v_key, v_cost;
        EXIT WHEN v_cursor%NOTFOUND;
        v_data_map(v_key) := v_cost;
    END LOOP;
    CLOSE v_cursor;

    -- Output data rows
    FOR date_rec IN cur_dates LOOP
        v_key := NULL;

        -- First cell in each row uses pivot-day-col for sticky behavior
        v_html := v_html || '<tr><td class="pivot-day-col">' ||
                  date_rec.week_label || '</td>';

        FOR i IN 1 .. v_idx LOOP
            v_key := date_rec.week_label || '|' ||
                     v_lvl1_map(i)        || '|' ||
                     v_lvl2_map(i)        || '|' ||
                     v_lvl3_map(i);

            v_cost := CASE
                        WHEN v_data_map.EXISTS(v_key) THEN v_data_map(v_key)
                        ELSE 0
                      END;

            v_html := v_html || '<td>' ||
                      CASE
                        WHEN v_cost < 1 THEN '0' || TO_CHAR(v_cost, 'FM.00')
                        ELSE TO_CHAR(v_cost, 'FM999G999G999G990D00')
                      END || '</td>';

            IF v_totals.EXISTS(v_columns(i)) THEN
                v_totals(v_columns(i)) := v_totals(v_columns(i)) + v_cost;
            ELSE
                v_totals(v_columns(i)) := v_cost;
            END IF;
        END LOOP;
        v_html := v_html || '</tr>';
    END LOOP;

    -- Totals row – first cell sticky too
    v_html := v_html || '<tr><td class="pivot-day-col"><b>Total</b></td>';
    FOR i IN 1 .. v_idx LOOP
        v_cost := NVL(v_totals(v_columns(i)), 0);
        v_html := v_html || '<td><b>' ||
                  CASE
                    WHEN v_cost < 1 THEN '0' || TO_CHAR(v_cost, 'FM.00')
                    ELSE TO_CHAR(v_cost, 'FM999G999G999G990D00')
                  END || '</b></td>';
    END LOOP;
    v_html := v_html || '</tr>';

    v_html := v_html || '</tbody></table></div>';
    RETURN v_html;
END;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_GLOSSARY_HINT" (
    p_question   IN VARCHAR2,
    p_dataset    IN VARCHAR2 DEFAULT 'LATEST',
    p_env        IN VARCHAR2 DEFAULT 'PROD'
) RETURN CLOB
IS
    l_ctx  chatbot_core_ctx_params_pkg.run_ctx_t;
    l_hint CLOB;
BEGIN
    l_ctx.dataset     := p_dataset;
    l_ctx.environment := p_env;

    l_hint := chatbot_router_pkg.get_glossary_hints(
                p_ctx      => l_ctx,
                p_question => p_question
              );

    RETURN l_hint;
END;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "JSON_ESCAPE" (p_text IN VARCHAR2) RETURN VARCHAR2 IS
  l_result VARCHAR2(32767);
BEGIN
  l_result := REPLACE(p_text, '\', '\\');        -- escape backslashes
  l_result := REPLACE(l_result, '"', '\"');      -- escape double quotes
  l_result := REPLACE(l_result, CHR(10), '\n');  -- line feed
  l_result := REPLACE(l_result, CHR(13), '');    -- carriage return
  RETURN l_result;
END;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "LLM_CALL_TEXT" (
    p_message        in  clob,
    p_model_id       in  varchar2,
    p_compartment_id in  varchar2
) return clob
as
  l_region              varchar2(50);
  l_model_cfg_model_id  varchar2(1000);
  l_api_format          varchar2(50);
  l_temperature         number;
  l_top_p               number;
  l_top_k               number;
  l_endpoint            varchar2(1000);
  l_payload             clob;
  l_resp                dbms_cloud_types.resp;
  l_body_json           clob;
  l_text                clob;

  -- helpers
  function clob_to_blob_utf8(p_clob in clob) return blob is
    l_blob        blob;
    l_dest_offset integer := 1;
    l_src_offset  integer := 1;
    l_lang_ctx    integer := 0;
    l_warning     integer := 0;
  begin
    dbms_lob.createtemporary(l_blob, true);
    dbms_lob.convertToBlob(
      dest_lob     => l_blob,
      src_clob     => p_clob,
      amount       => dbms_lob.lobmaxsize,
      dest_offset  => l_dest_offset,
      src_offset   => l_src_offset,
      blob_csid    => nls_charset_id('AL32UTF8'),
      lang_context => l_lang_ctx,
      warning      => l_warning
    );
    return l_blob;
  end;

  -- extract text robustly from OCI chat response
  function extract_text(p_json in clob) return clob is
    jo   json_object_t;
    cr   json_object_t;
    txt  clob;
  begin
    jo := json_object_t.parse(p_json);

    -- error payload?
    if jo.has('error') then
      raise_application_error(-20990,
        'OCI GenAI error: '||substr(p_json,1,2000));
    end if;

    if not jo.has('chatResponse') then
      return null;
    end if;

    cr := jo.get_object('chatResponse');

    -- Cohere-style single string
    if cr.has('text') then
      txt := cr.get_string('text');
      if txt is not null and trim(txt) is not null then
        return txt;
      end if;
    end if;

    -- Generic-style choices[0].message.content[*].text (concatenate TEXT parts)
    if cr.has('choices') then
      declare
        ca   json_array_t := cr.get_array('choices');
        ch   json_object_t;
        msg  json_object_t;
        cont json_array_t;
        i    pls_integer;
        part json_object_t;
        acc  clob := empty_clob();
      begin
        if ca.get_size > 0 then
          ch := treat(ca.get(0) as json_object_t);
          if ch.has('message') then
            msg := treat(ch.get('message') as json_object_t);
            if msg.has('content') then
              cont := treat(msg.get('content') as json_array_t);
              i := 0;
              while i < cont.get_size loop
                part := treat(cont.get(i) as json_object_t);
                if part.has('type') and upper(part.get_string('type')) = 'TEXT' then
                  acc := acc || part.get_string('text');
                end if;
                i := i + 1;
              end loop;
              if acc is not null and trim(acc) is not null then
                return acc;
              end if;
            end if;
          end if;
        end if;
      exception when others then
        null;
      end;
    end if;

    -- fallback: sometimes providers put text under output_text
    if cr.has('output_text') then
      txt := cr.get_string('output_text');
    end if;

    return txt;
  exception
    when others then
      -- if parsing failed, surface raw body for troubleshooting
      raise_application_error(-20991,
        'Failed to parse chat response: '||substr(p_json,1,2000));
  end;
begin
  -- 1) Load model config
  select region, model_id, api_format,
         nvl(temperature,1), nvl(top_p,1), nvl(top_k,1)
    into l_region, l_model_cfg_model_id, l_api_format,
         l_temperature, l_top_p, l_top_k
    from ai_model_config
   where model_id = p_model_id;

  l_endpoint :=
    'https://inference.generativeai.'||lower(l_region)||
    '.oci.oraclecloud.com/20231130/actions/chat';

  -- 2) Build payload (one-turn chat)
  if upper(l_api_format) = 'GENERIC' then
    l_payload :=
      json_object(
        'compartmentId' value p_compartment_id,
        'servingMode' value json_object(
          'modelId' value l_model_cfg_model_id,
          'servingType' value 'ON_DEMAND'
        ),
        'chatRequest' value json_object(
          'apiFormat' value 'GENERIC',
          'maxTokens' value 3999,
          'temperature' value l_temperature,
          'topP' value l_top_p,
          'topK' value l_top_k,
          'messages' value json_array(
            json_object(
              'role' value 'USER',
              'content' value json_array(
                json_object('type' value 'TEXT', 'text' value p_message)
              )
            )
          )
        )
      );
  else
    l_payload :=
      json_object(
        'compartmentId' value p_compartment_id,
        'servingMode' value json_object(
          'modelId' value l_model_cfg_model_id,
          'servingType' value 'ON_DEMAND'
        ),
        'chatRequest' value json_object(
          'apiFormat' value 'COHERE',
          'maxTokens' value 3999,
          'temperature' value l_temperature,
          'topP' value l_top_p,
          'topK' value l_top_k,
          'message' value p_message
        )
      );
  end if;

  -- 3) Call OCI GenAI endpoint (UTF-8 body)
  l_resp := dbms_cloud.send_request(
    credential_name => 'OCI$RESOURCE_PRINCIPAL',
    uri             => l_endpoint,
    method          => 'POST',
    headers         => json_object('Content-Type' value 'application/json'),
    body            => clob_to_blob_utf8(l_payload)
  );

  l_body_json := dbms_cloud.get_response_text(l_resp);

  -- 4) Robust extraction
  l_text := extract_text(l_body_json);

  if l_text is null or trim(l_text) is null then
    -- surface the body for troubleshooting
    raise_application_error(-20992,
      'Empty assistant text. Body: '||substr(l_body_json,1,2000));
  end if;

  return l_text;
end;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "USAGE_PIVOT_DYNAMIC_DAILY_HTML" (
    p_tenant             IN VARCHAR2,
    p_subscription_id    IN VARCHAR2,
    p_region             IN VARCHAR2,
    p_compartment        IN VARCHAR2,
    p_service_category   IN VARCHAR2,
    p_service_name       IN VARCHAR2,
    p_charge_description IN VARCHAR2,
    p_resource_type      IN VARCHAR2,
    p_resource_name      IN VARCHAR2,
    p_fromdate           IN VARCHAR2,
    p_todate             IN VARCHAR2,
    p_group_level1       IN VARCHAR2,
    p_group_level2       IN VARCHAR2,
    p_group_level3       IN VARCHAR2
) RETURN CLOB IS
    v_html         CLOB := '';
    v_key          VARCHAR2(1000);
    v_usage         NUMBER := 0;
    v_sql          CLOB;
    TYPE rc IS REF CURSOR;

    TYPE pivot_map_type IS TABLE OF NUMBER INDEX BY VARCHAR2(1000);
    v_data_map     pivot_map_type;
    v_totals       pivot_map_type;

    TYPE t_header_row IS TABLE OF VARCHAR2(1000) INDEX BY PLS_INTEGER;
    TYPE int_map_type IS TABLE OF INTEGER INDEX BY VARCHAR2(500);

    v_lvl1_col VARCHAR2(100);
    v_lvl2_col VARCHAR2(100);
    v_lvl3_col VARCHAR2(100);

    v_lvl1_map    t_header_row;
    v_lvl2_map    t_header_row;
    v_lvl3_map    t_header_row;
    v_columns     t_header_row;
    v_idx         INTEGER := 0;

    v_group_cursor rc;
    v_cursor       rc;

    CURSOR cur_dates IS
        SELECT DISTINCT TO_CHAR(DATE_BUCKET, 'DD-Mon') AS day_label, DATE_BUCKET
        FROM COST_USAGE_TIMESERIES_DAILY
        WHERE DATE_BUCKET BETWEEN TO_DATE(p_fromdate, 'DD-MON-YYYY HH24:MI:SS') AND TO_DATE(p_todate, 'DD-MON-YYYY HH24:MI:SS')
        ORDER BY DATE_BUCKET;

    FUNCTION add_filter(col_name VARCHAR2, param_val VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        IF param_val IS NULL OR TRIM(param_val) IS NULL THEN
            RETURN '';
        ELSE
            RETURN ' AND ' || col_name || ' IN (
                SELECT TRIM(COLUMN_VALUE)
                FROM TABLE(apex_string.split(''' || REPLACE(param_val, '''', '''''') || ''', '',''))
            )';
        END IF;
    END;

BEGIN
    v_lvl1_col := p_group_level1;
    v_lvl2_col := p_group_level2;
    v_lvl3_col := p_group_level3;

    -- HTML Table Start
    v_html := '<div class="pivot-scroll"><table id="pivot-table" class="pivot-table" border="1"><thead><tr><th class="pivot-day-col" rowspan="3">Day</th>';

    -- Build dynamic SQL for columns
    v_sql := 'SELECT DISTINCT NVL(' || v_lvl1_col || ', ''None''), NVL(' || v_lvl2_col || ', ''Unknown''), NVL(' || v_lvl3_col || ', ''Unknown'') '
          || 'FROM COST_USAGE_TIMESERIES_DAILY '
          || 'WHERE DATE_BUCKET BETWEEN TO_DATE(:1, ''DD-MON-YYYY HH24:MI:SS'') AND TO_DATE(:2, ''DD-MON-YYYY HH24:MI:SS'') '
          || add_filter('SUBACCOUNTNAME', p_tenant)
          || add_filter('BILLINGACCOUNTID', p_subscription_id)
          || add_filter('REGION', p_region)
          || add_filter('OCI_COMPARTMENTID', p_compartment)
          || add_filter('SERVICECATEGORY', p_service_category)
          || add_filter('SERVICENAME', p_service_name)
          || add_filter('CHARGEDESCRIPTION', p_charge_description)
          || add_filter('RESOURCETYPE', p_resource_type)
          || add_filter('RESOURCEID', p_resource_name)
          || ' ORDER BY 1, 2, 3';

    OPEN v_group_cursor FOR v_sql USING p_fromdate, p_todate;
    LOOP
        FETCH v_group_cursor INTO v_lvl1_map(v_idx + 1), v_lvl2_map(v_idx + 1), v_lvl3_map(v_idx + 1);
        EXIT WHEN v_group_cursor%NOTFOUND;
        v_idx := v_idx + 1;
        v_columns(v_idx) := v_lvl1_map(v_idx) || '|' || v_lvl2_map(v_idx) || '|' || v_lvl3_map(v_idx);
    END LOOP;
    CLOSE v_group_cursor;

    -- Header Rows
    DECLARE
        TYPE temp_map IS TABLE OF INTEGER INDEX BY VARCHAR2(500);
        v_colspan_map temp_map;
        col_key VARCHAR2(500);
    BEGIN
        FOR i IN 1 .. v_idx LOOP
            col_key := v_lvl1_map(i);
            IF v_colspan_map.EXISTS(col_key) THEN
                v_colspan_map(col_key) := v_colspan_map(col_key) + 1;
            ELSE
                v_colspan_map(col_key) := 1;
            END IF;
        END LOOP;

        col_key := v_colspan_map.FIRST;
        WHILE col_key IS NOT NULL LOOP
            v_html := v_html || '<th colspan="' || v_colspan_map(col_key) || '">' || col_key || '</th>';
            col_key := v_colspan_map.NEXT(col_key);
        END LOOP;
    END;

    v_html := v_html || '</tr><tr>';
    FOR i IN 1 .. v_idx LOOP
        v_html := v_html || '<th>' || v_lvl2_map(i) || '</th>';
    END LOOP;
    v_html := v_html || '</tr><tr>';
    FOR i IN 1 .. v_idx LOOP
        v_html := v_html || '<th>' || v_lvl3_map(i) || '</th>';
    END LOOP;
    v_html := v_html || '</tr></thead><tbody>';

    -- Build pivot data
    v_sql := '
        SELECT TO_CHAR(DATE_BUCKET, ''DD-Mon'') || ''|'' ||
               NVL(' || v_lvl1_col || ', ''None'') || ''|'' ||
               NVL(' || v_lvl2_col || ', ''Unknown'') || ''|'' ||
               NVL(' || v_lvl3_col || ', ''Unknown'') AS map_key,
               ROUND(SUM(USAGE),0)
        FROM COST_USAGE_TIMESERIES_DAILY
        WHERE DATE_BUCKET BETWEEN TO_DATE(:1, ''DD-MON-YYYY HH24:MI:SS'') AND TO_DATE(:2, ''DD-MON-YYYY HH24:MI:SS'') '
        || add_filter('SUBACCOUNTNAME', p_tenant)
        || add_filter('BILLINGACCOUNTID', p_subscription_id)
        || add_filter('REGION', p_region)
        || add_filter('OCI_COMPARTMENTID', p_compartment)
        || add_filter('SERVICECATEGORY', p_service_category)
        || add_filter('SERVICENAME', p_service_name)
        || add_filter('CHARGEDESCRIPTION', p_charge_description)
        || add_filter('RESOURCETYPE', p_resource_type)
        || add_filter('RESOURCEID', p_resource_name)
        || ' GROUP BY TO_CHAR(DATE_BUCKET, ''DD-Mon''), NVL(' || v_lvl1_col || ', ''None''), NVL(' || v_lvl2_col || ', ''Unknown''), NVL(' || v_lvl3_col || ', ''Unknown'')';

    OPEN v_cursor FOR v_sql USING p_fromdate, p_todate;
    LOOP
        FETCH v_cursor INTO v_key, v_usage;
        EXIT WHEN v_cursor%NOTFOUND;
        v_data_map(v_key) := v_usage;
    END LOOP;
    CLOSE v_cursor;

    -- Output data rows
    FOR date_rec IN cur_dates LOOP
        v_html := v_html || '<tr><td class="pivot-day-col">' || date_rec.day_label || '</td>';
        FOR i IN 1 .. v_idx LOOP
            v_key := date_rec.day_label || '|' || v_lvl1_map(i) || '|' || v_lvl2_map(i) || '|' || v_lvl3_map(i);
            v_usage := CASE
                        WHEN v_data_map.EXISTS(v_key) THEN v_data_map(v_key)
                        ELSE 0
                    END;
            v_html := v_html || '<td>' ||
                                        TO_CHAR(v_usage, 'FM999G999G999G999G990')
                                        || '</td>';
            IF v_totals.EXISTS(v_columns(i)) THEN
                v_totals(v_columns(i)) := v_totals(v_columns(i)) + v_usage;
            ELSE
                v_totals(v_columns(i)) := v_usage;
            END IF;
        END LOOP;
        v_html := v_html || '</tr>';
    END LOOP;

    v_html := v_html || '</tbody></table></div>';
    RETURN v_html;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ARCHIVE_AVAILABILITY_METRICS_PY" (
  p_retain_months in pls_integer default 13
) as
  -- Keep at most p_retain_months in the main table.
  -- Cutoff is first day of current month minus p_retain_months.
  l_cutoff_ts timestamp;
begin
  if p_retain_months < 1 then
    raise_application_error(-20001, 'p_retain_months must be >= 1');
  end if;

  l_cutoff_ts :=
    add_months(
      trunc(systimestamp, 'MM'),  -- first day of current month at 00:00
      -p_retain_months
    );

  -- 1) Move data to archive (older than cutoff)
  insert /*+ APPEND */
  into OCI_AVAILABILITY_METRICS_PY_ARCHIVE a
  select *
  from   OCI_AVAILABILITY_METRICS_PY m
  where  m."TIMESTAMP" < l_cutoff_ts;

  commit;

  -- 2) Delete same range from main table
  delete /*+ PARALLEL(8) */
  from   OCI_AVAILABILITY_METRICS_PY m
  where  m."TIMESTAMP" < l_cutoff_ts;

  commit;

  -- 3) Optionally gather stats (skip if you have central stats job)
  begin
    dbms_stats.gather_table_stats(
      ownname          => 'OCI_FOCUS_REPORTS',
      tabname          => 'OCI_AVAILABILITY_METRICS_PY',
      estimate_percent => dbms_stats.auto_sample_size,
      method_opt       => 'FOR ALL COLUMNS SIZE AUTO'
    );

    dbms_stats.gather_table_stats(
      ownname          => 'OCI_FOCUS_REPORTS',
      tabname          => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE',
      estimate_percent => dbms_stats.auto_sample_size,
      method_opt       => 'FOR ALL COLUMNS SIZE AUTO'
    );
  exception
    when others then
      null; -- ignore stats errors
  end;
end ARCHIVE_AVAILABILITY_METRICS_PY;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ARCHIVE_FOCUS_REPORTS_PY" (
  p_retain_months IN PLS_INTEGER DEFAULT 13
) AS
  -- Keep at most p_retain_months in the main table.
  -- Cutoff is first day of current month minus p_retain_months.
  l_cutoff_ts TIMESTAMP;
BEGIN
  IF p_retain_months < 1 THEN
    RAISE_APPLICATION_ERROR(-20001, 'p_retain_months must be >= 1');
  END IF;

  l_cutoff_ts :=
    ADD_MONTHS(
      TRUNC(SYSTIMESTAMP, 'MM'),  -- first day of current month at 00:00
      -p_retain_months
    );

  -- 1) Move data to archive (older than cutoff)
  INSERT /*+ APPEND */
  INTO FOCUS_REPORTS_PY_ARCHIVE a
  SELECT *
  FROM   FOCUS_REPORTS_PY m
  WHERE  m.CHARGEPERIODSTART < l_cutoff_ts;

  COMMIT;

  -- 2) Delete same range from main table
  DELETE /*+ PARALLEL(8) */
  FROM   FOCUS_REPORTS_PY m
  WHERE  m.CHARGEPERIODSTART < l_cutoff_ts;

  COMMIT;

  -- 3) Optionally gather stats (skip if you have central stats job)
  BEGIN
    DBMS_STATS.GATHER_TABLE_STATS(
      ownname          => 'OCI_FOCUS_REPORTS',
      tabname          => 'FOCUS_REPORTS_PY',
      estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
      method_opt       => 'FOR ALL COLUMNS SIZE AUTO'
    );

    DBMS_STATS.GATHER_TABLE_STATS(
      ownname          => 'OCI_FOCUS_REPORTS',
      tabname          => 'FOCUS_REPORTS_PY_ARCHIVE',
      estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
      method_opt       => 'FOR ALL COLUMNS SIZE AUTO'
    );
  EXCEPTION
    WHEN OTHERS THEN
      NULL; -- ignore stats errors
  END;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "CHATBOT_CORE_ENQUEUE" (
  p_user_message    IN  CLOB,
  p_model_id        IN  VARCHAR2,
  p_chat_id         IN  NUMBER,
  p_app_user        IN  VARCHAR2,
  p_app_session     IN  VARCHAR2,
  p_compartment_id  IN  VARCHAR2,
  p_include_history IN  VARCHAR2 DEFAULT 'N',
  p_dataset         IN  VARCHAR2 DEFAULT NULL,
  p_environment     IN  VARCHAR2 DEFAULT NULL,
  p_row_id          OUT NUMBER
) IS
  l_job_name    VARCHAR2(128);
  l_hist_flag   VARCHAR2(1);

  -- for intent decision
  l_api_format  VARCHAR2(50);
  l_region      VARCHAR2(50);
  l_intent      VARCHAR2(40) := 'NL2SQL';
  l_req_id      VARCHAR2(32) := RAWTOHEX(SYS_GUID());

  -- helpers to emit NULL (unquoted) when parameter is NULL
  function q_or_null(p_val in varchar2) return varchar2 is
  begin
    return case when p_val is null then 'NULL' else DBMS_ASSERT.ENQUOTE_LITERAL(p_val) end;
  end;

  -- dynamic table name helpers
  function T_LOG return varchar2 is
  begin
    return CHATBOT_ENV_PKG.tbl('CHATBOT_NL2SQL_LOG');
  end;
  function T_CONV return varchar2 is
  begin
    return CHATBOT_ENV_PKG.tbl('CHATBOT_NL2SQL_CONVERSATION');
  end;
  function T_MODEL return varchar2 is
  begin
    return CHATBOT_ENV_PKG.tbl('AI_MODEL_CONFIG');
  end;
BEGIN
  -- Normalize history flag to Y/N (single char)
  l_hist_flag := CASE WHEN UPPER(NVL(p_include_history,'N')) LIKE 'Y%' THEN 'Y' ELSE 'N' END;

  ---------------------------------------------------------------------------
  -- 1) Ensure parent conversation exists (or touch LAST_ACTIVITY)
  --    (refactor MERGE → UPDATE then INSERT if no row updated)
  ---------------------------------------------------------------------------
  EXECUTE IMMEDIATE
    'UPDATE '||T_CONV||' SET last_activity = SYSTIMESTAMP WHERE chat_id = :1'
    USING p_chat_id;

  IF SQL%ROWCOUNT = 0 THEN
    EXECUTE IMMEDIATE
      'INSERT INTO '||T_CONV||' (chat_id, app_user, friendly_name, created_at, last_activity, archived_yn)
       VALUES (:1, :2, :3, SYSTIMESTAMP, SYSTIMESTAMP, ''N'')'
      USING p_chat_id, p_app_user, '';
  END IF;

  ---------------------------------------------------------------------------
  -- 2) Pre-create the chat turn (child)
  ---------------------------------------------------------------------------
  EXECUTE IMMEDIATE
    'INSERT INTO '||T_LOG||' (
       chat_id, session_id, app_user,
       user_prompt, status, created_at,
       model_id, compartment_id, use_history
     ) VALUES (
       :1, :2, :3,
       :4, ''QUEUED'', SYSTIMESTAMP,
       :5, :6, :7
     )
     RETURNING id INTO :8'
  USING p_chat_id, p_app_session, p_app_user,
        p_user_message,
        p_model_id, p_compartment_id, l_hist_flag,
        OUT p_row_id;

  ---------------------------------------------------------------------------
  -- 2.5) Decide SYNC vs ASYNC: classify intent here
  ---------------------------------------------------------------------------
  begin
    EXECUTE IMMEDIATE
      'select api_format, region from '||T_MODEL||' where model_id = :1'
      INTO l_api_format, l_region
      USING p_model_id;

    l_intent := chatbot_core_sql_pkg.classify_intent_smart(
                  p_ctx            => chatbot_core_ctx_params_pkg.make_ctx(p_dataset, p_environment),
                  p_text           => p_user_message,
                  p_api_format     => l_api_format,
                  p_model_id       => p_model_id,
                  p_compartment_id => p_compartment_id,
                  p_region         => l_region,
                  p_req_id         => l_req_id,
                  p_log_id         => p_row_id,
                  p_chat_id        => p_chat_id
                );
  exception
    when others then
      l_intent := 'NL2SQL';
  end;

  ---------------------------------------------------------------------------
  -- 2.6) Direct paths (no scheduler for these)
  ---------------------------------------------------------------------------
  IF l_intent = 'FOLLOWUP_CLARIFY' THEN
    -- hand off to the new follow-up engine (it will create child rows/jobs if needed)
    CHATBOT_FOLLOWUP_PKG.run_followup(
      p_log_id         => p_row_id,
      p_model_id       => p_model_id,
      p_chat_id        => p_chat_id,
      p_app_user       => p_app_user,
      p_app_session    => p_app_session,
      p_compartment_id => p_compartment_id,
      p_dataset        => p_dataset,
      p_environment    => p_environment
    );
    RETURN;

  ELSIF l_intent = 'GENERAL_CHAT' THEN
    chatbot_core_runner_pkg.run_job(
      p_log_id          => p_row_id,
      p_model_id        => p_model_id,
      p_chat_id         => p_chat_id,
      p_app_user        => p_app_user,
      p_app_session     => p_app_session,
      p_compartment_id  => p_compartment_id,
      p_include_history => l_hist_flag,
      p_dataset         => p_dataset,
      p_environment     => p_environment
    );
    RETURN;
  END IF;

  ---------------------------------------------------------------------------
  -- 3) Schedule background run (updates this same row)
  ---------------------------------------------------------------------------
  l_job_name := 'CHATBOT_NL2SQL_JOB_' || p_row_id;

  -- NEW: persist job_name on the log
  EXECUTE IMMEDIATE
    'update '||T_LOG||' set job_name = :1 where id = :2'
  USING l_job_name, p_row_id;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name   => l_job_name,
    job_type   => 'PLSQL_BLOCK',
    job_action =>
      'begin chatbot_core_runner_pkg.run_job('||
          p_row_id||','||
          DBMS_ASSERT.ENQUOTE_LITERAL(p_model_id)||','||
          p_chat_id||','||
          DBMS_ASSERT.ENQUOTE_LITERAL(p_app_user)||','||
          DBMS_ASSERT.ENQUOTE_LITERAL(p_app_session)||','||
          DBMS_ASSERT.ENQUOTE_LITERAL(p_compartment_id)||','||
          DBMS_ASSERT.ENQUOTE_LITERAL(l_hist_flag)||','||
          q_or_null(p_dataset)||','||
          q_or_null(p_environment)||
      '); end;',
    start_date => SYSTIMESTAMP + INTERVAL '1' SECOND,
    enabled    => TRUE,
    auto_drop  => TRUE
  );
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    -- make sure the log row is marked failed if scheduling crashes
    BEGIN
      EXECUTE IMMEDIATE
        'UPDATE '||T_LOG||' SET status = ''FAILED'', finished_at = SYSTIMESTAMP, error_message = :1 WHERE id = :2'
        USING substr(SQLERRM,1,3500), p_row_id;
    EXCEPTION WHEN OTHERS THEN NULL; END;
    RAISE;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "FOCUS_AUTH_CONFIG" (
  p_conf in out nocopy apex_authentication.t_configuration
) is
  l_disc varchar2(4000);
begin
  begin
    select config_value
      into l_disc
      from app_config
     where config_key = 'OIDC_DISCOVERY_URL';
  exception
    when no_data_found then
      l_disc := null;
  end;

  if l_disc is not null then
    p_conf.substitutions := apex_t_varchar2(
      'DISCOVERY_URL', l_disc
    );
  end if;

  -- Optional: runtime proof in debug log
  apex_debug.message('AUTH_CONFIG DISCOVERY_URL=%s', nvl(l_disc,'<NULL>'));
end;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "PAGE1_CONS_WRKLD_MONTH_CHART_DATA_PROC" AS
  l_title   VARCHAR2(400);
  l_value   CLOB;
BEGIN
  -- Truncate the table once before processing
  EXECUTE IMMEDIATE 'TRUNCATE TABLE PAGE1_CONS_WRKLD_MONTH_CHART_DATA';

  -- Loop through top N rows by row_number
  FOR rec IN (
    SELECT DBMS_LOB.SUBSTR(WORKLOAD_NAME, 4000) AS WORKLOAD_NAME,
           DBMS_LOB.SUBSTR(VALUE, 4000) AS VALUE,
           ROW_NUMBER() OVER (ORDER BY WORKLOAD_NAME) AS rn
    FROM OCI_WORKLOADS
    WHERE VALUE IS NOT NULL
  ) LOOP
    -- Skip empty compartment lists
    IF rec.VALUE IS NOT NULL THEN
      -- Insert aggregated data
      INSERT INTO PAGE1_CONS_WRKLD_MONTH_CHART_DATA (
        WORKLOAD_NAME,
        MONTH,
        COST,
        LAST_REFRESH
      )
      SELECT
        rec.WORKLOAD_NAME,
        TRUNC(DATE_BUCKET, 'MM') AS MONTH,
        SUM(COST) AS COST,
        SYSDATE
      FROM COST_USAGE_TIMESERIES_DAILY fr
      WHERE DATE_BUCKET >= ADD_MONTHS(TRUNC(SYSDATE, 'MM'), -12)
            AND EXISTS (
              SELECT 1
              FROM TABLE(APEX_STRING.SPLIT(rec.VALUE, ',')) w
              WHERE TRIM(w.column_value) = fr.OCI_COMPARTMENTID
                 OR TRIM(w.column_value) = fr.COSTCENTER
            )
      GROUP BY TRUNC(DATE_BUCKET, 'MM');
    END IF;
  END LOOP;
  -- Ensure all changes are committed
  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "PAGE1_CONS_WRKLD_WEEK_CHART_DATA_PROC" AS
  l_title   VARCHAR2(400);
  l_value   CLOB;
BEGIN
  -- Truncate the entire table before inserting fresh data
  EXECUTE IMMEDIATE 'TRUNCATE TABLE PAGE1_CONS_WRKLD_WEEK_CHART_DATA';

  -- Loop through workloads (VALUE holds comma-separated compartment ids and/or cost centers)
  FOR rec IN (
    SELECT DBMS_LOB.SUBSTR(WORKLOAD_NAME, 4000) AS WORKLOAD_NAME,
           DBMS_LOB.SUBSTR(VALUE, 4000)         AS VALUE,
           ROW_NUMBER() OVER (ORDER BY WORKLOAD_NAME) AS rn
    FROM OCI_WORKLOADS
    WHERE VALUE IS NOT NULL
  ) LOOP
    IF rec.VALUE IS NOT NULL THEN
      INSERT INTO PAGE1_CONS_WRKLD_WEEK_CHART_DATA (
        WORKLOAD_NAME,
        WEEK_START,
        COST,
        LAST_REFRESH
      )
      SELECT
        rec.WORKLOAD_NAME,
        TRUNC(fr.DATE_BUCKET, 'IW') AS WEEK_START,
        SUM(fr.COST)                AS COST,
        SYSDATE
      FROM COST_USAGE_TIMESERIES_DAILY fr
      WHERE fr.DATE_BUCKET >= (TRUNC(SYSDATE, 'IW') - INTERVAL '56' DAY)
        AND fr.DATE_BUCKET <  TRUNC(SYSDATE, 'IW')  -- exclude current week
        AND EXISTS (
          SELECT 1
          FROM TABLE(APEX_STRING.SPLIT(rec.VALUE, ',')) w
          WHERE TRIM(w.column_value) = fr.OCI_COMPARTMENTID
             OR TRIM(w.column_value) = fr.COSTCENTER
        )
      GROUP BY TRUNC(fr.DATE_BUCKET, 'IW');
    END IF;
  END LOOP;

  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "POPULATE_OKE_RELATIONSHIPS_PROC" IS
BEGIN
    -- Optional: Clear old data
    EXECUTE IMMEDIATE 'TRUNCATE TABLE OCI_RESOURCE_OKE_RELATIONSHIPS';

    INSERT INTO OCI_RESOURCE_OKE_RELATIONSHIPS (
        CHILD_DISPLAY_NAME,
        CHILD_RESOURCE_TYPE,
        PARENT_DISPLAY_NAME,
        PARENT_RESOURCE_TYPE,
        RAW_CLUSTER_ID,
        NORMALIZED_CLUSTER_ID,
        NODE_TYPE,
        SNAPSHOT_DATE
    )
    SELECT
        child.DISPLAY_NAME,
        child.RESOURCE_TYPE,
        parent.DISPLAY_NAME,
        parent.RESOURCE_TYPE,
        JSON_VALUE(child.SYSTEM_TAGS, '$."orcl-containerengine".Cluster'),
        REGEXP_REPLACE(
            JSON_VALUE(child.SYSTEM_TAGS, '$."orcl-containerengine".Cluster'),
            '^default/',
            ''
        ),
        JSON_VALUE(child.SYSTEM_TAGS, '$."orcl-containerengine".NodeType'),
        SYSDATE
    FROM
        OCI_RESOURCES_PY child
    LEFT JOIN
        OCI_RESOURCES_PY parent
        ON REGEXP_REPLACE(
               JSON_VALUE(child.SYSTEM_TAGS, '$."orcl-containerengine".Cluster'),
               '^default/',
               ''
           ) IN (parent.DISPLAY_NAME, parent.IDENTIFIER)
    WHERE
        JSON_EXISTS(child.SYSTEM_TAGS, '$."orcl-containerengine".Cluster')
        AND JSON_VALUE(child.SYSTEM_TAGS, '$."orcl-containerengine".Cluster') IS NOT NULL;

    COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "POPULATE_RESOURCE_RELATIONSHIPS_PROC" IS
BEGIN
    -- Optional: Clear old data first
    EXECUTE IMMEDIATE 'TRUNCATE TABLE OCI_RESOURCE_RELATIONSHIPS';

    INSERT INTO OCI_RESOURCE_RELATIONSHIPS (
        CHILD_DISPLAY_NAME,
        CHILD_IDENTIFIER,
        CHILD_RESOURCE_TYPE,
        PARENT_DISPLAY_NAME,
        PARENT_IDENTIFIER,
        PARENT_RESOURCE_TYPE,
        RAW_CREATED_BY,
        NORMALIZED_CREATED_BY,
        SNAPSHOT_DATE
    )
    SELECT
        child.DISPLAY_NAME,
        child.IDENTIFIER,
        child.RESOURCE_TYPE,
        parent.DISPLAY_NAME,
        parent.IDENTIFIER,
        parent.RESOURCE_TYPE,
        JSON_VALUE(child.DEFINED_TAGS, '$."Oracle-Tags"."CreatedBy"'),
        REGEXP_REPLACE(
            JSON_VALUE(child.DEFINED_TAGS, '$."Oracle-Tags"."CreatedBy"'),
            '^default/',
            ''
        ),
        SYSDATE
    FROM
        OCI_RESOURCES_PY child
    LEFT JOIN
        OCI_RESOURCES_PY parent
        ON REGEXP_REPLACE(
               JSON_VALUE(child.DEFINED_TAGS, '$."Oracle-Tags"."CreatedBy"'),
               '^default/',
               ''
           ) IN (parent.DISPLAY_NAME, parent.IDENTIFIER)
    WHERE
        JSON_VALUE(child.DEFINED_TAGS, '$."Oracle-Tags"."CreatedBy"') IS NOT NULL;

    COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "REFRESH_COST_USAGE_TS_PROC" AS
  -- 12 months back from today; adjust to 'MM' if you want month-aligned
  l_from_ts TIMESTAMP := ADD_MONTHS(TRUNC(SYSTIMESTAMP, 'DD'), -12);
BEGIN
  EXECUTE IMMEDIATE 'ALTER SESSION ENABLE PARALLEL DML';

  EXECUTE IMMEDIATE 'TRUNCATE TABLE COST_USAGE_TIMESERIES_DAILY';
  EXECUTE IMMEDIATE 'TRUNCATE TABLE COST_USAGE_TIMESERIES_WEEKLY';
  EXECUTE IMMEDIATE 'TRUNCATE TABLE COST_USAGE_TIMESERIES_MONTHLY';

  ---------------------------------------------------------------------------
  -- DAILY: only partitions with CHARGEPERIODSTART >= l_from_ts are scanned
  ---------------------------------------------------------------------------
  INSERT /*+ APPEND PARALLEL(fr 8) PARALLEL(orp 8) PARALLEL(ocp 8) */
  INTO COST_USAGE_TIMESERIES_DAILY (
    DATE_BUCKET, BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    COST, USAGE, CREATED_BY, IMPLEMENTOR, ENVIRONMENT, COSTCENTER, LAST_REFRESH
  )
  SELECT
    TRUNC(fr.CHARGEPERIODSTART, 'DDD') AS DATE_BUCKET,
    fr.BILLINGACCOUNTID, fr.SUBACCOUNTNAME, fr.INVOICEISSUER, fr.REGION, fr.BILLINGCURRENCY,
    NVL(fr.SERVICECATEGORY, 'None') AS SERVICECATEGORY,
    fr.SERVICENAME, fr.CHARGEDESCRIPTION, fr.RESOURCETYPE, fr.RESOURCEID,
    orp.DISPLAY_NAME AS RESOURCENAME,
    fr.SKUID, fr.PRICINGUNIT, fr.OCI_COMPARTMENTID, fr.OCI_COMPARTMENTNAME,
    ocp.PATH AS OCI_COMPARTMENT_PATH,
    fr.USAGEUNIT,
    -- billed cost with fallback to effective cost
    SUM(
      NVL(
        NULLIF(fr.BILLEDCOST, 0),
        fr.EFFECTIVECOST
      )
    ) AS COST,
    SUM(
      CASE
        WHEN LOWER(fr.USAGEUNIT) LIKE '%month%' THEN fr.USAGEQUANTITY * (730 / 24)
        ELSE fr.USAGEQUANTITY / 24
      END
    ) AS USAGE,
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Tags.CreatedBy"'),
      '[^/]+$'
    ) AS CREATED_BY,
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.Implementor"'),
      '[^/]+$'
    ) AS IMPLEMENTOR,
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.Environment"'),
      '[^/]+$'
    ) AS ENVIRONMENT,
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.CostCenter"'),
      '[^/]+$'
    ) AS COSTCENTER,
    SYSDATE AS LAST_REFRESH
  FROM FOCUS_REPORTS_PY fr
  LEFT JOIN OCI_RESOURCES_PY    orp ON fr.RESOURCEID        = orp.IDENTIFIER
  LEFT JOIN OCI_COMPARTMENTS_PY ocp ON fr.OCI_COMPARTMENTID = ocp.COMPARTMENT_ID
  WHERE
        fr.CHARGEPERIODSTART >= l_from_ts                -- 12 months back, drives pruning
    AND fr.CHARGEPERIODEND   <= ADD_MONTHS(fr.CHARGEPERIODSTART, 7)
    AND NVL(NULLIF(fr.BILLEDCOST, 0), fr.EFFECTIVECOST) > 0
    AND fr.USAGEQUANTITY > 0
  GROUP BY
    TRUNC(fr.CHARGEPERIODSTART, 'DDD'),
    fr.BILLINGACCOUNTID, fr.SUBACCOUNTNAME, fr.INVOICEISSUER, fr.REGION, fr.BILLINGCURRENCY,
    fr.SERVICECATEGORY, fr.SERVICENAME, fr.CHARGEDESCRIPTION, fr.RESOURCETYPE, fr.RESOURCEID,
    orp.DISPLAY_NAME, fr.SKUID, fr.PRICINGUNIT, fr.OCI_COMPARTMENTID, fr.OCI_COMPARTMENTNAME,
    ocp.PATH, fr.USAGEUNIT,
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Tags.CreatedBy"'),
      '[^/]+$'
    ),
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.Environment"'),
      '[^/]+$'
    ),
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.CostCenter"'),
      '[^/]+$'
    ),
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.Implementor"'),
      '[^/]+$'
    );

  ---------------------------------------------------------------------------
  -- WEEKLY: aggregate from DAILY (already last 12 months only)
  ---------------------------------------------------------------------------
  INSERT /*+ APPEND PARALLEL(8) */
  INTO COST_USAGE_TIMESERIES_WEEKLY (
    DATE_BUCKET, BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    COST, USAGE, CREATED_BY, IMPLEMENTOR, ENVIRONMENT, COSTCENTER, LAST_REFRESH
  )
  SELECT
    TRUNC(DATE_BUCKET, 'IW') AS DATE_BUCKET,
    BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    SUM(COST)  AS COST,
    SUM(USAGE) AS USAGE,
    CREATED_BY,
    IMPLEMENTOR,
    ENVIRONMENT,
    COSTCENTER,
    SYSDATE AS LAST_REFRESH
  FROM COST_USAGE_TIMESERIES_DAILY
  GROUP BY
    TRUNC(DATE_BUCKET, 'IW'),
    BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    CREATED_BY, IMPLEMENTOR, ENVIRONMENT, COSTCENTER;

  ---------------------------------------------------------------------------
  -- MONTHLY: aggregate from DAILY (already last 12 months only)
  ---------------------------------------------------------------------------
  INSERT /*+ APPEND PARALLEL(8) */
  INTO COST_USAGE_TIMESERIES_MONTHLY (
    DATE_BUCKET, BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    COST, USAGE, CREATED_BY, IMPLEMENTOR, ENVIRONMENT, COSTCENTER, LAST_REFRESH
  )
  SELECT
    TRUNC(DATE_BUCKET, 'MM') AS DATE_BUCKET,
    BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    SUM(COST)  AS COST,
    SUM(USAGE) AS USAGE,
    CREATED_BY,
    IMPLEMENTOR,
    ENVIRONMENT,
    COSTCENTER,
    SYSDATE AS LAST_REFRESH
  FROM COST_USAGE_TIMESERIES_DAILY
  GROUP BY
    TRUNC(DATE_BUCKET, 'MM'),
    BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    CREATED_BY, IMPLEMENTOR, ENVIRONMENT, COSTCENTER;

  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "REFRESH_CREDIT_CONSUMPTION_STATE_PROC" IS

  TYPE slice_rec IS RECORD (
    rid                ROWID,
    subscription_id    credit_consumption_state.subscription_id%TYPE,
    time_start         credit_consumption_state.time_start%TYPE,
    original_quantity  credit_consumption_state.original_quantity%TYPE,
    remaining_quantity credit_consumption_state.remaining_quantity%TYPE,
    depleted           credit_consumption_state.depleted%TYPE
  );
  TYPE slice_tab IS TABLE OF slice_rec INDEX BY PLS_INTEGER;

  TYPE charge_rec IS RECORD (
    chargeperiodstart focus_reports_py.chargeperiodstart%TYPE,
    billedcost        focus_reports_py.billedcost%TYPE
  );
  TYPE charge_tab IS TABLE OF charge_rec INDEX BY PLS_INTEGER;

  slices        slice_tab;
  charges       charge_tab;

  i             INTEGER;
  j             INTEGER;
  slice_count   INTEGER;
  charge_count  INTEGER;
  last_index    INTEGER;
  running_total NUMBER;
  v_used        NUMBER;
  v_last_date   DATE;

BEGIN
  -----------------------------------------------------------------------------
  -- Phase 1: Truncate and populate CREDIT_CONSUMPTION_STATE from ACTIVE subs +
  --          commitments (no slices; keep commitment periods)
  -----------------------------------------------------------------------------
  EXECUTE IMMEDIATE 'TRUNCATE TABLE credit_consumption_state';

  INSERT INTO credit_consumption_state (
    subscription_line_id,
    subscription_id,
    billingaccountid,
    order_number,
    time_start,
    time_end,
    original_quantity,
    remaining_quantity,
    depleted,
    iso_code,
    last_consumed_at,
    last_updated
  )
  SELECT
    p.subscription_line_id,
    p.subscription_id,
    p.subscription_id AS billingaccountid,
    p.order_number,
    c.commitment_time_start AS time_start,
    c.commitment_time_end   AS time_end,

    TO_NUMBER(
      REPLACE(REGEXP_REPLACE(c.commitment_quantity, '[^0-9\.\-]', ''), ',', ''),
      '999999999999999999999999999999D999999999999999999',
      'NLS_NUMERIC_CHARACTERS=.,'
    ) AS original_quantity,

    CASE
      WHEN TO_NUMBER(
             REPLACE(REGEXP_REPLACE(c.commitment_available_amt, '[^0-9\.\-]', ''), ',', ''),
             '999999999999999999999999999999D999999999999999999',
             'NLS_NUMERIC_CHARACTERS=.,'
           ) <= 200
      THEN NULL
      ELSE TO_NUMBER(
             REPLACE(REGEXP_REPLACE(c.commitment_available_amt, '[^0-9\.\-]', ''), ',', ''),
             '999999999999999999999999999999D999999999999999999',
             'NLS_NUMERIC_CHARACTERS=.,'
           )
    END AS remaining_quantity,

    CASE
      WHEN TO_NUMBER(
             REPLACE(REGEXP_REPLACE(c.commitment_available_amt, '[^0-9\.\-]', ''), ',', ''),
             '999999999999999999999999999999D999999999999999999',
             'NLS_NUMERIC_CHARACTERS=.,'
           ) <= 200
      THEN 1
      ELSE 0
    END AS depleted,

    p.iso_code,
    NULL AS last_consumed_at,
    SYSDATE AS last_updated
  FROM oci_subscriptions_py p
  JOIN oci_subscription_commitments c
    ON c.subscription_line_id = p.subscription_line_id
  WHERE p.substatus = 'ACTIVE'
    AND c.commitment_time_start IS NOT NULL
    AND c.commitment_time_end   IS NOT NULL;

  -----------------------------------------------------------------------------
  -- Phase 2: Update LAST_CONSUMED_AT by back-calculating from current active order
  -----------------------------------------------------------------------------
  FOR sub IN (SELECT DISTINCT subscription_id FROM credit_consumption_state) LOOP

    v_used := NULL;
    slices.DELETE;
    charges.DELETE;

    -- Step 1: Get consumed amount from latest non-depleted order
    BEGIN
      SELECT original_quantity - NVL(remaining_quantity, 0)
        INTO v_used
        FROM (
          SELECT original_quantity, remaining_quantity
            FROM credit_consumption_state
           WHERE subscription_id = sub.subscription_id
             AND depleted = 0
           ORDER BY time_start DESC
        )
       WHERE ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        CONTINUE;
    END;

    -- Step 2: Get ALL depleted = 1 rows ordered by time_start DESC
    SELECT rowid, subscription_id, time_start, original_quantity, NVL(remaining_quantity, 0), depleted
      BULK COLLECT INTO slices
      FROM credit_consumption_state
     WHERE subscription_id = sub.subscription_id
       AND depleted = 1
     ORDER BY time_start DESC;

    slice_count := slices.COUNT;

    IF slice_count = 0 THEN
      CONTINUE;
    END IF;

    -- Step 3: Get charges, newest to oldest
    SELECT chargeperiodstart, billedcost
      BULK COLLECT INTO charges
      FROM focus_reports_py
     WHERE billingaccountid = sub.subscription_id
       AND billedcost > 0
     ORDER BY chargeperiodstart DESC;

    charge_count := charges.COUNT;
    last_index := 1;

    -- Step 4: FIRST depleted slice gets updated using v_used from current order
    running_total := 0;

    FOR j IN last_index .. charge_count LOOP
      running_total := running_total + charges(j).billedcost;

      IF running_total >= v_used THEN
        UPDATE credit_consumption_state
           SET last_consumed_at = charges(j).chargeperiodstart
         WHERE ROWID = slices(1).rid;

        v_last_date := charges(j).chargeperiodstart;
        last_index := j + 1;
        EXIT;
      END IF;
    END LOOP;

    -- Step 5: Remaining depleted slices get full original_quantity matched
    FOR i IN 2 .. slice_count LOOP
      running_total := 0;

      FOR j IN last_index .. charge_count LOOP
        IF charges(j).chargeperiodstart < v_last_date THEN
          running_total := running_total + charges(j).billedcost;

          IF running_total >= slices(i - 1).original_quantity THEN
            UPDATE credit_consumption_state
               SET last_consumed_at = charges(j).chargeperiodstart
             WHERE ROWID = slices(i).rid;

            v_last_date := charges(j).chargeperiodstart;
            last_index := j + 1;
            EXIT;
          END IF;
        END IF;
      END LOOP;
    END LOOP;

  END LOOP;

  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "REFRESH_CREDIT_USAGE_AGG_PROC" AS
BEGIN
  EXECUTE IMMEDIATE 'TRUNCATE TABLE CREDIT_USAGE_AGG';

  INSERT INTO CREDIT_USAGE_AGG (BILLINGACCOUNTID, CHARGEPERIODEND, BILLEDCOST, HOURLY_COST)
  SELECT
    BILLINGACCOUNTID,
    TRUNC(CHARGEPERIODEND, 'HH') AS CHARGEPERIODEND,
    SUM(BILLEDCOST) AS BILLEDCOST,
    SUM(BILLEDCOST) / 1 AS HOURLY_COST
  FROM FOCUS_REPORTS_PY
  WHERE CHARGEPERIODEND >= SYSDATE - 30  -- or -90 for 3 months of history
  GROUP BY BILLINGACCOUNTID, TRUNC(CHARGEPERIODEND, 'HH');

  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "SUMMARIZE_DDL_AND_UPSERT" 
(
  p_ddl_text        in  clob,         -- raw CREATE TABLE ... ;
  p_dataset         in  varchar2,     -- e.g. 'LATEST'
  p_environment     in  varchar2,     -- e.g. 'TEST'
  p_model_id        in  varchar2 default null,  -- override; else APP_CONFIG.MODEL_ID
  p_target_table    in  varchar2 default 'TEST_CHATBOT_NL2SQL_SUMMARY',
  p_id_sequence     in  varchar2 default null,  -- set if target table needs ID via sequence
  p_auto_commit     in  boolean  default false, -- caller controls commit
  -- outs
  p_summary_json    out clob,
  p_summary_row_op  out varchar2
)
as
  -- runtime context
  l_model_id        varchar2(1000);
  l_compartment_id  varchar2(4000);
  l_chat_id         number := trunc(dbms_random.value(10000,99999));
  l_app_user        varchar2(128)  := coalesce(v('APP_USER'), sys_context('USERENV','SESSION_USER'));
  l_app_session     varchar2(4000) := coalesce(v('APP_SESSION'), 'N/A');

  -- llm i/o
  l_prompt           clob;
  l_row_id           number;
  l_final_sql        clob;
  l_final_response   clob;
  l_final_aimessage  clob;

  -- json & merge
  l_json_obj         json_object_t;
  l_table_name       varchar2(256);
  l_summary_text     clob;
  l_op               varchar2(10);

  -- for UNKNOWN.<TABLE> fix
  l_table_override   varchar2(256);
begin
  -- basic checks
  if p_ddl_text is null then
    raise_application_error(-20050, 'DDL text is required.');
  end if;
  if p_dataset is null or p_environment is null then
    raise_application_error(-20051, 'DATASET and ENVIRONMENT are required.');
  end if;

  ---------------------------------------------------------------------------
  -- Resolve model/compartment from APP_CONFIG (caller can override model)
  ---------------------------------------------------------------------------
  declare
    v_model_id_app       varchar2(1000);
    v_compartment_id_app varchar2(4000);
  begin
    begin
      select config_value into v_model_id_app
      from app_config where upper(config_key) = 'MODEL_ID';
    exception when no_data_found then v_model_id_app := null; end;

    begin
      select config_value into v_compartment_id_app
      from app_config where upper(config_key) = 'COMPARTMENT_ID';
    exception when no_data_found then v_compartment_id_app := null; end;

    l_model_id       := coalesce(p_model_id, v_model_id_app);
    l_compartment_id := v_compartment_id_app;
  end;

  if l_model_id is null then
    raise_application_error(-20060, 'MODEL_ID is not set (p_model_id is NULL and APP_CONFIG.MODEL_ID missing).');
  end if;
  if l_compartment_id is null then
    raise_application_error(-20061, 'COMPARTMENT_ID is not set in APP_CONFIG.');
  end if;

  ---------------------------------------------------------------------------
  -- Build LLM instruction (JSON-only)
  ---------------------------------------------------------------------------
  l_prompt := q'[
You are a precise SQL DDL summarization engine that converts any CREATE TABLE statement into a structured JSON description for NL2SQL routing.

Return ONLY valid JSON (no markdown, no code fences, no trailing commas, no commentary).

Expected JSON:
{
  "summary": "One short sentence (≤150 chars) describing the table in business terms.",
  "table_name": "<OWNER>.<TABLE_NAME>",
  "keys": ["<col>", "..."],
  "metrics": ["<col>", "..."],
  "attributes": ["<col>", "..."],
  "notes": ""
}

Rules
- Use ONLY columns present in the DDL. Uppercase all names.
- table_name: if schema missing, use "UNKNOWN.<TABLE_NAME>".
- keys: if a PRIMARY KEY exists, use it in declared order; else best-guess identifiers (names ending with _ID, _NO, _CODE, DATE/DT).
- metrics: numeric/measurable columns (NUMBER/DECIMAL/FLOAT/INTEGER, or names with COUNT/AMOUNT/TOTAL/AVG/RATE/SCORE/BALANCE/QUANTITY).
- attributes: everything else (names, categories, regions, statuses, flags).
- Arrays contain unique strings; include empty arrays if none.
- Output must be strictly valid JSON.

DDL:
]' || p_ddl_text;

  ---------------------------------------------------------------------------
  -- Call headless LLM (no logging) and keep the same validation
  ---------------------------------------------------------------------------
  l_final_aimessage := llm_call_text(
    p_message        => l_prompt,
    p_model_id       => l_model_id,
    p_compartment_id => l_compartment_id
  );

  if l_final_aimessage is null or trim(l_final_aimessage) is null then
    raise_application_error(-20052, 'LLM returned empty content.');
  end if;

  -- Validate JSON (19c+ compatible)
  declare
    v_dummy number;
  begin
    select 1 into v_dummy from dual where l_final_aimessage is json strict;
  exception
    when others then
      raise_application_error(-20053, 'LLM did not return valid JSON.');
  end;

  l_json_obj := json_object_t.parse(l_final_aimessage);

  if not l_json_obj.has('summary') or
     not l_json_obj.has('table_name') or
     not l_json_obj.has('keys') or
     not l_json_obj.has('metrics') or
     not l_json_obj.has('attributes') then
    raise_application_error(-20054, 'JSON missing required fields.');
  end if;

  ---------------------------------------------------------------------------
  -- Fix table_name if LLM emitted UNKNOWN.<TABLE> — derive OWNER.TABLE from DDL
  ---------------------------------------------------------------------------
  declare
    v_raw   varchar2(4000);
    v_owner varchar2(128) := upper(nvl(sys_context('USERENV','CURRENT_SCHEMA'),'UNKNOWN'));
    v_name  varchar2(4000);
  begin
    v_raw := regexp_substr(p_ddl_text,
            'create\s+table\s+((?:\"?[[:alnum:]_]+\"?\.)?\"?[[:alnum:]_]+\"?)',
            1, 1, 'in', 1);
    v_raw := replace(upper(nvl(v_raw,'')),'"','');

    if v_raw is not null then
      if instr(v_raw,'.') > 0 then
        l_table_override := v_raw;                     -- schema provided
      else
        l_table_override := v_owner||'.'||v_raw;       -- prefix current schema
      end if;
    else
      v_name := replace(upper(regexp_substr(p_ddl_text,'([[:alnum:]_"]+)\s*\(',1,1,'in',1)),'"','');
      if v_name is not null then
        l_table_override := v_owner||'.'||v_name;
      end if;
    end if;
  end;

  l_table_name   := upper(l_json_obj.get_string('table_name'));
  if l_table_override is not null and l_table_name like 'UNKNOWN.%' then
    l_table_name := l_table_override;
  end if;

  l_summary_text := l_final_aimessage;  -- store raw JSON

  ---------------------------------------------------------------------------
  -- MERGE into target table (identity or sequence)
  ---------------------------------------------------------------------------
  declare
    l_sql   clob;
    l_count integer;
  begin
    if p_id_sequence is null then
      l_sql :=
        'merge into '||p_target_table||' t '||
        'using (select :dataset as dataset, :env as environment, :tname as table_name, '||
        '              systimestamp as last_refreshed, :sumtxt as summary_text from dual) s '||
        'on (t.dataset = s.dataset and t.environment = s.environment and t.table_name = s.table_name) '||
        'when matched then update set t.last_refreshed = s.last_refreshed, t.summary_text = s.summary_text '||
        'when not matched then insert (dataset, environment, table_name, last_refreshed, summary_text) '||
        'values (s.dataset, s.environment, s.table_name, s.last_refreshed, s.summary_text)';
      execute immediate l_sql using p_dataset, p_environment, l_table_name, l_summary_text;
    else
      l_sql :=
        'merge into '||p_target_table||' t '||
        'using (select :dataset as dataset, :env as environment, :tname as table_name, '||
        '              systimestamp as last_refreshed, :sumtxt as summary_text from dual) s '||
        'on (t.dataset = s.dataset and t.environment = s.environment and t.table_name = s.table_name) '||
        'when matched then update set t.last_refreshed = s.last_refreshed, t.summary_text = s.summary_text '||
        'when not matched then insert (id, dataset, environment, table_name, last_refreshed, summary_text) '||
        'values ('||p_id_sequence||'.nextval, s.dataset, s.environment, s.table_name, s.last_refreshed, s.summary_text)';
      execute immediate l_sql using p_dataset, p_environment, l_table_name, l_summary_text;
    end if;

    -- detect op (insert vs update)
    l_sql :=
      'select count(*) from '||p_target_table||
      ' where dataset = :1 and environment = :2 and table_name = :3'||
      '   and last_refreshed >= systimestamp - interval ''1'' minute';
    execute immediate l_sql into l_count using p_dataset, p_environment, l_table_name;
    l_op := case when l_count = 1 then 'UPDATE' else 'INSERT' end;
  end;

  -- outs
  p_summary_json   := l_summary_text;
  p_summary_row_op := l_op;

  if p_auto_commit then commit; end if;
end;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "SYNC_AI_MODEL_CONFIG_FROM_OCI" IS
  credential_name CONSTANT VARCHAR2(100) := 'OCI$RESOURCE_PRINCIPAL';

  TYPE region_list_t IS TABLE OF VARCHAR2(50);
  regions region_list_t := region_list_t('eu-frankfurt-1'
                            --, 'us-chicago-1'
                            );

  compartment_ocid VARCHAR2(1000);

  resp           DBMS_CLOUD_TYPES.resp;
  response_clob  CLOB;

  region      VARCHAR2(50);
  request_uri VARCHAR2(1000);

  l_http_code   PLS_INTEGER;
  l_total_items PLS_INTEGER;
  l_inserted    PLS_INTEGER;

  l_first_item  VARCHAR2(4000);
BEGIN
  -- Get COMPARTMENT_ID from APP_CONFIG
  SELECT CONFIG_VALUE
    INTO compartment_ocid
    FROM APP_CONFIG
   WHERE CONFIG_KEY = 'COMPARTMENT_ID';

  -- Make sure you're truncating the right table and schema
  EXECUTE IMMEDIATE 'TRUNCATE TABLE AI_MODEL_CONFIG';

  -- Loop through regions
  FOR i IN 1 .. regions.COUNT LOOP
    region := regions(i);
    request_uri := 'https://generativeai.' || region ||
                   '.oci.oraclecloud.com/20231130/models?compartmentId=' ||
                   compartment_ocid;

    resp := DBMS_CLOUD.SEND_REQUEST(
              credential_name => credential_name,
              uri             => request_uri,
              method          => DBMS_CLOUD.METHOD_GET,
              headers         => '{"content-type":"application/json"}'
            );

    l_http_code := DBMS_CLOUD.GET_RESPONSE_STATUS_CODE(resp);
    response_clob := DBMS_CLOUD.GET_RESPONSE_TEXT(resp);

    DBMS_OUTPUT.PUT_LINE('Region ' || region || ' HTTP ' || l_http_code);

    IF l_http_code <> 200 THEN
      DBMS_OUTPUT.PUT_LINE('Body snippet: ' || SUBSTR(response_clob, 1, 1000));
      CONTINUE; -- skip this region on error
    END IF;

    -- Count how many items are at the path we expect
    SELECT COUNT(*)
      INTO l_total_items
      FROM JSON_TABLE(
             response_clob, '$.items[*]'
             COLUMNS ( dummy VARCHAR2(1) PATH '$.id' )
           );

    DBMS_OUTPUT.PUT_LINE('Parsed items at $.items[*]: ' || l_total_items);

    -- Insert only models with capability = 'CHAT' (case-insensitive)
    INSERT INTO AI_MODEL_CONFIG (
      MODEL_ID,
      MODEL_NAME,
      API_FORMAT,
      IS_DEFAULT,
      REGION,
      TEMPERATURE,
      TOP_P,
      TOP_K,
      FREQUENCY_PENALTY,
      PRESENCE_PENALTY
    )
    SELECT DISTINCT
      jt.model_id,
      jt.model_name,
      CASE
        WHEN REGEXP_LIKE(LOWER(COALESCE(jt.vendor, jt.model_id, jt.model_name)),
                         '(^|[^a-z])cohere([^a-z]|$)')
          OR REGEXP_LIKE(LOWER(NVL(jt.model_id,'')),  '(^|[._/\-])cohere([._/\-]|$)')
          OR REGEXP_LIKE(LOWER(NVL(jt.model_name,'')),'(^|[ _/\-])cohere([ _/\-]|$)')
        THEN 'COHERE'
        ELSE 'GENERIC'
      END AS api_format,
      'N' AS is_default,
      region,
      NULL, NULL, NULL, NULL, NULL
    FROM JSON_TABLE(
           response_clob, '$.items[*]'
           COLUMNS (
             model_id    VARCHAR2(1000) PATH '$.id',
             model_name  VARCHAR2(1000) PATH '$.displayName',
             vendor      VARCHAR2(100)  PATH '$.vendor' NULL ON ERROR,
             NESTED PATH '$.capabilities[*]'
               COLUMNS (cap VARCHAR2(64) PATH '$')
           )
         ) jt
    WHERE REGEXP_LIKE(jt.cap, '^CHAT$', 'i');

    l_inserted := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Inserted CHAT rows: ' || l_inserted);

    IF l_inserted = 0 THEN
      -- Dump a few capabilities to confirm what we got back
      DBMS_OUTPUT.PUT_LINE('No CHAT rows. Sample capabilities:');
      FOR r IN (
        SELECT DISTINCT cap
        FROM JSON_TABLE(
               response_clob, '$.items[*]'
               COLUMNS (
                 NESTED PATH '$.capabilities[*]'
                   COLUMNS (cap VARCHAR2(64) PATH '$')
               )
             )
        WHERE ROWNUM <= 10
      ) LOOP
        DBMS_OUTPUT.PUT_LINE('  - ' || r.cap);
      END LOOP;

      -- Also show the first item's id/name (do a SELECT ... INTO first)
      BEGIN
        SELECT NVL(model_name,'<null>') || ' / ' || NVL(model_id,'<null>')
          INTO l_first_item
          FROM JSON_TABLE(
                 response_clob, '$.items[0]'
                 COLUMNS (
                   model_id    VARCHAR2(1000) PATH '$.id',
                   model_name  VARCHAR2(1000) PATH '$.displayName'
                 )
               );
        DBMS_OUTPUT.PUT_LINE('First item name/id: ' || l_first_item);
      EXCEPTION
        WHEN OTHERS THEN NULL;
      END;
    END IF;
  END LOOP;

  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('❌ Error: ' || SQLERRM);
    BEGIN
      DBMS_OUTPUT.PUT_LINE('Body snippet: ' || SUBSTR(response_clob, 1, 1000));
    EXCEPTION WHEN OTHERS THEN NULL; END;
    ROLLBACK;
END sync_ai_model_config_from_oci;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UPDATE_OCI_SUBSCRIPTION_DETAILS" AS
BEGIN
  MERGE INTO oci_subscription_details dst
  USING (
    SELECT DISTINCT
      c.subscription_line_id,
      TO_NUMBER(c.subscription_id) AS subscription_id,
      c.time_start,
      c.time_end,
      TO_NUMBER(c.order_number)    AS order_id,
      c.original_quantity          AS quantity
    FROM credit_consumption_state c
    WHERE c.subscription_line_id IS NOT NULL
      AND c.subscription_id IS NOT NULL
      AND c.order_number   IS NOT NULL
      AND REGEXP_LIKE(c.subscription_id, '^\d+$')
      AND REGEXP_LIKE(c.order_number,   '^\d+$')
  ) src
  ON (
    dst.subscription_line_id = src.subscription_line_id
    AND dst.time_start       = src.time_start
    AND dst.time_end         = src.time_end
  )

  WHEN MATCHED THEN
    UPDATE SET
      dst.subscription_id = src.subscription_id,
      dst.order_id        = src.order_id,
      dst.quantity        = src.quantity
      -- IMPORTANT: do NOT touch dst.order_name
  WHERE NVL(dst.subscription_id, -1) <> NVL(src.subscription_id, -1)
     OR NVL(dst.order_id, -1)        <> NVL(src.order_id, -1)
     OR NVL(dst.quantity, -1)        <> NVL(src.quantity, -1)

  WHEN NOT MATCHED THEN
    INSERT (
      subscription_line_id,
      subscription_id,
      time_start,
      time_end,
      order_id,
      quantity,
      order_name
    )
    VALUES (
      src.subscription_line_id,
      src.subscription_id,
      src.time_start,
      src.time_end,
      src.order_id,
      src.quantity,
      NULL  -- admin can set friendly name later
    );

  COMMIT;
END;
/
