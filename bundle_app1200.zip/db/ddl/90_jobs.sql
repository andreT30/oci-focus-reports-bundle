/* Scheduler jobs exported as CREATE_JOB blocks (with UPDATE via SET_ATTRIBUTE).
   NOTE: Credentials/secrets are NOT exported. Ensure required credentials exist per environment.
   Enabled/disabled logic:
   - If job exists on target and source is ENABLED: keep target enabled state.
   - If source is DISABLED: force job disabled on target.
   - If job does not exist on target: new job follows source enabled flag.
   Update logic:
   - If job exists and job_type differs: DROP + CREATE (Policy A).
   - Else: disable job, update changed attributes, then enable/disable per policy.
*/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'STORED_PROCEDURE';
  d_job_action      VARCHAR2(4000) := q'~OCI_FOCUS_REPORTS.ARCHIVE_FOCUS_REPORTS_PY~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=MONTHLY;BYMONTHDAY=1;BYHOUR=2;BYMINUTE=0;BYSECOND=0~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-12-01T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Archive FOCUS_REPORTS_PY data older than 13 months, keeping main table to max 13 months of data.~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'FOCUS_REPORTS_PY_ARCHIVE_JOB';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'FOCUS_REPORTS_PY_ARCHIVE_JOB';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('FOCUS_REPORTS_PY_ARCHIVE_JOB', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'FOCUS_REPORTS_PY_ARCHIVE_JOB', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('FOCUS_REPORTS_PY_ARCHIVE_JOB', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('FOCUS_REPORTS_PY_ARCHIVE_JOB', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('FOCUS_REPORTS_PY_ARCHIVE_JOB');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'PLSQL_BLOCK';
  d_job_action      VARCHAR2(4000) := q'~begin
  oci_price.refresh_catalog_full;
end;~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY; BYTIME=120000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-09-13T12:10:10.000000000 +00:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Refresh the OCI GenAI Price catalog~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'GENAI_PRICE_CATALOG_REFRESH_JOB';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'GENAI_PRICE_CATALOG_REFRESH_JOB';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('GENAI_PRICE_CATALOG_REFRESH_JOB', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'GENAI_PRICE_CATALOG_REFRESH_JOB', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('GENAI_PRICE_CATALOG_REFRESH_JOB', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('GENAI_PRICE_CATALOG_REFRESH_JOB', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('GENAI_PRICE_CATALOG_REFRESH_JOB');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'PLSQL_BLOCK';
  d_job_action      VARCHAR2(4000) := q'~
declare
  l_run_id number;
begin
  oci_availability_metrics_pkg.run(l_run_id);
end;
~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY;BYHOUR=02;BYMINUTE=15;BYSECOND=0; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-12-23T04:10:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Load OCI availability metrics via OCI PL/SQL SDK~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_AVAILABILITY_METRICS';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_AVAILABILITY_METRICS';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('JOB_AVAILABILITY_METRICS', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'JOB_AVAILABILITY_METRICS', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'JOB_AVAILABILITY_METRICS',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('JOB_AVAILABILITY_METRICS', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('JOB_AVAILABILITY_METRICS', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_AVAILABILITY_METRICS',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_AVAILABILITY_METRICS',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_AVAILABILITY_METRICS',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_AVAILABILITY_METRICS',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_AVAILABILITY_METRICS',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_AVAILABILITY_METRICS',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_AVAILABILITY_METRICS',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'JOB_AVAILABILITY_METRICS',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('JOB_AVAILABILITY_METRICS');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'JOB_AVAILABILITY_METRICS',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'PLSQL_BLOCK';
  d_job_action      VARCHAR2(4000) := q'~DECLARE
  l_run_id NUMBER;
BEGIN
  oci_exa_maintenance_loader_pkg.run(p_run_id => l_run_id);
  DBMS_OUTPUT.put_line('Run ID = ' || l_run_id);
END;
~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY; BYTIME=033000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-12-31T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Load OCI Exadata Infra maintenance history~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_EXA_MAINTENANCE';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_EXA_MAINTENANCE';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('JOB_EXA_MAINTENANCE', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'JOB_EXA_MAINTENANCE', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'JOB_EXA_MAINTENANCE',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('JOB_EXA_MAINTENANCE', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('JOB_EXA_MAINTENANCE', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_EXA_MAINTENANCE',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_EXA_MAINTENANCE',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_EXA_MAINTENANCE',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_EXA_MAINTENANCE',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_EXA_MAINTENANCE',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_EXA_MAINTENANCE',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_EXA_MAINTENANCE',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'JOB_EXA_MAINTENANCE',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('JOB_EXA_MAINTENANCE');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'JOB_EXA_MAINTENANCE',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'STORED_PROCEDURE';
  d_job_action      VARCHAR2(4000) := q'~OCI_FOCUS_REPORTS.OCI_FOCUS_REPORTS_LOADER_PKG.RUN~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=HOURLY; INTERVAL=12; BYTIME=0000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-12-29T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Focus Reports upload every 12 hours~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_FOCUS_REPORTS_12H';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_FOCUS_REPORTS_12H';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('JOB_FOCUS_REPORTS_12H', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'JOB_FOCUS_REPORTS_12H', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'JOB_FOCUS_REPORTS_12H',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('JOB_FOCUS_REPORTS_12H', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('JOB_FOCUS_REPORTS_12H', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_FOCUS_REPORTS_12H',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_FOCUS_REPORTS_12H',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_FOCUS_REPORTS_12H',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_FOCUS_REPORTS_12H',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_FOCUS_REPORTS_12H',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_FOCUS_REPORTS_12H',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_FOCUS_REPORTS_12H',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'JOB_FOCUS_REPORTS_12H',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('JOB_FOCUS_REPORTS_12H');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'JOB_FOCUS_REPORTS_12H',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'PLSQL_BLOCK';
  d_job_action      VARCHAR2(4000) := q'~DECLARE
  l_run_id NUMBER;
BEGIN
  OCI_FOCUS_REPORTS_COMPARTMENTS_PKG.run('ROOT', l_run_id);
END;
/~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY; BYTIME=010000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2026-01-08T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Load OCI Compartments from tenancy level~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_COMPARTMENTS';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_COMPARTMENTS';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('JOB_OCI_COMPARTMENTS', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'JOB_OCI_COMPARTMENTS', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'JOB_OCI_COMPARTMENTS',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('JOB_OCI_COMPARTMENTS', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('JOB_OCI_COMPARTMENTS', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_COMPARTMENTS',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_COMPARTMENTS',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_COMPARTMENTS',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_COMPARTMENTS',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_COMPARTMENTS',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_COMPARTMENTS',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_COMPARTMENTS',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'JOB_OCI_COMPARTMENTS',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('JOB_OCI_COMPARTMENTS');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'JOB_OCI_COMPARTMENTS',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'PLSQL_BLOCK';
  d_job_action      VARCHAR2(4000) := q'~DECLARE
  l_run_id NUMBER;
BEGIN
  OCI_FOCUS_REPORTS_COMPARTMENTS_PKG.run(
    p_scope  => 'CHILD1',
    p_run_id => l_run_id
  );
END;~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY; BYTIME=013000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2026-01-08T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Load OCI Compartments for child tenancies~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_COMPARTMENTS_CHILD';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_COMPARTMENTS_CHILD';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('JOB_OCI_COMPARTMENTS_CHILD', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'JOB_OCI_COMPARTMENTS_CHILD', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'JOB_OCI_COMPARTMENTS_CHILD',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('JOB_OCI_COMPARTMENTS_CHILD', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('JOB_OCI_COMPARTMENTS_CHILD', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_COMPARTMENTS_CHILD',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_COMPARTMENTS_CHILD',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_COMPARTMENTS_CHILD',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_COMPARTMENTS_CHILD',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_COMPARTMENTS_CHILD',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_COMPARTMENTS_CHILD',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_COMPARTMENTS_CHILD',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'JOB_OCI_COMPARTMENTS_CHILD',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('JOB_OCI_COMPARTMENTS_CHILD');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'JOB_OCI_COMPARTMENTS_CHILD',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'STORED_PROCEDURE';
  d_job_action      VARCHAR2(4000) := q'~OCI_FOCUS_REPORTS.OCI_RESOURCES_LOADER_PKG.RUN~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY; BYTIME=014500; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-12-29T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Load OCI resources~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_RESOURCES';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_RESOURCES';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('JOB_OCI_RESOURCES', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'JOB_OCI_RESOURCES', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'JOB_OCI_RESOURCES',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('JOB_OCI_RESOURCES', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('JOB_OCI_RESOURCES', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_RESOURCES',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_RESOURCES',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_RESOURCES',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_RESOURCES',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_RESOURCES',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_RESOURCES',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_RESOURCES',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'JOB_OCI_RESOURCES',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('JOB_OCI_RESOURCES');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'JOB_OCI_RESOURCES',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'PLSQL_BLOCK';
  d_job_action      VARCHAR2(4000) := q'~
declare
  l_run_id number;
begin
  oci_subscriptions_pkg.run(l_run_id);
end;
~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY;BYHOUR=02;BYMINUTE=0;BYSECOND=0~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-12-24T14:11:38.243665000 +00:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Load OCI subscriptions via OCI PL/SQL SDK~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_SUBSCRIPTIONS';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_SUBSCRIPTIONS';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('JOB_OCI_SUBSCRIPTIONS', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'JOB_OCI_SUBSCRIPTIONS', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'JOB_OCI_SUBSCRIPTIONS',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('JOB_OCI_SUBSCRIPTIONS', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('JOB_OCI_SUBSCRIPTIONS', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_SUBSCRIPTIONS',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_SUBSCRIPTIONS',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_SUBSCRIPTIONS',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_SUBSCRIPTIONS',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_SUBSCRIPTIONS',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'JOB_OCI_SUBSCRIPTIONS',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'JOB_OCI_SUBSCRIPTIONS',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'JOB_OCI_SUBSCRIPTIONS',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('JOB_OCI_SUBSCRIPTIONS');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'JOB_OCI_SUBSCRIPTIONS',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'PLSQL_BLOCK';
  d_job_action      VARCHAR2(4000) := q'~dbms_refresh.refresh('"OCI_FOCUS_REPORTS"."RATECARD_MV"');~';
  d_repeat_interval VARCHAR2(4000) := q'~TO_DATE(SYSDATE + 1)   ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-07-02T12:09:01.000000000 +03:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~dbms_refresh: submit_sch_job~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'MV_RF$J_0_S_82';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'MV_RF$J_0_S_82';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('MV_RF$J_0_S_82', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'MV_RF$J_0_S_82', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'MV_RF$J_0_S_82',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('MV_RF$J_0_S_82', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('MV_RF$J_0_S_82', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'MV_RF$J_0_S_82',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'MV_RF$J_0_S_82',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'MV_RF$J_0_S_82',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'MV_RF$J_0_S_82',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'MV_RF$J_0_S_82',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'MV_RF$J_0_S_82',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'MV_RF$J_0_S_82',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'MV_RF$J_0_S_82',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('MV_RF$J_0_S_82');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'MV_RF$J_0_S_82',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'STORED_PROCEDURE';
  d_job_action      VARCHAR2(4000) := q'~OCI_FOCUS_REPORTS.ARCHIVE_AVAILABILITY_METRICS_PY~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=MONTHLY;BYMONTHDAY=1;BYHOUR=3;BYMINUTE=0;BYSECOND=0~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-12-01T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Archive AVAILABILITY METRICS data older than 13 months, keeping main table to max 13 months of data.~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'PLSQL_BLOCK';
  d_job_action      VARCHAR2(4000) := q'~BEGIN
  oci_price.refresh_shapes_catalog;
END;~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY; BYTIME=130000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2026-01-07T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Get Publicly available VM shape configuration~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'OCI_VM_SHAPES_REFRESH';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'OCI_VM_SHAPES_REFRESH';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('OCI_VM_SHAPES_REFRESH', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'OCI_VM_SHAPES_REFRESH', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'OCI_VM_SHAPES_REFRESH',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('OCI_VM_SHAPES_REFRESH', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('OCI_VM_SHAPES_REFRESH', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'OCI_VM_SHAPES_REFRESH',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'OCI_VM_SHAPES_REFRESH',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'OCI_VM_SHAPES_REFRESH',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'OCI_VM_SHAPES_REFRESH',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'OCI_VM_SHAPES_REFRESH',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'OCI_VM_SHAPES_REFRESH',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'OCI_VM_SHAPES_REFRESH',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'OCI_VM_SHAPES_REFRESH',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('OCI_VM_SHAPES_REFRESH');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'OCI_VM_SHAPES_REFRESH',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'STORED_PROCEDURE';
  d_job_action      VARCHAR2(4000) := q'~OCI_FOCUS_REPORTS.OCI_ADB_SCALE_PKG.SCALE_DOWN~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY; BYTIME=190000; BYDAY=MON,TUE,WED,THU,FRI ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-12-31T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Scale ADB down during workdays/offhours~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'SCALE_ADB_DOWN';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'SCALE_ADB_DOWN';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('SCALE_ADB_DOWN', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'SCALE_ADB_DOWN', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'SCALE_ADB_DOWN',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('SCALE_ADB_DOWN', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('SCALE_ADB_DOWN', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SCALE_ADB_DOWN',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'SCALE_ADB_DOWN',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SCALE_ADB_DOWN',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'SCALE_ADB_DOWN',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SCALE_ADB_DOWN',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'SCALE_ADB_DOWN',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SCALE_ADB_DOWN',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'SCALE_ADB_DOWN',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('SCALE_ADB_DOWN');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'SCALE_ADB_DOWN',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'STORED_PROCEDURE';
  d_job_action      VARCHAR2(4000) := q'~OCI_FOCUS_REPORTS.OCI_ADB_SCALE_PKG.SCALE_UP~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY; BYTIME=090000; BYDAY=MON,TUE,WED,THU,FRI ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-12-31T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := q'~Scale ADB's ECPU Up during weekdays/workhours~';
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'SCALE_ADB_UP';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'SCALE_ADB_UP';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('SCALE_ADB_UP', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'SCALE_ADB_UP', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'SCALE_ADB_UP',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      , comments        => d_comments
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('SCALE_ADB_UP', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('SCALE_ADB_UP', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SCALE_ADB_UP',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'SCALE_ADB_UP',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SCALE_ADB_UP',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'SCALE_ADB_UP',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SCALE_ADB_UP',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'SCALE_ADB_UP',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SCALE_ADB_UP',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'SCALE_ADB_UP',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('SCALE_ADB_UP');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'SCALE_ADB_UP',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    ,  comments        => d_comments
    );
  END IF;
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
  l_exists          NUMBER := 0;

  -- Current (target) attributes
  l_job_type        VARCHAR2(30);
  l_job_action      VARCHAR2(4000);
  l_repeat_interval VARCHAR2(4000);
  l_start_date      TIMESTAMP WITH TIME ZONE;
  l_comments        VARCHAR2(4000);

  -- Desired (source) attributes
  d_job_type        VARCHAR2(30)   := 'STORED_PROCEDURE';
  d_job_action      VARCHAR2(4000) := q'~OCI_FOCUS_REPORTS.SYNC_AI_MODEL_CONFIG_FROM_OCI~';
  d_repeat_interval VARCHAR2(4000) := q'~FREQ=DAILY; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~';
  d_start_date      TIMESTAMP WITH TIME ZONE := TO_TIMESTAMP_TZ('2025-09-13T12:30:10.000000000 +00:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM');
  d_comments        VARCHAR2(4000) := NULL;
BEGIN
  -- Detect existence + current enabled state
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB';
    l_exists := 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
      l_exists := 0;
  END;

  -- Enabled/disabled policy
  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  IF l_exists = 1 THEN
    -- Read current attributes
    SELECT job_type, job_action, repeat_interval, start_date, comments
      INTO l_job_type, l_job_action, l_repeat_interval, l_start_date, l_comments
      FROM user_scheduler_jobs
     WHERE job_name = 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB';

    ----------------------------------------------------------------
    -- Policy A: if job_type differs, DROP + CREATE
    ----------------------------------------------------------------
    IF NVL(l_job_type,'#') <> NVL(d_job_type,'#') THEN
      BEGIN
        DBMS_SCHEDULER.DISABLE('SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      BEGIN
        DBMS_SCHEDULER.DROP_JOB(job_name => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB', force => TRUE);
      EXCEPTION WHEN OTHERS THEN NULL; END;

      DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
        job_type        => d_job_type,
        job_action      => d_job_action,
        repeat_interval => d_repeat_interval,
        start_date      => d_start_date,
        enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
        auto_drop       => FALSE
      );

      -- Enforce disabled if policy says disabled
      IF NVL(l_target_enabled, 'FALSE') <> 'TRUE' THEN
        BEGIN DBMS_SCHEDULER.DISABLE('SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB', force => TRUE); EXCEPTION WHEN OTHERS THEN NULL; END;
      END IF;

    ELSE
      --------------------------------------------------------------
      -- Same job_type: DISABLE + SET_ATTRIBUTE where needed
      --------------------------------------------------------------
      DBMS_SCHEDULER.DISABLE('SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB', force => TRUE);

      -- job_action
      IF NVL(l_job_action,'#') <> NVL(d_job_action,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
          attribute => 'job_action',
          value     => d_job_action
        );
      END IF;

      -- repeat_interval
      IF d_repeat_interval IS NULL THEN
        IF l_repeat_interval IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
            attribute => 'repeat_interval'
          );
        END IF;
      ELSIF NVL(l_repeat_interval,'#') <> NVL(d_repeat_interval,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
          attribute => 'repeat_interval',
          value     => d_repeat_interval
        );
      END IF;

      -- start_date
      IF d_start_date IS NULL THEN
        IF l_start_date IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
            attribute => 'start_date'
          );
        END IF;
      ELSIF l_start_date IS NULL OR l_start_date <> d_start_date THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
          attribute => 'start_date',
          value     => d_start_date
        );
      END IF;

      -- comments
      IF d_comments IS NULL THEN
        IF l_comments IS NOT NULL THEN
          DBMS_SCHEDULER.SET_ATTRIBUTE_NULL(
            name      => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
            attribute => 'comments'
          );
        END IF;
      ELSIF NVL(l_comments,'#') <> NVL(d_comments,'#') THEN
        DBMS_SCHEDULER.SET_ATTRIBUTE(
          name      => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
          attribute => 'comments',
          value     => d_comments
        );
      END IF;

      -- auto_drop (you force FALSE everywhere)
      DBMS_SCHEDULER.SET_ATTRIBUTE(
        name      => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
        attribute => 'auto_drop',
        value     => FALSE
      );

      -- Enable/disable per policy
      IF NVL(l_target_enabled, 'FALSE') = 'TRUE' THEN
        DBMS_SCHEDULER.ENABLE('SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB');
      END IF;
    END IF;

  ELSE
    -- Create new job (no REPLACE parameter on this DB version)
    DBMS_SCHEDULER.CREATE_JOB(
      job_name        => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
      job_type        => d_job_type,
      job_action      => d_job_action,
      repeat_interval => d_repeat_interval,
      start_date      => d_start_date,
      enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
      auto_drop       => FALSE
    );
  END IF;
END;
/

