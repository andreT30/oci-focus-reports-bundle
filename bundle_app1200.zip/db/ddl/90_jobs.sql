/* Scheduler jobs exported as CREATE_JOB blocks.
   NOTE: Credentials/secrets are NOT exported. Ensure required credentials exist per environment.
   Enabled/disabled logic:
   - If job exists on target and source is ENABLED: keep target enabled state.
   - If source is DISABLED: force job disabled on target.
   - If job does not exist on target: new job follows source enabled flag.
*/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'FOCUS_REPORTS_PY_ARCHIVE_JOB'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'FOCUS_REPORTS_PY_ARCHIVE_JOB',
    job_type        => 'STORED_PROCEDURE',
    job_action      => q'~OCI_FOCUS_REPORTS.ARCHIVE_FOCUS_REPORTS_PY~',
    repeat_interval => q'~FREQ=MONTHLY;BYMONTHDAY=1;BYHOUR=2;BYMINUTE=0;BYSECOND=0~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-01T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'GENAI_PRICE_CATALOG_REFRESH_JOB'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'GENAI_PRICE_CATALOG_REFRESH_JOB',
    job_type        => 'PLSQL_BLOCK',
    job_action      => q'~begin
  oci_price.refresh_catalog_full;
end;~',
    repeat_interval => q'~FREQ=DAILY; BYTIME=120000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN~',
    start_date      => TO_TIMESTAMP_TZ('2025-09-13T12:10:10.000000000 +00:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_AVAILABILITY_METRICS'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'JOB_AVAILABILITY_METRICS',
    job_type        => 'PLSQL_BLOCK',
    job_action      => q'~
declare
  l_run_id number;
begin
  oci_availability_metrics_pkg.run(l_run_id);
end;
~',
    repeat_interval => q'~FREQ=DAILY;BYHOUR=02;BYMINUTE=15;BYSECOND=0; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-23T04:10:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_EXA_MAINTENANCE'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'JOB_EXA_MAINTENANCE',
    job_type        => 'PLSQL_BLOCK',
    job_action      => q'~DECLARE
  l_run_id NUMBER;
BEGIN
  oci_exa_maintenance_loader_pkg.run(p_run_id => l_run_id);
  DBMS_OUTPUT.put_line('Run ID = ' || l_run_id);
END;
~',
    repeat_interval => q'~FREQ=DAILY; BYTIME=033000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-31T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_FOCUS_REPORTS_12H'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'JOB_FOCUS_REPORTS_12H',
    job_type        => 'STORED_PROCEDURE',
    job_action      => q'~OCI_FOCUS_REPORTS.OCI_FOCUS_REPORTS_LOADER_PKG.RUN~',
    repeat_interval => q'~FREQ=HOURLY; INTERVAL=12; BYTIME=0000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-29T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_COMPARTMENTS'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'JOB_OCI_COMPARTMENTS',
    job_type        => 'STORED_PROCEDURE',
    job_action      => q'~OCI_FOCUS_REPORTS.OCI_FOCUS_REPORTS_COMPARTMENTS_PKG.RUN~',
    repeat_interval => q'~FREQ=DAILY; BYTIME=010000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-29T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_COMPARTMENTS_CHILD'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'JOB_OCI_COMPARTMENTS_CHILD',
    job_type        => 'STORED_PROCEDURE',
    job_action      => q'~OCI_FOCUS_REPORTS.OCI_FOCUS_REPORTS_COMPARTMENTS_PKG.RUN~',
    repeat_interval => q'~FREQ=DAILY; BYTIME=013000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-29T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_RESOURCES'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'JOB_OCI_RESOURCES',
    job_type        => 'STORED_PROCEDURE',
    job_action      => q'~OCI_FOCUS_REPORTS.OCI_RESOURCES_LOADER_PKG.RUN~',
    repeat_interval => q'~FREQ=DAILY; BYTIME=014500; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-29T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'JOB_OCI_SUBSCRIPTIONS'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'JOB_OCI_SUBSCRIPTIONS',
    job_type        => 'PLSQL_BLOCK',
    job_action      => q'~
declare
  l_run_id number;
begin
  oci_subscriptions_pkg.run(l_run_id);
end;
~',
    repeat_interval => q'~FREQ=DAILY;BYHOUR=02;BYMINUTE=0;BYSECOND=0~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-24T14:11:38.243665000 +00:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'MV_RF$J_0_S_82'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'MV_RF$J_0_S_82',
    job_type        => 'PLSQL_BLOCK',
    job_action      => q'~dbms_refresh.refresh('"OCI_FOCUS_REPORTS"."RATECARD_MV"');~',
    repeat_interval => q'~TO_DATE(SYSDATE + 1)   ~',
    start_date      => TO_TIMESTAMP_TZ('2025-07-02T12:09:01.000000000 +03:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE_JOB',
    job_type        => 'STORED_PROCEDURE',
    job_action      => q'~OCI_FOCUS_REPORTS.ARCHIVE_AVAILABILITY_METRICS_PY~',
    repeat_interval => q'~FREQ=MONTHLY;BYMONTHDAY=1;BYHOUR=3;BYMINUTE=0;BYSECOND=0~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-01T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'OCI_VM_SHAPES_REFRESH'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'OCI_VM_SHAPES_REFRESH',
    job_type        => 'PLSQL_BLOCK',
    job_action      => q'~BEGIN
  oci_price.refresh_shapes_catalog;
END;~',
    repeat_interval => q'~FREQ=DAILY; BYTIME=130000; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~',
    start_date      => TO_TIMESTAMP_TZ('2026-01-07T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'SCALE_ADB_DOWN'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'SCALE_ADB_DOWN',
    job_type        => 'STORED_PROCEDURE',
    job_action      => q'~OCI_FOCUS_REPORTS.OCI_ADB_SCALE_PKG.SCALE_DOWN~',
    repeat_interval => q'~FREQ=DAILY; BYTIME=190000; BYDAY=MON,TUE,WED,THU,FRI ~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-31T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'SCALE_ADB_UP'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'SCALE_ADB_UP',
    job_type        => 'STORED_PROCEDURE',
    job_action      => q'~OCI_FOCUS_REPORTS.OCI_ADB_SCALE_PKG.SCALE_UP~',
    repeat_interval => q'~FREQ=DAILY; BYTIME=090000; BYDAY=MON,TUE,WED,THU,FRI ~',
    start_date      => TO_TIMESTAMP_TZ('2025-12-31T02:00:00.000000000 +02:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

DECLARE
  l_target_enabled  VARCHAR2(5);
BEGIN
  BEGIN
    SELECT enabled
      INTO l_target_enabled
      FROM user_scheduler_jobs
     WHERE job_name = 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB'
       AND owner     = SYS_CONTEXT('USERENV','CURRENT_SCHEMA');
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      l_target_enabled := NULL;
  END;

  IF l_target_enabled IS NULL THEN
    -- Job does not exist on target: follow source enabled flag
    l_target_enabled := 'TRUE';
  ELSIF 'TRUE' = 'FALSE' THEN
    -- Job disabled on source: force disabled on target
    l_target_enabled := 'FALSE';
  END IF;

  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'SYNC_AI_MODEL_CONFIG_FROM_OCI_JOB',
    job_type        => 'STORED_PROCEDURE',
    job_action      => q'~OCI_FOCUS_REPORTS.SYNC_AI_MODEL_CONFIG_FROM_OCI~',
    repeat_interval => q'~FREQ=DAILY; BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN ~',
    start_date      => TO_TIMESTAMP_TZ('2025-09-13T12:30:10.000000000 +00:00','YYYY-MM-DD"T"HH24:MI:SS.FF TZH:TZM'),
    enabled         => (NVL(l_target_enabled, 'FALSE') = 'TRUE'),
    auto_drop       => FALSE,
    replace         => TRUE
  );
END;
/

